"""M15 Adapter Certification Lab.

M15 adds review/analysis tooling *above* the M13/M14 certification boundary.
It never invents controller semantics, never creates owner approval and never
opens direct machine transfer.  Its persisted records are append-only review
evidence for compatibility, bulk regression, impact analysis and candidate
packages that can later be consumed by the existing external M13 gate.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import difflib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile
from typing import Any, Iterable, Mapping, Sequence

from cws_convertor.product import APP_VERSION, PROJECT_SCHEMA_VERSION
from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from cws_convertor.production_export.utils import canonical_json_bytes, sha256_file
from .adapter_certification import build_expected_actual_diff, validate_persisted_adapter_certificate
from .adapter_sdk import AdapterSDKManifest, validate_persisted_adapter_sdk_manifest
from .certification_ops import certificate_lifecycle_status, run_golden_batch, validate_persisted_certification_batch

M15_LAB_CONTRACT_VERSION = "1.0"
M15_COMPATIBILITY_MATRIX_FORMAT = "CWS_M15_ADAPTER_COMPATIBILITY_MATRIX_V1"
M15_CAMPAIGN_FORMAT = "CWS_M15_CERTIFICATION_CAMPAIGN_V1"
M15_IMPACT_FORMAT = "CWS_M15_CERTIFICATION_IMPACT_ANALYSIS_V1"
M15_ARTIFACT_DIFF_FORMAT = "CWS_M15_ARTIFACT_REVIEW_DIFF_V1"
M15_CANDIDATE_PACKAGE_FORMAT = "CWS_M15_CERTIFICATION_CANDIDATE_PACKAGE_V1"
M15_HASH_VERSION = "cws-m15-certification-lab-v1"
_M15_ZIP_DATE = (1980, 1, 1, 0, 0, 0)


class CertificationLabError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def _hash_record(value: Mapping[str, Any], field: str) -> str:
    return stable_sha256({k: v for k, v in value.items() if k != field})


def _safe_relative(value: Any) -> str:
    raw = str(value or "").replace("\\", "/").strip()
    p = PurePosixPath(raw)
    if not raw or p.is_absolute() or ".." in p.parts or any(part in {"", "."} for part in p.parts):
        raise CertificationLabError("CWS-LAB-001", f"Onveilig artifactpad: {raw!r}")
    return p.as_posix()


def _capability_rows(project: ProjectModel, machine_id: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for capability_id, raw in sorted(project.manufacturing_machine_capabilities.items()):
        if not isinstance(raw, Mapping) or str(raw.get("machine_id") or "") != machine_id:
            continue
        rows.append({
            "capability_id": str(capability_id),
            "capability_hash": str(raw.get("capability_hash") or ""),
            "validation_status": str(raw.get("validation_status") or ""),
        })
    return rows


def build_compatibility_matrix(
    project: ProjectModel,
    *,
    adapter_ids: Iterable[str] | None = None,
    expiring_within_days: int = 30,
    user: str = "system",
    persist: bool = True,
) -> dict[str, Any]:
    """Build an audit matrix over SDK manifests, capabilities and certificates.

    A matrix row is descriptive/review evidence only.  Even a fully compatible
    row does not release output or transfer.
    """
    wanted = {str(x) for x in adapter_ids or () if str(x)}
    manifests = []
    for manifest_id, raw in sorted(project.manufacturing_adapter_sdk_manifests.items()):
        if not isinstance(raw, Mapping):
            continue
        if wanted and str(raw.get("adapter_id") or "") not in wanted:
            continue
        manifests.append(validate_persisted_adapter_sdk_manifest(project, str(manifest_id)))
    if wanted and {str(x.get("adapter_id") or "") for x in manifests} != wanted:
        missing = sorted(wanted - {str(x.get("adapter_id") or "") for x in manifests})
        raise CertificationLabError("CWS-LAB-002", f"SDK manifest ontbreekt voor adapter(s): {missing}")
    if not manifests:
        raise CertificationLabError("CWS-LAB-002", "M15 compatibility matrix vereist minimaal één M14 SDK-manifest")

    rows: list[dict[str, Any]] = []
    for manifest in manifests:
        adapter_id = str(manifest.get("adapter_id") or "")
        machine_id = str(manifest.get("machine_id") or "")
        capability_rows = _capability_rows(project, machine_id)
        cert_rows: list[dict[str, Any]] = []
        for certificate_id, cert in sorted(project.manufacturing_adapter_certificates.items()):
            if not isinstance(cert, Mapping) or str(cert.get("adapter_id") or "") != adapter_id:
                continue
            lifecycle = certificate_lifecycle_status(project, str(certificate_id), expiring_within_days=expiring_within_days)
            cert_rows.append({
                "certificate_id": str(certificate_id),
                "status": lifecycle.get("status", ""),
                "current_for_output": bool(lifecycle.get("current_for_output")),
                "capability_id": str(cert.get("capability_id") or ""),
                "capability_hash": str(cert.get("capability_hash") or ""),
                "adapter_version": str(cert.get("adapter_version") or ""),
                "adapter_artifact_sha256": str(cert.get("adapter_artifact_sha256") or ""),
            })
        batch_rows = [
            validate_persisted_certification_batch(project, str(batch_id))
            for batch_id, batch in sorted(project.manufacturing_adapter_certification_batches.items())
            if isinstance(batch, Mapping) and str(batch.get("adapter_id") or "") == adapter_id
        ]
        current_cert_count = sum(1 for row in cert_rows if row["current_for_output"])
        current_capability_hashes = {x["capability_hash"] for x in capability_rows if x["capability_hash"]}
        certificate_capability_hashes = {x["capability_hash"] for x in cert_rows if x["current_for_output"] and x["capability_hash"]}
        capability_compatible = bool(current_capability_hashes & certificate_capability_hashes) if cert_rows else bool(capability_rows)
        row = {
            "adapter_id": adapter_id,
            "manifest_id": str(manifest.get("manifest_id") or ""),
            "manifest_hash": str(manifest.get("manifest_hash") or ""),
            "adapter_descriptor_hash": str(manifest.get("adapter_descriptor_hash") or ""),
            "machine_id": machine_id,
            "controller_id": str(manifest.get("controller_id") or ""),
            "adapter_version": str(manifest.get("adapter_version") or ""),
            "adapter_source_commit": str(manifest.get("adapter_source_commit") or ""),
            "adapter_artifact_sha256": str(manifest.get("adapter_artifact_sha256") or ""),
            "capabilities": capability_rows,
            "certificates": cert_rows,
            "golden_batch_count": len(batch_rows),
            "exact_golden_batch_count": sum(1 for b in batch_rows if bool(b.get("all_exact"))),
            "current_certificate_count": current_cert_count,
            "capability_compatible_with_current_certificate": capability_compatible,
            "review_status": "review_ready" if capability_rows and batch_rows else "incomplete",
            "owner_approved": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
        }
        row["row_hash"] = stable_sha256({k: v for k, v in row.items() if k != "row_hash"})
        rows.append(row)
    matrix = {
        "format": M15_COMPATIBILITY_MATRIX_FORMAT,
        "schema_version": M15_LAB_CONTRACT_VERSION,
        "phase": "M15",
        "created_for_cws_version": APP_VERSION,
        "created_for_project_schema": PROJECT_SCHEMA_VERSION,
        "row_count": len(rows),
        "rows": rows,
        "review_ready_count": sum(1 for x in rows if x["review_status"] == "review_ready"),
        "owner_approved": False,
        "certification_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M15_HASH_VERSION,
    }
    matrix_id = "cmatrix-" + stable_sha256({"rows": [x["row_hash"] for x in rows]})[:28]
    matrix["matrix_id"] = matrix_id
    matrix["matrix_hash"] = _hash_record(matrix, "matrix_hash")
    if persist:
        existing = project.manufacturing_adapter_lab_matrices.get(matrix_id)
        if isinstance(existing, Mapping) and str(existing.get("matrix_hash") or "") != matrix["matrix_hash"]:
            raise ProjectValidationError(f"M15 compatibility matrix-ID collision voor {matrix_id}")
        project.manufacturing_adapter_lab_matrices[matrix_id] = matrix
        project.audit("manufacturing.adapter_lab_matrix", user=user, entity_id=matrix_id, after_hash=matrix["matrix_hash"], details={"row_count": len(rows), "direct_machine_transfer": False})
    return matrix


def validate_persisted_compatibility_matrix(project: ProjectModel, matrix_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_lab_matrices.get(matrix_id)
    if not isinstance(raw, Mapping):
        raise ProjectValidationError(f"Onbekende M15 compatibility matrix {matrix_id}")
    if raw.get("format") != M15_COMPATIBILITY_MATRIX_FORMAT or str(raw.get("schema_version") or "") != M15_LAB_CONTRACT_VERSION:
        raise ProjectValidationError("M15 compatibility matrix format/schema ongeldig")
    if str(raw.get("matrix_id") or "") != matrix_id or str(raw.get("phase") or "") != "M15":
        raise ProjectValidationError("M15 compatibility matrix identity ongeldig")
    if str(raw.get("matrix_hash") or "") != _hash_record(raw, "matrix_hash"):
        raise ProjectValidationError("M15 compatibility matrix hash ongeldig")
    if any(bool(raw.get(k)) for k in ("owner_approved", "certification_eligible", "machine_output_released", "direct_machine_transfer")):
        raise ProjectValidationError("M15 compatibility matrix mag geen release/certification approval zetten")
    rows = list(raw.get("rows") or [])
    if int(raw.get("row_count") or -1) != len(rows) or not rows:
        raise ProjectValidationError("M15 compatibility matrix row_count ongeldig")
    for row in rows:
        if not isinstance(row, Mapping) or str(row.get("row_hash") or "") != stable_sha256({k: v for k, v in row.items() if k != "row_hash"}):
            raise ProjectValidationError("M15 compatibility matrix row hash ongeldig")
    return dict(raw)


def build_certification_lab_dashboard(project: ProjectModel) -> dict[str, Any]:
    matrices = [validate_persisted_compatibility_matrix(project, str(x)) for x in sorted(project.manufacturing_adapter_lab_matrices)]
    campaigns = [validate_persisted_certification_campaign(project, str(x)) for x in sorted(project.manufacturing_adapter_lab_campaigns)]
    impacts = [validate_persisted_certification_impact(project, str(x)) for x in sorted(project.manufacturing_adapter_lab_impacts)]
    diffs = [validate_persisted_artifact_review_diff(project, str(x)) for x in sorted(project.manufacturing_adapter_lab_diffs)]
    candidates = [validate_persisted_candidate_record(project, str(x)) for x in sorted(project.manufacturing_adapter_lab_candidates)]
    report = {
        "format": "CWS_M15_CERTIFICATION_LAB_DASHBOARD_V1",
        "schema_version": M15_LAB_CONTRACT_VERSION,
        "matrix_count": len(matrices),
        "campaign_count": len(campaigns),
        "impact_count": len(impacts),
        "artifact_diff_count": len(diffs),
        "candidate_count": len(candidates),
        "review_ready_adapter_rows": sum(int(x.get("review_ready_count") or 0) for x in matrices),
        "campaign_all_exact_count": sum(1 for x in campaigns if bool(x.get("all_exact"))),
        "recertification_review_count": sum(1 for x in impacts if bool(x.get("requires_recertification_review"))),
        "artifact_diff_all_exact_count": sum(1 for x in diffs if bool(x.get("all_exact"))),
        "owner_approved": False,
        "certification_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
    }
    report["dashboard_hash"] = stable_sha256({k: v for k, v in report.items() if k != "dashboard_hash"})
    return report


def run_certification_campaign(
    project: ProjectModel,
    campaign_cases: Iterable[Mapping[str, Any]],
    *,
    user: str = "system",
    persist: bool = True,
) -> dict[str, Any]:
    """Run multiple adapter golden batches as one non-production campaign."""
    groups: dict[str, list[Mapping[str, Any]]] = {}
    for item in campaign_cases:
        adapter_id = str(item.get("adapter_id") or "").strip()
        case = item.get("case")
        if not adapter_id or not isinstance(case, Mapping):
            raise CertificationLabError("CWS-LAB-003", "Campaign case vereist adapter_id + case object")
        groups.setdefault(adapter_id, []).append(dict(case))
    if not groups:
        raise CertificationLabError("CWS-LAB-003", "M15 campaign vereist minimaal één case")
    batch_rows: list[dict[str, Any]] = []
    for adapter_id, cases in sorted(groups.items()):
        batch = run_golden_batch(project, adapter_id, cases, user=user, persist=False)
        batch_rows.append({
            "adapter_id": adapter_id,
            "source_batch_hash": str(batch.get("batch_hash") or ""),
            "case_count": int(batch.get("case_count") or 0),
            "exact_count": int(batch.get("exact_count") or 0),
            "all_exact": bool(batch.get("all_exact")),
            "cases": list(batch.get("cases") or []),
        })
    campaign = {
        "format": M15_CAMPAIGN_FORMAT,
        "schema_version": M15_LAB_CONTRACT_VERSION,
        "phase": "M15",
        "adapter_count": len(batch_rows),
        "case_count": sum(x["case_count"] for x in batch_rows),
        "exact_count": sum(x["exact_count"] for x in batch_rows),
        "all_exact": all(x["all_exact"] for x in batch_rows),
        "adapter_batches": batch_rows,
        "owner_attested": False,
        "certification_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M15_HASH_VERSION,
    }
    campaign_id = "ccampaign-" + stable_sha256({"batches": [{"adapter_id": x["adapter_id"], "source_batch_hash": x["source_batch_hash"]} for x in batch_rows]})[:28]
    campaign["campaign_id"] = campaign_id
    campaign["campaign_hash"] = _hash_record(campaign, "campaign_hash")
    if persist:
        existing = project.manufacturing_adapter_lab_campaigns.get(campaign_id)
        if isinstance(existing, Mapping) and str(existing.get("campaign_hash") or "") != campaign["campaign_hash"]:
            raise ProjectValidationError(f"M15 campaign-ID collision voor {campaign_id}")
        project.manufacturing_adapter_lab_campaigns[campaign_id] = campaign
        project.audit("manufacturing.adapter_lab_campaign", user=user, entity_id=campaign_id, after_hash=campaign["campaign_hash"], details={"case_count": campaign["case_count"], "all_exact": campaign["all_exact"], "direct_machine_transfer": False})
    return campaign


def validate_persisted_certification_campaign(project: ProjectModel, campaign_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_lab_campaigns.get(campaign_id)
    if not isinstance(raw, Mapping):
        raise ProjectValidationError(f"Onbekende M15 certification campaign {campaign_id}")
    if raw.get("format") != M15_CAMPAIGN_FORMAT or str(raw.get("schema_version") or "") != M15_LAB_CONTRACT_VERSION or str(raw.get("campaign_id") or "") != campaign_id:
        raise ProjectValidationError("M15 campaign format/schema/identity ongeldig")
    if str(raw.get("campaign_hash") or "") != _hash_record(raw, "campaign_hash"):
        raise ProjectValidationError("M15 campaign hash ongeldig")
    if any(bool(raw.get(k)) for k in ("owner_attested", "certification_eligible", "machine_output_released", "direct_machine_transfer")):
        raise ProjectValidationError("M15 campaign mag geen owner/release status zetten")
    rows = list(raw.get("adapter_batches") or [])
    if int(raw.get("adapter_count") or -1) != len(rows) or not rows:
        raise ProjectValidationError("M15 campaign adapter_count ongeldig")
    if int(raw.get("case_count") or -1) != sum(int(x.get("case_count") or 0) for x in rows if isinstance(x, Mapping)):
        raise ProjectValidationError("M15 campaign case_count mismatch")
    return dict(raw)


def analyze_certification_impact(
    project: ProjectModel,
    *,
    changed_kind: str,
    changed_id: str,
    before_hash: str = "",
    after_hash: str = "",
    user: str = "system",
    persist: bool = True,
) -> dict[str, Any]:
    """Analyze which SDK/certificate/batch records are affected by a change."""
    changed_kind = str(changed_kind or "").strip().lower()
    changed_id = str(changed_id or "").strip()
    supported = {"adapter", "sdk_manifest", "capability", "machine", "controller", "software", "project_schema"}
    if changed_kind not in supported or not changed_id:
        raise CertificationLabError("CWS-LAB-004", f"Impact change vereist kind in {sorted(supported)} en changed_id")
    impacted: list[dict[str, Any]] = []
    for certificate_id, cert in sorted(project.manufacturing_adapter_certificates.items()):
        if not isinstance(cert, Mapping):
            continue
        reasons: list[str] = []
        if changed_kind == "adapter" and str(cert.get("adapter_id") or "") == changed_id: reasons.append("adapter_id_changed")
        if changed_kind == "capability" and str(cert.get("capability_id") or "") == changed_id: reasons.append("capability_changed")
        if changed_kind == "machine" and str(cert.get("machine_id") or "") == changed_id: reasons.append("machine_changed")
        if changed_kind == "controller" and str(cert.get("controller_id") or "") == changed_id: reasons.append("controller_changed")
        if changed_kind == "software" and str(cert.get("cws_version") or "") != changed_id: reasons.append("software_version_changed")
        if changed_kind == "project_schema" and str(cert.get("project_schema_version") or "") != changed_id: reasons.append("project_schema_changed")
        if changed_kind == "sdk_manifest":
            for manifest in project.manufacturing_adapter_sdk_manifests.values():
                if isinstance(manifest, Mapping) and str(manifest.get("manifest_id") or "") == changed_id and str(manifest.get("adapter_id") or "") == str(cert.get("adapter_id") or ""):
                    reasons.append("sdk_manifest_changed")
        if reasons:
            try:
                lifecycle = certificate_lifecycle_status(project, str(certificate_id))
                current_status = str(lifecycle.get("status") or "")
            except Exception as exc:
                current_status = f"invalid:{type(exc).__name__}"
            impacted.append({
                "object_type": "certificate",
                "object_id": str(certificate_id),
                "object_hash": str(cert.get("certificate_hash") or ""),
                "adapter_id": str(cert.get("adapter_id") or ""),
                "current_status": current_status,
                "impact": "recertification_review_required",
                "reasons": sorted(set(reasons)),
            })
    for manifest_id, manifest in sorted(project.manufacturing_adapter_sdk_manifests.items()):
        if not isinstance(manifest, Mapping): continue
        reasons = []
        if changed_kind == "adapter" and str(manifest.get("adapter_id") or "") == changed_id: reasons.append("adapter_id_changed")
        if changed_kind == "machine" and str(manifest.get("machine_id") or "") == changed_id: reasons.append("machine_changed")
        if changed_kind == "controller" and str(manifest.get("controller_id") or "") == changed_id: reasons.append("controller_changed")
        if changed_kind == "sdk_manifest" and str(manifest_id) == changed_id: reasons.append("sdk_manifest_changed")
        if reasons:
            impacted.append({
                "object_type": "sdk_manifest",
                "object_id": str(manifest_id),
                "object_hash": str(manifest.get("manifest_hash") or ""),
                "adapter_id": str(manifest.get("adapter_id") or ""),
                "current_status": str(manifest.get("status") or "registered"),
                "impact": "sdk_retest_required",
                "reasons": sorted(set(reasons)),
            })
    report = {
        "format": M15_IMPACT_FORMAT,
        "schema_version": M15_LAB_CONTRACT_VERSION,
        "phase": "M15",
        "changed_kind": changed_kind,
        "changed_id": changed_id,
        "before_hash": str(before_hash or ""),
        "after_hash": str(after_hash or ""),
        "impacted_count": len(impacted),
        "impacted": impacted,
        "requires_recertification_review": any(x["object_type"] == "certificate" for x in impacted),
        "owner_approved": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M15_HASH_VERSION,
    }
    impact_id = "cimpact-" + stable_sha256({"changed_kind": changed_kind, "changed_id": changed_id, "before_hash": before_hash, "after_hash": after_hash, "objects": [(x["object_type"], x["object_id"], x["object_hash"]) for x in impacted]})[:28]
    report["impact_id"] = impact_id
    report["impact_hash"] = _hash_record(report, "impact_hash")
    if persist:
        existing = project.manufacturing_adapter_lab_impacts.get(impact_id)
        if isinstance(existing, Mapping) and str(existing.get("impact_hash") or "") != report["impact_hash"]:
            raise ProjectValidationError(f"M15 impact-ID collision voor {impact_id}")
        project.manufacturing_adapter_lab_impacts[impact_id] = report
        project.audit("manufacturing.adapter_lab_impact", user=user, entity_id=impact_id, after_hash=report["impact_hash"], details={"changed_kind": changed_kind, "impacted_count": len(impacted), "direct_machine_transfer": False})
    return report


def validate_persisted_certification_impact(project: ProjectModel, impact_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_lab_impacts.get(impact_id)
    if not isinstance(raw, Mapping): raise ProjectValidationError(f"Onbekende M15 impact analyse {impact_id}")
    if raw.get("format") != M15_IMPACT_FORMAT or str(raw.get("schema_version") or "") != M15_LAB_CONTRACT_VERSION or str(raw.get("impact_id") or "") != impact_id:
        raise ProjectValidationError("M15 impact format/schema/identity ongeldig")
    if str(raw.get("impact_hash") or "") != _hash_record(raw, "impact_hash"):
        raise ProjectValidationError("M15 impact hash ongeldig")
    if bool(raw.get("owner_approved")) or bool(raw.get("machine_output_released")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M15 impactanalyse mag geen release zetten")
    return dict(raw)


def _decode_utf8(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return None


def _raster_metrics(expected: Path, actual: Path) -> dict[str, Any] | None:
    if expected.suffix.lower() not in {".png", ".jpg", ".jpeg", ".bmp", ".webp"}:
        return None
    try:
        from PIL import Image, ImageChops
        with Image.open(expected) as a, Image.open(actual) as b:
            ar = a.convert("RGBA"); br = b.convert("RGBA")
            if ar.size != br.size:
                return {"mode": "raster", "same_dimensions": False, "expected_size": list(ar.size), "actual_size": list(br.size), "pixel_equal": False}
            diff = ImageChops.difference(ar, br)
            bbox = diff.getbbox()
            if bbox is None:
                changed = 0
            else:
                changed = sum(1 for px in diff.getdata() if px != (0, 0, 0, 0))
            total = ar.size[0] * ar.size[1]
            return {"mode": "raster", "same_dimensions": True, "expected_size": list(ar.size), "actual_size": list(br.size), "changed_pixels": changed, "total_pixels": total, "pixel_change_ratio": (changed / total if total else 0.0), "pixel_equal": changed == 0}
    except Exception:
        return None


def build_artifact_review_diff(expected_root: str | Path, actual_root: str | Path, relative_paths: Iterable[str]) -> dict[str, Any]:
    expected_root = Path(expected_root).resolve(); actual_root = Path(actual_root).resolve()
    if not expected_root.is_dir() or not actual_root.is_dir():
        raise CertificationLabError("CWS-LAB-005", "Artifact review diff vereist bestaande expected/actual directories")
    rows: list[dict[str, Any]] = []
    for raw in sorted(set(str(x) for x in relative_paths)):
        rel = _safe_relative(raw)
        ep = expected_root.joinpath(*PurePosixPath(rel).parts); ap = actual_root.joinpath(*PurePosixPath(rel).parts)
        row: dict[str, Any] = {"relative_path": rel, "expected_exists": ep.is_file(), "actual_exists": ap.is_file()}
        if not ep.is_file() or not ap.is_file():
            row.update({"status": "missing", "exact": False, "review_mode": "presence"}); rows.append(row); continue
        row["expected_sha256"] = sha256_file(ep); row["actual_sha256"] = sha256_file(ap)
        row["expected_size"] = ep.stat().st_size; row["actual_size"] = ap.stat().st_size
        row["exact"] = row["expected_sha256"] == row["actual_sha256"] and row["expected_size"] == row["actual_size"]
        row["status"] = "exact" if row["exact"] else "different"
        raster = _raster_metrics(ep, ap)
        if raster is not None:
            row["review_mode"] = "raster"; row["review"] = raster
        else:
            et = _decode_utf8(ep); at = _decode_utf8(ap)
            if et is not None and at is not None:
                row["review_mode"] = "text"
                diff_lines = list(difflib.unified_diff(et.splitlines(), at.splitlines(), fromfile=f"expected/{rel}", tofile=f"actual/{rel}", lineterm=""))
                row["review"] = {"line_diff": diff_lines[:240], "truncated": len(diff_lines) > 240, "expected_line_count": len(et.splitlines()), "actual_line_count": len(at.splitlines())}
                if ep.suffix.lower() == ".json":
                    try:
                        ej = json.loads(et); aj = json.loads(at)
                        row["review"]["json_semantic_equal"] = stable_sha256(ej) == stable_sha256(aj)
                    except Exception:
                        pass
            else:
                row["review_mode"] = "binary"
                row["review"] = {"first_expected_hex": ep.read_bytes()[:32].hex(), "first_actual_hex": ap.read_bytes()[:32].hex()}
        row["row_hash"] = stable_sha256({k: v for k, v in row.items() if k != "row_hash"})
        rows.append(row)
    report = {
        "format": M15_ARTIFACT_DIFF_FORMAT,
        "schema_version": M15_LAB_CONTRACT_VERSION,
        "artifact_count": len(rows),
        "exact_count": sum(1 for x in rows if x.get("exact")),
        "all_exact": all(bool(x.get("exact")) for x in rows) if rows else False,
        "artifacts": rows,
        "certification_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M15_HASH_VERSION,
    }
    report["report_hash"] = _hash_record(report, "report_hash")
    return report


def persist_artifact_review_diff(project: ProjectModel, report: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(report or {})
    if raw.get("format") != M15_ARTIFACT_DIFF_FORMAT or str(raw.get("report_hash") or "") != _hash_record(raw, "report_hash"):
        raise CertificationLabError("CWS-LAB-005", "Ongeldig M15 artifact review diff")
    if bool(raw.get("certification_eligible")) or bool(raw.get("machine_output_released")) or bool(raw.get("direct_machine_transfer")):
        raise CertificationLabError("CWS-LAB-005", "Artifact diff mag geen releaseflags zetten")
    diff_id = "cdiff-" + str(raw["report_hash"])[:28]
    state = {**raw, "diff_id": diff_id, "phase": "M15"}
    state["state_hash"] = stable_sha256({k: v for k, v in state.items() if k != "state_hash"})
    existing = project.manufacturing_adapter_lab_diffs.get(diff_id)
    if isinstance(existing, Mapping) and str(existing.get("state_hash") or "") != state["state_hash"]:
        raise ProjectValidationError(f"M15 artifact diff-ID collision voor {diff_id}")
    project.manufacturing_adapter_lab_diffs[diff_id] = state
    project.audit("manufacturing.adapter_lab_diff", user=user, entity_id=diff_id, after_hash=state["state_hash"], details={"artifact_count": state.get("artifact_count", 0), "all_exact": state.get("all_exact", False), "direct_machine_transfer": False})
    return state


def validate_persisted_artifact_review_diff(project: ProjectModel, diff_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_lab_diffs.get(diff_id)
    if not isinstance(raw, Mapping): raise ProjectValidationError(f"Onbekende M15 artifact diff {diff_id}")
    if raw.get("format") != M15_ARTIFACT_DIFF_FORMAT or str(raw.get("diff_id") or "") != diff_id or str(raw.get("phase") or "") != "M15":
        raise ProjectValidationError("M15 artifact diff identity ongeldig")
    report = {k: v for k, v in raw.items() if k not in {"diff_id", "phase", "state_hash"}}
    if str(report.get("report_hash") or "") != _hash_record(report, "report_hash"):
        raise ProjectValidationError("M15 artifact diff report_hash ongeldig")
    if str(raw.get("state_hash") or "") != stable_sha256({k: v for k, v in raw.items() if k != "state_hash"}):
        raise ProjectValidationError("M15 artifact diff state_hash ongeldig")
    if bool(raw.get("certification_eligible")) or bool(raw.get("machine_output_released")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M15 artifact diff mag geen releaseflags zetten")
    return dict(raw)


def _deterministic_zip(files: Mapping[str, bytes]) -> bytes:
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel, data in sorted(files.items()):
            safe = _safe_relative(rel)
            info = zipfile.ZipInfo(safe, date_time=_M15_ZIP_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zf.writestr(info, bytes(data))
    return stream.getvalue()


def build_certification_candidate_package(
    project: ProjectModel,
    *,
    campaign_id: str,
    matrix_id: str,
    impact_ids: Iterable[str] = (),
    review_diffs: Iterable[Mapping[str, Any]] = (),
    output_path: str | Path,
    created_by: str = "system",
    persist: bool = True,
) -> dict[str, Any]:
    campaign = validate_persisted_certification_campaign(project, campaign_id)
    matrix = validate_persisted_compatibility_matrix(project, matrix_id)
    impacts = [validate_persisted_certification_impact(project, str(x)) for x in impact_ids]
    diffs = []
    for value in review_diffs:
        raw = dict(value)
        d = {k: v for k, v in raw.items() if k not in {"diff_id", "phase", "state_hash"}}
        if d.get("format") != M15_ARTIFACT_DIFF_FORMAT or str(d.get("report_hash") or "") != _hash_record(d, "report_hash"):
            raise CertificationLabError("CWS-LAB-006", "Candidate package bevat ongeldig review-diff report")
        diffs.append(d)
    manifest = {
        "format": M15_CANDIDATE_PACKAGE_FORMAT,
        "schema_version": M15_LAB_CONTRACT_VERSION,
        "phase": "M15",
        "cws_version": APP_VERSION,
        "project_schema_version": PROJECT_SCHEMA_VERSION,
        "campaign_id": campaign_id,
        "campaign_hash": campaign["campaign_hash"],
        "matrix_id": matrix_id,
        "matrix_hash": matrix["matrix_hash"],
        "impact_bindings": [{"impact_id": x["impact_id"], "impact_hash": x["impact_hash"]} for x in impacts],
        "review_diff_hashes": [str(x.get("report_hash") or "") for x in diffs],
        "created_by": str(created_by or "system"),
        "review_only": True,
        "owner_attested": False,
        "certification_eligible": False,
        "offline_controller_output_released": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M15_HASH_VERSION,
    }
    manifest["candidate_id"] = "ccandidate-" + stable_sha256({"campaign_hash": campaign["campaign_hash"], "matrix_hash": matrix["matrix_hash"], "impacts": manifest["impact_bindings"], "diffs": manifest["review_diff_hashes"]})[:28]
    manifest["manifest_hash"] = _hash_record(manifest, "manifest_hash")
    files: dict[str, bytes] = {
        "manifest.json": canonical_json_bytes(manifest),
        "campaign.json": canonical_json_bytes(campaign),
        "compatibility_matrix.json": canonical_json_bytes(matrix),
    }
    for i, impact in enumerate(impacts, 1): files[f"impacts/{i:03d}_{impact['impact_id']}.json"] = canonical_json_bytes(impact)
    for i, diff in enumerate(diffs, 1): files[f"review_diffs/{i:03d}.json"] = canonical_json_bytes(diff)
    # Include conventional SHA-256 for external verification.
    import hashlib
    sha_rows = []
    for name, data in sorted(files.items()): sha_rows.append(f"{hashlib.sha256(data).hexdigest()}  {name}")
    files["SHA256SUMS.txt"] = ("\n".join(sha_rows) + "\n").encode("utf-8")
    data = _deterministic_zip(files)
    target = Path(output_path); target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
    result = {
        "candidate_id": manifest["candidate_id"],
        "manifest_hash": manifest["manifest_hash"],
        "campaign_id": campaign_id,
        "campaign_hash": campaign["campaign_hash"],
        "matrix_id": matrix_id,
        "matrix_hash": matrix["matrix_hash"],
        "impact_ids": [x["impact_id"] for x in impacts],
        "review_diff_hashes": [str(x.get("report_hash") or "") for x in diffs],
        "output_name": f"M15_{manifest['candidate_id']}.zip",
        "output_sha256": sha256_file(target),
        "file_count": len(files),
        "review_only": True,
        "owner_attested": False,
        "certification_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M15_HASH_VERSION,
    }
    result["state_hash"] = stable_sha256({k: v for k, v in result.items() if k != "state_hash"})
    if persist:
        existing = project.manufacturing_adapter_lab_candidates.get(result["candidate_id"])
        if isinstance(existing, Mapping) and str(existing.get("state_hash") or "") != result["state_hash"]:
            raise ProjectValidationError(f"M15 candidate-ID collision voor {result['candidate_id']}")
        project.manufacturing_adapter_lab_candidates[result["candidate_id"]] = result
        project.audit("manufacturing.adapter_lab_candidate", user=created_by, entity_id=result["candidate_id"], after_hash=result["state_hash"], details={"output_name": result["output_name"], "review_only": True, "direct_machine_transfer": False})
    return {**result, "output_path": str(target)}


def validate_persisted_candidate_record(project: ProjectModel, candidate_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_lab_candidates.get(candidate_id)
    if not isinstance(raw, Mapping): raise ProjectValidationError(f"Onbekende M15 candidate record {candidate_id}")
    if str(raw.get("candidate_id") or "") != candidate_id or str(raw.get("hash_version") or "") != M15_HASH_VERSION:
        raise ProjectValidationError("M15 candidate identity/hash-version ongeldig")
    if str(raw.get("state_hash") or "") != stable_sha256({k: v for k, v in raw.items() if k != "state_hash"}):
        raise ProjectValidationError("M15 candidate state_hash ongeldig")
    if not bool(raw.get("review_only")) or any(bool(raw.get(k)) for k in ("owner_attested", "certification_eligible", "machine_output_released", "direct_machine_transfer")):
        raise ProjectValidationError("M15 candidate record bevat onveilige releaseflags")
    if validate_persisted_certification_campaign(project, str(raw.get("campaign_id") or ""))["campaign_hash"] != str(raw.get("campaign_hash") or ""):
        raise ProjectValidationError("M15 candidate campaign binding mismatch")
    if validate_persisted_compatibility_matrix(project, str(raw.get("matrix_id") or ""))["matrix_hash"] != str(raw.get("matrix_hash") or ""):
        raise ProjectValidationError("M15 candidate matrix binding mismatch")
    return dict(raw)


def validate_certification_candidate_package(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    if not path.is_file(): raise CertificationLabError("CWS-LAB-007", "Candidate package ontbreekt")
    with zipfile.ZipFile(path, "r") as zf:
        names = zf.namelist()
        for name in names: _safe_relative(name)
        if "manifest.json" not in names or "SHA256SUMS.txt" not in names:
            raise CertificationLabError("CWS-LAB-007", "Candidate package mist manifest/checksums")
        manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
        if manifest.get("format") != M15_CANDIDATE_PACKAGE_FORMAT or str(manifest.get("schema_version") or "") != M15_LAB_CONTRACT_VERSION:
            raise CertificationLabError("CWS-LAB-007", "Candidate package format/schema ongeldig")
        if str(manifest.get("manifest_hash") or "") != _hash_record(manifest, "manifest_hash"):
            raise CertificationLabError("CWS-LAB-007", "Candidate package manifest_hash ongeldig")
        if not bool(manifest.get("review_only")) or any(bool(manifest.get(k)) for k in ("owner_attested", "certification_eligible", "offline_controller_output_released", "machine_output_released", "direct_machine_transfer")):
            raise CertificationLabError("CWS-LAB-007", "Candidate package bevat onveilige releaseflags")
        checksum_lines = zf.read("SHA256SUMS.txt").decode("utf-8").splitlines()
        expected: dict[str, str] = {}
        for line in checksum_lines:
            if not line.strip(): continue
            try:
                digest, rel = line.split("  ", 1)
            except ValueError as exc:
                raise CertificationLabError("CWS-LAB-007", "Candidate package checksumregel ongeldig") from exc
            rel = _safe_relative(rel)
            if rel in expected:
                raise CertificationLabError("CWS-LAB-007", f"Dubbele checksum-entry voor {rel}")
            expected[rel] = digest
        content_names = sorted(name for name in names if name != "SHA256SUMS.txt")
        if sorted(expected) != content_names:
            raise CertificationLabError("CWS-LAB-007", "Candidate package bestandsset wijkt af van SHA256SUMS")
        import hashlib
        for rel, digest in expected.items():
            if len(digest) != 64 or hashlib.sha256(zf.read(rel)).hexdigest() != digest:
                raise CertificationLabError("CWS-LAB-007", f"Candidate package checksum mismatch voor {rel}")
        campaign = json.loads(zf.read("campaign.json").decode("utf-8"))
        matrix = json.loads(zf.read("compatibility_matrix.json").decode("utf-8"))
        if campaign.get("format") != M15_CAMPAIGN_FORMAT or str(campaign.get("campaign_hash") or "") != _hash_record(campaign, "campaign_hash"):
            raise CertificationLabError("CWS-LAB-007", "Candidate package campaignrecord ongeldig")
        if matrix.get("format") != M15_COMPATIBILITY_MATRIX_FORMAT or str(matrix.get("matrix_hash") or "") != _hash_record(matrix, "matrix_hash"):
            raise CertificationLabError("CWS-LAB-007", "Candidate package matrixrecord ongeldig")
        if str(campaign.get("campaign_id") or "") != str(manifest.get("campaign_id") or "") or str(campaign.get("campaign_hash") or "") != str(manifest.get("campaign_hash") or ""):
            raise CertificationLabError("CWS-LAB-007", "Candidate package campaign-binding mismatch")
        if str(matrix.get("matrix_id") or "") != str(manifest.get("matrix_id") or "") or str(matrix.get("matrix_hash") or "") != str(manifest.get("matrix_hash") or ""):
            raise CertificationLabError("CWS-LAB-007", "Candidate package matrix-binding mismatch")
        impact_files = sorted(name for name in content_names if name.startswith("impacts/") and name.endswith(".json"))
        actual_impact_bindings: list[dict[str, str]] = []
        for rel in impact_files:
            impact = json.loads(zf.read(rel).decode("utf-8"))
            if impact.get("format") != M15_IMPACT_FORMAT or str(impact.get("impact_hash") or "") != _hash_record(impact, "impact_hash"):
                raise CertificationLabError("CWS-LAB-007", f"Candidate package impactrecord ongeldig: {rel}")
            if any(bool(impact.get(k)) for k in ("owner_approved", "machine_output_released", "direct_machine_transfer")):
                raise CertificationLabError("CWS-LAB-007", f"Candidate package impactrecord bevat onveilige releaseflags: {rel}")
            actual_impact_bindings.append({"impact_id": str(impact.get("impact_id") or ""), "impact_hash": str(impact.get("impact_hash") or "")})
        expected_impact_bindings = [
            {"impact_id": str(x.get("impact_id") or ""), "impact_hash": str(x.get("impact_hash") or "")}
            for x in list(manifest.get("impact_bindings") or []) if isinstance(x, Mapping)
        ]
        if actual_impact_bindings != expected_impact_bindings:
            raise CertificationLabError("CWS-LAB-007", "Candidate package impact-binding mismatch")

        diff_files = sorted(name for name in content_names if name.startswith("review_diffs/") and name.endswith(".json"))
        actual_diff_hashes: list[str] = []
        for rel in diff_files:
            diff = json.loads(zf.read(rel).decode("utf-8"))
            if diff.get("format") != M15_ARTIFACT_DIFF_FORMAT or str(diff.get("report_hash") or "") != _hash_record(diff, "report_hash"):
                raise CertificationLabError("CWS-LAB-007", f"Candidate package review-diff ongeldig: {rel}")
            if bool(diff.get("certification_eligible")):
                raise CertificationLabError("CWS-LAB-007", f"Candidate package review-diff mag niet certification-eligible zijn: {rel}")
            actual_diff_hashes.append(str(diff.get("report_hash") or ""))
        if actual_diff_hashes != [str(x) for x in list(manifest.get("review_diff_hashes") or [])]:
            raise CertificationLabError("CWS-LAB-007", "Candidate package review-diff binding mismatch")
    return {"status": "passed", "candidate_id": manifest["candidate_id"], "manifest_hash": manifest["manifest_hash"], "output_sha256": sha256_file(path), "file_count": len(names), "review_only": True, "direct_machine_transfer": False}


__all__ = [name for name in globals() if not name.startswith("_")]
