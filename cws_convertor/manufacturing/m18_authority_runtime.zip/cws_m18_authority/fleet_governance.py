"""M16 certification fleet governance and controlled offline deployment boundary.

M16 operates *above* the M13 certification authority and M15 review lab. It
never certifies an adapter and never transfers data to a machine.  Its job is to
bind already-certified offline controller output to a site/machine policy,
verify externally signed deployment approvals, surface recertification work and
produce a deterministic deployment bundle for a separate human/controlled
release process.
"""
from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
from typing import Any, Iterable, Mapping
import zipfile

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

from cws_convertor.product import APP_VERSION, PROJECT_SCHEMA_VERSION
from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from cws_convertor.production_export.utils import canonical_json_bytes, sha256_file
from .adapter_certification import (
    current_adapter_certificate,
    validate_persisted_adapter_certificate,
    verify_certified_sequence_package,
)
from .certification_lab import validate_persisted_certification_impact
from .certification_ops import certificate_lifecycle_status
from .machine_marking_service import load_machine_marking_capability

M16_CONTRACT_VERSION = "1.0"
M16_SITE_FORMAT = "CWS_M16_FLEET_SITE_V1"
M16_BINDING_FORMAT = "CWS_M16_FLEET_MACHINE_BINDING_V1"
M16_POLICY_FORMAT = "CWS_M16_FLEET_POLICY_V1"
M16_SIGNER_FORMAT = "CWS_M16_TRUSTED_APPROVAL_SIGNER_V1"
M16_APPROVAL_PAYLOAD_FORMAT = "CWS_M16_DEPLOYMENT_APPROVAL_PAYLOAD_V1"
M16_APPROVAL_FORMAT = "CWS_M16_SIGNED_EXTERNAL_APPROVAL_V1"
M16_QUEUE_FORMAT = "CWS_M16_RECERTIFICATION_QUEUE_V1"
M16_DEPLOYMENT_RECORD_FORMAT = "CWS_M16_DEPLOYMENT_BUNDLE_RECORD_V1"
M16_DEPLOYMENT_PACKAGE_FORMAT = "CWS_M16_OFFLINE_DEPLOYMENT_BUNDLE_V1"
M16_HASH_VERSION = "cws-m16-fleet-governance-v1"
_ZIP_DATE = (1980, 1, 1, 0, 0, 0)
_SHA256_RE = re.compile(r"[0-9a-f]{64}")


class FleetGovernanceError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def _hash_record(value: Mapping[str, Any], field: str) -> str:
    return stable_sha256({k: v for k, v in value.items() if k != field})


def _parse_iso(value: Any, *, label: str) -> datetime:
    text = str(value or "").strip()
    if not text:
        raise FleetGovernanceError("CWS-FLEET-001", f"{label} ontbreekt")
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise FleetGovernanceError("CWS-FLEET-001", f"{label} is geen geldige ISO-8601 datum/tijd") from exc
    if dt.tzinfo is None:
        raise FleetGovernanceError("CWS-FLEET-001", f"{label} moet timezone-aware zijn")
    return dt.astimezone(timezone.utc)


def _safe_rel(value: Any) -> str:
    raw = str(value or "").replace("\\", "/").strip()
    p = PurePosixPath(raw)
    if not raw or p.is_absolute() or ".." in p.parts or any(x in {"", "."} for x in p.parts) or len(raw) > 512:
        raise FleetGovernanceError("CWS-FLEET-002", f"Onveilig relatief pad: {raw!r}")
    return p.as_posix()


def _store_immutable(store: dict[str, dict[str, Any]], key: str, record: dict[str, Any], hash_field: str) -> dict[str, Any]:
    old = store.get(key)
    if isinstance(old, Mapping):
        if str(old.get(hash_field) or "") != str(record.get(hash_field) or ""):
            raise ProjectValidationError(f"M16 immutable record-ID collision voor {key}")
        return dict(old)
    store[key] = record
    return record


def register_fleet_site(
    project: ProjectModel,
    *,
    site_id: str,
    name: str,
    country_code: str,
    timezone_name: str,
    environment: str = "production",
    user: str = "system",
) -> dict[str, Any]:
    site_id = str(site_id or "").strip()
    if not site_id or not str(name or "").strip() or len(country_code.strip()) != 2 or not str(timezone_name or "").strip():
        raise FleetGovernanceError("CWS-FLEET-003", "Site vereist site_id, naam, ISO-landcode en timezone")
    record = {
        "format": M16_SITE_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16",
        "site_id": site_id, "name": str(name).strip(), "country_code": country_code.upper().strip(),
        "timezone": str(timezone_name).strip(), "environment": str(environment or "production").strip(),
        "status": "active", "created_for_cws_version": APP_VERSION, "created_for_project_schema": PROJECT_SCHEMA_VERSION,
        "direct_machine_transfer": False, "hash_version": M16_HASH_VERSION,
    }
    record["site_hash"] = _hash_record(record, "site_hash")
    result = _store_immutable(project.manufacturing_fleet_sites, site_id, record, "site_hash")
    project.audit("manufacturing.fleet_site_registered", user=user, entity_id=site_id, after_hash=result["site_hash"], details={"direct_machine_transfer": False})
    return result


def validate_persisted_fleet_site(project: ProjectModel, site_id: str) -> dict[str, Any]:
    raw = project.manufacturing_fleet_sites.get(site_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M16_SITE_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION:
        raise ProjectValidationError(f"M16 fleet site {site_id} ontbreekt/ongeldig")
    if str(raw.get("site_id") or "") != site_id or str(raw.get("site_hash") or "") != _hash_record(raw, "site_hash"):
        raise ProjectValidationError("M16 fleet site identity/hash ongeldig")
    if bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M16 fleet site mag direct transfer niet vrijgeven")
    return dict(raw)


def register_fleet_machine_binding(
    project: ProjectModel,
    *,
    site_id: str,
    machine_id: str,
    controller_id: str,
    capability_id: str,
    adapter_id: str,
    user: str = "system",
) -> dict[str, Any]:
    site = validate_persisted_fleet_site(project, site_id)
    capability = load_machine_marking_capability(project, capability_id)
    if str(capability.machine_id) != str(machine_id):
        raise FleetGovernanceError("CWS-FLEET-004", "Capability hoort niet bij fleet machine_id")
    cert = current_adapter_certificate(project, adapter_id=adapter_id, machine_id=machine_id, controller_id=controller_id, capability_id=capability_id)
    binding = {
        "format": M16_BINDING_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16",
        "site_id": site_id, "site_hash": site["site_hash"], "machine_id": machine_id, "controller_id": controller_id,
        "capability_id": capability_id, "capability_hash": capability.capability_hash, "adapter_id": adapter_id,
        "current_certificate_id": str(cert.get("certificate_id") or "") if cert else "",
        "current_certificate_hash": str(cert.get("certificate_hash") or "") if cert else "",
        "status": "certificate_current" if cert else "certificate_missing",
        "created_for_cws_version": APP_VERSION, "created_for_project_schema": PROJECT_SCHEMA_VERSION,
        "direct_machine_transfer": False, "hash_version": M16_HASH_VERSION,
    }
    binding_id = "fbind-" + stable_sha256({k: binding[k] for k in ("site_id", "machine_id", "controller_id", "capability_id", "capability_hash", "adapter_id")})[:28]
    binding["binding_id"] = binding_id
    binding["binding_hash"] = _hash_record(binding, "binding_hash")
    result = _store_immutable(project.manufacturing_fleet_machine_bindings, binding_id, binding, "binding_hash")
    project.audit("manufacturing.fleet_machine_binding", user=user, entity_id=binding_id, after_hash=result["binding_hash"], details={"site_id": site_id, "direct_machine_transfer": False})
    return result


def validate_persisted_fleet_machine_binding(project: ProjectModel, binding_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_fleet_machine_bindings.get(binding_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M16_BINDING_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION:
        raise ProjectValidationError(f"M16 fleet binding {binding_id} ontbreekt/ongeldig")
    if str(raw.get("binding_id") or "") != binding_id or str(raw.get("binding_hash") or "") != _hash_record(raw, "binding_hash"):
        raise ProjectValidationError("M16 fleet binding identity/hash ongeldig")
    site = validate_persisted_fleet_site(project, str(raw.get("site_id") or ""))
    if str(raw.get("site_hash") or "") != str(site.get("site_hash") or ""):
        raise ProjectValidationError("M16 fleet binding site is stale")
    capability = load_machine_marking_capability(project, str(raw.get("capability_id") or ""))
    if capability.capability_hash != str(raw.get("capability_hash") or "") or capability.machine_id != str(raw.get("machine_id") or ""):
        raise ProjectValidationError("M16 fleet binding capability is stale")
    if require_current:
        cert = current_adapter_certificate(project, adapter_id=str(raw.get("adapter_id") or ""), machine_id=str(raw.get("machine_id") or ""), controller_id=str(raw.get("controller_id") or ""), capability_id=str(raw.get("capability_id") or ""))
        if not cert:
            raise ProjectValidationError("M16 fleet binding heeft geen current M13 certificaat")
        if str(raw.get("current_certificate_id") or "") and str(raw.get("current_certificate_id") or "") != str(cert.get("certificate_id") or ""):
            raise ProjectValidationError("M16 fleet binding certificate snapshot is stale")
    if bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M16 fleet binding mag direct transfer niet vrijgeven")
    return dict(raw)


def create_fleet_policy(
    project: ProjectModel,
    *,
    policy_name: str,
    site_ids: Iterable[str],
    trusted_signer_ids: Iterable[str] = (),
    allowed_adapter_ids: Iterable[str] = (),
    maximum_approval_age_hours: int = 72,
    maximum_bundle_age_hours: int = 24,
    expiring_certificate_days: int = 30,
    user: str = "system",
) -> dict[str, Any]:
    sites = sorted({str(x) for x in site_ids if str(x)})
    if not sites or not str(policy_name or "").strip():
        raise FleetGovernanceError("CWS-FLEET-005", "Fleet policy vereist naam en minimaal één site")
    site_hashes = []
    for site_id in sites:
        site_hashes.append(validate_persisted_fleet_site(project, site_id)["site_hash"])
    signers = sorted({str(x) for x in trusted_signer_ids if str(x)})
    signer_hashes: list[str] = []
    for signer_id in signers:
        signer_hashes.append(
            str(validate_persisted_trusted_signer(project, signer_id, require_current=True)["signer_hash"])
        )
    record = {
        "format": M16_POLICY_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16",
        "policy_name": str(policy_name).strip(), "site_ids": sites, "site_hashes": site_hashes,
        "trusted_signer_ids": signers, "trusted_signer_hashes": signer_hashes,
        "allowed_adapter_ids": sorted({str(x) for x in allowed_adapter_ids if str(x)}),
        "require_current_m13_certificate": True, "require_signed_external_approval": True,
        "require_current_m11_m12_release_chain": True, "offline_deployment_bundle_only": True,
        "maximum_approval_age_hours": max(1, int(maximum_approval_age_hours)),
        "maximum_bundle_age_hours": max(1, int(maximum_bundle_age_hours)),
        "expiring_certificate_days": max(0, int(expiring_certificate_days)),
        "direct_machine_transfer": False, "hash_version": M16_HASH_VERSION,
    }
    policy_id = "fpolicy-" + stable_sha256({"name": record["policy_name"], "sites": sites, "signers": signers, "adapters": record["allowed_adapter_ids"]})[:28]
    record["policy_id"] = policy_id
    record["policy_hash"] = _hash_record(record, "policy_hash")
    result = _store_immutable(project.manufacturing_fleet_policies, policy_id, record, "policy_hash")
    project.audit("manufacturing.fleet_policy_created", user=user, entity_id=policy_id, after_hash=result["policy_hash"], details={"site_count": len(sites), "direct_machine_transfer": False})
    return result


def validate_persisted_fleet_policy(project: ProjectModel, policy_id: str) -> dict[str, Any]:
    raw = project.manufacturing_fleet_policies.get(policy_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M16_POLICY_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION:
        raise ProjectValidationError(f"M16 fleet policy {policy_id} ontbreekt/ongeldig")
    if str(raw.get("policy_id") or "") != policy_id or str(raw.get("policy_hash") or "") != _hash_record(raw, "policy_hash"):
        raise ProjectValidationError("M16 fleet policy identity/hash ongeldig")
    for site_id, site_hash in zip(list(raw.get("site_ids") or []), list(raw.get("site_hashes") or [])):
        if validate_persisted_fleet_site(project, str(site_id)).get("site_hash") != site_hash:
            raise ProjectValidationError("M16 fleet policy site snapshot is stale")
    signer_ids = list(raw.get("trusted_signer_ids") or [])
    signer_hashes = list(raw.get("trusted_signer_hashes") or [])
    if len(signer_ids) != len(signer_hashes):
        raise ProjectValidationError("M16 fleet policy signer snapshot is incompleet")
    for signer_id, signer_hash in zip(signer_ids, signer_hashes):
        if validate_persisted_trusted_signer(project, str(signer_id), require_current=False).get("signer_hash") != signer_hash:
            raise ProjectValidationError("M16 fleet policy signer snapshot is stale")
    if not bool(raw.get("require_current_m13_certificate")) or not bool(raw.get("require_signed_external_approval")) or not bool(raw.get("offline_deployment_bundle_only")):
        raise ProjectValidationError("M16 fleet policy mag harde governance-eisen niet uitschakelen")
    if bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M16 fleet policy mag direct transfer niet vrijgeven")
    return dict(raw)


def register_trusted_approval_signer(
    project: ProjectModel,
    *,
    signer_id: str,
    organization: str,
    public_key_pem: str | bytes,
    valid_from: str,
    expires_at: str,
    user: str = "system",
) -> dict[str, Any]:
    signer_id = str(signer_id or "").strip()
    if not signer_id or not str(organization or "").strip():
        raise FleetGovernanceError("CWS-FLEET-006", "Trusted signer vereist signer_id en organisatie")
    start, end = _parse_iso(valid_from, label="valid_from"), _parse_iso(expires_at, label="expires_at")
    if end <= start:
        raise FleetGovernanceError("CWS-FLEET-006", "Signer expires_at moet na valid_from liggen")
    pem = public_key_pem.encode("utf-8") if isinstance(public_key_pem, str) else bytes(public_key_pem)
    try:
        key = serialization.load_pem_public_key(pem)
    except Exception as exc:
        raise FleetGovernanceError("CWS-FLEET-006", "Signer public key PEM is ongeldig") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise FleetGovernanceError("CWS-FLEET-006", "M16 ondersteunt voor external approvals alleen Ed25519 public keys")
    raw = key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    normalized_pem = key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode("ascii")
    record = {
        "format": M16_SIGNER_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16",
        "signer_id": signer_id, "organization": str(organization).strip(), "algorithm": "ed25519",
        "public_key_pem": normalized_pem, "public_key_fingerprint_sha256": hashlib.sha256(raw).hexdigest(),
        "valid_from": start.isoformat(), "expires_at": end.isoformat(), "status": "trusted",
        "direct_machine_transfer": False, "hash_version": M16_HASH_VERSION,
    }
    record["signer_hash"] = _hash_record(record, "signer_hash")
    result = _store_immutable(project.manufacturing_fleet_trusted_signers, signer_id, record, "signer_hash")
    project.audit("manufacturing.fleet_signer_registered", user=user, entity_id=signer_id, after_hash=result["signer_hash"], details={"fingerprint": result["public_key_fingerprint_sha256"], "direct_machine_transfer": False})
    return result


def validate_persisted_trusted_signer(project: ProjectModel, signer_id: str, *, at: datetime | None = None, require_current: bool = True) -> dict[str, Any]:
    raw = project.manufacturing_fleet_trusted_signers.get(signer_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M16_SIGNER_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION:
        raise ProjectValidationError(f"M16 trusted signer {signer_id} ontbreekt/ongeldig")
    if str(raw.get("signer_id") or "") != signer_id or str(raw.get("signer_hash") or "") != _hash_record(raw, "signer_hash"):
        raise ProjectValidationError("M16 signer identity/hash ongeldig")
    try:
        key = serialization.load_pem_public_key(str(raw.get("public_key_pem") or "").encode("ascii"))
    except Exception as exc:
        raise ProjectValidationError("M16 signer public key kan niet worden geladen") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise ProjectValidationError("M16 signer key is geen Ed25519 key")
    fp = hashlib.sha256(key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).hexdigest()
    if fp != str(raw.get("public_key_fingerprint_sha256") or ""):
        raise ProjectValidationError("M16 signer public key fingerprint mismatch")
    now = at or datetime.now(timezone.utc)
    if require_current and not (_parse_iso(raw.get("valid_from"), label="signer valid_from") <= now < _parse_iso(raw.get("expires_at"), label="signer expires_at")):
        raise ProjectValidationError("M16 signer is buiten geldigheidsperiode")
    return dict(raw)


def deployment_approval_payload(
    project: ProjectModel,
    *,
    policy_id: str,
    binding_id: str,
    certificate_id: str,
    certified_package_root: str | Path,
    signer_id: str,
    approval_nonce: str,
    expires_at: str,
) -> dict[str, Any]:
    policy = validate_persisted_fleet_policy(project, policy_id)
    binding = validate_persisted_fleet_machine_binding(project, binding_id, require_current=True)
    cert = validate_persisted_adapter_certificate(project, certificate_id, require_current=True)
    if str(cert.get("certificate_id") or "") != str(binding.get("current_certificate_id") or ""):
        raise FleetGovernanceError("CWS-FLEET-007", "Approval certificate wijkt af van fleet binding current certificate")
    if binding["site_id"] not in policy["site_ids"]:
        raise FleetGovernanceError("CWS-FLEET-007", "Fleet binding site valt buiten policy")
    if policy.get("allowed_adapter_ids") and binding["adapter_id"] not in policy["allowed_adapter_ids"]:
        raise FleetGovernanceError("CWS-FLEET-007", "Adapter valt buiten fleet policy")
    if policy.get("trusted_signer_ids") and signer_id not in policy["trusted_signer_ids"]:
        raise FleetGovernanceError("CWS-FLEET-007", "Signer valt buiten fleet policy")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    verify = verify_certified_sequence_package(certified_package_root)
    manifest = json.loads((Path(certified_package_root) / "manifest.json").read_text(encoding="utf-8"))
    if str(manifest.get("certificate_id") or "") != certificate_id or str(manifest.get("certificate_hash") or "") != str(cert.get("certificate_hash") or ""):
        raise FleetGovernanceError("CWS-FLEET-007", "Certified package certificate-binding ongeldig")
    if str(manifest.get("machine_id") or "") != binding["machine_id"] or str(manifest.get("controller_id") or "") != binding["controller_id"]:
        raise FleetGovernanceError("CWS-FLEET-007", "Certified package machine/controller wijkt af van fleet binding")
    exp = _parse_iso(expires_at, label="approval expires_at")
    if exp <= datetime.now(timezone.utc):
        raise FleetGovernanceError("CWS-FLEET-007", "Approval payload mag niet reeds verlopen zijn")
    observed_at = utc_now_iso()
    payload = {
        "format": M16_APPROVAL_PAYLOAD_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16",
        "project_id": project.project_id, "policy_id": policy_id, "policy_hash": policy["policy_hash"],
        "binding_id": binding_id, "binding_hash": binding["binding_hash"], "site_id": binding["site_id"],
        "machine_id": binding["machine_id"], "controller_id": binding["controller_id"], "adapter_id": binding["adapter_id"],
        "certificate_id": certificate_id, "certificate_hash": cert["certificate_hash"],
        "certified_package_id": str(verify.get("package_id") or ""), "certified_package_manifest_hash": str(manifest.get("manifest_hash") or ""),
        "signer_id": signer_id, "signer_hash": signer["signer_hash"],
        "approved_action": "promote_offline_controller_package_to_controlled_deployment_bundle",
        "approval_nonce": str(approval_nonce or "").strip(), "issued_at": observed_at,
        "certified_package_observed_at": observed_at, "expires_at": exp.isoformat(),
        "offline_deployment_only": True, "operator_release_required": True, "direct_machine_transfer": False,
        "hash_version": M16_HASH_VERSION,
    }
    if not payload["approval_nonce"]:
        raise FleetGovernanceError("CWS-FLEET-007", "Approval nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_external_approval(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {})
    if raw.get("format") != M16_APPROVAL_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519":
        raise FleetGovernanceError("CWS-FLEET-008", "External approval envelope format/schema/algorithm ongeldig")
    payload = raw.get("payload")
    if not isinstance(payload, Mapping) or payload.get("format") != M16_APPROVAL_PAYLOAD_FORMAT:
        raise FleetGovernanceError("CWS-FLEET-008", "External approval payload ontbreekt/ongeldig")
    payload = dict(payload)
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise FleetGovernanceError("CWS-FLEET-008", "External approval payload_hash ongeldig")
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("signer_id") or ""):
        raise FleetGovernanceError("CWS-FLEET-008", "Approval signer mismatch")
    issued = _parse_iso(payload.get("issued_at"), label="approval issued_at")
    expires = _parse_iso(payload.get("expires_at"), label="approval expires_at")
    now = datetime.now(timezone.utc)
    if not (issued <= now < expires):
        raise FleetGovernanceError("CWS-FLEET-008", "External approval is nog niet geldig of verlopen")
    signer = validate_persisted_trusted_signer(project, signer_id, at=issued)
    policy = validate_persisted_fleet_policy(project, str(payload.get("policy_id") or ""))
    binding = validate_persisted_fleet_machine_binding(project, str(payload.get("binding_id") or ""), require_current=True)
    cert = validate_persisted_adapter_certificate(project, str(payload.get("certificate_id") or ""), require_current=True)
    if str(payload.get("policy_hash") or "") != policy["policy_hash"] or str(payload.get("binding_hash") or "") != binding["binding_hash"] or str(payload.get("certificate_hash") or "") != cert["certificate_hash"]:
        raise FleetGovernanceError("CWS-FLEET-008", "Approval payload reference/hash binding is stale")
    if str(payload.get("signer_hash") or "") != signer["signer_hash"]:
        raise FleetGovernanceError("CWS-FLEET-008", "Approval payload signer snapshot is stale")
    if policy.get("trusted_signer_ids") and signer_id not in policy["trusted_signer_ids"]:
        raise FleetGovernanceError("CWS-FLEET-008", "Approval signer niet toegestaan door policy")
    if now - issued > timedelta(hours=int(policy.get("maximum_approval_age_hours") or 72)):
        raise FleetGovernanceError("CWS-FLEET-008", "External approval is ouder dan policy toestaat")
    if bool(payload.get("direct_machine_transfer")) or not bool(payload.get("offline_deployment_only")) or not bool(payload.get("operator_release_required")):
        raise FleetGovernanceError("CWS-FLEET-008", "Approval payload probeert harde offline/operator boundary te verzwakken")
    try:
        signature = base64.b64decode(str(raw.get("signature_base64") or ""), validate=True)
    except Exception as exc:
        raise FleetGovernanceError("CWS-FLEET-008", "Approval signature_base64 ongeldig") from exc
    key = serialization.load_pem_public_key(str(signer["public_key_pem"]).encode("ascii"))
    assert isinstance(key, Ed25519PublicKey)
    try:
        key.verify(signature, canonical_json_bytes(payload))
    except InvalidSignature as exc:
        raise FleetGovernanceError("CWS-FLEET-008", "External approval signature verification failed") from exc
    approval_id = "approval-" + stable_sha256({"payload_hash": payload["payload_hash"], "signer_hash": signer["signer_hash"], "signature": str(raw.get("signature_base64") or "")})[:28]
    existing = project.manufacturing_fleet_external_approvals.get(approval_id)
    if isinstance(existing, Mapping):
        validated = validate_persisted_external_approval(project, approval_id, require_current=True)
        if (
            str(validated.get("signer_hash") or "") != signer["signer_hash"]
            or dict(validated.get("payload") or {}) != payload
            or str(validated.get("signature_base64") or "") != str(raw.get("signature_base64") or "")
        ):
            raise FleetGovernanceError("CWS-FLEET-008", "Bestaand approval-ID botst met andere signed evidence")
        return validated
    record = {
        "format": M16_APPROVAL_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16", "approval_id": approval_id,
        "signer_id": signer_id, "signer_hash": signer["signer_hash"], "algorithm": "ed25519", "payload": payload,
        "signature_base64": str(raw.get("signature_base64") or ""), "signature_verified": True, "received_at": utc_now_iso(),
        "owner_adapter_certification_authority": False, "offline_deployment_approved": True, "direct_machine_transfer": False,
        "hash_version": M16_HASH_VERSION,
    }
    record["approval_hash"] = _hash_record(record, "approval_hash")
    result = _store_immutable(project.manufacturing_fleet_external_approvals, approval_id, record, "approval_hash")
    project.audit("manufacturing.fleet_external_approval_ingested", user=user, entity_id=approval_id, after_hash=result["approval_hash"], details={"signer_id": signer_id, "direct_machine_transfer": False})
    return result


def validate_persisted_external_approval(project: ProjectModel, approval_id: str, *, require_current: bool = True) -> dict[str, Any]:
    raw = project.manufacturing_fleet_external_approvals.get(approval_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M16_APPROVAL_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION:
        raise ProjectValidationError(f"M16 external approval {approval_id} ontbreekt/ongeldig")
    if str(raw.get("approval_id") or "") != approval_id or str(raw.get("approval_hash") or "") != _hash_record(raw, "approval_hash"):
        raise ProjectValidationError("M16 external approval identity/hash ongeldig")
    if not bool(raw.get("signature_verified")) or bool(raw.get("owner_adapter_certification_authority")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M16 external approval veiligheidsflags ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M16 external approval payload_hash ongeldig")
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), at=_parse_iso(payload.get("issued_at"), label="approval issued_at"))
    if str(raw.get("signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M16 external approval signer binding stale")
    key = serialization.load_pem_public_key(str(signer["public_key_pem"]).encode("ascii")); assert isinstance(key, Ed25519PublicKey)
    try:
        key.verify(base64.b64decode(str(raw.get("signature_base64") or ""), validate=True), canonical_json_bytes(payload))
    except Exception as exc:
        raise ProjectValidationError("M16 external approval signature ongeldig") from exc
    if require_current and datetime.now(timezone.utc) >= _parse_iso(payload.get("expires_at"), label="approval expires_at"):
        raise ProjectValidationError("M16 external approval is verlopen")
    validate_persisted_fleet_policy(project, str(payload.get("policy_id") or ""))
    validate_persisted_fleet_machine_binding(project, str(payload.get("binding_id") or ""), require_current=require_current)
    validate_persisted_adapter_certificate(project, str(payload.get("certificate_id") or ""), require_current=require_current)
    return dict(raw)


def build_recertification_queue(project: ProjectModel, *, user: str = "system", persist: bool = True) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    for binding_id in sorted(project.manufacturing_fleet_machine_bindings):
        try:
            binding = validate_persisted_fleet_machine_binding(project, binding_id, require_current=False)
        except Exception as exc:
            entries.append({"binding_id": binding_id, "priority": "critical", "action": "repair_binding", "blocking": True, "reasons": [str(exc)]})
            continue
        cert = current_adapter_certificate(project, adapter_id=binding["adapter_id"], machine_id=binding["machine_id"], controller_id=binding["controller_id"], capability_id=binding["capability_id"])
        reasons: list[str] = []
        action = "none"; priority = "low"
        if not cert:
            reasons.append("current_m13_certificate_missing_or_stale"); action = "recertify_adapter"; priority = "critical"
        else:
            lifecycle = certificate_lifecycle_status(project, str(cert["certificate_id"]))
            if lifecycle["status"] == "expiring":
                reasons.append("certificate_expiring"); action = "renew_certificate"; priority = "high"
        for impact_id in sorted(project.manufacturing_adapter_lab_impacts):
            try:
                impact = validate_persisted_certification_impact(project, impact_id)
            except Exception:
                continue
            for item in impact.get("impacted_objects") or impact.get("impacted") or []:
                if not isinstance(item, Mapping):
                    continue
                if str(item.get("adapter_id") or "") == binding["adapter_id"] or str(item.get("object_id") or "") in {str(cert.get("certificate_id") if cert else ""), binding["capability_id"]}:
                    if bool(impact.get("requires_recertification_review")):
                        reasons.append(f"m15_impact:{impact_id}"); action = "review_impact_and_recertify"; priority = "high" if cert else "critical"
                        break
        if reasons:
            entry = {"binding_id": binding_id, "site_id": binding["site_id"], "machine_id": binding["machine_id"], "adapter_id": binding["adapter_id"], "priority": priority, "action": action, "blocking": True, "reasons": sorted(set(reasons))}
            entry["queue_item_id"] = "rqitem-" + stable_sha256(entry)[:24]
            entry["item_hash"] = stable_sha256(entry)
            entries.append(entry)
    entries.sort(key=lambda x: ({"critical": 0, "high": 1, "medium": 2, "low": 3}.get(str(x.get("priority")), 9), str(x.get("binding_id"))))
    queue = {"format": M16_QUEUE_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16", "entry_count": len(entries), "blocking_count": sum(1 for x in entries if x.get("blocking")), "entries": entries, "direct_machine_transfer": False, "hash_version": M16_HASH_VERSION}
    queue_id = "rqueue-" + stable_sha256([x["item_hash"] for x in entries])[:28]
    queue["queue_id"] = queue_id; queue["queue_hash"] = _hash_record(queue, "queue_hash")
    if persist:
        _store_immutable(project.manufacturing_fleet_recertification_queues, queue_id, queue, "queue_hash")
        project.audit("manufacturing.fleet_recertification_queue", user=user, entity_id=queue_id, after_hash=queue["queue_hash"], details={"blocking_count": queue["blocking_count"], "direct_machine_transfer": False})
    return queue


def validate_persisted_recertification_queue(project: ProjectModel, queue_id: str) -> dict[str, Any]:
    raw = project.manufacturing_fleet_recertification_queues.get(queue_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M16_QUEUE_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION:
        raise ProjectValidationError(f"M16 recertification queue {queue_id} ontbreekt/ongeldig")
    if str(raw.get("queue_id") or "") != queue_id or str(raw.get("queue_hash") or "") != _hash_record(raw, "queue_hash"):
        raise ProjectValidationError("M16 recertification queue identity/hash ongeldig")
    if bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M16 recertification queue mag transfer niet vrijgeven")
    return dict(raw)


def _blocking_impacts_for_binding(project: ProjectModel, binding: Mapping[str, Any], certificate_id: str) -> list[str]:
    out: list[str] = []
    for impact_id in sorted(project.manufacturing_adapter_lab_impacts):
        try: impact = validate_persisted_certification_impact(project, impact_id)
        except Exception: continue
        if not bool(impact.get("requires_recertification_review")): continue
        for item in impact.get("impacted_objects") or impact.get("impacted") or []:
            if not isinstance(item, Mapping): continue
            if str(item.get("adapter_id") or "") == str(binding.get("adapter_id") or "") or str(item.get("object_id") or "") in {certificate_id, str(binding.get("capability_id") or "")}:
                out.append(str(impact_id)); break
    return out


def build_controlled_deployment_bundle(
    project: ProjectModel,
    *,
    binding_id: str,
    policy_id: str,
    approval_id: str,
    certified_package_root: str | Path,
    output_path: str | Path,
    created_by: str = "system",
    persist: bool = True,
) -> dict[str, Any]:
    binding = validate_persisted_fleet_machine_binding(project, binding_id, require_current=True)
    policy = validate_persisted_fleet_policy(project, policy_id)
    approval = validate_persisted_external_approval(project, approval_id, require_current=True)
    payload = dict(approval["payload"])
    if payload["binding_id"] != binding_id or payload["policy_id"] != policy_id:
        raise FleetGovernanceError("CWS-FLEET-009", "Approval hoort niet bij gevraagde binding/policy")
    cert_id = str(payload.get("certificate_id") or "")
    cert = validate_persisted_adapter_certificate(project, cert_id, require_current=True)
    package_root = Path(certified_package_root)
    verify = verify_certified_sequence_package(package_root)
    source_manifest = json.loads((package_root / "manifest.json").read_text(encoding="utf-8"))
    if str(source_manifest.get("manifest_hash") or "") != str(payload.get("certified_package_manifest_hash") or "") or str(verify.get("package_id") or "") != str(payload.get("certified_package_id") or ""):
        raise FleetGovernanceError("CWS-FLEET-009", "Signed approval bindt niet aan dit certified controller package")
    if str(source_manifest.get("certificate_id") or "") != cert_id or str(source_manifest.get("certificate_hash") or "") != cert["certificate_hash"]:
        raise FleetGovernanceError("CWS-FLEET-009", "Certified package certificate is stale")
    impacts = _blocking_impacts_for_binding(project, binding, cert_id)
    if impacts:
        raise FleetGovernanceError("CWS-FLEET-010", "Open M15 impact blokkeert deployment promotion", details={"impact_ids": impacts})
    if binding["site_id"] not in policy["site_ids"] or (policy.get("allowed_adapter_ids") and binding["adapter_id"] not in policy["allowed_adapter_ids"]):
        raise FleetGovernanceError("CWS-FLEET-010", "Fleet policy blokkeert deze binding")
    approval_time = _parse_iso(payload["issued_at"], label="approval issued_at")
    if datetime.now(timezone.utc) - approval_time > timedelta(hours=int(policy.get("maximum_approval_age_hours") or 72)):
        raise FleetGovernanceError("CWS-FLEET-010", "Approval is ouder dan policy toestaat")
    package_observed_at = _parse_iso(payload.get("certified_package_observed_at"), label="certified package observed_at")
    if datetime.now(timezone.utc) - package_observed_at > timedelta(hours=int(policy.get("maximum_bundle_age_hours") or 24)):
        raise FleetGovernanceError("CWS-FLEET-010", "Certified controller package is langer geleden geobserveerd dan policy toestaat")
    source_artifacts = list(source_manifest.get("artifacts") or [])
    artifact_rows: list[dict[str, Any]] = []
    file_payloads: dict[str, bytes] = {}
    for item in source_artifacts:
        rel = _safe_rel(item.get("relative_path")); data = (package_root / rel).read_bytes()
        if hashlib.sha256(data).hexdigest() != str(item.get("sha256") or ""):
            raise FleetGovernanceError("CWS-FLEET-009", f"Certified source artifact gewijzigd: {rel}")
        target = f"controller/{rel}"; file_payloads[target] = data
        artifact_rows.append({"relative_path": target, "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)})
    evidence_files = {
        "evidence/m13_manifest.json": canonical_json_bytes(source_manifest),
        "evidence/m16_policy.json": canonical_json_bytes(policy),
        "evidence/m16_binding.json": canonical_json_bytes(binding),
        "evidence/m16_approval.json": canonical_json_bytes(approval),
    }
    file_payloads.update(evidence_files)
    for rel, data in evidence_files.items(): artifact_rows.append({"relative_path": rel, "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)})
    package_id = "deploy-" + stable_sha256({"source_manifest_hash": source_manifest["manifest_hash"], "approval_hash": approval["approval_hash"], "policy_hash": policy["policy_hash"], "binding_hash": binding["binding_hash"]})[:28]
    manifest = {
        "format": M16_DEPLOYMENT_PACKAGE_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16", "package_id": package_id,
        "project_id": project.project_id, "site_id": binding["site_id"], "binding_id": binding_id, "binding_hash": binding["binding_hash"],
        "policy_id": policy_id, "policy_hash": policy["policy_hash"], "approval_id": approval_id, "approval_hash": approval["approval_hash"],
        "certificate_id": cert_id, "certificate_hash": cert["certificate_hash"], "source_certified_package_id": source_manifest["package_id"], "source_certified_manifest_hash": source_manifest["manifest_hash"],
        "machine_id": binding["machine_id"], "controller_id": binding["controller_id"], "adapter_id": binding["adapter_id"],
        "offline_controller_output_released": True, "offline_deployment_bundle_released": True, "operator_release_required": True,
        "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "machine_transfer": {"allowed": False, "reason": "M16 produces a controlled offline deployment bundle only. Physical/network machine transfer remains a separate external system."},
        "created_for_cws_version": APP_VERSION, "created_for_project_schema": PROJECT_SCHEMA_VERSION,
        "artifacts": sorted(artifact_rows, key=lambda x: x["relative_path"]), "hash_version": M16_HASH_VERSION,
    }
    manifest["manifest_hash"] = _hash_record(manifest, "manifest_hash")
    file_payloads["manifest.json"] = canonical_json_bytes(manifest)
    checksums = "\n".join(f"{hashlib.sha256(data).hexdigest()}  {name}" for name, data in sorted(file_payloads.items())) + "\n"
    file_payloads["SHA256SUMS.txt"] = checksums.encode("utf-8")
    output = Path(output_path); output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted(file_payloads.items()):
            info = zipfile.ZipInfo(name, date_time=_ZIP_DATE); info.compress_type = zipfile.ZIP_DEFLATED; info.external_attr = 0o644 << 16
            zf.writestr(info, data)
    verified = validate_controlled_deployment_bundle(output)
    record = {
        "format": M16_DEPLOYMENT_RECORD_FORMAT, "schema_version": M16_CONTRACT_VERSION, "phase": "M16", "deployment_id": package_id,
        "bundle_filename": f"{package_id}.zip", "bundle_sha256": sha256_file(output), "bundle_size_bytes": output.stat().st_size,
        "manifest_hash": manifest["manifest_hash"], "binding_id": binding_id, "policy_id": policy_id, "approval_id": approval_id,
        "certificate_id": cert_id, "offline_deployment_bundle_released": True, "operator_release_required": True,
        "deployment_transport_authorized": False, "direct_machine_transfer": False, "verified": bool(verified.get("valid")), "hash_version": M16_HASH_VERSION,
    }
    record["deployment_record_hash"] = _hash_record(record, "deployment_record_hash")
    if persist:
        _store_immutable(project.manufacturing_fleet_deployments, package_id, record, "deployment_record_hash")
        project.audit("manufacturing.fleet_deployment_bundle", user=created_by, entity_id=package_id, after_hash=record["deployment_record_hash"], details={"site_id": binding["site_id"], "direct_machine_transfer": False})
    return {"output": str(output), "manifest": manifest, "record": record, "verify": verified}


def validate_controlled_deployment_bundle(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.is_file(): raise FleetGovernanceError("CWS-FLEET-011", "M16 deployment bundle ontbreekt")
    with zipfile.ZipFile(p, "r") as zf:
        names = zf.namelist()
        if len(names) != len(set(names)) or "manifest.json" not in names or "SHA256SUMS.txt" not in names:
            raise FleetGovernanceError("CWS-FLEET-011", "M16 deployment bundle structuur ongeldig")
        for name in names: _safe_rel(name)
        checks: dict[str, str] = {}
        for line in zf.read("SHA256SUMS.txt").decode("utf-8").splitlines():
            if not line.strip(): continue
            sha, rel = line.split("  ", 1); rel = _safe_rel(rel)
            if not _SHA256_RE.fullmatch(sha): raise FleetGovernanceError("CWS-FLEET-011", "M16 SHA256SUMS bevat ongeldige hash")
            checks[rel] = sha
        expected = set(names) - {"SHA256SUMS.txt"}
        if set(checks) != expected:
            raise FleetGovernanceError("CWS-FLEET-011", "M16 SHA256SUMS dekt niet exact alle bundlebestanden")
        for rel, sha in checks.items():
            if hashlib.sha256(zf.read(rel)).hexdigest() != sha: raise FleetGovernanceError("CWS-FLEET-011", f"M16 bundle SHA mismatch: {rel}")
        manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
        if manifest.get("format") != M16_DEPLOYMENT_PACKAGE_FORMAT or str(manifest.get("schema_version") or "") != M16_CONTRACT_VERSION:
            raise FleetGovernanceError("CWS-FLEET-011", "M16 bundle manifest format/schema ongeldig")
        if str(manifest.get("manifest_hash") or "") != _hash_record(manifest, "manifest_hash"):
            raise FleetGovernanceError("CWS-FLEET-011", "M16 bundle manifest_hash ongeldig")
        if not bool(manifest.get("offline_deployment_bundle_released")) or not bool(manifest.get("operator_release_required")) or bool(manifest.get("deployment_transport_authorized")) or bool(manifest.get("direct_machine_transfer")) or bool(dict(manifest.get("machine_transfer") or {}).get("allowed")):
            raise FleetGovernanceError("CWS-FLEET-011", "M16 bundle veiligheidsflags ongeldig")
        artifact_names = {str(x.get("relative_path") or "") for x in manifest.get("artifacts") or [] if isinstance(x, Mapping)}
        if artifact_names != (expected - {"manifest.json"}):
            raise FleetGovernanceError("CWS-FLEET-011", "M16 bundle manifest artifactset mismatch")
        for item in manifest.get("artifacts") or []:
            rel = _safe_rel(item.get("relative_path")); data = zf.read(rel)
            if str(item.get("sha256") or "") != hashlib.sha256(data).hexdigest() or int(item.get("size_bytes") or -1) != len(data):
                raise FleetGovernanceError("CWS-FLEET-011", f"M16 bundle artifact metadata mismatch: {rel}")
        return {"valid": True, "package_id": manifest.get("package_id"), "manifest_hash": manifest.get("manifest_hash"), "artifact_count": len(artifact_names), "offline_deployment_bundle_released": True, "operator_release_required": True, "deployment_transport_authorized": False, "direct_machine_transfer": False}


def validate_persisted_fleet_deployment(project: ProjectModel, deployment_id: str) -> dict[str, Any]:
    raw = project.manufacturing_fleet_deployments.get(deployment_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M16_DEPLOYMENT_RECORD_FORMAT or str(raw.get("schema_version") or "") != M16_CONTRACT_VERSION:
        raise ProjectValidationError(f"M16 deployment record {deployment_id} ontbreekt/ongeldig")
    if str(raw.get("deployment_id") or "") != deployment_id or str(raw.get("deployment_record_hash") or "") != _hash_record(raw, "deployment_record_hash"):
        raise ProjectValidationError("M16 deployment record identity/hash ongeldig")
    if not bool(raw.get("offline_deployment_bundle_released")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M16 deployment record veiligheidsflags ongeldig")
    return dict(raw)


def build_fleet_governance_dashboard(project: ProjectModel) -> dict[str, Any]:
    sites = [validate_persisted_fleet_site(project, k) for k in sorted(project.manufacturing_fleet_sites)]
    bindings = []
    for k in sorted(project.manufacturing_fleet_machine_bindings):
        try:
            row = validate_persisted_fleet_machine_binding(project, k, require_current=False); row["current_valid"] = True
            try: validate_persisted_fleet_machine_binding(project, k, require_current=True)
            except Exception: row["current_valid"] = False
        except Exception as exc: row = {"binding_id": k, "current_valid": False, "error": str(exc)}
        bindings.append(row)
    policies = [validate_persisted_fleet_policy(project, k) for k in sorted(project.manufacturing_fleet_policies)]
    approvals = []
    for k in sorted(project.manufacturing_fleet_external_approvals):
        try: row = validate_persisted_external_approval(project, k, require_current=False); row["status"] = "verified"
        except Exception as exc: row = {"approval_id": k, "status": "invalid", "error": str(exc)}
        approvals.append(row)
    deployments = [validate_persisted_fleet_deployment(project, k) for k in sorted(project.manufacturing_fleet_deployments)]
    queue = build_recertification_queue(project, persist=False)
    return {
        "format": "CWS_M16_FLEET_GOVERNANCE_DASHBOARD_V1", "phase": "M16",
        "site_count": len(sites), "binding_count": len(bindings), "policy_count": len(policies), "trusted_signer_count": len(project.manufacturing_fleet_trusted_signers),
        "approval_count": len(approvals), "deployment_count": len(deployments), "recertification_blocking_count": queue["blocking_count"],
        "sites": sites, "bindings": bindings, "policies": policies, "approvals": approvals, "deployments": deployments, "recertification_queue": queue,
        "owner_adapter_certification_authority": False, "offline_deployment_bundle_only": True, "deployment_transport_authorized": False, "direct_machine_transfer": False,
    }


__all__ = [name for name in globals() if not name.startswith("_")]
