"""Canonical Scribing M3 contracts.

ManufacturingMark is a deterministic manufacturing feature derived from current
ManufacturingFace + ContactPatch evidence and a versioned ManufacturingRuleSet.
It is deliberately format/controller neutral: DSTV SI and machine postprocessors
remain later adapters.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectValidationError, stable_sha256

MARK_GEOMETRY_SCHEMA_VERSION = "1.1"
MANUFACTURING_MARK_SCHEMA_VERSION = "1.1"
MANUFACTURING_MARK_SET_SCHEMA_VERSION = "1.0"
MANUFACTURING_RULESET_SCHEMA_VERSION = "1.0"
MANUFACTURING_MARK_STATE_SCHEMA_VERSION = "1.0"
MARK_HASH_VERSION = "cws-manufacturing-mark-v1"
MARK_SET_HASH_VERSION = "cws-manufacturing-mark-set-v1"
RULESET_HASH_VERSION = "cws-manufacturing-ruleset-v1"


class MarkType(str, Enum):
    SCRIBE_LINE = "scribe_line"
    CONTOUR_SCRIBE = "contour_scribe"
    REFERENCE_LINE = "reference_line"
    HOLE_CENTER_CROSS = "hole_center_cross"
    POP_MARK = "pop_mark"
    CENTER_PUNCH = "center_punch"
    POSITION_TEXT = "position_text"
    ASSEMBLY_TEXT = "assembly_text"
    PART_TEXT = "part_text"
    HARD_STAMP_REQUEST = "hard_stamp_request"
    DATUM_MARK = "datum_mark"
    CUSTOM_SYMBOL = "custom_symbol"


class MarkGeometryKind(str, Enum):
    POINT = "point"
    TEXT_ANCHOR = "text_anchor"
    SYMBOL_ANCHOR = "symbol_anchor"
    LINE = "line"
    POLYLINE = "polyline"
    ARC = "arc"
    CIRCLE = "circle"
    COMPOUND = "compound"


class MarkReviewStatus(str, Enum):
    ACCEPTED = "accepted"
    REVIEW = "review"
    BLOCKED = "blocked"
    SUPPRESSED = "suppressed"


class RuleValidationStatus(str, Enum):
    DRAFT = "draft"
    VALIDATED = "validated"
    RETIRED = "retired"


class ContourPolicy(str, Enum):
    FULL_CONTOUR = "full_contour"
    CORNERS_ONLY = "corners_only"
    CENTER_REFERENCE = "center_reference"
    MINIMUM_LINE_SET = "minimum_line_set"
    COMPANY_TEMPLATE = "company_template"


class PredicateOperator(str, Enum):
    EQ = "eq"
    NE = "ne"
    IN = "in"
    NOT_IN = "not_in"
    EXISTS = "exists"


def _finite(value: Any, label: str) -> float:
    try:
        number = float(value)
    except Exception as exc:  # pragma: no cover - defensive conversion
        raise ProjectValidationError(f"{label} is geen geldig getal") from exc
    if not math.isfinite(number):
        raise ProjectValidationError(f"{label} moet eindig zijn")
    return number


def _point2(value: Iterable[Any], label: str) -> tuple[float, float]:
    raw = tuple(value)
    if len(raw) != 2:
        raise ProjectValidationError(f"{label} moet twee componenten bevatten")
    return (_finite(raw[0], label), _finite(raw[1], label))


@dataclass(frozen=True)
class MarkGeometry2D:
    kind: str
    points: tuple[tuple[float, float], ...] = ()
    center: tuple[float, float] | None = None
    radius_mm: float = 0.0
    start_angle_deg: float = 0.0
    end_angle_deg: float = 0.0
    closed: bool = False
    components: tuple["MarkGeometry2D", ...] = ()
    orientation_deg: float = 0.0
    anchor_horizontal: str = "left"
    anchor_vertical: str = "baseline"
    schema_version: str = MARK_GEOMETRY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if str(self.schema_version) not in {"1.0", MARK_GEOMETRY_SCHEMA_VERSION}:
            raise ProjectValidationError(f"Onbekende toekomstige MarkGeometry2D schema-versie {self.schema_version!r}")
        if self.kind not in {item.value for item in MarkGeometryKind}:
            raise ProjectValidationError(f"Onbekende mark geometry kind {self.kind!r}")
        points = tuple(_point2(p, "Mark geometry punt") for p in self.points)
        object.__setattr__(self, "points", points)
        if self.center is not None:
            object.__setattr__(self, "center", _point2(self.center, "Mark geometry middelpunt"))
        radius = _finite(self.radius_mm, "Mark geometry radius")
        if radius < 0:
            raise ProjectValidationError("Mark geometry radius kan niet negatief zijn")
        if self.kind in {MarkGeometryKind.POINT.value, MarkGeometryKind.TEXT_ANCHOR.value, MarkGeometryKind.SYMBOL_ANCHOR.value} and len(points) != 1:
            raise ProjectValidationError("Point/anchor mark geometry vereist exact één punt")
        if self.kind == MarkGeometryKind.LINE.value:
            if len(points) != 2:
                raise ProjectValidationError("Line mark geometry vereist exact twee punten")
            if self.length_mm() <= 0.0:
                raise ProjectValidationError("Line mark geometry heeft nul lengte")
        if self.kind == MarkGeometryKind.POLYLINE.value and len(points) < 2:
            raise ProjectValidationError("Polyline mark geometry vereist minimaal twee punten")
        if self.kind in {MarkGeometryKind.ARC.value, MarkGeometryKind.CIRCLE.value}:
            if self.center is None or radius <= 0.0:
                raise ProjectValidationError("Arc/circle mark geometry mist middelpunt of positieve radius")
            if self.kind == MarkGeometryKind.ARC.value:
                _finite(self.start_angle_deg, "Mark boog beginhoek")
                _finite(self.end_angle_deg, "Mark boog eindhoek")
        if self.kind == MarkGeometryKind.COMPOUND.value and not self.components:
            raise ProjectValidationError("Compound mark geometry mag niet leeg zijn")
        orientation = _finite(self.orientation_deg, "Mark geometry orientation")
        object.__setattr__(self, "orientation_deg", orientation % 360.0)
        if self.anchor_horizontal not in {"left", "middle", "right"}:
            raise ProjectValidationError("Mark geometry anchor_horizontal is ongeldig")
        if self.anchor_vertical not in {"bottom", "middle", "top", "baseline"}:
            raise ProjectValidationError("Mark geometry anchor_vertical is ongeldig")
        for child in self.components:
            child.__post_init__()

    def length_mm(self) -> float:
        if self.kind == MarkGeometryKind.LINE.value:
            a, b = self.points
            return math.hypot(b[0] - a[0], b[1] - a[1])
        if self.kind == MarkGeometryKind.POLYLINE.value:
            total = sum(
                math.hypot(self.points[i + 1][0] - self.points[i][0], self.points[i + 1][1] - self.points[i][1])
                for i in range(len(self.points) - 1)
            )
            if self.closed and len(self.points) > 2:
                total += math.hypot(self.points[0][0] - self.points[-1][0], self.points[0][1] - self.points[-1][1])
            return total
        if self.kind == MarkGeometryKind.CIRCLE.value:
            return math.tau * self.radius_mm
        if self.kind == MarkGeometryKind.ARC.value:
            sweep = (self.end_angle_deg - self.start_angle_deg) % 360.0
            return math.radians(sweep) * self.radius_mm
        if self.kind == MarkGeometryKind.COMPOUND.value:
            return sum(item.length_mm() for item in self.components)
        return 0.0

    def canonical_dict(self) -> dict[str, Any]:
        payload = {
            "schema_version": self.schema_version,
            "kind": self.kind,
            "points": [list(p) for p in self.points],
            "center": list(self.center) if self.center is not None else None,
            "radius_mm": self.radius_mm,
            "start_angle_deg": self.start_angle_deg,
            "end_angle_deg": self.end_angle_deg,
            "closed": self.closed,
            "components": [item.canonical_dict() for item in self.components],
        }
        # Schema 1.0 payloads must remain hash-stable when older projects are
        # reopened.  Orientation/alignment became canonical in M4 / schema 1.1.
        if str(self.schema_version) != "1.0":
            payload.update({
                "orientation_deg": self.orientation_deg,
                "anchor_horizontal": self.anchor_horizontal,
                "anchor_vertical": self.anchor_vertical,
            })
        return payload

    def geometry_hash(self) -> str:
        return stable_sha256(self.canonical_dict())

    def to_dict(self) -> dict[str, Any]:
        return self.canonical_dict()

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "MarkGeometry2D":
        return cls(
            kind=str(value.get("kind") or ""),
            points=tuple(tuple(float(v) for v in p) for p in value.get("points") or []),
            center=tuple(float(v) for v in value["center"]) if value.get("center") is not None else None,
            radius_mm=float(value.get("radius_mm") or 0.0),
            start_angle_deg=float(value.get("start_angle_deg") or 0.0),
            end_angle_deg=float(value.get("end_angle_deg") or 0.0),
            closed=bool(value.get("closed", False)),
            components=tuple(cls.from_dict(item) for item in value.get("components") or []),
            orientation_deg=float(value.get("orientation_deg") or 0.0),
            anchor_horizontal=str(value.get("anchor_horizontal") or "left"),
            anchor_vertical=str(value.get("anchor_vertical") or "baseline"),
            schema_version=str(value.get("schema_version") or MARK_GEOMETRY_SCHEMA_VERSION),
        )


@dataclass(frozen=True)
class RulePredicate:
    field_path: str
    operator: str
    value: Any = None

    def __post_init__(self) -> None:
        if not self.field_path.strip():
            raise ProjectValidationError("Ruleset predicate mist field_path")
        if self.operator not in {item.value for item in PredicateOperator}:
            raise ProjectValidationError(f"Onbekende ruleset predicate operator {self.operator!r}")

    def to_dict(self) -> dict[str, Any]:
        return {"field_path": self.field_path, "operator": self.operator, "value": self.value}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RulePredicate":
        return cls(str(value.get("field_path") or ""), str(value.get("operator") or ""), value.get("value"))


@dataclass(frozen=True)
class ManufacturingRuleSet:
    ruleset_id: str
    version: str = "1.0"
    tenant_scope: str = "default"
    applicable_machine_ids: tuple[str, ...] = ()
    applicable_profile_types: tuple[str, ...] = ()
    inclusion_predicates: tuple[RulePredicate, ...] = ()
    exclusion_predicates: tuple[RulePredicate, ...] = ()
    contact_rules: Mapping[str, Any] = field(default_factory=dict)
    hole_reference_rules: Mapping[str, Any] = field(default_factory=dict)
    text_identification_rules: Mapping[str, Any] = field(default_factory=dict)
    nonplanar_policy: str = "block"
    mirror_policy: str = "preserve_canonical"
    backface_policy: str = "block"
    fallback_face_policy: str = "block"
    output_mapping_policy: Mapping[str, Any] = field(default_factory=dict)
    contour_policy: str = ContourPolicy.FULL_CONTOUR.value
    generate_reference_line: bool = False
    exact_contacts_only: bool = True
    min_edge_distance_mm: float = 2.0
    hole_margin_mm: float = 2.0
    weld_margin_mm: float = 0.0
    avoid_contact_surface: bool = False
    require_explicit_weld_geometry: bool = True
    min_line_length_mm: float = 8.0
    corner_mark_length_mm: float = 25.0
    segment_straight_lines: bool = False
    segment_length_mm: float = 100.0
    segment_gap_mm: float = 15.0
    validation_status: str = RuleValidationStatus.DRAFT.value
    approved_by: str = ""
    approved_at: str = ""
    provenance: Mapping[str, Any] = field(default_factory=dict)
    ruleset_hash: str = ""
    schema_version: str = MANUFACTURING_RULESET_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.ruleset_id.strip():
            raise ProjectValidationError("ManufacturingRuleSet mist ruleset_id")
        if not self.version.strip():
            raise ProjectValidationError("ManufacturingRuleSet mist versie")
        if self.contour_policy not in {item.value for item in ContourPolicy}:
            raise ProjectValidationError(f"Onbekend contourbeleid {self.contour_policy!r}")
        if self.contour_policy == ContourPolicy.COMPANY_TEMPLATE.value:
            template = self.contact_rules.get("company_template") if isinstance(self.contact_rules, Mapping) else None
            indices = template.get("edge_indices") if isinstance(template, Mapping) else None
            if not isinstance(indices, (list, tuple)) or not indices:
                raise ProjectValidationError("company_template contourbeleid vereist declaratieve edge_indices")
            if any(not isinstance(index, int) or isinstance(index, bool) or index < 0 for index in indices):
                raise ProjectValidationError("company_template edge_indices moeten niet-negatieve integers zijn")
        if self.validation_status not in {item.value for item in RuleValidationStatus}:
            raise ProjectValidationError(f"Onbekende ruleset validation status {self.validation_status!r}")
        if self.nonplanar_policy not in {"block", "trim_planar_subset", "review"}:
            raise ProjectValidationError(f"Onbekend nonplanar_policy {self.nonplanar_policy!r}")
        if self.mirror_policy not in {"preserve_canonical", "explicit_only", "block"}:
            raise ProjectValidationError(f"Onbekend mirror_policy {self.mirror_policy!r}")
        if self.backface_policy not in {"block", "allow_explicit", "review"}:
            raise ProjectValidationError(f"Onbekend backface_policy {self.backface_policy!r}")
        if self.fallback_face_policy not in {"block", "adjacent_explicit_only", "review"}:
            raise ProjectValidationError(f"Onbekend fallback_face_policy {self.fallback_face_policy!r}")
        for name in (
            "min_edge_distance_mm",
            "hole_margin_mm",
            "weld_margin_mm",
            "min_line_length_mm",
            "corner_mark_length_mm",
            "segment_length_mm",
            "segment_gap_mm",
        ):
            number = _finite(getattr(self, name), f"Ruleset {name}")
            if number < 0.0:
                raise ProjectValidationError(f"Ruleset {name} kan niet negatief zijn")
            # Canonicalize numeric policy values before hashing.  Without this,
            # semantically equal values such as 0 and 0.0 serialize differently
            # and break persisted ruleset hash roundtrips.
            object.__setattr__(self, name, float(number))
        if self.segment_straight_lines and self.segment_length_mm <= 0.0:
            raise ProjectValidationError("Segmentatie vereist positieve segment_length_mm")
        for predicate in (*self.inclusion_predicates, *self.exclusion_predicates):
            predicate.__post_init__()
        expected = stable_sha256(self.hash_payload())
        if self.ruleset_hash and self.ruleset_hash != expected:
            raise ProjectValidationError(f"Ruleset {self.ruleset_id} heeft ongeldige hash")
        object.__setattr__(self, "ruleset_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": RULESET_HASH_VERSION,
            "schema_version": self.schema_version,
            "ruleset_id": self.ruleset_id,
            "version": self.version,
            "tenant_scope": self.tenant_scope,
            "applicable_machine_ids": list(self.applicable_machine_ids),
            "applicable_profile_types": list(self.applicable_profile_types),
            "inclusion_predicates": [item.to_dict() for item in self.inclusion_predicates],
            "exclusion_predicates": [item.to_dict() for item in self.exclusion_predicates],
            "contact_rules": dict(self.contact_rules),
            "hole_reference_rules": dict(self.hole_reference_rules),
            "text_identification_rules": dict(self.text_identification_rules),
            "nonplanar_policy": self.nonplanar_policy,
            "mirror_policy": self.mirror_policy,
            "backface_policy": self.backface_policy,
            "fallback_face_policy": self.fallback_face_policy,
            "output_mapping_policy": dict(self.output_mapping_policy),
            "contour_policy": self.contour_policy,
            "generate_reference_line": self.generate_reference_line,
            "exact_contacts_only": self.exact_contacts_only,
            "min_edge_distance_mm": self.min_edge_distance_mm,
            "hole_margin_mm": self.hole_margin_mm,
            "weld_margin_mm": self.weld_margin_mm,
            "avoid_contact_surface": self.avoid_contact_surface,
            "require_explicit_weld_geometry": self.require_explicit_weld_geometry,
            "min_line_length_mm": self.min_line_length_mm,
            "corner_mark_length_mm": self.corner_mark_length_mm,
            "segment_straight_lines": self.segment_straight_lines,
            "segment_length_mm": self.segment_length_mm,
            "segment_gap_mm": self.segment_gap_mm,
            "validation_status": self.validation_status,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "provenance": dict(self.provenance), "ruleset_hash": self.ruleset_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ManufacturingRuleSet":
        return cls(
            ruleset_id=str(value.get("ruleset_id") or ""),
            version=str(value.get("version") or "1.0"),
            tenant_scope=str(value.get("tenant_scope") or "default"),
            applicable_machine_ids=tuple(str(x) for x in value.get("applicable_machine_ids") or []),
            applicable_profile_types=tuple(str(x) for x in value.get("applicable_profile_types") or []),
            inclusion_predicates=tuple(RulePredicate.from_dict(x) for x in value.get("inclusion_predicates") or []),
            exclusion_predicates=tuple(RulePredicate.from_dict(x) for x in value.get("exclusion_predicates") or []),
            contact_rules=dict(value.get("contact_rules") or {}),
            hole_reference_rules=dict(value.get("hole_reference_rules") or {}),
            text_identification_rules=dict(value.get("text_identification_rules") or {}),
            nonplanar_policy=str(value.get("nonplanar_policy") or "block"),
            mirror_policy=str(value.get("mirror_policy") or "preserve_canonical"),
            backface_policy=str(value.get("backface_policy") or "block"),
            fallback_face_policy=str(value.get("fallback_face_policy") or "block"),
            output_mapping_policy=dict(value.get("output_mapping_policy") or {}),
            contour_policy=str(value.get("contour_policy") or ContourPolicy.FULL_CONTOUR.value),
            generate_reference_line=bool(value.get("generate_reference_line", False)),
            exact_contacts_only=bool(value.get("exact_contacts_only", True)),
            min_edge_distance_mm=float(value.get("min_edge_distance_mm") or 0.0),
            hole_margin_mm=float(value.get("hole_margin_mm") or 0.0),
            weld_margin_mm=float(value.get("weld_margin_mm") or 0.0),
            avoid_contact_surface=bool(value.get("avoid_contact_surface", False)),
            require_explicit_weld_geometry=bool(value.get("require_explicit_weld_geometry", True)),
            min_line_length_mm=float(value.get("min_line_length_mm") or 0.0),
            corner_mark_length_mm=float(value.get("corner_mark_length_mm") or 0.0),
            segment_straight_lines=bool(value.get("segment_straight_lines", False)),
            segment_length_mm=float(value.get("segment_length_mm") or 0.0),
            segment_gap_mm=float(value.get("segment_gap_mm") or 0.0),
            validation_status=str(value.get("validation_status") or RuleValidationStatus.DRAFT.value),
            approved_by=str(value.get("approved_by") or ""),
            approved_at=str(value.get("approved_at") or ""),
            provenance=dict(value.get("provenance") or {}),
            ruleset_hash=str(value.get("ruleset_hash") or ""),
            schema_version=str(value.get("schema_version") or MANUFACTURING_RULESET_SCHEMA_VERSION),
        )


@dataclass(frozen=True)
class ManufacturingMark:
    mark_id: str
    part_id: str
    assembly_id: str
    source_part_id: str
    target_part_id: str
    target_face_id: str
    mark_type: str
    geometry_2d: MarkGeometry2D
    purpose: str
    generated_by_rule_id: str
    source_contact_id: str
    text_payload: str = ""
    text_height_mm: float = 0.0
    depth_mm: float = 0.0
    line_width_mm: float = 0.0
    requested_operation: str = "scribe"
    source_feature_ids: tuple[str, ...] = ()
    machine_constraints: Mapping[str, Any] = field(default_factory=dict)
    suppression_reason: str = ""
    review_status: str = MarkReviewStatus.ACCEPTED.value
    provenance: Mapping[str, Any] = field(default_factory=dict)
    source_contact_hash: str = ""
    target_face_geometry_hash: str = ""
    ruleset_hash: str = ""
    mark_hash: str = ""
    schema_version: str = MANUFACTURING_MARK_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if str(self.schema_version) not in {"1.0", MANUFACTURING_MARK_SCHEMA_VERSION}:
            raise ProjectValidationError(f"Onbekende toekomstige ManufacturingMark schema-versie {self.schema_version!r}")
        if not self.mark_id or not self.part_id or not self.assembly_id:
            raise ProjectValidationError("ManufacturingMark mist identiteit")
        if self.part_id != self.target_part_id:
            raise ProjectValidationError("ManufacturingMark part_id moet target_part_id zijn")
        if not self.source_part_id or not self.target_part_id or not self.target_face_id:
            raise ProjectValidationError("ManufacturingMark mist source/target/face")
        if self.mark_type not in {item.value for item in MarkType}:
            raise ProjectValidationError(f"Onbekend mark_type {self.mark_type!r}")
        if self.review_status not in {item.value for item in MarkReviewStatus}:
            raise ProjectValidationError(f"Onbekende mark review status {self.review_status!r}")
        if not self.generated_by_rule_id:
            raise ProjectValidationError("ManufacturingMark mist ruleset provenance")
        contact_types = {MarkType.SCRIBE_LINE.value, MarkType.CONTOUR_SCRIBE.value, MarkType.REFERENCE_LINE.value}
        hole_types = {MarkType.HOLE_CENTER_CROSS.value, MarkType.POP_MARK.value, MarkType.CENTER_PUNCH.value}
        text_types = {MarkType.POSITION_TEXT.value, MarkType.ASSEMBLY_TEXT.value, MarkType.PART_TEXT.value, MarkType.HARD_STAMP_REQUEST.value}
        if self.mark_type in contact_types and not self.source_contact_id:
            raise ProjectValidationError("Scribe/reference ManufacturingMark mist source contact")
        if self.mark_type in hole_types and not self.source_feature_ids:
            raise ProjectValidationError("Hole-reference ManufacturingMark mist source feature")
        if self.mark_type in text_types and not self.text_payload.strip():
            raise ProjectValidationError("Identification ManufacturingMark mist text_payload")
        self.geometry_2d.__post_init__()
        for name in ("text_height_mm", "depth_mm", "line_width_mm"):
            number = _finite(getattr(self, name), f"ManufacturingMark {name}")
            if number < 0.0:
                raise ProjectValidationError(f"ManufacturingMark {name} kan niet negatief zijn")
            object.__setattr__(self, name, float(number))
        expected = stable_sha256(self.hash_payload())
        if self.mark_hash and self.mark_hash != expected:
            raise ProjectValidationError(f"ManufacturingMark {self.mark_id} heeft ongeldige mark_hash")
        object.__setattr__(self, "mark_hash", expected)

    @property
    def length_mm(self) -> float:
        return self.geometry_2d.length_mm()

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": MARK_HASH_VERSION,
            "schema_version": self.schema_version,
            "mark_id": self.mark_id,
            "part_id": self.part_id,
            "assembly_id": self.assembly_id,
            "source_part_id": self.source_part_id,
            "target_part_id": self.target_part_id,
            "target_face_id": self.target_face_id,
            "target_face_geometry_hash": self.target_face_geometry_hash,
            "mark_type": self.mark_type,
            "geometry_2d": self.geometry_2d.canonical_dict(),
            "purpose": self.purpose,
            "text_payload": self.text_payload,
            "text_height_mm": self.text_height_mm,
            "depth_mm": self.depth_mm,
            "line_width_mm": self.line_width_mm,
            "generated_by_rule_id": self.generated_by_rule_id,
            "source_contact_id": self.source_contact_id,
            "source_contact_hash": self.source_contact_hash,
            "source_feature_ids": list(self.source_feature_ids),
            "requested_operation": self.requested_operation,
            "machine_constraints": dict(self.machine_constraints),
            "suppression_reason": self.suppression_reason,
            "review_status": self.review_status,
            "ruleset_hash": self.ruleset_hash,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "provenance": dict(self.provenance), "mark_hash": self.mark_hash, "length_mm": self.length_mm}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ManufacturingMark":
        return cls(
            mark_id=str(value.get("mark_id") or ""),
            part_id=str(value.get("part_id") or value.get("target_part_id") or ""),
            assembly_id=str(value.get("assembly_id") or ""),
            source_part_id=str(value.get("source_part_id") or ""),
            target_part_id=str(value.get("target_part_id") or ""),
            target_face_id=str(value.get("target_face_id") or ""),
            mark_type=str(value.get("mark_type") or ""),
            geometry_2d=MarkGeometry2D.from_dict(dict(value.get("geometry_2d") or {})),
            purpose=str(value.get("purpose") or ""),
            generated_by_rule_id=str(value.get("generated_by_rule_id") or ""),
            source_contact_id=str(value.get("source_contact_id") or ""),
            text_payload=str(value.get("text_payload") or ""),
            text_height_mm=float(value.get("text_height_mm") or 0.0),
            depth_mm=float(value.get("depth_mm") or 0.0),
            line_width_mm=float(value.get("line_width_mm") or 0.0),
            requested_operation=str(value.get("requested_operation") or "scribe"),
            source_feature_ids=tuple(str(x) for x in value.get("source_feature_ids") or []),
            machine_constraints=dict(value.get("machine_constraints") or {}),
            suppression_reason=str(value.get("suppression_reason") or ""),
            review_status=str(value.get("review_status") or MarkReviewStatus.ACCEPTED.value),
            provenance=dict(value.get("provenance") or {}),
            source_contact_hash=str(value.get("source_contact_hash") or ""),
            target_face_geometry_hash=str(value.get("target_face_geometry_hash") or ""),
            ruleset_hash=str(value.get("ruleset_hash") or ""),
            mark_hash=str(value.get("mark_hash") or ""),
            schema_version=str(value.get("schema_version") or MANUFACTURING_MARK_SCHEMA_VERSION),
        )


@dataclass(frozen=True)
class MarkSuppressionRecord:
    suppression_id: str
    assembly_id: str
    source_contact_id: str
    target_part_id: str
    target_face_id: str
    rule_id: str
    code: str
    reason: str
    original_geometry: MarkGeometry2D | None = None
    resulting_geometry: tuple[MarkGeometry2D, ...] = ()
    provenance: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "suppression_id": self.suppression_id,
            "assembly_id": self.assembly_id,
            "source_contact_id": self.source_contact_id,
            "target_part_id": self.target_part_id,
            "target_face_id": self.target_face_id,
            "rule_id": self.rule_id,
            "code": self.code,
            "reason": self.reason,
            "original_geometry": self.original_geometry.to_dict() if self.original_geometry else None,
            "resulting_geometry": [item.to_dict() for item in self.resulting_geometry],
            "provenance": dict(self.provenance),
        }


def mark_set_hash(assembly_id: str, ruleset_hash: str, marks: Iterable[ManufacturingMark]) -> str:
    rows = sorted(marks, key=lambda item: item.mark_id)
    return stable_sha256(
        {
            "hash_version": MARK_SET_HASH_VERSION,
            "schema_version": MANUFACTURING_MARK_SET_SCHEMA_VERSION,
            "assembly_id": assembly_id,
            "ruleset_hash": ruleset_hash,
            "marks": [item.mark_hash for item in rows],
        }
    )


def validate_mark_set(assembly_id: str, ruleset_hash: str, marks: Iterable[ManufacturingMark]) -> str:
    rows = list(marks)
    seen: set[str] = set()
    for mark in rows:
        if mark.assembly_id != assembly_id:
            raise ProjectValidationError(f"Mark {mark.mark_id} hoort niet bij assembly {assembly_id}")
        if mark.ruleset_hash != ruleset_hash:
            raise ProjectValidationError(f"Mark {mark.mark_id} is niet aan de actuele ruleset gebonden")
        if mark.mark_id in seen:
            raise ProjectValidationError(f"Dubbele ManufacturingMark ID {mark.mark_id}")
        seen.add(mark.mark_id)
        if ManufacturingMark.from_dict(mark.to_dict()).mark_hash != mark.mark_hash:
            raise ProjectValidationError(f"ManufacturingMark {mark.mark_id} faalt roundtrip")
    return mark_set_hash(assembly_id, ruleset_hash, rows)


def default_scribing_ruleset() -> ManufacturingRuleSet:
    """Deterministic internal M3 baseline profile.

    It is validated for the bounded M3 planar/contact scope only; it is not a
    machine/controller release. Weld clearance defaults to zero because M2 does
    not yet provide exact weld-path geometry. A non-zero weld margin therefore
    requires explicit geometric weld zones in the target part properties.
    """
    return ManufacturingRuleSet(
        ruleset_id="cws-m3-default-scribing-v1",
        version="1.0",
        tenant_scope="cws-internal-default",
        contour_policy=ContourPolicy.FULL_CONTOUR.value,
        generate_reference_line=False,
        exact_contacts_only=True,
        min_edge_distance_mm=2.0,
        hole_margin_mm=2.0,
        weld_margin_mm=0.0,
        avoid_contact_surface=False,
        require_explicit_weld_geometry=True,
        min_line_length_mm=8.0,
        segment_straight_lines=False,
        validation_status=RuleValidationStatus.VALIDATED.value,
        approved_by="CWS deterministic M3 baseline",
        approved_at="schema-defined",
        provenance={"phase": "M3", "scope": "planar_contact_scribing", "machine_release": False},
    )


def default_m4_ruleset() -> ManufacturingRuleSet:
    """Deterministic M4 baseline for hole references and identification.

    This remains machine/controller neutral.  It adds canonical reference and
    text intent to the M3 contact-scribing baseline, but never releases DSTV SI
    or proprietary machine output.
    """
    return ManufacturingRuleSet(
        ruleset_id="cws-m4-default-marking-v1",
        version="1.0",
        tenant_scope="cws-internal-default",
        contour_policy=ContourPolicy.FULL_CONTOUR.value,
        generate_reference_line=False,
        exact_contacts_only=True,
        min_edge_distance_mm=2.0,
        hole_margin_mm=2.0,
        weld_margin_mm=0.0,
        avoid_contact_surface=False,
        require_explicit_weld_geometry=True,
        min_line_length_mm=8.0,
        segment_straight_lines=False,
        hole_reference_rules={
            "enabled": True,
            "mode": "crosshair",
            "arm_length_mm": 12.0,
            "gap_from_hole_mm": 2.0,
            "minimum_arm_length_mm": 4.0,
            "profile_specific": {},
        },
        text_identification_rules={
            "enabled": True,
            "emit_assembly_text_on_main": True,
            "emit_part_text": True,
            "emit_position_text": False,
            "assembly_template": "{assembly_mark}",
            "part_template": "{part_position}",
            "position_template": "{assembly_mark}-{part_position}",
            "company_code": "",
            "batch_property": "production_batch",
            "sequence_property": "production_sequence",
            "text_height_mm": 8.0,
            "edge_margin_mm": 10.0,
            "hole_margin_mm": 5.0,
            "other_mark_margin_mm": 3.0,
            "search_step_mm": 5.0,
            "anchor_horizontal": "left",
            "anchor_vertical": "bottom",
            "preferred_face_roles": [
                "plate_front", "top_outer", "web_left", "web_outer",
                "flange_a_outer", "leg_a_outer", "end_start", "end_finish"
            ],
            "orientation_deg": 0.0,
        },
        mirror_policy="preserve_canonical",
        validation_status=RuleValidationStatus.VALIDATED.value,
        approved_by="CWS deterministic M4 baseline",
        approved_at="schema-defined",
        provenance={"phase": "M4", "scope": "hole_references_identification", "machine_release": False},
    )


__all__ = [
    "MARK_GEOMETRY_SCHEMA_VERSION",
    "MANUFACTURING_MARK_SCHEMA_VERSION",
    "MANUFACTURING_MARK_SET_SCHEMA_VERSION",
    "MANUFACTURING_RULESET_SCHEMA_VERSION",
    "MANUFACTURING_MARK_STATE_SCHEMA_VERSION",
    "MarkType",
    "MarkGeometryKind",
    "MarkReviewStatus",
    "RuleValidationStatus",
    "ContourPolicy",
    "PredicateOperator",
    "MarkGeometry2D",
    "RulePredicate",
    "ManufacturingRuleSet",
    "ManufacturingMark",
    "MarkSuppressionRecord",
    "mark_set_hash",
    "validate_mark_set",
    "default_scribing_ruleset",
    "default_m4_ruleset",
]
