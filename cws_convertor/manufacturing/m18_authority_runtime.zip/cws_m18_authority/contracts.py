"""Canonical manufacturing-face contracts.

ManufacturingFace is geometry truth. Format/controller sides (DSTV v/h/o/u, etc.)
are adapter metadata and must never define canonical face identity.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectValidationError, stable_sha256

MANUFACTURING_FACE_SCHEMA_VERSION = "1.0"
MANUFACTURING_FACE_SET_SCHEMA_VERSION = "1.0"
FACE_FRAME_CONVENTION = "cws_part_local_production_uvn_v1"
FACE_GEOMETRY_HASH_VERSION = "cws-manufacturing-face-geometry-v1"
FACE_SET_HASH_VERSION = "cws-manufacturing-face-set-v1"
FRAME_TOLERANCE = 1e-8


class ManufacturingFaceRole(str, Enum):
    LONGITUDINAL_PRIMARY = "longitudinal_primary"
    LONGITUDINAL_SECONDARY = "longitudinal_secondary"
    TOP_OUTER = "top_outer"
    TOP_INNER = "top_inner"
    BOTTOM_OUTER = "bottom_outer"
    BOTTOM_INNER = "bottom_inner"
    WEB_LEFT = "web_left"
    WEB_RIGHT = "web_right"
    WEB_OUTER = "web_outer"
    WEB_INNER = "web_inner"
    FLANGE_A_OUTER = "flange_a_outer"
    FLANGE_A_INNER = "flange_a_inner"
    FLANGE_B_OUTER = "flange_b_outer"
    FLANGE_B_INNER = "flange_b_inner"
    LEG_A_OUTER = "leg_a_outer"
    LEG_A_INNER = "leg_a_inner"
    LEG_B_OUTER = "leg_b_outer"
    LEG_B_INNER = "leg_b_inner"
    PLATE_FRONT = "plate_front"
    PLATE_BACK = "plate_back"
    END_START = "end_start"
    END_FINISH = "end_finish"
    ROUND_SURFACE = "round_surface"
    CUSTOM = "custom"


class ManufacturingSurfaceType(str, Enum):
    PLANE = "plane"
    CYLINDER = "cylinder"
    CONE = "cone"
    ANALYTIC_OTHER = "analytic_other"
    UNSUPPORTED = "unsupported"


class FaceProofStatus(str, Enum):
    EXACT = "exact"
    USER_CONFIRMED = "user_confirmed"
    REVIEW = "review"
    BLOCKED = "blocked"


def _finite(value: Any, label: str) -> float:
    try:
        result = float(value)
    except Exception as exc:
        raise ProjectValidationError(f"{label} is geen geldig getal") from exc
    if not math.isfinite(result):
        raise ProjectValidationError(f"{label} moet eindig zijn")
    return result


def _vec3(value: Iterable[Any], label: str) -> tuple[float, float, float]:
    values = tuple(value)
    if len(values) != 3:
        raise ProjectValidationError(f"{label} moet uit drie componenten bestaan")
    return tuple(_finite(v, label) for v in values)  # type: ignore[return-value]


def _vec2(value: Iterable[Any], label: str) -> tuple[float, float]:
    values = tuple(value)
    if len(values) != 2:
        raise ProjectValidationError(f"{label} moet uit twee componenten bestaan")
    return tuple(_finite(v, label) for v in values)  # type: ignore[return-value]


def _dot(a: tuple[float,float,float], b: tuple[float,float,float]) -> float:
    return sum(x*y for x,y in zip(a,b))

def _cross(a: tuple[float,float,float], b: tuple[float,float,float]) -> tuple[float,float,float]:
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def _norm(a: tuple[float,float,float]) -> float:
    return math.sqrt(_dot(a,a))

def _sub(a: tuple[float,float,float], b: tuple[float,float,float]) -> tuple[float,float,float]:
    return (a[0]-b[0],a[1]-b[1],a[2]-b[2])

def _add(a: tuple[float,float,float], b: tuple[float,float,float]) -> tuple[float,float,float]:
    return (a[0]+b[0],a[1]+b[1],a[2]+b[2])

def _scale(a: tuple[float,float,float], s: float) -> tuple[float,float,float]:
    return (a[0]*s,a[1]*s,a[2]*s)


@dataclass(frozen=True)
class FaceLocalFrame:
    origin_mm: tuple[float,float,float]
    u_axis: tuple[float,float,float]
    v_axis: tuple[float,float,float]
    normal: tuple[float,float,float]
    convention: str = FACE_FRAME_CONVENTION
    tolerance: float = FRAME_TOLERANCE

    def __post_init__(self) -> None:
        object.__setattr__(self, "origin_mm", _vec3(self.origin_mm, "Face-origin"))
        object.__setattr__(self, "u_axis", _vec3(self.u_axis, "Face U-as"))
        object.__setattr__(self, "v_axis", _vec3(self.v_axis, "Face V-as"))
        object.__setattr__(self, "normal", _vec3(self.normal, "Face normaal"))
        tol = abs(_finite(self.tolerance, "Face-frame tolerantie")) or FRAME_TOLERANCE
        for label, axis in (("U",self.u_axis),("V",self.v_axis),("N",self.normal)):
            if abs(_norm(axis)-1.0) > tol:
                raise ProjectValidationError(f"Face {label}-as is niet genormaliseerd")
        if any(abs(_dot(a,b)) > tol for a,b in ((self.u_axis,self.v_axis),(self.u_axis,self.normal),(self.v_axis,self.normal))):
            raise ProjectValidationError("Face-frameassen zijn niet orthogonaal")
        if _norm(_sub(_cross(self.u_axis,self.v_axis), self.normal)) > tol*10:
            raise ProjectValidationError("Face-frame is niet rechterhandig (U x V != N)")

    def part_xyz(self, u_mm: float, v_mm: float, n_mm: float=0.0) -> tuple[float,float,float]:
        return _add(self.origin_mm, _add(_scale(self.u_axis,_finite(u_mm,"U")), _add(_scale(self.v_axis,_finite(v_mm,"V")), _scale(self.normal,_finite(n_mm,"N")))))

    def local_uvn(self, point_xyz: Iterable[Any]) -> tuple[float,float,float]:
        delta=_sub(_vec3(point_xyz,"3D-punt"),self.origin_mm)
        return (_dot(delta,self.u_axis),_dot(delta,self.v_axis),_dot(delta,self.normal))

    def transformed(self, transform: Any) -> "FaceLocalFrame":
        """Return a non-canonical global/view frame from a rigid 4x4 transform.

        The canonical persisted face always remains part-local; this helper is
        intentionally one-way presentation/manufacturing-placement support.
        """
        matrix = getattr(transform, "matrix", transform)
        if not isinstance(matrix, (list, tuple)) or len(matrix) != 4:
            raise ProjectValidationError("Face-transform vereist een 4x4 matrix")
        def point(p):
            return tuple(sum(float(matrix[r][c]) * (p[c] if c < 3 else 1.0) for c in range(4)) for r in range(3))
        def vector(v):
            return tuple(sum(float(matrix[r][c]) * v[c] for c in range(3)) for r in range(3))
        return FaceLocalFrame(point(self.origin_mm), vector(self.u_axis), vector(self.v_axis), vector(self.normal), self.convention, self.tolerance)

    def to_dict(self)->dict[str,Any]:
        return {"origin_mm":list(self.origin_mm),"u_axis":list(self.u_axis),"v_axis":list(self.v_axis),"normal":list(self.normal),"convention":self.convention,"tolerance":self.tolerance}

    @classmethod
    def from_dict(cls,value:Mapping[str,Any])->"FaceLocalFrame":
        return cls(tuple(value.get("origin_mm") or (0,0,0)),tuple(value.get("u_axis") or (1,0,0)),tuple(value.get("v_axis") or (0,1,0)),tuple(value.get("normal") or (0,0,1)),str(value.get("convention") or FACE_FRAME_CONVENTION),float(value.get("tolerance") or FRAME_TOLERANCE))


@dataclass(frozen=True)
class FaceBoundarySegment2D:
    kind: str
    start: tuple[float,float] | None = None
    end: tuple[float,float] | None = None
    center: tuple[float,float] | None = None
    radius_mm: float = 0.0
    start_angle_deg: float = 0.0
    end_angle_deg: float = 0.0

    def validate(self)->None:
        if self.kind=="line":
            if self.start is None or self.end is None: raise ProjectValidationError("Face-boundarylijn mist begin- of eindpunt")
            _vec2(self.start,"Face-boundary start"); _vec2(self.end,"Face-boundary einde"); return
        if self.kind in {"arc","circle"}:
            if self.center is None: raise ProjectValidationError("Face-boog/cirkel mist middelpunt")
            _vec2(self.center,"Face-boundary middelpunt")
            if _finite(self.radius_mm,"Face-boundary radius")<=0: raise ProjectValidationError("Face-boundary radius moet groter dan nul zijn")
            if self.kind=="arc": _finite(self.start_angle_deg,"Boogbeginhoek"); _finite(self.end_angle_deg,"Boogeindhoek")
            return
        raise ProjectValidationError(f"Onbekend face-boundarysegment {self.kind!r}")

    def to_dict(self)->dict[str,Any]:
        d=asdict(self)
        for key in ("start","end","center"):
            if d[key] is not None: d[key]=list(d[key])
        return d

    @classmethod
    def from_dict(cls,value:Mapping[str,Any])->"FaceBoundarySegment2D":
        tup=lambda k: tuple(value[k]) if value.get(k) is not None else None
        return cls(str(value.get("kind") or ""),tup("start"),tup("end"),tup("center"),float(value.get("radius_mm") or 0),float(value.get("start_angle_deg") or 0),float(value.get("end_angle_deg") or 0))


@dataclass(frozen=True)
class FaceBoundaryLoop2D:
    segments: tuple[FaceBoundarySegment2D,...]
    is_hole: bool=False
    def validate(self)->None:
        if not self.segments: raise ProjectValidationError("Face-boundaryloop mag niet leeg zijn")
        for s in self.segments: s.validate()
        if all(s.kind == "line" for s in self.segments):
            tol = 1e-7
            for index, segment in enumerate(self.segments):
                nxt = self.segments[(index + 1) % len(self.segments)]
                if segment.end is None or nxt.start is None:
                    raise ProjectValidationError("Face-boundarylijn mist topologische aansluiting")
                if math.hypot(segment.end[0]-nxt.start[0], segment.end[1]-nxt.start[1]) > tol:
                    raise ProjectValidationError("Face-boundaryloop is niet gesloten/continu")
    def to_dict(self)->dict[str,Any]: return {"segments":[s.to_dict() for s in self.segments],"is_hole":self.is_hole}
    @classmethod
    def from_dict(cls,value:Mapping[str,Any])->"FaceBoundaryLoop2D": return cls(tuple(FaceBoundarySegment2D.from_dict(x) for x in value.get("segments") or []),bool(value.get("is_hole",False)))


def polygon_loop(points: Iterable[tuple[float,float]], *, is_hole: bool=False)->FaceBoundaryLoop2D:
    pts=[_vec2(p,"Face-boundarypunt") for p in points]
    if len(pts)<3: raise ProjectValidationError("Face-polygoon vereist minimaal drie punten")
    segs=[]
    for i,p in enumerate(pts): segs.append(FaceBoundarySegment2D("line",p,pts[(i+1)%len(pts)]))
    return FaceBoundaryLoop2D(tuple(segs),is_hole)

def rectangle_loop(u0:float,v0:float,u1:float,v1:float,*,is_hole:bool=False)->FaceBoundaryLoop2D:
    return polygon_loop([(u0,v0),(u1,v0),(u1,v1),(u0,v1)],is_hole=is_hole)

def circle_loop(radius_mm:float,*,is_hole:bool=False)->FaceBoundaryLoop2D:
    return FaceBoundaryLoop2D((FaceBoundarySegment2D("circle",center=(0.0,0.0),radius_mm=radius_mm),),is_hole)


@dataclass(frozen=True)
class DstvFaceMappingCandidate:
    dstv_side: str
    source: str
    proof_status: str = FaceProofStatus.USER_CONFIRMED.value
    mapping_hash: str = ""
    def __post_init__(self)->None:
        side=self.dstv_side.strip().lower()
        if side not in {"v","h","o","u"}: raise ProjectValidationError(f"Ongeldige expliciete DSTV-zijde {self.dstv_side!r}")
        object.__setattr__(self,"dstv_side",side)
        if self.proof_status not in {FaceProofStatus.EXACT.value,FaceProofStatus.USER_CONFIRMED.value,FaceProofStatus.REVIEW.value}: raise ProjectValidationError("Ongeldige DSTV face proof-status")
    def to_dict(self)->dict[str,Any]: return asdict(self)
    @classmethod
    def from_dict(cls,value:Mapping[str,Any])->"DstvFaceMappingCandidate": return cls(str(value.get("dstv_side") or ""),str(value.get("source") or ""),str(value.get("proof_status") or FaceProofStatus.USER_CONFIRMED.value),str(value.get("mapping_hash") or ""))


@dataclass(frozen=True)
class ManufacturingFace:
    face_id: str
    part_id: str
    semantic_role: str
    canonical_kind: str
    source_geometry_ref: str
    local_frame: FaceLocalFrame
    surface_type: str
    boundary_loops_2d: tuple[FaceBoundaryLoop2D,...] = ()
    area_mm2: float = 0.0
    orientation_class: str = ""
    material_side: str = "material"
    accessibility: tuple[str,...] = ()
    surface_parameters: Mapping[str,Any] = field(default_factory=dict)
    dstv_side_candidates: tuple[DstvFaceMappingCandidate,...] = ()
    machine_aliases: Mapping[str,str] = field(default_factory=dict)
    proof_status: str = FaceProofStatus.EXACT.value
    provenance: Mapping[str,Any] = field(default_factory=dict)
    confidence: float = 1.0
    geometry_hash: str = ""
    schema_version: str = MANUFACTURING_FACE_SCHEMA_VERSION

    def __post_init__(self)->None:
        if not self.face_id or not self.part_id: raise ProjectValidationError("ManufacturingFace mist face_id of part_id")
        if self.surface_type not in {x.value for x in ManufacturingSurfaceType}: raise ProjectValidationError(f"Onbekend manufacturing surface type {self.surface_type!r}")
        if self.proof_status not in {x.value for x in FaceProofStatus}: raise ProjectValidationError(f"Onbekende face proof-status {self.proof_status!r}")
        area=_finite(self.area_mm2,"Face-oppervlak")
        if area<0: raise ProjectValidationError("Face-oppervlak kan niet negatief zijn")
        conf=_finite(self.confidence,"Face confidence")
        if not 0<=conf<=1: raise ProjectValidationError("Face confidence moet tussen 0 en 1 liggen")
        self.local_frame.__post_init__()
        for loop in self.boundary_loops_2d: loop.validate()
        expected=stable_sha256(self.geometry_payload())
        if self.geometry_hash and self.geometry_hash!=expected: raise ProjectValidationError(f"ManufacturingFace {self.face_id} heeft ongeldige geometry_hash")
        object.__setattr__(self,"geometry_hash",expected)

    def geometry_payload(self)->dict[str,Any]:
        # Excludes adapter/proof/audit metadata: canonical geometric identity is format-independent.
        return {"hash_version":FACE_GEOMETRY_HASH_VERSION,"schema_version":self.schema_version,"face_id":self.face_id,"part_id":self.part_id,"semantic_role":self.semantic_role,"canonical_kind":self.canonical_kind,"source_geometry_ref":self.source_geometry_ref,"local_frame":self.local_frame.to_dict(),"surface_type":self.surface_type,"boundary_loops_2d":[x.to_dict() for x in self.boundary_loops_2d],"area_mm2":self.area_mm2,"orientation_class":self.orientation_class,"material_side":self.material_side,"surface_parameters":dict(self.surface_parameters)}

    def to_dict(self)->dict[str,Any]:
        return {**self.geometry_payload(),"accessibility":list(self.accessibility),"dstv_side_candidates":[x.to_dict() for x in self.dstv_side_candidates],"machine_aliases":dict(self.machine_aliases),"proof_status":self.proof_status,"provenance":dict(self.provenance),"confidence":self.confidence,"geometry_hash":self.geometry_hash}

    @classmethod
    def from_dict(cls,value:Mapping[str,Any])->"ManufacturingFace":
        return cls(face_id=str(value.get("face_id") or ""),part_id=str(value.get("part_id") or ""),semantic_role=str(value.get("semantic_role") or ""),canonical_kind=str(value.get("canonical_kind") or ""),source_geometry_ref=str(value.get("source_geometry_ref") or ""),local_frame=FaceLocalFrame.from_dict(dict(value.get("local_frame") or {})),surface_type=str(value.get("surface_type") or ""),boundary_loops_2d=tuple(FaceBoundaryLoop2D.from_dict(x) for x in value.get("boundary_loops_2d") or []),area_mm2=float(value.get("area_mm2") or 0),orientation_class=str(value.get("orientation_class") or ""),material_side=str(value.get("material_side") or "material"),accessibility=tuple(str(x) for x in value.get("accessibility") or []),surface_parameters=dict(value.get("surface_parameters") or {}),dstv_side_candidates=tuple(DstvFaceMappingCandidate.from_dict(x) for x in value.get("dstv_side_candidates") or []),machine_aliases=dict(value.get("machine_aliases") or {}),proof_status=str(value.get("proof_status") or FaceProofStatus.EXACT.value),provenance=dict(value.get("provenance") or {}),confidence=float(value.get("confidence") if value.get("confidence") is not None else 1.0),geometry_hash=str(value.get("geometry_hash") or ""),schema_version=str(value.get("schema_version") or MANUFACTURING_FACE_SCHEMA_VERSION))


def face_set_hash(part_id:str,faces:Iterable[ManufacturingFace])->str:
    ordered=sorted(faces,key=lambda f:f.face_id)
    return stable_sha256({"hash_version":FACE_SET_HASH_VERSION,"schema_version":MANUFACTURING_FACE_SET_SCHEMA_VERSION,"part_id":part_id,"faces":[f.geometry_hash for f in ordered]})

def validate_face_set(part_id:str,faces:Iterable[ManufacturingFace])->str:
    rows=list(faces); ids=set()
    for face in rows:
        if face.part_id!=part_id: raise ProjectValidationError(f"Face {face.face_id} hoort bij ander onderdeel")
        if face.face_id in ids: raise ProjectValidationError(f"Dubbele ManufacturingFace ID {face.face_id}")
        ids.add(face.face_id)
        if ManufacturingFace.from_dict(face.to_dict()).geometry_hash != face.geometry_hash: raise ProjectValidationError(f"Face {face.face_id} faalt roundtripvalidatie")
    return face_set_hash(part_id,rows)
