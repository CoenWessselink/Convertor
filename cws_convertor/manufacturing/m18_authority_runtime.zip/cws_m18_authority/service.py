"""Project-bound manufacturing-face service and persistence validation."""
from __future__ import annotations
from copy import deepcopy
from typing import Any
from cws_convertor.project.model import Part,ProjectModel,ProjectValidationError,ReviewStatus,utc_now_iso
from .contracts import MANUFACTURING_FACE_SET_SCHEMA_VERSION,ManufacturingFace,validate_face_set
from .face_resolver import FACE_RESOLUTION_SCHEMA_VERSION,FACE_RESOLVER_VERSION,FaceResolutionReport,ManufacturingFaceResolver

MANUFACTURING_FACE_STATE_SCHEMA_VERSION="1.0"

def load_faces(part:Part)->list[ManufacturingFace]: return [ManufacturingFace.from_dict(x) for x in list(part.manufacturing_faces or [])]

def validate_persisted_face_state(part:Part,*,require_current:bool=False)->dict[str,Any]:
    faces=load_faces(part); state=dict(part.manufacturing_faces_state or {})
    if not faces and not state:return {"status":"not_resolved","face_count":0,"current":False}
    if not state: raise ProjectValidationError(f"Onderdeel {part.internal_id} bevat onvolledige Manufacturing Faces-opslag")
    if str(state.get("schema_version") or "")!=MANUFACTURING_FACE_STATE_SCHEMA_VERSION: raise ProjectValidationError(f"Onderdeel {part.internal_id} heeft onbekend Manufacturing Faces state-schema")
    if str(state.get("resolver_schema_version") or "")!=FACE_RESOLUTION_SCHEMA_VERSION: raise ProjectValidationError(f"Onderdeel {part.internal_id} heeft onbekend face-resolution-schema")
    if str(state.get("part_id") or "")!=part.internal_id: raise ProjectValidationError("Manufacturing Faces state verwijst naar verkeerd onderdeel")
    status=str(state.get("status") or "")
    if status not in {"current","stale","blocked"}: raise ProjectValidationError(f"Onbekende Manufacturing Faces status {status!r}")
    if not faces:
        if status!="blocked" or str(state.get("face_set_hash") or ""): raise ProjectValidationError("Lege Manufacturing Faces-state moet blocked zijn zonder face_set_hash")
        if require_current: raise ProjectValidationError(f"Manufacturing Faces van onderdeel {part.internal_id} zijn geblokkeerd")
        return {"status":"blocked","face_count":0,"face_set_hash":"","current":False,"proof_status":str(state.get("proof_status") or "blocked"),"unresolved_ambiguities":list(state.get("unresolved_ambiguities") or []),"warnings":list(state.get("warnings") or [])}
    actual=validate_face_set(part.internal_id,faces)
    if actual!=str(state.get("face_set_hash") or ""): raise ProjectValidationError(f"Manufacturing Faces face_set_hash ongeldig voor onderdeel {part.internal_id}")
    current=status=="current" and str(state.get("source_geometry_hash") or "")==part.geometry_hash and str(state.get("source_manufacturing_hash") or "")==part.manufacturing_hash
    if status=="current" and not current: raise ProjectValidationError(f"Manufacturing Faces van onderdeel {part.internal_id} zijn als current gemarkeerd maar bronhashes zijn gewijzigd")
    if require_current and not current: raise ProjectValidationError(f"Manufacturing Faces van onderdeel {part.internal_id} zijn niet actueel")
    return {"status":status,"face_count":len(faces),"face_set_hash":actual,"current":current,"proof_status":str(state.get("proof_status") or ""),"unresolved_ambiguities":list(state.get("unresolved_ambiguities") or []),"warnings":list(state.get("warnings") or [])}

def invalidate_faces_if_hash_changed(part:Part,*,reason:str="part_hash_changed")->bool:
    state=part.manufacturing_faces_state
    if not isinstance(state,dict) or not state or str(state.get("status") or "")!="current":return False
    if str(state.get("source_geometry_hash") or "")==part.geometry_hash and str(state.get("source_manufacturing_hash") or "")==part.manufacturing_hash:return False
    state["status"]="stale"; state["stale_reason"]=reason; state["stale_at"]=utc_now_iso(); return True

class ManufacturingFaceService:
    def __init__(self,resolver:ManufacturingFaceResolver|None=None)->None:self.resolver=resolver or ManufacturingFaceResolver()
    def resolve_part(self,project:ProjectModel,part_id:str,*,user:str="system",persist:bool=True)->FaceResolutionReport:
        part=project.parts.get(part_id)
        if part is None: raise ProjectValidationError(f"Onbekend onderdeel {part_id}")
        if part.status not in {ReviewStatus.VALIDATED.value,ReviewStatus.RELEASED.value}: raise ProjectValidationError(f"Onderdeel {part_id} moet gevalideerd zijn voordat canonical manufacturing faces worden vastgelegd")
        part.recompute_hashes(); report=self.resolver.resolve(part)
        if persist:
            previous=deepcopy(part.manufacturing_faces_state)
            part.manufacturing_faces=[x.to_dict() for x in report.faces]
            state=report.to_state_dict(); state.update({"schema_version":MANUFACTURING_FACE_STATE_SCHEMA_VERSION,"resolver_schema_version":FACE_RESOLUTION_SCHEMA_VERSION,"face_contract_schema_version":MANUFACTURING_FACE_SET_SCHEMA_VERSION,"resolved_at":utc_now_iso(),"resolved_by":user or "system"})
            part.manufacturing_faces_state=state; validate_persisted_face_state(part)
            # Existing assembly contact geometry is derived from canonical faces;
            # re-resolving any participating part therefore invalidates it.
            from .contact_service import invalidate_contacts_for_part
            invalidated_contacts = invalidate_contacts_for_part(project, part.internal_id, reason="manufacturing_faces_reresolved")
            project.audit("manufacturing_faces.resolved",user=user or "system",entity_id=part.internal_id,before_hash=str(previous.get("face_set_hash") or ""),after_hash=report.face_set_hash,details={"resolver_version":FACE_RESOLVER_VERSION,"face_count":len(report.faces),"proof_status":report.proof_status,"unresolved_ambiguities":list(report.unresolved_ambiguities),"invalidated_contact_assemblies":invalidated_contacts})
        return report
    def current_faces(self,part:Part,*,require_current:bool=True)->list[ManufacturingFace]: validate_persisted_face_state(part,require_current=require_current); return load_faces(part)
