"""M7 deterministic manufacturing operation DAG planner."""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from cws_convertor.optimization.profile_nesting.units import LengthKernel
from .marking_contracts import ManufacturingMark, MarkType
from .reference_identification import canonical_hole_features
from .nesting_mark_binding_contracts import NestingMarkBindingProof
from .nesting_mark_binding_service import binding_set_id, validate_persisted_nesting_mark_binding
from .manufacturing_sequence_contracts import (
    ManufacturingSequenceIssue, SequenceOperation, SequenceDependency,
    ManufacturingSequencePlan, SequenceOperationType,
)


def sequence_id(run_id: str, assembly_id: str, capability_id: str) -> str:
    return "mseq-" + stable_sha256({"run":run_id,"assembly":assembly_id,"capability":capability_id})[:24]


def m7_source_snapshot(project: ProjectModel, run_id: str, assembly_id: str, capability_id: str) -> dict[str, Any]:
    sid = binding_set_id(run_id, assembly_id, capability_id)
    m6 = validate_persisted_nesting_mark_binding(project, sid, require_current=True)
    rec = project.profile_nesting_runs.get(run_id)
    if not isinstance(rec, dict) or not isinstance(rec.get("plan"), dict):
        raise ProjectValidationError("CWS-MARK-030 nestingrun ontbreekt voor M7")
    parts = {}
    assembly = project.assemblies.get(assembly_id)
    for pid in sorted(set(getattr(assembly, "part_ids", []) or [])):
        part = project.parts.get(pid)
        if part is not None:
            parts[pid] = {"manufacturing_hash":part.manufacturing_hash,"features_hash":stable_sha256(part.production_features)}
    snapshot = {
        "run_id":run_id,"assembly_id":assembly_id,"capability_id":capability_id,
        "binding_set_id":sid,"m6_state_hash":str(m6.get("state_hash") or ""),
        "m6_report_hash":str(dict(m6.get("report") or {}).get("report_hash") or ""),
        "plan_hash":str(dict(rec.get("plan") or {}).get("plan_hash") or ""),
        "parts":parts,
    }
    snapshot["snapshot_hash"] = stable_sha256(snapshot)
    return snapshot


def m7_source_snapshot_hash(project: ProjectModel, run_id: str, assembly_id: str, capability_id: str) -> str:
    return m7_source_snapshot(project,run_id,assembly_id,capability_id)["snapshot_hash"]


def _op_id(sequence: str, kind: str, *parts: str) -> str:
    return "op-" + stable_sha256({"sequence":sequence,"kind":kind,"parts":list(parts)})[:28]


def _issue(code: str, msg: str, **kw) -> ManufacturingSequenceIssue:
    return ManufacturingSequenceIssue(code=code,message=msg,blocking=kw.pop("blocking",True),severity=kw.pop("severity","error"),**kw)


def _mark_operation_type(mark: ManufacturingMark) -> str:
    if mark.mark_type in {MarkType.SCRIBE_LINE.value,MarkType.CONTOUR_SCRIBE.value,MarkType.REFERENCE_LINE.value}:
        return SequenceOperationType.SCRIBE.value
    if mark.mark_type == MarkType.POP_MARK.value:
        return SequenceOperationType.POP_MARK.value
    if mark.mark_type == MarkType.CENTER_PUNCH.value:
        return SequenceOperationType.CENTER_PUNCH.value
    if mark.mark_type == MarkType.HOLE_CENTER_CROSS.value:
        return SequenceOperationType.HOLE_REFERENCE.value
    return SequenceOperationType.IDENTIFY.value


def _time_for(capability: dict[str,Any], key: str) -> float:
    constraints = dict(capability.get("sequence_constraints") or {})
    times = dict(constraints.get("operation_time_seconds") or {})
    try: return max(0.0,float(times.get(key,0.0) or 0.0))
    except Exception: return 0.0


def _toposort(operation_ids: list[str], deps: list[SequenceDependency]) -> tuple[list[str], bool]:
    incoming={x:0 for x in operation_ids}; outgoing=defaultdict(list)
    for d in deps:
        if d.predecessor_id not in incoming or d.successor_id not in incoming: continue
        outgoing[d.predecessor_id].append(d.successor_id);incoming[d.successor_id]+=1
    ready=sorted([x for x,v in incoming.items() if v==0]);result=[]
    while ready:
        node=ready.pop(0);result.append(node)
        for nxt in sorted(outgoing.get(node,())):
            incoming[nxt]-=1
            if incoming[nxt]==0:
                ready.append(nxt);ready.sort()
    return result,len(result)==len(operation_ids)


class ManufacturingSequencePlanner:
    def build(self, project: ProjectModel, run_id: str, assembly_id: str, capability_id: str) -> ManufacturingSequencePlan:
        sid=binding_set_id(run_id,assembly_id,capability_id)
        m6=validate_persisted_nesting_mark_binding(project,sid,require_current=True)
        rec=project.profile_nesting_runs.get(run_id); plan=dict(rec.get("plan") or {}); snapshot=dict(rec.get("input_snapshot") or {})
        seq_id=sequence_id(run_id,assembly_id,capability_id)
        bindings=[NestingMarkBindingProof.from_dict(x) for x in dict(m6.get("report") or {}).get("bindings") or []]
        marks={mid:ManufacturingMark.from_dict(raw) for mid,raw in project.manufacturing_marks.items()}
        capability=dict(project.manufacturing_machine_capabilities.get(capability_id) or {})
        profiles={str(x.get("profile_id") or ""):dict(x) for x in dict(snapshot.get("machine_snapshot") or {}).get("profiles") or []}
        kernel=LengthKernel();operations=[];deps=[];issues=[]
        assembly=project.assemblies.get(assembly_id)
        assembly_mark=str(getattr(assembly,"assembly_mark","") or "")
        assembly_part_ids=set(getattr(assembly,"part_ids",[]) or [])
        instance_rows={str(x.get("instance_id") or ""):dict(x) for x in snapshot.get("piece_instances") or []}
        relevant_instances=set()
        for iid,row in instance_rows.items():
            ctx={str(x) for x in row.get("assembly_context") or []}
            if str(row.get("part_id") or "") in assembly_part_ids and (not ctx or not assembly_mark or assembly_mark in ctx):
                relevant_instances.add(iid)
        bind_by_piece=defaultdict(list)
        for b in bindings: bind_by_piece[b.piece_instance_id].append(b)
        # M6 can persist valid-but-infeasible evidence. M7 must preserve blockers.
        for b in bindings:
            if not b.feasible:
                issues.append(_issue("CWS-MARK-020",f"M6 binding {b.binding_id} is niet uitvoerbaar",piece_instance_id=b.piece_instance_id,mark_id=b.mark_id,suggested_remediation="Los M5/M6 machinebereikbaarheid op vóór sequencevrijgave."))
        for bar in sorted(plan.get("bars") or [],key=lambda x:str(x.get("bar_id") or "")):
            bar_placements=[dict(x) for x in bar.get("placements") or []]
            bar_piece_ids={str(x.get("instance_id") or "") for x in bar_placements}
            if not (bar_piece_ids & relevant_instances):
                continue
            foreign=sorted(bar_piece_ids-relevant_instances)
            if foreign:
                issues.append(_issue("CWS-MARK-020",f"Nestingbar {bar.get('bar_id')} bevat ook pieces buiten assembly {assembly_id}: {foreign}",bar_id=str(bar.get("bar_id") or ""),suggested_remediation="Maak een run-scope sequence waarin alle assembly-specifieke M6 bindings op deze staaf aanwezig zijn."))
            bar_id=str(bar.get("bar_id") or ""); machine_id=str(bar.get("machine_id") or ""); profile=profiles.get(str(bar.get("machine_profile_id") or ""),{})
            load=SequenceOperation(_op_id(seq_id,"load",bar_id),SequenceOperationType.LOAD_BAR.value,machine_id,bar_id,parameters={"stock_length_mm":kernel.units_to_mm(int(bar.get("stock_length_units") or 0))},estimated_seconds=_time_for(capability,"load_bar"))
            clamp=SequenceOperation(_op_id(seq_id,"clamp",bar_id),SequenceOperationType.CLAMP.value,machine_id,bar_id,estimated_seconds=_time_for(capability,"clamp"))
            operations += [load,clamp]; deps.append(SequenceDependency(load.operation_id,clamp.operation_id,"bar_loaded_before_clamp",bar_id))
            placements=sorted(bar_placements,key=lambda x:int(x.get("sequence_index") or 0))
            transitions={str(x.get("transition_id") or ""):dict(x) for x in bar.get("transitions") or []}
            previous_anchor=clamp.operation_id
            # First physical start cut.
            if placements:
                p0=placements[0]
                op=SequenceOperation(_op_id(seq_id,"saw_start",bar_id,str(p0.get("instance_id"))),SequenceOperationType.SAW_START.value,machine_id,bar_id,piece_instance_id=str(p0.get("instance_id") or ""),part_id=str(p0.get("part_id") or ""),part_position=str(p0.get("part_position") or ""),position_mm=kernel.units_to_mm(int(p0.get("start_units") or 0)),parameters={"cut_hash":p0.get("start_cut_hash","")},estimated_seconds=_time_for(capability,"saw"))
                operations.append(op);deps.append(SequenceDependency(previous_anchor,op.operation_id,"clamped_before_first_cut",bar_id));previous_anchor=op.operation_id
            for idx,p in enumerate(placements):
                piece=str(p.get("instance_id") or ""); part_id=str(p.get("part_id") or ""); part=project.parts.get(part_id)
                piece_ops=[]
                pbindings=sorted(bind_by_piece.get(piece,()),key=lambda b:(b.mark_id,b.binding_id))
                need_reorient=any(b.reorientation_required for b in pbindings); need_reclamp=any(b.reclamp_required for b in pbindings)
                gate=previous_anchor
                if need_reorient:
                    rop=SequenceOperation(_op_id(seq_id,"reorient",piece),SequenceOperationType.REORIENT.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),parameters={"orientation_id":p.get("orientation_id","")},estimated_seconds=_time_for(capability,"reorient"))
                    operations.append(rop);deps.append(SequenceDependency(gate,rop.operation_id,"m6_reorientation_required",piece));gate=rop.operation_id
                if need_reclamp:
                    rc=SequenceOperation(_op_id(seq_id,"reclamp",piece),SequenceOperationType.RECLAMP.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),estimated_seconds=_time_for(capability,"reclamp"))
                    operations.append(rc);deps.append(SequenceDependency(gate,rc.operation_id,"m6_reclamp_required",piece));gate=rc.operation_id
                # Drill production features when they exist. Profile Nesting already gates required operations/tools;
                # M7 independently refuses to silently omit them.
                hole_ops=[]
                if part is not None:
                    holes=canonical_hole_features(part)
                    supported={str(x) for x in profile.get("supported_operations") or []}
                    if holes and "drill" not in supported:
                        issues.append(_issue("CWS-MARK-020",f"Machine {machine_id} ondersteunt vereiste drill-operaties niet",bar_id=bar_id,piece_instance_id=piece,suggested_remediation="Kies een machineprofiel met gevalideerde drill capability."))
                    for h in holes:
                        hop=SequenceOperation(_op_id(seq_id,"drill",piece,str(h.get("feature_id"))),SequenceOperationType.DRILL.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),feature_id=str(h.get("feature_id") or ""),face_id=str(h.get("face_ref") or ""),feasible=("drill" in supported),parameters={"u_mm":h.get("u_mm"),"v_mm":h.get("v_mm"),"diameter_mm":h.get("diameter_mm"),"depth_mm":h.get("depth_mm")},estimated_seconds=_time_for(capability,"drill"),provenance={"feature_hash":h.get("feature_hash","")})
                        operations.append(hop);deps.append(SequenceDependency(gate,hop.operation_id,"piece_positioned_before_drill",piece));hole_ops.append(hop);piece_ops.append(hop)
                # Canonical mark operations from M6.
                for b in pbindings:
                    mark=marks.get(b.mark_id)
                    if mark is None:
                        issues.append(_issue("CWS-MARK-020",f"Canonical mark {b.mark_id} ontbreekt",piece_instance_id=piece,mark_id=b.mark_id));continue
                    typ=_mark_operation_type(mark)
                    mop=SequenceOperation(_op_id(seq_id,"mark",b.binding_id),typ,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=b.part_position,binding_id=b.binding_id,mark_id=b.mark_id,face_id=b.target_face_id,tool_id=b.selected_tool_id,feasible=b.feasible,parameters={"mark_type":mark.mark_type,"machine_geometry_hash":b.machine_geometry.geometry_hash,"must_execute_before_severing":b.must_execute_before_severing,"precedence_requirements":list(b.precedence_requirements)},estimated_seconds=_time_for(capability,typ),provenance={"binding_hash":b.binding_hash,"mark_hash":b.mark_hash})
                    operations.append(mop);piece_ops.append(mop);deps.append(SequenceDependency(gate,mop.operation_id,"piece_positioned_before_mark",b.binding_id))
                    # Hole-reference policies can require drilling first. Pop/center-punch remains a separate marking intent.
                    if mark.mark_type == MarkType.HOLE_CENTER_CROSS.value and hole_ops:
                        source=set(mark.source_feature_ids)
                        for hop in hole_ops:
                            if not source or hop.feature_id in source:
                                deps.append(SequenceDependency(hop.operation_id,mop.operation_id,"qc_hole_reference_after_drill",mark.mark_id))
                # Determine the severing cut after current piece.
                next_p=placements[idx+1] if idx+1<len(placements) else None
                transition_id=str(p.get("transition_after_id") or "")
                if next_p is not None and transition_id:
                    t=transitions.get(transition_id,{})
                    if bool(t.get("common_cut")):
                        cut=SequenceOperation(_op_id(seq_id,"common_cut",transition_id),SequenceOperationType.COMMON_CUT.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),transition_id=transition_id,position_mm=kernel.units_to_mm(int(p.get("end_units") or 0)),parameters={"transition_hash":t.get("transition_hash","")},estimated_seconds=float(t.get("estimated_time_seconds") or _time_for(capability,"saw")))
                        operations.append(cut)
                        # Every relevant M6 mark on either side that names this transition must precede it.
                        relevant=[x for x in pbindings if transition_id in x.common_cut_transition_ids]
                        next_bind=bind_by_piece.get(str(next_p.get("instance_id") or ""),())
                        relevant += [x for x in next_bind if transition_id in x.common_cut_transition_ids]
                        if relevant:
                            for b in relevant:
                                mid=_op_id(seq_id,"mark",b.binding_id);deps.append(SequenceDependency(mid,cut.operation_id,"m6_mark_before_common_cut",transition_id))
                        else:
                            deps.append(SequenceDependency(gate,cut.operation_id,"piece_positioned_before_common_cut",transition_id))
                        sever_cut=cut; next_anchor=cut.operation_id
                    else:
                        end=SequenceOperation(_op_id(seq_id,"saw_end",piece),SequenceOperationType.SAW_END.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),position_mm=kernel.units_to_mm(int(p.get("end_units") or 0)),parameters={"cut_hash":p.get("end_cut_hash","")},estimated_seconds=_time_for(capability,"saw"))
                        start=SequenceOperation(_op_id(seq_id,"saw_start",bar_id,str(next_p.get("instance_id"))),SequenceOperationType.SAW_START.value,machine_id,bar_id,piece_instance_id=str(next_p.get("instance_id") or ""),part_id=str(next_p.get("part_id") or ""),part_position=str(next_p.get("part_position") or ""),position_mm=kernel.units_to_mm(int(next_p.get("start_units") or 0)),parameters={"cut_hash":next_p.get("start_cut_hash","")},estimated_seconds=_time_for(capability,"saw"))
                        operations += [end,start]
                        deps.append(SequenceDependency(gate,end.operation_id,"piece_positioned_before_end_cut",piece)); sever_cut=end
                        # start of next part can only occur after prior piece is removed; dependency added below through unload.
                        next_anchor=start.operation_id
                else:
                    end=SequenceOperation(_op_id(seq_id,"saw_end",piece),SequenceOperationType.SAW_END.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),position_mm=kernel.units_to_mm(int(p.get("end_units") or 0)),parameters={"cut_hash":p.get("end_cut_hash","")},estimated_seconds=_time_for(capability,"saw"))
                    operations.append(end);deps.append(SequenceDependency(gate,end.operation_id,"piece_positioned_before_end_cut",piece));sever_cut=end;next_anchor=""
                for pop in piece_ops:
                    deps.append(SequenceDependency(pop.operation_id,sever_cut.operation_id,"operation_before_severing",piece))
                sever=SequenceOperation(_op_id(seq_id,"sever",piece),SequenceOperationType.SEVER_PIECE.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),estimated_seconds=_time_for(capability,"sever_piece"))
                unload=SequenceOperation(_op_id(seq_id,"unload_piece",piece),SequenceOperationType.UNLOAD_PIECE.value,machine_id,bar_id,piece_instance_id=piece,part_id=part_id,part_position=str(p.get("part_position") or ""),estimated_seconds=_time_for(capability,"unload_piece"))
                operations += [sever,unload];deps += [SequenceDependency(sever_cut.operation_id,sever.operation_id,"cut_before_sever",piece),SequenceDependency(sever.operation_id,unload.operation_id,"sever_before_unload",piece)]
                if next_p is not None:
                    # For non-common transition, next start cut exists and must follow unload. For common cut it was already executed once.
                    t=transitions.get(transition_id,{}) if transition_id else {}
                    if transition_id and not bool(t.get("common_cut")):
                        deps.append(SequenceDependency(unload.operation_id,next_anchor,"unload_before_next_start_cut",piece));previous_anchor=next_anchor
                    else:
                        previous_anchor=unload.operation_id
                else:
                    previous_anchor=unload.operation_id
            unload_bar=SequenceOperation(_op_id(seq_id,"unload_bar",bar_id),SequenceOperationType.UNLOAD_BAR.value,machine_id,bar_id,estimated_seconds=_time_for(capability,"unload_bar"))
            operations.append(unload_bar);deps.append(SequenceDependency(previous_anchor,unload_bar.operation_id,"all_pieces_before_bar_unload",bar_id))
        # Deduplicate deterministic dependencies created from overlapping proof reasons.
        dep_map={(d.predecessor_id,d.successor_id,d.reason,d.source_ref):d for d in deps};deps=list(dep_map.values())
        op_ids=[x.operation_id for x in operations];linear,acyclic=_toposort(op_ids,deps)
        if not acyclic:
            issues.append(_issue("CWS-MARK-016","Manufacturing sequence dependency graph bevat een cyclus",suggested_remediation="Controleer M6 precedence/reclamp/common-cut relaties."))
        # Each M6 binding must materialize exactly one mark operation.
        mark_binding_ids={x.binding_id for x in operations if x.binding_id}
        missing=sorted({b.binding_id for b in bindings}-mark_binding_ids)
        if missing: issues.append(_issue("CWS-MARK-020",f"M7 heeft M6 mark operations verloren: {missing}"))
        feasible=acyclic and not any(x.blocking for x in issues) and all(x.feasible for x in operations)
        source=m7_source_snapshot(project,run_id,assembly_id,capability_id)
        return ManufacturingSequencePlan(seq_id,run_id,assembly_id,capability_id,sid,str(dict(m6.get("report") or {}).get("machine_id") or ""),tuple(operations),tuple(deps),tuple(linear),feasible,any(x.severity=="warning" for x in issues),tuple(issues),source["snapshot_hash"],str(dict(rec.get("plan") or {}).get("plan_hash") or ""),str(m6.get("state_hash") or ""),sum(x.estimated_seconds for x in operations))


def build_sequence_neutral_job(project: ProjectModel, sequence: ManufacturingSequencePlan) -> dict[str,Any]:
    payload={"format":"cws-neutral-manufacturing-sequence","schema_version":"2.0","project_id":project.project_id,"project_name":project.project_name,"sequence_id":sequence.sequence_id,"run_id":sequence.run_id,"assembly_id":sequence.assembly_id,"capability_id":sequence.capability_id,"machine_id":sequence.machine_id,"sequence_hash":sequence.sequence_hash,"operations":[x.to_dict() for x in sequence.operations],"dependencies":[x.to_dict() for x in sequence.dependencies],"linearized_operation_ids":list(sequence.linearized_operation_ids),"machine_transfer":{"allowed":False,"reason":"M7 neutral manufacturing intent only; no validated controller adapter."},"dstv_si_released":False,"machine_output_released":False}
    payload["manifest_hash"]=stable_sha256({k:v for k,v in payload.items() if k!="manifest_hash"});return payload


__all__=[name for name in globals() if not name.startswith("_")]
