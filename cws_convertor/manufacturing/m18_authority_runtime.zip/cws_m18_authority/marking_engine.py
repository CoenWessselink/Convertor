"""Deterministic Scribing / Mark Generation engine for phase M3."""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import Part, ProjectModel, ProjectValidationError, stable_sha256
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .service import load_faces, validate_persisted_face_state
from .contact_contracts import ContactPatch, ContactProofStatus
from .contact_service import load_assembly_contacts, validate_persisted_contact_state
from .marking_contracts import (
    ContourPolicy,
    ManufacturingMark,
    ManufacturingRuleSet,
    MarkGeometry2D,
    MarkGeometryKind,
    MarkReviewStatus,
    MarkSuppressionRecord,
    MarkType,
    RulePredicate,
    RuleValidationStatus,
    mark_set_hash,
)
from .marking_geometry import (
    canonical_segment,
    clip_segment_to_polygon,
    distance,
    inset_convex_polygon,
    line_face_outer_polygon,
    merge_collinear_contiguous,
    split_segment,
    subtract_circle_zones,
    subtract_rect_zones,
    target_hole_zones,
    target_weld_zones,
)

SCRIBING_ENGINE_VERSION = "cws-scribing-mark-engine-1.0"
SCRIBING_ENGINE_SCHEMA_VERSION = "1.0"
MARK_SOURCE_SNAPSHOT_VERSION = "cws-mark-source-snapshot-v1"


@dataclass
class ScribingGenerationIssue:
    code: str
    message: str
    blocking: bool = False
    contact_id: str = ""
    face_id: str = ""
    rule_id: str = ""
    suggested_remediation: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "blocking": self.blocking,
            "contact_id": self.contact_id,
            "face_id": self.face_id,
            "rule_id": self.rule_id,
            "suggested_remediation": self.suggested_remediation,
        }


@dataclass
class ScribingGenerationReport:
    assembly_id: str
    ruleset_id: str
    ruleset_hash: str
    marks: list[ManufacturingMark]
    suppressions: list[MarkSuppressionRecord]
    issues: list[ScribingGenerationIssue]
    source_snapshot_hash: str
    raw_candidate_count: int = 0
    normalized_count: int = 0
    accepted_count: int = 0
    proof_status: str = "blocked"
    engine_version: str = SCRIBING_ENGINE_VERSION
    mark_set_hash: str = ""

    def __post_init__(self) -> None:
        self.accepted_count = len(self.marks)
        self.mark_set_hash = mark_set_hash(self.assembly_id, self.ruleset_hash, self.marks)
        if self.marks and not any(issue.blocking for issue in self.issues):
            self.proof_status = "exact"
        elif self.marks:
            self.proof_status = "review"
        else:
            self.proof_status = "blocked"

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCRIBING_ENGINE_SCHEMA_VERSION,
            "engine_version": self.engine_version,
            "assembly_id": self.assembly_id,
            "ruleset_id": self.ruleset_id,
            "ruleset_hash": self.ruleset_hash,
            "mark_set_hash": self.mark_set_hash,
            "source_snapshot_hash": self.source_snapshot_hash,
            "raw_candidate_count": self.raw_candidate_count,
            "normalized_count": self.normalized_count,
            "accepted_count": self.accepted_count,
            "proof_status": self.proof_status,
            "issues": [item.to_dict() for item in self.issues],
            "suppressions": [item.to_dict() for item in self.suppressions],
            "marks": [item.to_dict() for item in self.marks],
        }


def _part_rule_value(part: Part, path: str) -> Any:
    """Resolve a bounded declarative ruleset field path; no eval/script support."""
    path = str(path or "").strip()
    if path.startswith("properties."):
        current: Any = part.properties
        for token in path.split(".")[1:]:
            if not isinstance(current, Mapping):
                return None
            current = current.get(token)
        return current
    allowed = {
        "profile_type", "profile", "normalized_profile", "material", "material_grade",
        "part_type", "mirrored", "status", "classification_status", "part_position",
    }
    if path not in allowed:
        raise ProjectValidationError(f"Ruleset predicate field {path!r} is niet toegestaan")
    return getattr(part, path)


def predicate_matches(part: Part, predicate: RulePredicate) -> bool:
    actual = _part_rule_value(part, predicate.field_path)
    op = predicate.operator
    expected = predicate.value
    if op == "eq": return actual == expected
    if op == "ne": return actual != expected
    if op == "in": return actual in (expected if isinstance(expected, (list,tuple,set)) else [expected])
    if op == "not_in": return actual not in (expected if isinstance(expected, (list,tuple,set)) else [expected])
    if op == "exists": return (actual is not None) == bool(expected if expected is not None else True)
    raise ProjectValidationError(f"Onbekende predicate operator {op!r}")


def ruleset_applies(part: Part, ruleset: ManufacturingRuleSet) -> bool:
    if ruleset.applicable_profile_types:
        profile_tokens = {part.profile_type.upper(), part.part_type.upper()}
        if not any(str(item).upper() in profile_tokens for item in ruleset.applicable_profile_types):
            return False
    if ruleset.inclusion_predicates and not all(predicate_matches(part, item) for item in ruleset.inclusion_predicates):
        return False
    if any(predicate_matches(part, item) for item in ruleset.exclusion_predicates):
        return False
    return True


def marking_source_snapshot(project: ProjectModel, assembly_id: str, ruleset: ManufacturingRuleSet) -> dict[str, Any]:
    assembly = project.assemblies.get(assembly_id)
    if assembly is None:
        raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
    contact_state = validate_persisted_contact_state(project, assembly_id, require_current=True)
    part_rows = {}
    for part_id in sorted(set(assembly.part_ids)):
        part = project.parts.get(part_id)
        if part is None:
            continue
        face_state = validate_persisted_face_state(part, require_current=True)
        part_rows[part_id] = {
            "manufacturing_hash": part.manufacturing_hash,
            "geometry_hash": part.geometry_hash,
            "face_set_hash": face_state.get("face_set_hash", ""),
            "hole_features_hash": stable_sha256(part.production_features),
            "marking_exclusion_properties_hash": stable_sha256({
                "marking_hole_zones": part.properties.get("marking_hole_zones", []) if isinstance(part.properties, dict) else [],
                "marking_weld_zones": part.properties.get("marking_weld_zones", []) if isinstance(part.properties, dict) else [],
            }),
        }
    return {
        "version": MARK_SOURCE_SNAPSHOT_VERSION,
        "project_id": project.project_id,
        "assembly_id": assembly_id,
        "assembly_mark": assembly.assembly_mark,
        "main_part_id": assembly.main_part_id,
        "part_ids": sorted(assembly.part_ids),
        "contact_set_hash": contact_state.get("contact_set_hash", ""),
        "contact_source_snapshot_hash": contact_state.get("source_snapshot_hash", ""),
        "ruleset_id": ruleset.ruleset_id,
        "ruleset_hash": ruleset.ruleset_hash,
        "parts": part_rows,
    }


def marking_source_snapshot_hash(project: ProjectModel, assembly_id: str, ruleset: ManufacturingRuleSet) -> str:
    return stable_sha256(marking_source_snapshot(project, assembly_id, ruleset))


def _make_suppression(
    assembly_id: str, patch: ContactPatch, face: ManufacturingFace, ruleset: ManufacturingRuleSet,
    code: str, reason: str, geometry: MarkGeometry2D | None, resulting: Iterable[MarkGeometry2D] = (),
    *, stage: str,
) -> MarkSuppressionRecord:
    payload = {
        "assembly_id": assembly_id, "contact": patch.contact_id, "face": face.face_id,
        "rule": ruleset.ruleset_hash, "code": code, "stage": stage,
        "geometry": geometry.to_dict() if geometry else None,
    }
    return MarkSuppressionRecord(
        suppression_id="msup-" + stable_sha256(payload)[:24],
        assembly_id=assembly_id,
        source_contact_id=patch.contact_id,
        target_part_id=patch.main_part_id,
        target_face_id=face.face_id,
        rule_id=ruleset.ruleset_id,
        code=code,
        reason=reason,
        original_geometry=geometry,
        resulting_geometry=tuple(resulting),
        provenance={"engine": SCRIBING_ENGINE_VERSION, "stage": stage},
    )


def _contact_segments(patch: ContactPatch) -> list[tuple[tuple[float,float],tuple[float,float]]]:
    pts = [tuple(map(float, p)) for p in patch.projected_boundary_on_main_face]
    return [canonical_segment(pts[i], pts[(i+1)%len(pts)]) for i in range(len(pts))]


def _corners_only(segments, mark_length: float, min_len: float):
    out=[]
    for a,b in segments:
        total=distance(a,b)
        if total <= 2*mark_length + min_len:
            out.append((a,b));continue
        ux=(b[0]-a[0])/total;uy=(b[1]-a[1])/total
        p=(a[0]+ux*mark_length,a[1]+uy*mark_length)
        q=(b[0]-ux*mark_length,b[1]-uy*mark_length)
        out.extend([(a,p),(q,b)])
    return out


def _minimum_line_set(segments):
    ordered=sorted(segments,key=lambda s:(-distance(*s),s))
    if not ordered:return []
    chosen=[ordered[0]]
    a,b=ordered[0];dx=b[0]-a[0];dy=b[1]-a[1];ln=max(distance(a,b),1e-12)
    for seg in ordered[1:]:
        c,d=seg;ex=d[0]-c[0];ey=d[1]-c[1];eln=max(distance(c,d),1e-12)
        cosine=abs((dx*ex+dy*ey)/(ln*eln))
        if cosine < 0.95:
            chosen.append(seg);break
    return chosen


def _company_template(segments, ruleset: ManufacturingRuleSet):
    template = dict(ruleset.contact_rules.get("company_template") or {})
    indices = list(template.get("edge_indices") or [])
    return [segments[index] for index in indices if 0 <= index < len(segments)]

def _center_reference(segments):
    pts=[p for seg in segments for p in seg]
    if not pts:return []
    u0=min(p[0] for p in pts);u1=max(p[0] for p in pts);v0=min(p[1] for p in pts);v1=max(p[1] for p in pts)
    if (u1-u0) >= (v1-v0):
        v=(v0+v1)/2;return [((u0,v),(u1,v))]
    u=(u0+u1)/2;return [((u,v0),(u,v1))]

def _point_on_segment_for_audit(point, segment, tol=1e-7):
    a,b=segment;dx=b[0]-a[0];dy=b[1]-a[1];ln=max(distance(a,b),1.0)
    cross=dx*(point[1]-a[1])-dy*(point[0]-a[0])
    if abs(cross)>tol*ln:return False
    dot=(point[0]-a[0])*(point[0]-b[0])+(point[1]-a[1])*(point[1]-b[1])
    return dot<=tol*tol

def _containing_segments(segment, candidates):
    return [candidate for candidate in candidates if _point_on_segment_for_audit(segment[0],candidate) and _point_on_segment_for_audit(segment[1],candidate)]


class ScribingMarkEngine:
    """Generate M3 marks only from current exact/confirmed contact evidence."""

    def generate(self, project: ProjectModel, assembly_id: str, ruleset: ManufacturingRuleSet) -> ScribingGenerationReport:
        if ruleset.validation_status != RuleValidationStatus.VALIDATED.value:
            raise ProjectValidationError("CWS-MARK-013 ruleset not validated")
        assembly = project.assemblies.get(assembly_id)
        if assembly is None:
            raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
        contact_state = validate_persisted_contact_state(project, assembly_id, require_current=True)
        validation = dict(contact_state.get("validation") or {})
        if validation and validation.get("status") != "passed":
            raise ProjectValidationError("CWS-MARK-004 contact geometry heeft geen geldige onafhankelijke validatie")
        patches = load_assembly_contacts(project, assembly_id)
        issues: list[ScribingGenerationIssue] = []
        suppressions: list[MarkSuppressionRecord] = []
        candidates: list[tuple[ContactPatch, ManufacturingFace, str, tuple[tuple[float,float],tuple[float,float]], list[str]]] = []
        raw_count = 0

        for patch in sorted(patches, key=lambda item: item.contact_id):
            if ruleset.exact_contacts_only and patch.proof_status != ContactProofStatus.EXACT.value:
                issues.append(ScribingGenerationIssue(
                    "CWS-MARK-004", "Contactbewijs is niet exact; markering niet gegenereerd.", True,
                    patch.contact_id, patch.main_face_id, ruleset.ruleset_id,
                    "Bevestig/los Contact Geometry op voordat scribing wordt gegenereerd.",
                ))
                continue
            target = project.parts.get(patch.main_part_id)
            source = project.parts.get(patch.secondary_part_id)
            if target is None or source is None:
                issues.append(ScribingGenerationIssue("CWS-MARK-001", "Contact verwijst naar ontbrekend onderdeel.", True, patch.contact_id, patch.main_face_id, ruleset.ruleset_id))
                continue
            if not ruleset_applies(target, ruleset):
                issues.append(ScribingGenerationIssue("CWS-MARK-013", f"Ruleset is niet van toepassing op target part {target.internal_id}.", False, patch.contact_id, patch.main_face_id, ruleset.ruleset_id))
                continue
            validate_persisted_face_state(target, require_current=True)
            face_map = {face.face_id: face for face in load_faces(target)}
            face = face_map.get(patch.main_face_id)
            if face is None:
                issues.append(ScribingGenerationIssue("CWS-MARK-001", "Target ManufacturingFace ontbreekt.", True, patch.contact_id, patch.main_face_id, ruleset.ruleset_id))
                continue
            if face.surface_type != ManufacturingSurfaceType.PLANE.value:
                issues.append(ScribingGenerationIssue("CWS-MARK-003", "M3 ondersteunt scribing alleen op bewezen vlakke faces.", True, patch.contact_id, face.face_id, ruleset.ruleset_id))
                continue
            if face.geometry_hash != patch.main_face_geometry_hash:
                issues.append(ScribingGenerationIssue("CWS-MARK-014", "Contact verwijst naar verouderde target-face geometry hash.", True, patch.contact_id, face.face_id, ruleset.ruleset_id))
                continue
            try:
                face_polygon = line_face_outer_polygon(face)
            except ProjectValidationError as exc:
                issues.append(ScribingGenerationIssue("CWS-MARK-003", str(exc), True, patch.contact_id, face.face_id, ruleset.ruleset_id))
                continue
            safe_polygon = inset_convex_polygon(face_polygon, ruleset.min_edge_distance_mm)
            if not safe_polygon:
                issues.append(ScribingGenerationIssue("CWS-MARK-005", "Edge margin laat geen geldig scribable facegebied over.", True, patch.contact_id, face.face_id, ruleset.ruleset_id))
                continue

            source_segments = _contact_segments(patch)
            segments = list(source_segments)
            if ruleset.contour_policy == ContourPolicy.CORNERS_ONLY.value:
                segments = _corners_only(source_segments, ruleset.corner_mark_length_mm, ruleset.min_line_length_mm)
            elif ruleset.contour_policy == ContourPolicy.MINIMUM_LINE_SET.value:
                segments = _minimum_line_set(source_segments)
            elif ruleset.contour_policy == ContourPolicy.CENTER_REFERENCE.value:
                segments = _center_reference(source_segments)
            elif ruleset.contour_policy == ContourPolicy.COMPANY_TEMPLATE.value:
                segments = _company_template(source_segments, ruleset)
            if ruleset.contour_policy != ContourPolicy.FULL_CONTOUR.value:
                for source_segment in source_segments:
                    source_geom = MarkGeometry2D(MarkGeometryKind.LINE.value, points=source_segment)
                    resulting_segments = _containing_segments(source_segment, segments)
                    if source_segment not in segments or ruleset.contour_policy == ContourPolicy.CENTER_REFERENCE.value:
                        suppressions.append(_make_suppression(
                            assembly_id, patch, face, ruleset, "CWS-MARK-POLICY-001",
                            f"Contourbeleid {ruleset.contour_policy} heeft de broncontactlijn vervangen/gereduceerd.",
                            source_geom,
                            tuple(MarkGeometry2D(MarkGeometryKind.LINE.value, points=item) for item in resulting_segments),
                            stage="contour_policy",
                        ))
            mark_type = MarkType.REFERENCE_LINE.value if ruleset.contour_policy == ContourPolicy.CENTER_REFERENCE.value else MarkType.CONTOUR_SCRIBE.value
            if ruleset.generate_reference_line and ruleset.contour_policy != ContourPolicy.CENTER_REFERENCE.value:
                for seg in _center_reference(_contact_segments(patch)):
                    candidates.append((patch, face, MarkType.REFERENCE_LINE.value, canonical_segment(*seg), ["derived:center_reference"]))
                    raw_count += 1
            for seg in segments:
                candidates.append((patch, face, mark_type, canonical_segment(*seg), ["derived:contact_boundary"]))
                raw_count += 1

        # Process candidate geometry per source contact/face/type so collinear duplicates are normalized first.
        grouped: dict[tuple[str,str,str], list[tuple[ContactPatch,ManufacturingFace,tuple[tuple[float,float],tuple[float,float]],list[str]]]] = {}
        for patch,face,mtype,seg,sources in candidates:
            grouped.setdefault((patch.contact_id,face.face_id,mtype),[]).append((patch,face,seg,sources))

        marks: list[ManufacturingMark] = []
        normalized_total = 0
        for key in sorted(grouped):
            rows = grouped[key]; patch=rows[0][0];face=rows[0][1]
            target=project.parts[patch.main_part_id]
            face_polygon=line_face_outer_polygon(face)
            safe_polygon=inset_convex_polygon(face_polygon,ruleset.min_edge_distance_mm)
            raw_group_segments=[row[2] for row in rows]
            base_segments=merge_collinear_contiguous(raw_group_segments)
            normalized_total += len(base_segments)
            seen_raw: dict[str, int] = {}
            for raw_segment in raw_group_segments:
                raw_geom=MarkGeometry2D(MarkGeometryKind.LINE.value,points=raw_segment)
                raw_key=raw_geom.geometry_hash();seen_raw[raw_key]=seen_raw.get(raw_key,0)+1
                exact_present=any(MarkGeometry2D(MarkGeometryKind.LINE.value,points=item).geometry_hash()==raw_key for item in base_segments)
                containers=_containing_segments(raw_segment,base_segments)
                if not exact_present or seen_raw[raw_key] > 1:
                    suppressions.append(_make_suppression(
                        assembly_id,patch,face,ruleset,"CWS-MARK-NORM-001",
                        "Deterministische normalisatie heeft een duplicate/collineaire lijn samengevoegd.",raw_geom,
                        tuple(MarkGeometry2D(MarkGeometryKind.LINE.value,points=item) for item in containers),stage="normalization",
                    ))
            hole_zones=target_hole_zones(target,face,ruleset.hole_margin_mm)
            weld_zones=target_weld_zones(target,face,ruleset.weld_margin_mm)
            if patch.weld_ids and ruleset.weld_margin_mm > 0 and ruleset.require_explicit_weld_geometry and not weld_zones:
                issues.append(ScribingGenerationIssue(
                    "CWS-MARK-007", "Weld margin is actief maar exacte weld exclusion-geometrie ontbreekt; marks voor dit contact zijn geblokkeerd.", True,
                    patch.contact_id, face.face_id, ruleset.ruleset_id,
                    "Lever expliciete weld-zonegeometrie of zet weld_margin_mm bewust op 0 binnen een gevalideerde ruleset.",
                ))
                for seg in base_segments:
                    geom=MarkGeometry2D(MarkGeometryKind.LINE.value,points=seg)
                    suppressions.append(_make_suppression(assembly_id,patch,face,ruleset,"CWS-MARK-007","Geen exacte weld exclusion-geometrie",geom,stage="weld_exclusion"))
                continue
            for seg in base_segments:
                original=MarkGeometry2D(MarkGeometryKind.LINE.value,points=seg)
                stage_segments=clip_segment_to_polygon(seg[0],seg[1],safe_polygon)
                if not stage_segments:
                    suppressions.append(_make_suppression(assembly_id,patch,face,ruleset,"CWS-MARK-005","Lijn valt buiten toegestaan facegebied/edge margin",original,stage="face_clip"))
                    continue
                before_hole=list(stage_segments)
                after_hole=[]
                for a,b in stage_segments:after_hole.extend(subtract_circle_zones(a,b,hole_zones))
                if len(after_hole)!=len(before_hole) or any(distance(*x) < distance(*y)-1e-8 for x,y in zip(after_hole,before_hole)):
                    resulting=tuple(MarkGeometry2D(MarkGeometryKind.LINE.value,points=s) for s in after_hole)
                    suppressions.append(_make_suppression(assembly_id,patch,face,ruleset,"CWS-MARK-006","Lijn geclipt/gesplitst rond uitgesloten gat-zone",original,resulting,stage="hole_exclusion"))
                stage_segments=after_hole
                if weld_zones:
                    circle_z=[z for z in weld_zones if z.get("kind")=="circle"]
                    rect_z=[z for z in weld_zones if z.get("kind")=="rect"]
                    after_weld=[]
                    for a,b in stage_segments:
                        pieces=[(a,b)]
                        if circle_z:
                            tmp=[]
                            for p,q in pieces:tmp.extend(subtract_circle_zones(p,q,circle_z))
                            pieces=tmp
                        if rect_z:
                            tmp=[]
                            for p,q in pieces:tmp.extend(subtract_rect_zones(p,q,rect_z))
                            pieces=tmp
                        after_weld.extend(pieces)
                    if after_weld != stage_segments:
                        resulting=tuple(MarkGeometry2D(MarkGeometryKind.LINE.value,points=s) for s in after_weld)
                        suppressions.append(_make_suppression(assembly_id,patch,face,ruleset,"CWS-MARK-007","Lijn geclipt/gesplitst rond weld exclusion-zone",original,resulting,stage="weld_exclusion"))
                    stage_segments=after_weld
                if ruleset.avoid_contact_surface and patch.weld_ids:
                    suppressions.append(_make_suppression(assembly_id,patch,face,ruleset,"CWS-MARK-007","Ruleset verbiedt scribing op gelast contactoppervlak",original,stage="contact_surface_policy"))
                    stage_segments=[]
                filtered=[]
                for a,b in stage_segments:
                    if distance(a,b)+1e-9 < ruleset.min_line_length_mm:
                        suppressions.append(_make_suppression(assembly_id,patch,face,ruleset,"CWS-MARK-005",f"Marklijn korter dan minimum {ruleset.min_line_length_mm:g} mm",MarkGeometry2D(MarkGeometryKind.LINE.value,points=(a,b)),stage="minimum_length"))
                        continue
                    filtered.append((a,b))
                stage_segments=filtered
                if ruleset.segment_straight_lines:
                    segmented=[]
                    for a,b in stage_segments:
                        source_segment=(a,b)
                        pieces=split_segment(a,b,ruleset.segment_length_mm,ruleset.segment_gap_mm,ruleset.min_line_length_mm)
                        segmented.extend(pieces)
                        if len(pieces)!=1 or (pieces and canonical_segment(*pieces[0])!=canonical_segment(*source_segment)):
                            suppressions.append(_make_suppression(
                                assembly_id,patch,face,ruleset,"CWS-MARK-SEG-001",
                                "Gevalideerde interrupt/segmentation policy heeft een rechte marklijn onderbroken.",
                                MarkGeometry2D(MarkGeometryKind.LINE.value,points=source_segment),
                                tuple(MarkGeometry2D(MarkGeometryKind.LINE.value,points=item) for item in pieces),
                                stage="segmentation",
                            ))
                    stage_segments=segmented
                for a,b in stage_segments:
                    geom=MarkGeometry2D(MarkGeometryKind.LINE.value,points=canonical_segment(a,b))
                    identity={
                        "assembly_id":assembly_id,"contact_id":patch.contact_id,"face_id":face.face_id,
                        "ruleset_hash":ruleset.ruleset_hash,"mark_type":key[2],"geometry_hash":geom.geometry_hash(),
                    }
                    mark_id="mk-"+stable_sha256(identity)[:24]
                    marks.append(ManufacturingMark(
                        mark_id=mark_id,
                        part_id=target.internal_id,
                        assembly_id=assembly_id,
                        source_part_id=patch.secondary_part_id,
                        target_part_id=patch.main_part_id,
                        target_face_id=face.face_id,
                        mark_type=key[2],
                        geometry_2d=geom,
                        purpose="assembly_contact_reference",
                        generated_by_rule_id=ruleset.ruleset_id,
                        source_contact_id=patch.contact_id,
                        requested_operation="scribe",
                        source_feature_ids=tuple(rows[0][3]),
                        machine_constraints={"machine_binding": "not_in_m3", "requires_planar_face": True},
                        review_status=MarkReviewStatus.ACCEPTED.value,
                        provenance={
                            "engine":SCRIBING_ENGINE_VERSION,
                            "pipeline":["contact_boundary","normalize","face_clip","hole_exclusion","weld_exclusion","minimum_length",("segment" if ruleset.segment_straight_lines else "no_segment")],
                            "coordinate_frame":"target_manufacturing_face_uv",
                            "machine_output":False,
                        },
                        source_contact_hash=patch.contact_hash,
                        target_face_geometry_hash=face.geometry_hash,
                        ruleset_hash=ruleset.ruleset_hash,
                    ))

        # Global deterministic dedup. A duplicate can arise when reference and contour policies collapse to the same line.
        dedup: dict[tuple[str,str,str,str],ManufacturingMark] = {}
        for mark in marks:
            key=(mark.source_contact_id,mark.target_face_id,mark.mark_type,mark.geometry_2d.geometry_hash())
            dedup.setdefault(key,mark)
        marks=sorted(dedup.values(),key=lambda m:(m.target_part_id,m.target_face_id,m.mark_type,m.geometry_2d.geometry_hash(),m.mark_id))
        return ScribingGenerationReport(
            assembly_id=assembly_id,
            ruleset_id=ruleset.ruleset_id,
            ruleset_hash=ruleset.ruleset_hash,
            marks=marks,
            suppressions=suppressions,
            issues=issues,
            source_snapshot_hash=marking_source_snapshot_hash(project,assembly_id,ruleset),
            raw_candidate_count=raw_count,
            normalized_count=normalized_total,
        )


__all__=[
    "SCRIBING_ENGINE_VERSION","SCRIBING_ENGINE_SCHEMA_VERSION","MARK_SOURCE_SNAPSHOT_VERSION",
    "ScribingGenerationIssue","ScribingGenerationReport","ScribingMarkEngine",
    "predicate_matches","ruleset_applies","marking_source_snapshot","marking_source_snapshot_hash",
]
