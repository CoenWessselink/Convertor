"""Independent M7 sequence validator.

The validator reconstructs the expected operation DAG from current M6 evidence and
profile-nesting facts, then compares semantic operations/dependencies rather than
trusting stored sequence flags/hashes alone.
"""
from __future__ import annotations
from typing import Any
from cws_convertor.project.model import ProjectModel, stable_sha256
from .manufacturing_sequence import ManufacturingSequencePlanner, m7_source_snapshot_hash
from .manufacturing_sequence_contracts import ManufacturingSequencePlan, ManufacturingSequenceIssue, ManufacturingSequenceValidationReport


def _issue(msg: str, code: str="CWS-MARK-020") -> ManufacturingSequenceIssue:
    return ManufacturingSequenceIssue(code=code,message=msg,blocking=True,severity="error")


class IndependentManufacturingSequenceValidator:
    def validate(self, project: ProjectModel, sequence: ManufacturingSequencePlan) -> ManufacturingSequenceValidationReport:
        expected=ManufacturingSequencePlanner().build(project,sequence.run_id,sequence.assembly_id,sequence.capability_id)
        issues=[]
        if sequence.sequence_id!=expected.sequence_id:issues.append(_issue("sequence_id mismatch"))
        if sequence.source_snapshot_hash!=m7_source_snapshot_hash(project,sequence.run_id,sequence.assembly_id,sequence.capability_id):issues.append(_issue("CWS-MARK-015 sequence source is stale","CWS-MARK-015"))
        actual_ops={x.operation_id:x for x in sequence.operations}; expected_ops={x.operation_id:x for x in expected.operations}
        if set(actual_ops)!=set(expected_ops):issues.append(_issue(f"operation set mismatch missing={sorted(set(expected_ops)-set(actual_ops))} extra={sorted(set(actual_ops)-set(expected_ops))}"))
        for oid,e in expected_ops.items():
            a=actual_ops.get(oid)
            if a and a.to_dict()!=e.to_dict():issues.append(_issue(f"operation mismatch {oid}"))
        actual_deps={(x.predecessor_id,x.successor_id,x.reason,x.source_ref):x.dependency_hash for x in sequence.dependencies}
        expected_deps={(x.predecessor_id,x.successor_id,x.reason,x.source_ref):x.dependency_hash for x in expected.dependencies}
        if actual_deps!=expected_deps:issues.append(_issue("dependency DAG mismatch"))
        if tuple(sequence.linearized_operation_ids)!=tuple(expected.linearized_operation_ids):issues.append(_issue("deterministic DAG linearization mismatch"))
        if sequence.feasible!=expected.feasible:issues.append(_issue("feasible flag mismatch"))
        if sequence.plan_hash!=expected.plan_hash or sequence.m6_state_hash!=expected.m6_state_hash:issues.append(_issue("M6/nesting evidence binding mismatch"))
        report=ManufacturingSequenceValidationReport("passed" if not issues else "failed",sequence.sequence_id,sequence.source_snapshot_hash,sorted(expected_ops),issues)
        report.report_hash=stable_sha256({k:v for k,v in report.to_dict().items() if k!="report_hash"});return report


__all__=[name for name in globals() if not name.startswith("_")]
