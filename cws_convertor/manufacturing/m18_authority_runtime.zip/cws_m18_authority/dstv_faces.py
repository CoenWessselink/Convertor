"""DSTV-side adapter boundary for canonical manufacturing faces.

No default v/h/o/u inference lives here. M1 accepts only explicit, traceable mapping.
"""
from __future__ import annotations
from typing import Protocol
from cws_convertor.project.model import Part, stable_sha256
from .contracts import DstvFaceMappingCandidate, ManufacturingFace

class DstvFaceMappingAdapter(Protocol):
    def candidates(self, part: Part, semantic_role: str) -> tuple[DstvFaceMappingCandidate,...]: ...

class ExplicitDstvFaceMappingAdapter:
    def candidates(self, part: Part, semantic_role: str) -> tuple[DstvFaceMappingCandidate,...]:
        mapping=part.properties.get("dstv_face_mapping") if isinstance(part.properties,dict) else None
        if not isinstance(mapping,dict) or semantic_role not in mapping: return ()
        raw=mapping[semantic_role]
        if isinstance(raw,str): raw={"side":raw,"source":"explicit_part_property","proof_status":"user_confirmed"}
        if not isinstance(raw,dict): return ()
        side=str(raw.get("side") or raw.get("dstv_side") or "").strip().lower()
        if not side: return ()
        source=str(raw.get("source") or "explicit_part_property")
        proof=str(raw.get("proof_status") or "user_confirmed")
        mh=stable_sha256({"part_id":part.internal_id,"semantic_role":semantic_role,"side":side,"source":source,"proof_status":proof})
        return (DstvFaceMappingCandidate(side,source,proof,mh),)

def apply_explicit_dstv_candidates(part:Part,face:ManufacturingFace,adapter:DstvFaceMappingAdapter|None=None)->tuple[DstvFaceMappingCandidate,...]:
    return (adapter or ExplicitDstvFaceMappingAdapter()).candidates(part,face.semantic_role)
