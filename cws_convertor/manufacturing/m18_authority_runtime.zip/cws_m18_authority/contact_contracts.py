"""Versioned canonical contracts for assembly contact geometry (Scribing M2).

ContactPatch stores source/geometry facts only.  It deliberately does not contain
scribing policy or exporter syntax: later phases may derive many different marks
from the same immutable contact fact without mutating the source contact.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectValidationError, stable_sha256

CONTACT_PATCH_SCHEMA_VERSION = "1.0"
CONTACT_SET_SCHEMA_VERSION = "1.0"
CONTACT_HASH_VERSION = "cws-contact-geometry-v1"
CONTACT_STATE_SCHEMA_VERSION = "1.0"
CONTACT_TOLERANCE_PROFILE_VERSION = "cws-contact-tolerance-v1"


class ContactRelationType(str, Enum):
    WELDED_CONTACT = "welded_contact"
    BOLTED_CONTACT = "bolted_contact"
    GEOMETRIC_TOUCH = "geometric_touch"
    PROJECTED_ATTACHMENT = "projected_attachment"
    EXPLICIT_USER_RELATION = "explicit_user_relation"


class ContactProofStatus(str, Enum):
    EXACT = "exact"
    USER_CONFIRMED = "user_confirmed"
    REVIEW = "review"
    BLOCKED = "blocked"


@dataclass(frozen=True)
class ContactToleranceProfile:
    profile_id: str = CONTACT_TOLERANCE_PROFILE_VERSION
    plane_distance_mm: float = 0.05
    angular_tolerance_deg: float = 0.05
    projection_max_gap_mm: float = 25.0
    minimum_patch_area_mm2: float = 1.0
    point_tolerance_mm: float = 0.05

    def __post_init__(self) -> None:
        for name in (
            "plane_distance_mm",
            "angular_tolerance_deg",
            "projection_max_gap_mm",
            "minimum_patch_area_mm2",
            "point_tolerance_mm",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ProjectValidationError(f"Contacttolerantie {name} is ongeldig")
        if not self.profile_id.strip():
            raise ProjectValidationError("Contacttolerantieprofiel mist profile_id")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any] | None) -> "ContactToleranceProfile":
        raw = dict(value or {})
        allowed = {item.name for item in cls.__dataclass_fields__.values()}
        return cls(**{key: raw[key] for key in allowed if key in raw})


@dataclass(frozen=True)
class ContactPatch:
    contact_id: str
    assembly_id: str
    main_part_id: str
    secondary_part_id: str
    main_face_id: str
    secondary_face_id: str
    source_relation: Mapping[str, Any]
    relation_type: str
    exact_intersection_geometry: tuple[tuple[float, float, float], ...]
    projected_boundary_on_main_face: tuple[tuple[float, float], ...]
    projected_boundary_on_secondary_face: tuple[tuple[float, float], ...]
    area_mm2: float
    intersection_frame: str = "main_part_local"
    gap_mm: float = 0.0
    penetration_mm: float = 0.0
    weld_ids: tuple[str, ...] = ()
    fastener_ids: tuple[str, ...] = ()
    proof_status: str = ContactProofStatus.EXACT.value
    tolerance_profile: ContactToleranceProfile = field(default_factory=ContactToleranceProfile)
    provenance: Mapping[str, Any] = field(default_factory=dict)
    main_face_geometry_hash: str = ""
    secondary_face_geometry_hash: str = ""
    contact_hash: str = ""
    schema_version: str = CONTACT_PATCH_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.contact_id or not self.assembly_id:
            raise ProjectValidationError("ContactPatch mist contact_id of assembly_id")
        if not self.main_part_id or not self.secondary_part_id or self.main_part_id == self.secondary_part_id:
            raise ProjectValidationError("ContactPatch heeft ongeldige partrelatie")
        if not self.main_face_id or not self.secondary_face_id:
            raise ProjectValidationError("ContactPatch mist manufacturing face-referentie")
        if self.relation_type not in {item.value for item in ContactRelationType}:
            raise ProjectValidationError(f"Onbekend contactrelationtype {self.relation_type!r}")
        if self.intersection_frame != "main_part_local":
            raise ProjectValidationError("M2 ContactPatch vereist intersection_frame='main_part_local'")
        if self.proof_status not in {item.value for item in ContactProofStatus}:
            raise ProjectValidationError(f"Onbekende contact proof-status {self.proof_status!r}")
        area = float(self.area_mm2)
        gap = float(self.gap_mm)
        penetration = float(self.penetration_mm)
        if not all(math.isfinite(x) for x in (area, gap, penetration)):
            raise ProjectValidationError("ContactPatch bevat niet-eindige maat")
        if area <= 0.0:
            raise ProjectValidationError("ContactPatch-oppervlak moet positief zijn")
        if gap < 0.0 or penetration < 0.0:
            raise ProjectValidationError("Contact gap/penetration kan niet negatief zijn")
        if len(self.exact_intersection_geometry) < 3:
            raise ProjectValidationError("ContactPatch vereist minimaal drie 3D-punten")
        if len(self.projected_boundary_on_main_face) != len(self.exact_intersection_geometry):
            raise ProjectValidationError("Main-face projectie telt niet evenveel punten als contactgeometrie")
        if len(self.projected_boundary_on_secondary_face) != len(self.exact_intersection_geometry):
            raise ProjectValidationError("Secondary-face projectie telt niet evenveel punten als contactgeometrie")
        for point in self.exact_intersection_geometry:
            if len(point) != 3 or not all(math.isfinite(float(v)) for v in point):
                raise ProjectValidationError("ContactPatch bevat ongeldig 3D-punt")
        for boundary in (self.projected_boundary_on_main_face, self.projected_boundary_on_secondary_face):
            for point in boundary:
                if len(point) != 2 or not all(math.isfinite(float(v)) for v in point):
                    raise ProjectValidationError("ContactPatch bevat ongeldig 2D-projectiepunt")
        self.tolerance_profile.__post_init__()
        expected = stable_sha256(self.hash_payload())
        if self.contact_hash and self.contact_hash != expected:
            raise ProjectValidationError(f"ContactPatch {self.contact_id} heeft ongeldige contact_hash")
        object.__setattr__(self, "contact_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": CONTACT_HASH_VERSION,
            "schema_version": self.schema_version,
            "contact_id": self.contact_id,
            "assembly_id": self.assembly_id,
            "main_part_id": self.main_part_id,
            "secondary_part_id": self.secondary_part_id,
            "main_face_id": self.main_face_id,
            "secondary_face_id": self.secondary_face_id,
            "main_face_geometry_hash": self.main_face_geometry_hash,
            "secondary_face_geometry_hash": self.secondary_face_geometry_hash,
            "source_relation": dict(self.source_relation),
            "relation_type": self.relation_type,
            "exact_intersection_geometry": [list(p) for p in self.exact_intersection_geometry],
            "intersection_frame": self.intersection_frame,
            "projected_boundary_on_main_face": [list(p) for p in self.projected_boundary_on_main_face],
            "projected_boundary_on_secondary_face": [list(p) for p in self.projected_boundary_on_secondary_face],
            "area_mm2": self.area_mm2,
            "gap_mm": self.gap_mm,
            "penetration_mm": self.penetration_mm,
            "weld_ids": list(self.weld_ids),
            "fastener_ids": list(self.fastener_ids),
            "proof_status": self.proof_status,
            "tolerance_profile": self.tolerance_profile.to_dict(),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            **self.hash_payload(),
            "provenance": dict(self.provenance),
            "contact_hash": self.contact_hash,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ContactPatch":
        return cls(
            contact_id=str(value.get("contact_id") or ""),
            assembly_id=str(value.get("assembly_id") or ""),
            main_part_id=str(value.get("main_part_id") or ""),
            secondary_part_id=str(value.get("secondary_part_id") or ""),
            main_face_id=str(value.get("main_face_id") or ""),
            secondary_face_id=str(value.get("secondary_face_id") or ""),
            source_relation=dict(value.get("source_relation") or {}),
            relation_type=str(value.get("relation_type") or ""),
            exact_intersection_geometry=tuple(tuple(float(v) for v in p) for p in value.get("exact_intersection_geometry") or []),
            projected_boundary_on_main_face=tuple(tuple(float(v) for v in p) for p in value.get("projected_boundary_on_main_face") or []),
            projected_boundary_on_secondary_face=tuple(tuple(float(v) for v in p) for p in value.get("projected_boundary_on_secondary_face") or []),
            area_mm2=float(value.get("area_mm2") or 0.0),
            intersection_frame=str(value.get("intersection_frame") or "main_part_local"),
            gap_mm=float(value.get("gap_mm") or 0.0),
            penetration_mm=float(value.get("penetration_mm") or 0.0),
            weld_ids=tuple(sorted(str(x) for x in value.get("weld_ids") or [])),
            fastener_ids=tuple(sorted(str(x) for x in value.get("fastener_ids") or [])),
            proof_status=str(value.get("proof_status") or ContactProofStatus.EXACT.value),
            tolerance_profile=ContactToleranceProfile.from_dict(value.get("tolerance_profile")),
            provenance=dict(value.get("provenance") or {}),
            main_face_geometry_hash=str(value.get("main_face_geometry_hash") or ""),
            secondary_face_geometry_hash=str(value.get("secondary_face_geometry_hash") or ""),
            contact_hash=str(value.get("contact_hash") or ""),
            schema_version=str(value.get("schema_version") or CONTACT_PATCH_SCHEMA_VERSION),
        )


def contact_set_hash(assembly_id: str, patches: Iterable[ContactPatch]) -> str:
    ordered = sorted(patches, key=lambda item: item.contact_id)
    return stable_sha256(
        {
            "schema_version": CONTACT_SET_SCHEMA_VERSION,
            "assembly_id": assembly_id,
            "contacts": [item.contact_hash for item in ordered],
        }
    )


def validate_contact_set(assembly_id: str, patches: Iterable[ContactPatch]) -> str:
    ids: set[str] = set()
    rows = list(patches)
    for patch in rows:
        if patch.assembly_id != assembly_id:
            raise ProjectValidationError(f"Contact {patch.contact_id} hoort bij andere assembly")
        if patch.contact_id in ids:
            raise ProjectValidationError(f"Dubbele ContactPatch ID {patch.contact_id}")
        ids.add(patch.contact_id)
        restored = ContactPatch.from_dict(patch.to_dict())
        if restored.contact_hash != patch.contact_hash:
            raise ProjectValidationError(f"ContactPatch {patch.contact_id} faalt roundtripvalidatie")
    return contact_set_hash(assembly_id, rows)


__all__ = [
    "CONTACT_PATCH_SCHEMA_VERSION",
    "CONTACT_SET_SCHEMA_VERSION",
    "CONTACT_HASH_VERSION",
    "CONTACT_STATE_SCHEMA_VERSION",
    "ContactRelationType",
    "ContactProofStatus",
    "ContactToleranceProfile",
    "ContactPatch",
    "contact_set_hash",
    "validate_contact_set",
]
