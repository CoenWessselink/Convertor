"""Deterministic offline digital-twin replay for Scribing M12."""
from __future__ import annotations

from copy import deepcopy
import math
from typing import Any

from cws_convertor.project.model import ProjectModel, stable_sha256
from .manufacturing_sequence_contracts import ManufacturingSequencePlan, SequenceOperationType
from .simulation_contracts import ManufacturingSimulationReport, SimulationEvent, SimulationIssue

M12_PHASE = "M12"
_MARK_TYPES = {
    SequenceOperationType.SCRIBE.value,
    SequenceOperationType.IDENTIFY.value,
    SequenceOperationType.HOLE_REFERENCE.value,
    SequenceOperationType.POP_MARK.value,
    SequenceOperationType.CENTER_PUNCH.value,
}
_CUT_TYPES = {
    SequenceOperationType.SAW_START.value,
    SequenceOperationType.SAW_END.value,
    SequenceOperationType.COMMON_CUT.value,
}
_PROCESS_TYPES = _MARK_TYPES | {SequenceOperationType.DRILL.value}


def simulation_id(sequence: ManufacturingSequencePlan) -> str:
    return "sim-" + stable_sha256({"phase": M12_PHASE, "sequence_id": sequence.sequence_id, "sequence_hash": sequence.sequence_hash})[:28]


def _issue(code: str, message: str, op: Any | None = None, *, blocking: bool = True, severity: str = "error", remediation: str = "") -> SimulationIssue:
    return SimulationIssue(
        code=code,
        message=message,
        blocking=blocking,
        severity=severity,
        operation_id=str(getattr(op, "operation_id", "") or ""),
        bar_id=str(getattr(op, "bar_id", "") or ""),
        piece_instance_id=str(getattr(op, "piece_instance_id", "") or ""),
        mark_id=str(getattr(op, "mark_id", "") or ""),
        suggested_remediation=remediation,
    )


def _blank_bar() -> dict[str, Any]:
    return {
        "loaded": False,
        "clamped": False,
        "unloaded": False,
        "stock_length_mm": None,
        "orientation_changes": 0,
        "reclamps": 0,
        "cut_operation_ids": [],
        "cut_positions_mm": [],
        "processed_operation_ids": [],
        "executed_mark_ids": [],
        "drilled_feature_ids": [],
        "severed_piece_ids": [],
        "unloaded_piece_ids": [],
    }


def _normalize_states(states: dict[str, dict[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for bar_id in sorted(states):
        row = deepcopy(states[bar_id])
        for key in (
            "cut_operation_ids",
            "processed_operation_ids",
            "executed_mark_ids",
            "drilled_feature_ids",
            "severed_piece_ids",
            "unloaded_piece_ids",
        ):
            row[key] = list(row.get(key) or [])
        row["cut_positions_mm"] = [float(x) for x in row.get("cut_positions_mm") or []]
        result[bar_id] = row
    return result


def _state_hash(states: dict[str, dict[str, Any]]) -> str:
    return stable_sha256(_normalize_states(states))


def _part_has_face(project: ProjectModel, part_id: str, face_id: str) -> bool:
    part = project.parts.get(part_id)
    if part is None or not face_id:
        return False
    return any(str(x.get("face_id") or "") == face_id for x in part.manufacturing_faces if isinstance(x, dict))


def simulate_sequence(
    project: ProjectModel,
    sequence: ManufacturingSequencePlan,
    *,
    source_sequence_state_hash: str,
) -> ManufacturingSimulationReport:
    """Replay an M7 plan without emitting controller syntax or doing I/O.

    The replay intentionally uses only persisted M7 operations plus current
    canonical project evidence.  It models lifecycle invariants (load/clamp,
    processing-before-sever, sever-before-unload, complete bar unload) rather
    than pretending to simulate proprietary servo motion.
    """

    operations = {x.operation_id: x for x in sequence.operations}
    order = tuple(sequence.linearized_operation_ids)
    order_index = {op_id: i for i, op_id in enumerate(order)}
    issues: list[SimulationIssue] = []

    if set(order) != set(operations) or len(order) != len(operations):
        issues.append(_issue("CWS-SIM-001", "M12 operation_order bevat niet exact alle M7 operations"))
    for dep in sequence.dependencies:
        if dep.predecessor_id not in order_index or dep.successor_id not in order_index:
            issues.append(_issue("CWS-SIM-002", f"Dependency verwijst naar onbekende operation: {dep.predecessor_id} -> {dep.successor_id}"))
        elif order_index[dep.predecessor_id] >= order_index[dep.successor_id]:
            issues.append(_issue("CWS-SIM-003", f"Dependencyvolgorde geschonden: {dep.predecessor_id} -> {dep.successor_id}"))

    expected_pieces: dict[str, set[str]] = {}
    for op in sequence.operations:
        if op.piece_instance_id:
            expected_pieces.setdefault(op.bar_id, set()).add(op.piece_instance_id)

    states: dict[str, dict[str, Any]] = {}
    events: list[SimulationEvent] = []
    elapsed = 0.0

    for index, op_id in enumerate(order):
        op = operations.get(op_id)
        if op is None:
            continue
        bar = states.setdefault(op.bar_id, _blank_bar())
        before = _state_hash(states)
        local: list[SimulationIssue] = []
        observations: dict[str, Any] = {"estimated_seconds": float(op.estimated_seconds)}

        if op.machine_id != sequence.machine_id:
            local.append(_issue("CWS-SIM-004", "Operation machine-ID wijkt af van sequence machine-ID", op))
        if not op.feasible:
            local.append(_issue("CWS-SIM-005", "M7 operation is zelf als niet-feasible gemarkeerd", op))

        kind = op.operation_type
        if kind == SequenceOperationType.LOAD_BAR.value:
            if bar["loaded"] and not bar["unloaded"]:
                local.append(_issue("CWS-SIM-006", "Staaf wordt dubbel geladen", op))
            if bar["unloaded"]:
                local.append(_issue("CWS-SIM-006", "Staaf wordt opnieuw geladen nadat hij al is uitgeladen", op))
            if not local:
                bar["loaded"] = True
                raw_length = dict(op.parameters).get("stock_length_mm")
                if raw_length is not None:
                    try:
                        length = float(raw_length)
                        if not math.isfinite(length) or length <= 0:
                            raise ValueError
                        bar["stock_length_mm"] = length
                    except (TypeError, ValueError):
                        local.append(_issue("CWS-SIM-007", "Ongeldige stock_length_mm bij load_bar", op))
        else:
            if not bar["loaded"] or bar["unloaded"]:
                local.append(_issue("CWS-SIM-008", "Operation wordt uitgevoerd terwijl de staaf niet geladen is", op))

        if kind == SequenceOperationType.CLAMP.value:
            if bar["clamped"]:
                local.append(_issue("CWS-SIM-009", "Staaf wordt dubbel geklemd zonder reclamp-semantiek", op, blocking=False, severity="warning"))
            if not any(x.blocking for x in local):
                bar["clamped"] = True
        elif kind == SequenceOperationType.RECLAMP.value:
            if not bar["clamped"]:
                local.append(_issue("CWS-SIM-010", "Reclamp vereist een reeds geklemde staaf", op))
            if not any(x.blocking for x in local):
                bar["reclamps"] += 1
        elif kind == SequenceOperationType.REORIENT.value:
            if not bar["clamped"]:
                local.append(_issue("CWS-SIM-011", "Reorient vereist een geklemde/gelokaliseerde staaf", op))
            if not any(x.blocking for x in local):
                bar["orientation_changes"] += 1
        elif kind in (_PROCESS_TYPES | _CUT_TYPES | {SequenceOperationType.SEVER_PIECE.value}):
            if not bar["clamped"]:
                local.append(_issue("CWS-SIM-012", f"{kind} vereist clamp/reclamp", op))

        if op.piece_instance_id and op.piece_instance_id in set(bar["unloaded_piece_ids"]):
            local.append(_issue("CWS-SIM-013", "Operation richt zich op een reeds uitgeladen piece", op))
        elif op.piece_instance_id and kind not in {SequenceOperationType.UNLOAD_PIECE.value} and op.piece_instance_id in set(bar["severed_piece_ids"]):
            local.append(_issue("CWS-SIM-014", "Operation richt zich op een reeds afgescheiden piece", op))

        if kind in _CUT_TYPES:
            if op.position_mm is None or not math.isfinite(float(op.position_mm)) or float(op.position_mm) < 0:
                local.append(_issue("CWS-SIM-015", "Zaagoperation mist een geldige niet-negatieve positie", op))
            else:
                position = float(op.position_mm)
                stock_length = bar.get("stock_length_mm")
                if stock_length is not None and position > float(stock_length) + 1e-6:
                    local.append(_issue("CWS-SIM-016", "Zaagpositie ligt buiten de geladen handelslengte", op))
                if not any(x.blocking for x in local):
                    bar["cut_operation_ids"].append(op.operation_id)
                    bar["cut_positions_mm"].append(position)
                    observations["cut_position_mm"] = position

        if kind in _PROCESS_TYPES:
            if op.part_id not in project.parts:
                local.append(_issue("CWS-SIM-017", "Process-operation verwijst naar onbekend part", op))
            if kind in _MARK_TYPES:
                mark = project.manufacturing_marks.get(op.mark_id)
                if not isinstance(mark, dict):
                    local.append(_issue("CWS-SIM-018", "Mark-operation verwijst naar ontbrekende canonical mark", op))
                else:
                    if str(mark.get("target_part_id") or mark.get("part_id") or "") not in {"", op.part_id}:
                        local.append(_issue("CWS-SIM-019", "Canonical mark target-part wijkt af van M7 operation", op))
                    if op.face_id and not _part_has_face(project, op.part_id, op.face_id):
                        local.append(_issue("CWS-SIM-020", "M7 target face bestaat niet meer op current part", op))
                if op.tool_id and op.tool_id not in project.manufacturing_marking_tools:
                    local.append(_issue("CWS-SIM-021", "Mark-operation verwijst naar onbekende M5 marking tool", op))
            if kind == SequenceOperationType.DRILL.value and op.feature_id:
                observations["feature_id"] = op.feature_id
            if not any(x.blocking for x in local):
                bar["processed_operation_ids"].append(op.operation_id)
                if op.mark_id:
                    bar["executed_mark_ids"].append(op.mark_id)
                if op.feature_id:
                    bar["drilled_feature_ids"].append(op.feature_id)

        if kind == SequenceOperationType.SEVER_PIECE.value:
            if not op.piece_instance_id:
                local.append(_issue("CWS-SIM-022", "sever_piece mist piece_instance_id", op))
            if op.piece_instance_id in set(bar["severed_piece_ids"]):
                local.append(_issue("CWS-SIM-023", "Piece wordt dubbel afgescheiden", op))
            preceding_cut = False
            for cut_id in bar["cut_operation_ids"]:
                cut_op = operations.get(cut_id)
                if cut_op and cut_op.piece_instance_id == op.piece_instance_id:
                    preceding_cut = True
                    break
            if not preceding_cut:
                local.append(_issue("CWS-SIM-024", "sever_piece heeft geen voorafgaande piece-cut in replaystate", op))
            if not any(x.blocking for x in local):
                bar["severed_piece_ids"].append(op.piece_instance_id)
        elif kind == SequenceOperationType.UNLOAD_PIECE.value:
            if not op.piece_instance_id or op.piece_instance_id not in set(bar["severed_piece_ids"]):
                local.append(_issue("CWS-SIM-025", "unload_piece vereist een vooraf afgescheiden piece", op))
            if op.piece_instance_id in set(bar["unloaded_piece_ids"]):
                local.append(_issue("CWS-SIM-026", "Piece wordt dubbel uitgeladen", op))
            if not any(x.blocking for x in local):
                bar["unloaded_piece_ids"].append(op.piece_instance_id)
        elif kind == SequenceOperationType.UNLOAD_BAR.value:
            missing = sorted(expected_pieces.get(op.bar_id, set()) - set(bar["unloaded_piece_ids"]))
            if missing:
                local.append(_issue("CWS-SIM-027", f"Staaf wordt uitgeladen terwijl pieces nog niet zijn uitgeladen: {missing}", op))
            if not any(x.blocking for x in local):
                bar["unloaded"] = True
                bar["clamped"] = False

        elapsed += float(op.estimated_seconds)
        issues.extend(local)
        after = _state_hash(states)
        result = "blocked" if any(x.blocking for x in local) else ("review" if local else "passed")
        observations.update({"bar_loaded": bool(bar["loaded"]), "bar_clamped": bool(bar["clamped"]), "bar_unloaded": bool(bar["unloaded"])})
        events.append(SimulationEvent(
            event_index=index,
            operation_id=op.operation_id,
            operation_type=op.operation_type,
            bar_id=op.bar_id,
            piece_instance_id=op.piece_instance_id,
            result=result,
            state_before_hash=before,
            state_after_hash=after,
            operation_hash=op.operation_hash,
            observations=observations,
        ))

    for bar_id, bar in sorted(states.items()):
        if not bar["unloaded"]:
            issues.append(SimulationIssue("CWS-SIM-028", "Simulation eindigt met geladen staaf", True, "error", bar_id=bar_id))
        expected = expected_pieces.get(bar_id, set())
        missing = sorted(expected - set(bar["unloaded_piece_ids"]))
        if missing:
            issues.append(SimulationIssue("CWS-SIM-029", f"Simulation eindigt met niet-uitgeladen pieces: {missing}", True, "error", bar_id=bar_id))

    final_states = _normalize_states(states)
    final_hash = stable_sha256(final_states)
    blocking = any(x.blocking for x in issues)
    review = any(not x.blocking for x in issues)
    feasible = bool(sequence.feasible and not blocking and len(events) == len(sequence.operations))
    return ManufacturingSimulationReport(
        simulation_id=simulation_id(sequence),
        sequence_id=sequence.sequence_id,
        machine_id=sequence.machine_id,
        source_sequence_hash=sequence.sequence_hash,
        source_sequence_state_hash=source_sequence_state_hash,
        operation_order=order,
        events=tuple(events),
        issues=tuple(issues),
        final_bar_states=final_states,
        feasible=feasible,
        review_required=review,
        simulated_total_seconds=elapsed,
        final_state_hash=final_hash,
    )


__all__ = [name for name in globals() if not name.startswith("_")]
