"""Deterministic 2D geometry helpers for Scribing M3 generation.

This module belongs to the generator path. The independent validator deliberately
reimplements its decisive containment/clearance checks rather than importing
these helpers wholesale.
"""
from __future__ import annotations

import math
from typing import Any, Iterable

from cws_convertor.project.model import Part, ProjectValidationError
from .contracts import ManufacturingFace

GEOMETRY_EPS = 1e-9


def canonical_segment(a: tuple[float, float], b: tuple[float, float]) -> tuple[tuple[float, float], tuple[float, float]]:
    pa = (float(a[0]), float(a[1])); pb = (float(b[0]), float(b[1]))
    return (pa, pb) if pa <= pb else (pb, pa)


def distance(a: tuple[float, float], b: tuple[float, float]) -> float:
    return math.hypot(b[0] - a[0], b[1] - a[1])


def line_face_outer_polygon(face: ManufacturingFace) -> list[tuple[float, float]]:
    outer = [loop for loop in face.boundary_loops_2d if not loop.is_hole]
    if len(outer) != 1:
        raise ProjectValidationError(f"Face {face.face_id} heeft geen unieke outer boundary")
    if any(segment.kind != "line" or segment.start is None for segment in outer[0].segments):
        raise ProjectValidationError(f"Face {face.face_id} heeft geen M3-ondersteunde analytische lijnboundary")
    points = [(float(segment.start[0]), float(segment.start[1])) for segment in outer[0].segments]
    if len(points) < 3:
        raise ProjectValidationError(f"Face {face.face_id} heeft onvoldoende boundarypunten")
    return points


def polygon_signed_area(points: Iterable[tuple[float, float]]) -> float:
    pts = list(points)
    return 0.5 * sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts)))


def point_on_segment(p, a, b, tol=1e-8) -> bool:
    cross = (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])
    if abs(cross) > tol * max(1.0, distance(a,b)):
        return False
    dot = (p[0]-a[0])*(p[0]-b[0]) + (p[1]-a[1])*(p[1]-b[1])
    return dot <= tol*tol


def point_in_polygon(point: tuple[float,float], polygon: list[tuple[float,float]], tol=1e-8) -> bool:
    for i, a in enumerate(polygon):
        if point_on_segment(point, a, polygon[(i+1)%len(polygon)], tol):
            return True
    x, y = point; inside = False; j = len(polygon)-1
    for i in range(len(polygon)):
        xi, yi = polygon[i]; xj, yj = polygon[j]
        if (yi > y) != (yj > y):
            x_at = (xj-xi)*(y-yi)/(yj-yi)+xi
            if x < x_at:
                inside = not inside
        j = i
    return inside


def _line_intersection(p1, p2, p3, p4):
    x1,y1=p1; x2,y2=p2; x3,y3=p3; x4,y4=p4
    den=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4)
    if abs(den)<GEOMETRY_EPS:return None
    px=((x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4))/den
    py=((x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4))/den
    return (px,py)


def inset_convex_polygon(polygon: list[tuple[float,float]], margin: float) -> list[tuple[float,float]]:
    margin=max(0.0,float(margin))
    if margin<=GEOMETRY_EPS:return list(polygon)
    if len(polygon)<3:return []
    orientation=1.0 if polygon_signed_area(polygon)>0 else -1.0
    shifted=[]
    for i,a in enumerate(polygon):
        b=polygon[(i+1)%len(polygon)]
        dx=b[0]-a[0];dy=b[1]-a[1];ln=math.hypot(dx,dy)
        if ln<=GEOMETRY_EPS:return []
        # CCW interior is left of each edge; CW interior is right.
        nx=orientation*(-dy/ln);ny=orientation*(dx/ln)
        shifted.append(((a[0]+nx*margin,a[1]+ny*margin),(b[0]+nx*margin,b[1]+ny*margin)))
    result=[]
    for i in range(len(shifted)):
        prev=shifted[(i-1)%len(shifted)];cur=shifted[i]
        p=_line_intersection(prev[0],prev[1],cur[0],cur[1])
        if p is None:return []
        result.append(p)
    # Excessive margin can invert/empty the polygon; require the inset centroid
    # to still be inside the original and area to remain meaningful.
    if abs(polygon_signed_area(result))<=GEOMETRY_EPS:return []
    centroid=(sum(p[0] for p in result)/len(result),sum(p[1] for p in result)/len(result))
    if not point_in_polygon(centroid,polygon,1e-7):return []
    return result


def _segment_intersection_parameter(a,b,c,d):
    rx=b[0]-a[0];ry=b[1]-a[1];sx=d[0]-c[0];sy=d[1]-c[1]
    den=rx*sy-ry*sx
    if abs(den)<GEOMETRY_EPS:return None
    qx=c[0]-a[0];qy=c[1]-a[1]
    t=(qx*sy-qy*sx)/den;u=(qx*ry-qy*rx)/den
    if -GEOMETRY_EPS<=t<=1+GEOMETRY_EPS and -GEOMETRY_EPS<=u<=1+GEOMETRY_EPS:
        return min(1.0,max(0.0,t))
    return None


def point_at(a,b,t):return (a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)


def clip_segment_to_polygon(a: tuple[float,float], b: tuple[float,float], polygon: list[tuple[float,float]]) -> list[tuple[tuple[float,float],tuple[float,float]]]:
    if distance(a,b)<=GEOMETRY_EPS:return []
    ts=[0.0,1.0]
    for i,c in enumerate(polygon):
        t=_segment_intersection_parameter(a,b,c,polygon[(i+1)%len(polygon)])
        if t is not None:ts.append(t)
    ts=sorted(set(round(x,12) for x in ts))
    out=[]
    for left,right in zip(ts,ts[1:]):
        if right-left<=1e-12:continue
        mid=point_at(a,b,(left+right)/2)
        if point_in_polygon(mid,polygon,1e-8):
            pa=point_at(a,b,left);pb=point_at(a,b,right)
            if distance(pa,pb)>GEOMETRY_EPS:out.append(canonical_segment(pa,pb))
    return out


def _inside_circle_intervals(a,b,center,radius):
    dx=b[0]-a[0];dy=b[1]-a[1];fx=a[0]-center[0];fy=a[1]-center[1]
    aa=dx*dx+dy*dy
    if aa<=GEOMETRY_EPS:return []
    bb=2*(fx*dx+fy*dy);cc=fx*fx+fy*fy-radius*radius
    disc=bb*bb-4*aa*cc
    roots=[]
    if disc>=0:
        root=math.sqrt(max(0.0,disc));roots=[(-bb-root)/(2*aa),(-bb+root)/(2*aa)]
    ts=[0.0,1.0]+[min(1.0,max(0.0,t)) for t in roots if -GEOMETRY_EPS<=t<=1+GEOMETRY_EPS]
    ts=sorted(set(round(t,12) for t in ts))
    intervals=[]
    for l,r in zip(ts,ts[1:]):
        if r-l<=1e-12:continue
        m=point_at(a,b,(l+r)/2)
        if distance(m,center)<radius-GEOMETRY_EPS:intervals.append((l,r))
    return intervals


def _inside_rect_intervals(a,b,rect):
    u0,v0,u1,v1=rect;poly=[(u0,v0),(u1,v0),(u1,v1),(u0,v1)]
    segments=clip_segment_to_polygon(a,b,poly)
    result=[];length=distance(a,b)
    if length<=GEOMETRY_EPS:return result
    dx=b[0]-a[0];dy=b[1]-a[1]
    for p,q in segments:
        def param(x):
            if abs(dx)>=abs(dy) and abs(dx)>GEOMETRY_EPS:return (x[0]-a[0])/dx
            return (x[1]-a[1])/dy if abs(dy)>GEOMETRY_EPS else 0.0
        result.append(tuple(sorted((max(0.0,min(1.0,param(p))),max(0.0,min(1.0,param(q)))))))
    return result


def subtract_intervals(a,b,blocked_intervals):
    blocked=[]
    for l,r in blocked_intervals:
        l=max(0.0,min(1.0,float(l)));r=max(0.0,min(1.0,float(r)))
        if r<l:l,r=r,l
        if r-l>1e-12:blocked.append((l,r))
    blocked.sort()
    merged=[]
    for l,r in blocked:
        if not merged or l>merged[-1][1]+1e-12:merged.append([l,r])
        else:merged[-1][1]=max(merged[-1][1],r)
    cursor=0.0;out=[]
    for l,r in merged:
        if l>cursor+1e-12:out.append(canonical_segment(point_at(a,b,cursor),point_at(a,b,l)))
        cursor=max(cursor,r)
    if cursor<1.0-1e-12:out.append(canonical_segment(point_at(a,b,cursor),b))
    return [seg for seg in out if distance(*seg)>GEOMETRY_EPS]


def subtract_circle_zones(a,b,zones):
    intervals=[]
    for zone in zones:
        intervals.extend(_inside_circle_intervals(a,b,zone["center"],zone["radius_mm"]))
    return subtract_intervals(a,b,intervals)


def subtract_rect_zones(a,b,zones):
    intervals=[]
    for zone in zones:intervals.extend(_inside_rect_intervals(a,b,zone["rect"]))
    return subtract_intervals(a,b,intervals)


def split_segment(a,b,segment_length:float,gap:float,min_length:float=0.0):
    total=distance(a,b)
    if total<=GEOMETRY_EPS:return []
    segment_length=max(float(segment_length),GEOMETRY_EPS);gap=max(float(gap),0.0)
    direction=((b[0]-a[0])/total,(b[1]-a[1])/total)
    cursor=0.0;out=[]
    while cursor<total-GEOMETRY_EPS:
        end=min(total,cursor+segment_length)
        if end-cursor>=min_length-GEOMETRY_EPS:
            p=(a[0]+direction[0]*cursor,a[1]+direction[1]*cursor)
            q=(a[0]+direction[0]*end,a[1]+direction[1]*end)
            out.append(canonical_segment(p,q))
        cursor=end+gap
    return out


def merge_collinear_contiguous(segments, tol=1e-7):
    work=[canonical_segment(*seg) for seg in segments if distance(*seg)>tol]
    changed=True
    while changed:
        changed=False
        for i in range(len(work)):
            a,b=work[i];dx=b[0]-a[0];dy=b[1]-a[1];ln=math.hypot(dx,dy)
            if ln<=tol:continue
            for j in range(i+1,len(work)):
                c,d=work[j]
                # collinear endpoints and touching/overlapping projection
                if abs(dx*(c[1]-a[1])-dy*(c[0]-a[0]))>tol*ln or abs(dx*(d[1]-a[1])-dy*(d[0]-a[0]))>tol*ln:continue
                ux,uy=dx/ln,dy/ln
                vals=[0.0,ln,(c[0]-a[0])*ux+(c[1]-a[1])*uy,(d[0]-a[0])*ux+(d[1]-a[1])*uy]
                first1,last1=0.0,ln;first2,last2=sorted(vals[2:])
                if first2>last1+tol or last2<first1-tol:continue
                lo=min(vals);hi=max(vals)
                merged=canonical_segment((a[0]+ux*lo,a[1]+uy*lo),(a[0]+ux*hi,a[1]+uy*hi))
                work[i]=merged;work.pop(j);changed=True;break
            if changed:break
    unique={tuple(round(v,9) for p in seg for v in p):seg for seg in work}
    return [unique[key] for key in sorted(unique)]


def target_hole_zones(part: Part, face: ManufacturingFace, margin_mm: float) -> list[dict[str,Any]]:
    zones=[];margin=max(0.0,float(margin_mm));candidate_sides={c.dstv_side for c in face.dstv_side_candidates}
    explicit=part.properties.get("marking_hole_zones") if isinstance(part.properties,dict) else None
    for idx,raw in enumerate(explicit if isinstance(explicit,list) else []):
        if not isinstance(raw,dict):continue
        ref=str(raw.get("face_id") or raw.get("semantic_role") or "")
        if ref and ref not in {face.face_id,face.semantic_role,*candidate_sides}:continue
        try:
            u=float(raw.get("u_mm"));v=float(raw.get("v_mm"));diam=float(raw.get("diameter_mm") or 0.0)
        except (TypeError,ValueError):continue
        if diam>0:zones.append({"id":str(raw.get("id") or f"explicit-hole-{idx}"),"center":(u,v),"radius_mm":diam/2+margin,"source":"part.properties.marking_hole_zones"})
    for idx,raw in enumerate(part.production_features):
        if not isinstance(raw,dict) or str(raw.get("kind") or "")!="hole":continue
        ref=str(raw.get("face") or "")
        if ref and ref not in {face.face_id,face.semantic_role,*candidate_sides}:continue
        try:u=float(raw.get("x"));v=float(raw.get("q"));diam=float(raw.get("diameter") or 0.0)
        except (TypeError,ValueError):continue
        if diam>0:zones.append({"id":str(raw.get("id") or f"feature-hole-{idx}"),"center":(u,v),"radius_mm":diam/2+margin,"source":"part.production_features"})
    return zones


def target_weld_zones(part: Part, face: ManufacturingFace, margin_mm: float) -> list[dict[str,Any]]:
    zones=[];margin=max(0.0,float(margin_mm));candidate_sides={c.dstv_side for c in face.dstv_side_candidates}
    explicit=part.properties.get("marking_weld_zones") if isinstance(part.properties,dict) else None
    for idx,raw in enumerate(explicit if isinstance(explicit,list) else []):
        if not isinstance(raw,dict):continue
        ref=str(raw.get("face_id") or raw.get("semantic_role") or "")
        if ref and ref not in {face.face_id,face.semantic_role,*candidate_sides}:continue
        kind=str(raw.get("kind") or "circle")
        try:
            if kind=="circle":
                u=float(raw.get("u_mm"));v=float(raw.get("v_mm"));radius=float(raw.get("radius_mm") or 0.0)+margin
                if radius>0:zones.append({"id":str(raw.get("id") or f"weld-circle-{idx}"),"kind":"circle","center":(u,v),"radius_mm":radius,"source":"part.properties.marking_weld_zones"})
            elif kind=="rect":
                u0=float(raw.get("u0_mm"))-margin;v0=float(raw.get("v0_mm"))-margin;u1=float(raw.get("u1_mm"))+margin;v1=float(raw.get("v1_mm"))+margin
                zones.append({"id":str(raw.get("id") or f"weld-rect-{idx}"),"kind":"rect","rect":(min(u0,u1),min(v0,v1),max(u0,u1),max(v0,v1)),"source":"part.properties.marking_weld_zones"})
        except (TypeError,ValueError):continue
    return zones


__all__=[name for name in globals() if not name.startswith("_")]
