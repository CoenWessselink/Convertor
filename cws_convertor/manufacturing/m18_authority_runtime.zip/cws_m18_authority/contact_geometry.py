"""Deterministic assembly contact geometry engine for Scribing M2.

The M2 exact path is intentionally limited to analytically resolved planar
ManufacturingFaces whose outer boundary is a single convex line loop.  Within
that scope the result is exact with respect to the canonical face model.  More
complex BREP intersections are *not* guessed; they remain review/blocked until a
later exact geometry adapter proves them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import Assembly, Part, ProjectModel, ProjectValidationError, stable_sha256
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .service import load_faces, validate_persisted_face_state
from .contact_contracts import (
    ContactPatch,
    ContactProofStatus,
    ContactRelationType,
    ContactToleranceProfile,
    contact_set_hash,
)

CONTACT_GEOMETRY_ENGINE_VERSION = "cws-contact-geometry-engine-1.0"
CONTACT_GEOMETRY_ENGINE_SCHEMA_VERSION = "1.0"


def _dot(a: Iterable[float], b: Iterable[float]) -> float:
    return sum(float(x) * float(y) for x, y in zip(a, b))


def _sub(a: Iterable[float], b: Iterable[float]) -> tuple[float, float, float]:
    av, bv = tuple(float(x) for x in a), tuple(float(x) for x in b)
    return (av[0]-bv[0], av[1]-bv[1], av[2]-bv[2])


def _distance(a: Iterable[float], b: Iterable[float]) -> float:
    d = _sub(a, b)
    return math.sqrt(_dot(d, d))


def _transform_point(transform, point: Iterable[float]) -> tuple[float,float,float]:
    matrix = transform.matrix
    p = tuple(float(x) for x in point)
    return tuple(sum(float(matrix[r][c]) * (p[c] if c < 3 else 1.0) for c in range(4)) for r in range(3))


def _relative_transform(reference: Part, target: Part) -> list[list[float]]:
    """Rigid target placement expressed in reference-part coordinates."""
    rm = [[float(reference.global_placement.matrix[r][c]) for c in range(3)] for r in range(3)]
    rs = [[float(target.global_placement.matrix[r][c]) for c in range(3)] for r in range(3)]
    tm = [float(reference.global_placement.matrix[r][3]) for r in range(3)]
    ts = [float(target.global_placement.matrix[r][3]) for r in range(3)]
    # inverse(Rm) = transpose(Rm) for validated rigid transforms.
    rt = [[rm[c][r] for c in range(3)] for r in range(3)]
    rel_r = [[sum(rt[r][k]*rs[k][c] for k in range(3)) for c in range(3)] for r in range(3)]
    delta = [ts[i]-tm[i] for i in range(3)]
    rel_t = [sum(rt[r][k]*delta[k] for k in range(3)) for r in range(3)]
    rows = [[rel_r[r][0],rel_r[r][1],rel_r[r][2],rel_t[r]] for r in range(3)] + [[0.0,0.0,0.0,1.0]]
    return [[round(v,12) for v in row] for row in rows]


def _polygon_area(points: Iterable[tuple[float, float]]) -> float:
    rows = list(points)
    if len(rows) < 3:
        return 0.0
    return 0.5 * sum(
        rows[i][0] * rows[(i + 1) % len(rows)][1]
        - rows[(i + 1) % len(rows)][0] * rows[i][1]
        for i in range(len(rows))
    )


def _clean_polygon(points: Iterable[tuple[float, float]], tol: float = 1e-8) -> list[tuple[float, float]]:
    result: list[tuple[float, float]] = []
    for point in points:
        p = (float(point[0]), float(point[1]))
        if result and math.hypot(p[0]-result[-1][0], p[1]-result[-1][1]) <= tol:
            continue
        result.append(p)
    if len(result) > 1 and math.hypot(result[0][0]-result[-1][0], result[0][1]-result[-1][1]) <= tol:
        result.pop()
    if len(result) >= 3 and _polygon_area(result) < 0.0:
        result.reverse()
    return result


def _is_convex(points: list[tuple[float, float]], tol: float = 1e-9) -> bool:
    if len(points) < 3:
        return False
    sign = 0
    for i in range(len(points)):
        a, b, c = points[i-1], points[i], points[(i+1) % len(points)]
        cross = (b[0]-a[0])*(c[1]-b[1]) - (b[1]-a[1])*(c[0]-b[0])
        if abs(cross) <= tol:
            continue
        current = 1 if cross > 0 else -1
        if sign and current != sign:
            return False
        sign = current
    return sign != 0


def _line_loop_polygon(face: ManufacturingFace) -> list[tuple[float, float]] | None:
    if face.surface_type != ManufacturingSurfaceType.PLANE.value:
        return None
    outer = [loop for loop in face.boundary_loops_2d if not loop.is_hole]
    holes = [loop for loop in face.boundary_loops_2d if loop.is_hole]
    if len(outer) != 1 or holes:
        return None
    loop = outer[0]
    if not loop.segments or any(segment.kind != "line" or segment.start is None for segment in loop.segments):
        return None
    points = _clean_polygon([segment.start for segment in loop.segments])
    return points if len(points) >= 3 and _is_convex(points) else None


def _inside(point: tuple[float, float], edge_a: tuple[float, float], edge_b: tuple[float, float], tol: float = 1e-9) -> bool:
    return (edge_b[0]-edge_a[0])*(point[1]-edge_a[1]) - (edge_b[1]-edge_a[1])*(point[0]-edge_a[0]) >= -tol


def _intersection(
    s: tuple[float, float],
    e: tuple[float, float],
    a: tuple[float, float],
    b: tuple[float, float],
) -> tuple[float, float]:
    dx1, dy1 = e[0]-s[0], e[1]-s[1]
    dx2, dy2 = b[0]-a[0], b[1]-a[1]
    denom = dx1*dy2 - dy1*dx2
    if abs(denom) <= 1e-14:
        return e
    t = ((a[0]-s[0])*dy2 - (a[1]-s[1])*dx2) / denom
    return (s[0]+t*dx1, s[1]+t*dy1)


def _convex_intersection(subject: list[tuple[float, float]], clip: list[tuple[float, float]]) -> list[tuple[float, float]]:
    output = _clean_polygon(subject)
    clipper = _clean_polygon(clip)
    if not output or not clipper:
        return []
    for i, cp1 in enumerate(clipper):
        cp2 = clipper[(i+1) % len(clipper)]
        input_list = output
        output = []
        if not input_list:
            break
        s = input_list[-1]
        for e in input_list:
            if _inside(e, cp1, cp2):
                if not _inside(s, cp1, cp2):
                    output.append(_intersection(s, e, cp1, cp2))
                output.append(e)
            elif _inside(s, cp1, cp2):
                output.append(_intersection(s, e, cp1, cp2))
            s = e
        output = _clean_polygon(output)
    return output


def _global_frame(part: Part, face: ManufacturingFace):
    return face.local_frame.transformed(part.global_placement)


def _project_face_polygon_to_frame(part: Part, face: ManufacturingFace, target_frame) -> list[tuple[float, float]] | None:
    polygon = _line_loop_polygon(face)
    if polygon is None:
        return None
    source_global = _global_frame(part, face)
    result: list[tuple[float, float]] = []
    for u, v in polygon:
        global_point = source_global.part_xyz(u, v, 0.0)
        tu, tv, _tn = target_frame.local_uvn(global_point)
        result.append((tu, tv))
    return _clean_polygon(result)


def _relation_ids(project: ProjectModel, assembly: Assembly, main_part_id: str, secondary_part_id: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    pair = {main_part_id, secondary_part_id}
    weld_ids = []
    for weld_id in assembly.weld_ids:
        weld = project.welds.get(weld_id)
        if weld and pair.issubset(set(weld.connected_part_ids)):
            weld_ids.append(weld_id)
    fastener_ids = []
    for fastener_id in assembly.fastener_ids:
        fastener = project.fasteners.get(fastener_id)
        if fastener and pair.issubset(set(fastener.connected_part_ids)):
            fastener_ids.append(fastener_id)
    return tuple(sorted(weld_ids)), tuple(sorted(fastener_ids))


def _explicit_relation(project: ProjectModel, assembly_id: str, main_part_id: str, secondary_part_id: str) -> dict[str, Any] | None:
    rows = project.settings.get("manufacturing_contact_relations", []) if isinstance(project.settings, dict) else []
    if not isinstance(rows, list):
        return None
    for raw in rows:
        if not isinstance(raw, Mapping):
            continue
        if str(raw.get("assembly_id") or "") != assembly_id:
            continue
        if str(raw.get("main_part_id") or "") != main_part_id:
            continue
        if str(raw.get("secondary_part_id") or "") != secondary_part_id:
            continue
        return dict(raw)
    return None


@dataclass
class ContactGeometryReport:
    assembly_id: str
    patches: list[ContactPatch]
    proof_status: str
    candidate_count: int = 0
    unresolved_ambiguities: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    source_snapshot_hash: str = ""
    engine_version: str = CONTACT_GEOMETRY_ENGINE_VERSION

    @property
    def contact_set_hash(self) -> str:
        return contact_set_hash(self.assembly_id, self.patches) if self.patches else ""


class ContactGeometryEngine:
    def __init__(self, tolerance: ContactToleranceProfile | None = None) -> None:
        self.tolerance = tolerance or ContactToleranceProfile()

    def resolve_assembly(self, project: ProjectModel, assembly_id: str) -> ContactGeometryReport:
        assembly = project.assemblies.get(assembly_id)
        if assembly is None:
            raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
        if not assembly.main_part_id or assembly.main_part_id not in project.parts:
            return ContactGeometryReport(
                assembly_id, [], ContactProofStatus.BLOCKED.value,
                unresolved_ambiguities=["Assembly heeft geen bewezen main_part_id; contactgeometrie wordt niet gegokt."],
                source_snapshot_hash=contact_source_snapshot_hash(project, assembly_id),
            )
        main = project.parts[assembly.main_part_id]
        validate_persisted_face_state(main, require_current=True)
        secondaries = [pid for pid in assembly.part_ids if pid != main.internal_id and pid in project.parts]
        patches: list[ContactPatch] = []
        warnings: list[str] = []
        unresolved: list[str] = []
        candidates = 0
        for secondary_id in sorted(set(secondaries)):
            secondary = project.parts[secondary_id]
            try:
                validate_persisted_face_state(secondary, require_current=True)
            except ProjectValidationError as exc:
                unresolved.append(f"{secondary_id}: {exc}")
                continue
            pair_patches, pair_candidates, pair_warnings = self._resolve_pair(project, assembly, main, secondary)
            patches.extend(pair_patches)
            candidates += pair_candidates
            warnings.extend(pair_warnings)
            if not pair_patches:
                weld_ids, fastener_ids = _relation_ids(project, assembly, main.internal_id, secondary.internal_id)
                explicit = _explicit_relation(project, assembly_id, main.internal_id, secondary.internal_id)
                if weld_ids or fastener_ids or explicit:
                    unresolved.append(
                        f"{main.internal_id} ↔ {secondary.internal_id}: bronrelatie aanwezig maar geen bewezen projecteerbare contactpatch gevonden."
                    )
        proof = ContactProofStatus.EXACT.value
        if unresolved:
            proof = ContactProofStatus.REVIEW.value if patches else ContactProofStatus.BLOCKED.value
        if any(item.proof_status != ContactProofStatus.EXACT.value for item in patches):
            proof = ContactProofStatus.REVIEW.value
        return ContactGeometryReport(
            assembly_id=assembly_id,
            patches=sorted(patches, key=lambda item: item.contact_id),
            proof_status=proof,
            candidate_count=candidates,
            unresolved_ambiguities=unresolved,
            warnings=warnings,
            source_snapshot_hash=contact_source_snapshot_hash(project, assembly_id),
        )

    def _resolve_pair(self, project: ProjectModel, assembly: Assembly, main: Part, secondary: Part) -> tuple[list[ContactPatch], int, list[str]]:
        main_faces = load_faces(main)
        secondary_faces = load_faces(secondary)
        weld_ids, fastener_ids = _relation_ids(project, assembly, main.internal_id, secondary.internal_id)
        explicit = _explicit_relation(project, assembly.internal_id, main.internal_id, secondary.internal_id)
        warnings: list[str] = []
        exact: list[ContactPatch] = []
        projected_candidates: list[tuple[float, float, ManufacturingFace, ManufacturingFace, list[tuple[float, float]], list[tuple[float, float]], list[tuple[float,float,float]]]] = []
        candidate_count = 0
        cos_tol = math.cos(math.radians(self.tolerance.angular_tolerance_deg))
        for mf in main_faces:
            main_poly = _line_loop_polygon(mf)
            if main_poly is None:
                continue
            mg = _global_frame(main, mf)
            for sf in secondary_faces:
                sec_poly = _line_loop_polygon(sf)
                if sec_poly is None:
                    continue
                sg = _global_frame(secondary, sf)
                normal_dot = _dot(mg.normal, sg.normal)
                if abs(normal_dot) < cos_tol:
                    continue
                plane_gap = abs(_dot(_sub(sg.origin_mm, mg.origin_mm), mg.normal))
                if plane_gap > self.tolerance.projection_max_gap_mm:
                    continue
                sec_on_main = _project_face_polygon_to_frame(secondary, sf, mg)
                if not sec_on_main:
                    continue
                intersection = _convex_intersection(main_poly, sec_on_main)
                area = abs(_polygon_area(intersection))
                if area < self.tolerance.minimum_patch_area_mm2:
                    continue
                candidate_count += 1
                points3d = [mg.part_xyz(u, v, 0.0) for u, v in intersection]
                sec_boundary = []
                max_sec_plane_error = 0.0
                for point in points3d:
                    su, sv, sn = sg.local_uvn(point)
                    sec_boundary.append((su, sv))
                    max_sec_plane_error = max(max_sec_plane_error, abs(sn))
                if normal_dot <= -cos_tol and plane_gap <= self.tolerance.plane_distance_mm and max_sec_plane_error <= self.tolerance.point_tolerance_mm:
                    exact.append(self._make_patch(
                        project, assembly, main, secondary, mf, sf, intersection, sec_boundary, points3d,
                        area=area, gap=plane_gap, weld_ids=weld_ids, fastener_ids=fastener_ids,
                        explicit=explicit, exact=True,
                    ))
                else:
                    projected_candidates.append((plane_gap, -area, mf, sf, intersection, sec_boundary, points3d))
        if exact:
            return self._deduplicate(exact), candidate_count, warnings
        # A source weld/fastener/user relation may justify a projected attachment
        # candidate, but it is review evidence rather than exact physical contact.
        if projected_candidates and (weld_ids or fastener_ids or explicit):
            projected_candidates.sort(key=lambda row: (row[0], row[1], row[2].face_id, row[3].face_id))
            gap, neg_area, mf, sf, main_boundary, sec_boundary, points3d = projected_candidates[0]
            area = -neg_area
            warnings.append(
                f"{main.internal_id} ↔ {secondary.internal_id}: bronrelatie als projected_attachment vastgelegd; fysieke face-touch is niet bewezen."
            )
            return [self._make_patch(
                project, assembly, main, secondary, mf, sf, main_boundary, sec_boundary, points3d,
                area=area, gap=gap, weld_ids=weld_ids, fastener_ids=fastener_ids,
                explicit=explicit, exact=False,
            )], candidate_count, warnings
        return [], candidate_count, warnings

    def _make_patch(
        self, project: ProjectModel, assembly: Assembly, main: Part, secondary: Part,
        main_face: ManufacturingFace, secondary_face: ManufacturingFace,
        main_boundary: list[tuple[float,float]], secondary_boundary: list[tuple[float,float]],
        points3d: list[tuple[float,float,float]], *, area: float, gap: float,
        weld_ids: tuple[str,...], fastener_ids: tuple[str,...], explicit: dict[str,Any] | None,
        exact: bool,
    ) -> ContactPatch:
        if exact:
            relation_type = (
                ContactRelationType.WELDED_CONTACT.value if weld_ids else
                ContactRelationType.BOLTED_CONTACT.value if fastener_ids else
                ContactRelationType.EXPLICIT_USER_RELATION.value if explicit else
                ContactRelationType.GEOMETRIC_TOUCH.value
            )
            proof = ContactProofStatus.EXACT.value
        else:
            relation_type = ContactRelationType.PROJECTED_ATTACHMENT.value
            proof = ContactProofStatus.USER_CONFIRMED.value if explicit and bool(explicit.get("confirmed")) else ContactProofStatus.REVIEW.value
        source_relation = {
            "assembly_membership": True,
            "assembly_mark": assembly.assembly_mark,
            "weld_ids": list(weld_ids),
            "fastener_ids": list(fastener_ids),
            "explicit_relation": dict(explicit or {}),
        }
        identity = {
            "assembly_id": assembly.internal_id,
            "main_part_id": main.internal_id,
            "secondary_part_id": secondary.internal_id,
            "main_face_id": main_face.face_id,
            "secondary_face_id": secondary_face.face_id,
            "main_boundary": [[round(x,9),round(y,9)] for x,y in main_boundary],
        }
        contact_id = "cp-" + stable_sha256(identity)[:24]
        return ContactPatch(
            contact_id=contact_id,
            assembly_id=assembly.internal_id,
            main_part_id=main.internal_id,
            secondary_part_id=secondary.internal_id,
            main_face_id=main_face.face_id,
            secondary_face_id=secondary_face.face_id,
            source_relation=source_relation,
            relation_type=relation_type,
            # Canonical contact intersection is persisted in main-part-local
            # coordinates so a rigid project/assembly move does not change
            # manufacturing contact identity.
            exact_intersection_geometry=tuple(main_face.local_frame.part_xyz(float(u), float(v), 0.0) for u, v in main_boundary),
            projected_boundary_on_main_face=tuple(tuple(float(v) for v in p) for p in main_boundary),
            projected_boundary_on_secondary_face=tuple(tuple(float(v) for v in p) for p in secondary_boundary),
            area_mm2=float(area),
            gap_mm=float(gap),
            penetration_mm=0.0,
            weld_ids=weld_ids,
            fastener_ids=fastener_ids,
            proof_status=proof,
            tolerance_profile=self.tolerance,
            provenance={
                "engine": CONTACT_GEOMETRY_ENGINE_VERSION,
                "method": "analytic_planar_face_intersection" if exact else "relation_backed_face_projection",
                "scope": "convex_planar_manufacturing_faces",
                "intersection_frame": "main_part_local",
            },
            main_face_geometry_hash=main_face.geometry_hash,
            secondary_face_geometry_hash=secondary_face.geometry_hash,
        )

    def _deduplicate(self, patches: list[ContactPatch]) -> list[ContactPatch]:
        result: dict[tuple[str,str],ContactPatch] = {}
        for patch in patches:
            key=(patch.main_face_id,patch.secondary_face_id)
            existing=result.get(key)
            if existing is None or patch.area_mm2 > existing.area_mm2:
                result[key]=patch
        return sorted(result.values(),key=lambda item:item.contact_id)


def contact_source_snapshot(project: ProjectModel, assembly_id: str) -> dict[str, Any]:
    assembly = project.assemblies.get(assembly_id)
    if assembly is None:
        raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
    part_ids = sorted(pid for pid in assembly.part_ids if pid in project.parts)
    main_part = project.parts.get(assembly.main_part_id)
    part_rows: list[dict[str,Any]] = []
    for part_id in part_ids:
        part = project.parts[part_id]
        face_state = validate_persisted_face_state(part, require_current=False)
        part_rows.append({
            "part_id": part_id,
            "manufacturing_hash": part.manufacturing_hash,
            "geometry_hash": part.geometry_hash,
            "face_set_hash": str(face_state.get("face_set_hash") or ""),
            "face_status": str(face_state.get("status") or ""),
            "relative_placement_to_main": _relative_transform(main_part, part) if main_part is not None else [],
        })
    weld_rows=[]
    for weld_id in sorted(assembly.weld_ids):
        weld=project.welds.get(weld_id)
        if weld:
            weld_rows.append({"weld_id":weld_id,"connected_part_ids":sorted(weld.connected_part_ids),"weld_type":weld.weld_type,"size_mm":weld.size_mm,"length_mm":weld.length_mm,"side":weld.side})
    fastener_rows=[]
    for fastener_id in sorted(assembly.fastener_ids):
        fastener=project.fasteners.get(fastener_id)
        if fastener:
            fastener_rows.append({"fastener_id":fastener_id,"connected_part_ids":sorted(fastener.connected_part_ids),"diameter_mm":fastener.diameter_mm,"hole_diameter_mm":fastener.hole_diameter_mm,"quantity":fastener.quantity})
    explicit=[]
    rows=project.settings.get("manufacturing_contact_relations",[]) if isinstance(project.settings,dict) else []
    if isinstance(rows,list):
        explicit=[dict(row) for row in rows if isinstance(row,Mapping) and str(row.get("assembly_id") or "")==assembly_id]
    return {
        "schema_version": CONTACT_GEOMETRY_ENGINE_SCHEMA_VERSION,
        "assembly_id": assembly_id,
        "main_part_id": assembly.main_part_id,
        "part_ids": part_ids,
        "weld_ids": sorted(assembly.weld_ids),
        "fastener_ids": sorted(assembly.fastener_ids),
        "parts": part_rows,
        "welds": weld_rows,
        "fasteners": fastener_rows,
        "explicit_relations": explicit,
    }


def contact_source_snapshot_hash(project: ProjectModel, assembly_id: str) -> str:
    return stable_sha256(contact_source_snapshot(project, assembly_id))


__all__ = [
    "CONTACT_GEOMETRY_ENGINE_VERSION",
    "CONTACT_GEOMETRY_ENGINE_SCHEMA_VERSION",
    "ContactGeometryReport",
    "ContactGeometryEngine",
    "contact_source_snapshot",
    "contact_source_snapshot_hash",
]
