"""Controller-neutral nesting-aware mark binding contracts for Scribing M6.

M6 binds already validated canonical marks to one immutable profile-nesting plan.
It does not generate marks and it does not serialize DSTV/controller syntax.
Every binding captures the exact transform chain

    face-local UV -> part local XYZ -> nesting orientation -> bar frame -> machine frame

plus the selected M5 capability proof and the active nesting plan evidence.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from cws_convertor.project.model import ProjectValidationError, stable_sha256

NESTING_MARK_BINDING_SCHEMA_VERSION = "1.0"
NESTING_MARK_BINDING_REPORT_SCHEMA_VERSION = "1.0"
NESTING_MARK_BINDING_STATE_SCHEMA_VERSION = "1.0"
NESTING_MARK_BINDING_HASH_VERSION = "cws-nesting-mark-binding-v1"
NESTING_MARK_BINDING_REPORT_HASH_VERSION = "cws-nesting-mark-binding-report-v1"
NESTING_MARK_TRANSFORM_CONVENTION = "cws-part-face-to-bar-to-machine-v1"


@dataclass(frozen=True)
class NestingMarkBindingIssue:
    code: str
    message: str
    blocking: bool = True
    severity: str = "error"
    mark_id: str = ""
    piece_instance_id: str = ""
    bar_id: str = ""
    transition_id: str = ""
    suggested_remediation: str = ""
    provenance: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "blocking": bool(self.blocking),
            "severity": self.severity,
            "mark_id": self.mark_id,
            "piece_instance_id": self.piece_instance_id,
            "bar_id": self.bar_id,
            "transition_id": self.transition_id,
            "suggested_remediation": self.suggested_remediation,
            "provenance": dict(self.provenance),
        }


@dataclass(frozen=True)
class BoundMarkGeometry3D:
    """Exact transformed representation of canonical mark intent.

    Curves remain analytic: circle/arc records keep center + two transformed
    in-plane basis vectors and radius.  Text remains a semantic anchor; glyph
    geometry is still a later adapter concern.
    """

    kind: str
    points_xyz: tuple[tuple[float, float, float], ...] = ()
    center_xyz: tuple[float, float, float] | None = None
    radius_mm: float = 0.0
    u_axis_xyz: tuple[float, float, float] | None = None
    v_axis_xyz: tuple[float, float, float] | None = None
    start_angle_deg: float = 0.0
    end_angle_deg: float = 0.0
    closed: bool = False
    components: tuple["BoundMarkGeometry3D", ...] = ()
    semantic_text: str = ""
    geometry_hash: str = ""

    def __post_init__(self) -> None:
        def vec3(value, label):
            raw = tuple(float(x) for x in value)
            if len(raw) != 3:
                raise ProjectValidationError(f"{label} moet drie componenten bevatten")
            return raw
        object.__setattr__(self, "points_xyz", tuple(vec3(p, "Bound mark point") for p in self.points_xyz))
        if self.center_xyz is not None:
            object.__setattr__(self, "center_xyz", vec3(self.center_xyz, "Bound mark center"))
        if self.u_axis_xyz is not None:
            object.__setattr__(self, "u_axis_xyz", vec3(self.u_axis_xyz, "Bound mark U-axis"))
        if self.v_axis_xyz is not None:
            object.__setattr__(self, "v_axis_xyz", vec3(self.v_axis_xyz, "Bound mark V-axis"))
        if float(self.radius_mm) < 0:
            raise ProjectValidationError("Bound mark radius kan niet negatief zijn")
        expected = stable_sha256(self.hash_payload())
        if self.geometry_hash and self.geometry_hash != expected:
            raise ProjectValidationError("BoundMarkGeometry3D geometry_hash ongeldig")
        object.__setattr__(self, "geometry_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "points_xyz": [list(p) for p in self.points_xyz],
            "center_xyz": list(self.center_xyz) if self.center_xyz is not None else None,
            "radius_mm": float(self.radius_mm),
            "u_axis_xyz": list(self.u_axis_xyz) if self.u_axis_xyz is not None else None,
            "v_axis_xyz": list(self.v_axis_xyz) if self.v_axis_xyz is not None else None,
            "start_angle_deg": float(self.start_angle_deg),
            "end_angle_deg": float(self.end_angle_deg),
            "closed": bool(self.closed),
            "components": [item.to_dict() for item in self.components],
            "semantic_text": self.semantic_text,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "geometry_hash": self.geometry_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "BoundMarkGeometry3D":
        return cls(
            kind=str(value.get("kind") or ""),
            points_xyz=tuple(tuple(float(v) for v in p) for p in value.get("points_xyz") or []),
            center_xyz=tuple(float(v) for v in value["center_xyz"]) if value.get("center_xyz") is not None else None,
            radius_mm=float(value.get("radius_mm") or 0.0),
            u_axis_xyz=tuple(float(v) for v in value["u_axis_xyz"]) if value.get("u_axis_xyz") is not None else None,
            v_axis_xyz=tuple(float(v) for v in value["v_axis_xyz"]) if value.get("v_axis_xyz") is not None else None,
            start_angle_deg=float(value.get("start_angle_deg") or 0.0),
            end_angle_deg=float(value.get("end_angle_deg") or 0.0),
            closed=bool(value.get("closed", False)),
            components=tuple(cls.from_dict(row) for row in value.get("components") or []),
            semantic_text=str(value.get("semantic_text") or ""),
            geometry_hash=str(value.get("geometry_hash") or ""),
        )


@dataclass(frozen=True)
class NestingMarkBindingProof:
    binding_id: str
    run_id: str
    assembly_id: str
    capability_id: str
    machine_id: str
    mark_id: str
    mark_hash: str
    m5_evaluation_id: str
    m5_proof_hash: str
    part_id: str
    part_position: str
    base_manufacturing_hash: str
    piece_instance_id: str
    production_artifact_identity: str
    production_instance_identity: str
    assembly_marking_variant_hash: str
    bar_id: str
    sequence_index: int
    orientation_id: str
    orientation_hash: str
    orientation_transform: tuple[tuple[float, float, float], ...]
    bar_translation_mm: tuple[float, float, float]
    bar_to_machine_transform: tuple[tuple[float, float, float, float], ...]
    transform_chain_hash: str
    target_face_id: str
    target_face_role: str
    selected_tool_id: str
    selected_tool_hash: str
    bar_geometry: BoundMarkGeometry3D
    machine_geometry: BoundMarkGeometry3D
    feasible: bool
    review_required: bool
    transformed_face_reachable: bool
    clamp_clearance_ok: bool
    gripper_clearance_ok: bool
    common_cut_ok: bool
    must_execute_before_severing: bool = True
    reorientation_required: bool = False
    reclamp_required: bool = False
    common_cut_transition_ids: tuple[str, ...] = ()
    precedence_requirements: tuple[str, ...] = ()
    issues: tuple[NestingMarkBindingIssue, ...] = ()
    evidence: Mapping[str, Any] = field(default_factory=dict)
    requires_m7_sequence: bool = True
    dstv_si_released: bool = False
    machine_output_released: bool = False
    binding_hash: str = ""
    schema_version: str = NESTING_MARK_BINDING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != NESTING_MARK_BINDING_SCHEMA_VERSION:
            raise ProjectValidationError(f"Onbekende toekomstige M6 binding schema-versie {self.schema_version!r}")
        if not self.binding_id or not self.run_id or not self.mark_id or not self.piece_instance_id:
            raise ProjectValidationError("M6 binding mist identiteit")
        if self.machine_output_released or self.dstv_si_released:
            raise ProjectValidationError("M6 mag geen DSTV SI of machine-output vrijgeven")
        expected = stable_sha256(self.hash_payload())
        if self.binding_hash and self.binding_hash != expected:
            raise ProjectValidationError(f"M6 binding {self.binding_id} heeft ongeldige binding_hash")
        object.__setattr__(self, "binding_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": NESTING_MARK_BINDING_HASH_VERSION,
            "schema_version": self.schema_version,
            "binding_id": self.binding_id,
            "run_id": self.run_id,
            "assembly_id": self.assembly_id,
            "capability_id": self.capability_id,
            "machine_id": self.machine_id,
            "mark_id": self.mark_id,
            "mark_hash": self.mark_hash,
            "m5_evaluation_id": self.m5_evaluation_id,
            "m5_proof_hash": self.m5_proof_hash,
            "part_id": self.part_id,
            "part_position": self.part_position,
            "base_manufacturing_hash": self.base_manufacturing_hash,
            "piece_instance_id": self.piece_instance_id,
            "production_artifact_identity": self.production_artifact_identity,
            "production_instance_identity": self.production_instance_identity,
            "assembly_marking_variant_hash": self.assembly_marking_variant_hash,
            "bar_id": self.bar_id,
            "sequence_index": int(self.sequence_index),
            "orientation_id": self.orientation_id,
            "orientation_hash": self.orientation_hash,
            "orientation_transform": [list(row) for row in self.orientation_transform],
            "bar_translation_mm": list(self.bar_translation_mm),
            "bar_to_machine_transform": [list(row) for row in self.bar_to_machine_transform],
            "transform_chain_hash": self.transform_chain_hash,
            "target_face_id": self.target_face_id,
            "target_face_role": self.target_face_role,
            "selected_tool_id": self.selected_tool_id,
            "selected_tool_hash": self.selected_tool_hash,
            "bar_geometry": self.bar_geometry.to_dict(),
            "machine_geometry": self.machine_geometry.to_dict(),
            "feasible": bool(self.feasible),
            "review_required": bool(self.review_required),
            "transformed_face_reachable": bool(self.transformed_face_reachable),
            "clamp_clearance_ok": bool(self.clamp_clearance_ok),
            "gripper_clearance_ok": bool(self.gripper_clearance_ok),
            "common_cut_ok": bool(self.common_cut_ok),
            "must_execute_before_severing": bool(self.must_execute_before_severing),
            "reorientation_required": bool(self.reorientation_required),
            "reclamp_required": bool(self.reclamp_required),
            "common_cut_transition_ids": list(self.common_cut_transition_ids),
            "precedence_requirements": list(self.precedence_requirements),
            "issues": [item.to_dict() for item in self.issues],
            "evidence": dict(self.evidence),
            "requires_m7_sequence": bool(self.requires_m7_sequence),
            "dstv_si_released": False,
            "machine_output_released": False,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "binding_hash": self.binding_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "NestingMarkBindingProof":
        return cls(
            binding_id=str(value.get("binding_id") or ""), run_id=str(value.get("run_id") or ""),
            assembly_id=str(value.get("assembly_id") or ""), capability_id=str(value.get("capability_id") or ""),
            machine_id=str(value.get("machine_id") or ""), mark_id=str(value.get("mark_id") or ""), mark_hash=str(value.get("mark_hash") or ""),
            m5_evaluation_id=str(value.get("m5_evaluation_id") or ""), m5_proof_hash=str(value.get("m5_proof_hash") or ""),
            part_id=str(value.get("part_id") or ""), part_position=str(value.get("part_position") or ""),
            base_manufacturing_hash=str(value.get("base_manufacturing_hash") or ""), piece_instance_id=str(value.get("piece_instance_id") or ""),
            production_artifact_identity=str(value.get("production_artifact_identity") or ""), production_instance_identity=str(value.get("production_instance_identity") or ""),
            assembly_marking_variant_hash=str(value.get("assembly_marking_variant_hash") or ""), bar_id=str(value.get("bar_id") or ""), sequence_index=int(value.get("sequence_index") or 0),
            orientation_id=str(value.get("orientation_id") or ""), orientation_hash=str(value.get("orientation_hash") or ""),
            orientation_transform=tuple(tuple(float(v) for v in row) for row in value.get("orientation_transform") or []),
            bar_translation_mm=tuple(float(v) for v in value.get("bar_translation_mm") or (0,0,0)),
            bar_to_machine_transform=tuple(tuple(float(v) for v in row) for row in value.get("bar_to_machine_transform") or []),
            transform_chain_hash=str(value.get("transform_chain_hash") or ""), target_face_id=str(value.get("target_face_id") or ""), target_face_role=str(value.get("target_face_role") or ""),
            selected_tool_id=str(value.get("selected_tool_id") or ""), selected_tool_hash=str(value.get("selected_tool_hash") or ""),
            bar_geometry=BoundMarkGeometry3D.from_dict(dict(value.get("bar_geometry") or {})), machine_geometry=BoundMarkGeometry3D.from_dict(dict(value.get("machine_geometry") or {})),
            feasible=bool(value.get("feasible", False)), review_required=bool(value.get("review_required", False)),
            transformed_face_reachable=bool(value.get("transformed_face_reachable", False)), clamp_clearance_ok=bool(value.get("clamp_clearance_ok", False)),
            gripper_clearance_ok=bool(value.get("gripper_clearance_ok", False)), common_cut_ok=bool(value.get("common_cut_ok", False)),
            must_execute_before_severing=bool(value.get("must_execute_before_severing", True)), reorientation_required=bool(value.get("reorientation_required", False)),
            reclamp_required=bool(value.get("reclamp_required", False)), common_cut_transition_ids=tuple(str(x) for x in value.get("common_cut_transition_ids") or []),
            precedence_requirements=tuple(str(x) for x in value.get("precedence_requirements") or []),
            issues=tuple(NestingMarkBindingIssue(**dict(row)) for row in value.get("issues") or []), evidence=dict(value.get("evidence") or {}),
            requires_m7_sequence=bool(value.get("requires_m7_sequence", True)), dstv_si_released=bool(value.get("dstv_si_released", False)), machine_output_released=bool(value.get("machine_output_released", False)),
            binding_hash=str(value.get("binding_hash") or ""), schema_version=str(value.get("schema_version") or NESTING_MARK_BINDING_SCHEMA_VERSION),
        )


def nesting_mark_binding_report_hash(payload: Mapping[str, Any]) -> str:
    return stable_sha256({"hash_version": NESTING_MARK_BINDING_REPORT_HASH_VERSION, **dict(payload)})


__all__ = [name for name in globals() if not name.startswith("_")]
