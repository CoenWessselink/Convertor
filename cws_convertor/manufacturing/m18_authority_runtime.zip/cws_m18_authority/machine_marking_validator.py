"""Independent M5 validator for machine-marking capability proofs.

The validator does not invoke :class:`MachineMarkingCapabilityEngine` and does
not trust persisted ``feasible`` flags.  It reconstructs the required operation,
face support, tool binding, reach envelope and physical head clearances directly
from the current project graph.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .machine_marking_contracts import (
    InternalFacePolicy, MarkCapabilityIssue, MarkCapabilityProof, MarkingCapabilityValidationStatus,
    MarkingOperation, MarkingToolDefinition, ManufacturingMachineCapability, machine_marking_report_hash,
)
from .marking_contracts import ManufacturingMark, MarkGeometryKind, MarkType
from .marking_service import load_assembly_marks, load_ruleset, validate_persisted_mark_state
from .marking_geometry import line_face_outer_polygon, target_hole_zones, target_weld_zones
from .service import load_faces, validate_persisted_face_state

M5_VALIDATOR_VERSION="cws-independent-machine-marking-validator-v1"
_INTERNAL={"top_inner","bottom_inner","flange_a_inner","flange_b_inner","leg_a_inner","leg_b_inner","web_inner"}


def _operation(mark:ManufacturingMark)->str:
    raw=str(mark.requested_operation or "").lower().strip()
    if raw=="scribe":return MarkingOperation.CONTOUR_SCRIBE.value if mark.mark_type==MarkType.CONTOUR_SCRIBE.value else MarkingOperation.SCRIBE_LINE.value
    if raw=="text_mark":return MarkingOperation.TEXT_MARK.value
    if raw in {x.value for x in MarkingOperation}:return raw
    if mark.mark_type==MarkType.POP_MARK.value:return MarkingOperation.POP_MARK.value
    if mark.mark_type==MarkType.CENTER_PUNCH.value:return MarkingOperation.CENTER_PUNCH.value
    if mark.mark_type in {MarkType.POSITION_TEXT.value,MarkType.ASSEMBLY_TEXT.value,MarkType.PART_TEXT.value}:return MarkingOperation.TEXT_MARK.value
    if mark.mark_type==MarkType.HARD_STAMP_REQUEST.value:return MarkingOperation.HARD_STAMP.value
    return MarkingOperation.NONE.value


def _face(project:ProjectModel,mark:ManufacturingMark)->ManufacturingFace:
    part=project.parts.get(mark.target_part_id)
    if part is None:raise ProjectValidationError("missing target part")
    validate_persisted_face_state(part,require_current=True)
    rows=[f for f in load_faces(part) if f.face_id==mark.target_face_id]
    if len(rows)!=1:raise ProjectValidationError("missing/ambiguous face")
    if rows[0].geometry_hash!=mark.target_face_geometry_hash:raise ProjectValidationError("stale face")
    return rows[0]


def _tool(project:ProjectModel,cap:ManufacturingMachineCapability,op:str)->MarkingToolDefinition|None:
    ids=tuple(cap.operation_tool_ids.get(op,())) or cap.marking_tool_ids
    for tid in ids:
        raw=project.manufacturing_marking_tools.get(tid)
        if not isinstance(raw,dict):continue
        t=MarkingToolDefinition.from_dict(raw)
        if t.validation_status!="validated" or t.status!="active" or t.maintenance_status!="ok":continue
        if t.allowed_machine_ids and cap.machine_id not in t.allowed_machine_ids:continue
        if t.allowed_station_ids and cap.station_id not in t.allowed_station_ids:continue
        if op not in t.supported_operations:continue
        return t
    return None


def _geom_segments_points(mark:ManufacturingMark):
    segments=[];points=[]
    def visit(g):
        if g.kind==MarkGeometryKind.LINE.value and len(g.points)==2:segments.append((g.points[0],g.points[1]))
        elif g.kind==MarkGeometryKind.POLYLINE.value:
            segments.extend((g.points[i],g.points[i+1]) for i in range(len(g.points)-1))
            if g.closed and len(g.points)>2:segments.append((g.points[-1],g.points[0]))
        elif g.kind in {MarkGeometryKind.POINT.value,MarkGeometryKind.TEXT_ANCHOR.value,MarkGeometryKind.SYMBOL_ANCHOR.value} and g.points:points.append(g.points[0])
        elif g.kind==MarkGeometryKind.COMPOUND.value:
            for child in g.components:visit(child)
        elif g.kind in {MarkGeometryKind.CIRCLE.value,MarkGeometryKind.ARC.value} and g.center is not None:
            count=24;start=0.0 if g.kind==MarkGeometryKind.CIRCLE.value else g.start_angle_deg;sweep=360.0 if g.kind==MarkGeometryKind.CIRCLE.value else (g.end_angle_deg-g.start_angle_deg)%360.0
            pts=[(g.center[0]+g.radius_mm*math.cos(math.radians(start+sweep*i/count)),g.center[1]+g.radius_mm*math.sin(math.radians(start+sweep*i/count))) for i in range(count+1)]
            segments.extend((pts[i],pts[i+1]) for i in range(count))
    visit(mark.geometry_2d)
    rect=mark.provenance.get("placement_envelope_mm") if isinstance(mark.provenance,Mapping) else None
    if mark.geometry_2d.kind==MarkGeometryKind.TEXT_ANCHOR.value and isinstance(rect,(list,tuple)) and len(rect)==4:
        u0,v0,u1,v1=(float(v) for v in rect);c=[(u0,v0),(u1,v0),(u1,v1),(u0,v1)];points.extend(c);segments.extend((c[i],c[(i+1)%4]) for i in range(4))
    return segments,points


def _point_seg(p,a,b):
    dx=b[0]-a[0];dy=b[1]-a[1];den=dx*dx+dy*dy
    if den<=1e-18:return math.hypot(p[0]-a[0],p[1]-a[1])
    t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den));q=(a[0]+t*dx,a[1]+t*dy);return math.hypot(p[0]-q[0],p[1]-q[1])


def _orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def _on(a,p,b):return min(a[0],b[0])-1e-9<=p[0]<=max(a[0],b[0])+1e-9 and min(a[1],b[1])-1e-9<=p[1]<=max(a[1],b[1])+1e-9

def _seg_seg(a,b,c,d):
    o1,o2,o3,o4=_orient(a,b,c),_orient(a,b,d),_orient(c,d,a),_orient(c,d,b)
    if ((o1>1e-9 and o2<-1e-9) or (o1<-1e-9 and o2>1e-9)) and ((o3>1e-9 and o4<-1e-9) or (o3<-1e-9 and o4>1e-9)):return 0.0
    if abs(o1)<=1e-9 and _on(a,c,b):return 0.0
    if abs(o2)<=1e-9 and _on(a,d,b):return 0.0
    if abs(o3)<=1e-9 and _on(c,a,d):return 0.0
    if abs(o4)<=1e-9 and _on(c,b,d):return 0.0
    return min(_point_seg(a,c,d),_point_seg(b,c,d),_point_seg(c,a,b),_point_seg(d,a,b))


def _bounds(mark):
    segs,pts=_geom_segments_points(mark);allp=pts+[p for s in segs for p in s]
    if not allp:return None
    return (min(p[0] for p in allp),min(p[1] for p in allp),max(p[0] for p in allp),max(p[1] for p in allp))


def _boundary_distance(mark,face):
    poly=line_face_outer_polygon(face);edges=[(poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly))];segs,pts=_geom_segments_points(mark);d=[]
    for p in pts:d.extend(_point_seg(p,*e) for e in edges)
    for s in segs:d.extend(_seg_seg(*s,*e) for e in edges)
    return min(d) if d else 0.0


def _circle_hit(mark,center,radius):
    segs,pts=_geom_segments_points(mark)
    return any(_point_seg(center,*s)<radius-1e-8 for s in segs) or any(math.hypot(p[0]-center[0],p[1]-center[1])<radius-1e-8 for p in pts)


def _rect_hit(mark,rect):
    segs,pts=_geom_segments_points(mark)
    def inside(p):return rect[0]-1e-9<=p[0]<=rect[2]+1e-9 and rect[1]-1e-9<=p[1]<=rect[3]+1e-9
    if any(inside(p) for p in pts):return True
    c=[(rect[0],rect[1]),(rect[2],rect[1]),(rect[2],rect[3]),(rect[0],rect[3])]
    return any(inside(a) or inside(b) or any(_seg_seg(a,b,c[i],c[(i+1)%4])<=1e-9 for i in range(4)) for a,b in segs)


def _issue(code,msg,mark,tool_id=""):
    return MarkCapabilityIssue(code,msg,True,"error",mark.mark_id,mark.target_part_id,mark.target_face_id,tool_id,"",{"validator":M5_VALIDATOR_VERSION})


def _effective_capability_hash(project,cap):
    hashes={}
    for tid in cap.marking_tool_ids:
        raw=project.manufacturing_marking_tools.get(tid)
        if isinstance(raw,dict):hashes[tid]=MarkingToolDefinition.from_dict(raw).tool_hash
    profile_hash=""
    if cap.machine_profile_id:
        raw=project.profile_nesting_machine_profiles.get(cap.machine_profile_id)
        if not isinstance(raw,dict):raise ProjectValidationError("linked machine profile missing")
        profile_hash=str(raw.get("configuration_hash") or "")
    return cap.effective_hash(tool_hashes=hashes,machine_profile_hash=profile_hash)


def _snapshot(project,assembly_id,cap):
    state=validate_persisted_mark_state(project,assembly_id,require_current=True);rule=load_ruleset(project,str(state.get("ruleset_id") or ""))
    hashes={}
    for tid in cap.marking_tool_ids:
        raw=project.manufacturing_marking_tools.get(tid)
        if isinstance(raw,dict):hashes[tid]=MarkingToolDefinition.from_dict(raw).tool_hash
    profile_hash=""
    if cap.machine_profile_id:
        raw=project.profile_nesting_machine_profiles.get(cap.machine_profile_id)
        if isinstance(raw,dict):profile_hash=str(raw.get("configuration_hash") or "")
    return {"schema_version":"cws-machine-marking-source-v1","project_id":project.project_id,"assembly_id":assembly_id,"mark_set_hash":str(state.get("mark_set_hash") or ""),"mark_source_snapshot_hash":str(state.get("source_snapshot_hash") or ""),"ruleset_id":rule.ruleset_id,"ruleset_hash":rule.ruleset_hash,"capability_id":cap.capability_id,"machine_id":cap.machine_id,"machine_marking_capability_hash":cap.effective_hash(tool_hashes=hashes,machine_profile_hash=profile_hash),"marking_tool_hashes":dict(sorted(hashes.items())),"linked_machine_profile_hash":profile_hash}


@dataclass
class IndependentMachineMarkingValidationReport:
    status:str
    assembly_id:str
    capability_id:str
    machine_id:str
    issues:list[MarkCapabilityIssue]
    expected_proofs:list[dict[str,Any]]
    source_snapshot_hash:str
    report_hash:str=""
    def to_dict(self):
        raw={"schema_version":"1.0","validator":M5_VALIDATOR_VERSION,"status":self.status,"assembly_id":self.assembly_id,"capability_id":self.capability_id,"machine_id":self.machine_id,"issues":[i.to_dict() for i in self.issues],"expected_proofs":self.expected_proofs,"source_snapshot_hash":self.source_snapshot_hash}
        raw["report_hash"]=self.report_hash or stable_sha256(raw);return raw


class IndependentMachineMarkingValidator:
    def validate(self,project:ProjectModel,assembly_id:str,capability:ManufacturingMachineCapability,proofs:list[MarkCapabilityProof]|tuple[MarkCapabilityProof,...])->IndependentMachineMarkingValidationReport:
        state=validate_persisted_mark_state(project,assembly_id,require_current=True);rule=load_ruleset(project,str(state.get("ruleset_id") or ""));marks=load_assembly_marks(project,assembly_id)
        proof_map={p.mark_id:p for p in proofs};issues=[];expected=[]
        if set(proof_map)!= {m.mark_id for m in marks}:
            missing=sorted({m.mark_id for m in marks}-set(proof_map));extra=sorted(set(proof_map)-{m.mark_id for m in marks})
            if marks:issues.append(_issue("CWS-MARK-020",f"Capability proof set mismatch; missing={missing}, extra={extra}",marks[0]))
        cap_hash=_effective_capability_hash(project,capability)
        if capability.capability_hash and capability.capability_hash!=cap_hash:
            if marks:issues.append(_issue("CWS-MARK-027","Persisted machine marking capability is stale",marks[0]))
        for mark in marks:
            op=_operation(mark);local=[]
            try:face=_face(project,mark)
            except Exception as exc:
                local.append(_issue("CWS-MARK-001",str(exc),mark));face=None
            tool=_tool(project,capability,op)
            op_ok=op in capability.supported_mark_operations and (not capability.supported_mark_types or mark.mark_type in capability.supported_mark_types)
            if not op_ok:local.append(_issue("CWS-MARK-009","Operation/mark type unsupported",mark))
            face_ok=False;surface_ok=False;rot_ok=True;approach_ok=True;reach_ok=True;clear_ok=True;min_dist=0.0;required=0.0
            if face is not None:
                face_ok=face.semantic_role in capability.supported_face_roles and face.semantic_role not in capability.forbidden_face_roles
                if face.semantic_role in _INTERNAL and capability.internal_face_policy==InternalFacePolicy.BLOCKED.value:face_ok=False
                if not face_ok:local.append(_issue("CWS-MARK-008","Face unreachable",mark))
                surface_ok=face.surface_type in capability.supported_surface_types
                if face.surface_type==ManufacturingSurfaceType.CYLINDER.value:
                    rot_ok=capability.rotational_marking_supported
                    if not rot_ok:local.append(_issue("CWS-MARK-025","Rotational marking missing",mark))
                elif not surface_ok:local.append(_issue("CWS-MARK-008","Surface unsupported",mark))
                vectors=tuple(capability.canonical_approach_vectors_by_face_role.get(face.semantic_role,())) or (tool.approach_vectors if tool else ())
                if vectors:approach_ok=any(sum(a*b for a,b in zip(face.local_frame.normal,v))>=1-1e-6 for v in vectors)
                if not approach_ok:local.append(_issue("CWS-MARK-008","Approach vector mismatch",mark,tool.tool_id if tool else ""))
                b=_bounds(mark)
                if b is None:reach_ok=False
                else:
                    u0,v0,u1,v1=b
                    if capability.min_reachable_u_mm is not None and u0<capability.min_reachable_u_mm-1e-8:reach_ok=False
                    if capability.max_reachable_u_mm is not None and u1>capability.max_reachable_u_mm+1e-8:reach_ok=False
                    if capability.min_reachable_v_mm is not None and v0<capability.min_reachable_v_mm-1e-8:reach_ok=False
                    if capability.max_reachable_v_mm is not None and v1>capability.max_reachable_v_mm+1e-8:reach_ok=False
                if not reach_ok:local.append(_issue("CWS-MARK-008","Reach envelope mismatch",mark,tool.tool_id if tool else ""))
                if face.surface_type==ManufacturingSurfaceType.PLANE.value:
                    try:
                        min_dist=_boundary_distance(mark,face);required=max(float(capability.face_role_clearance_mm.get(face.semantic_role,0.0)),float(tool.minimum_edge_distance_mm if tool else 0.0),float(tool.physical_clearance_radius_mm if tool else 0.0))
                        if min_dist+1e-8<required:clear_ok=False
                        clearance=float(tool.physical_clearance_radius_mm if tool else 0.0);part=project.parts[mark.target_part_id]
                        for z in target_hole_zones(part,face,clearance):
                            if _circle_hit(mark,z["center"],float(z["radius_mm"])):clear_ok=False
                        for z in target_weld_zones(part,face,clearance):
                            if z.get("kind")=="circle" and _circle_hit(mark,z["center"],float(z["radius_mm"])):clear_ok=False
                            if z.get("kind")=="rect" and _rect_hit(mark,tuple(z["rect"])):clear_ok=False
                        for z in capability.forbidden_face_zones.get(face.semantic_role,()):
                            if z.get("kind")=="circle":
                                c=(float(z.get("u_mm") or 0),float(z.get("v_mm") or 0));r=float(z.get("radius_mm") or 0)+clearance
                                if _circle_hit(mark,c,r):clear_ok=False
                            elif z.get("kind")=="rect":
                                r=(float(z.get("u0_mm") or 0)-clearance,float(z.get("v0_mm") or 0)-clearance,float(z.get("u1_mm") or 0)+clearance,float(z.get("v1_mm") or 0)+clearance);r=(min(r[0],r[2]),min(r[1],r[3]),max(r[0],r[2]),max(r[1],r[3]))
                                if _rect_hit(mark,r):clear_ok=False
                        if not clear_ok:local.append(_issue("CWS-MARK-023","Head clearance/collision mismatch",mark,tool.tool_id if tool else ""))
                    except Exception as exc:clear_ok=False;local.append(_issue("CWS-MARK-023",str(exc),mark,tool.tool_id if tool else ""))
            if tool is None:local.append(_issue("CWS-MARK-022","No validated tool",mark))
            if capability.validation_status!="validated" or not capability.enabled:local.append(_issue("CWS-MARK-021","Capability not validated/enabled",mark))
            if rule.applicable_machine_ids and capability.machine_id not in rule.applicable_machine_ids:local.append(_issue("CWS-MARK-024","Ruleset-machine mismatch",mark))
            expected_feasible=not any(i.blocking for i in local)
            expected_row={"mark_id":mark.mark_id,"operation":op,"feasible":expected_feasible,"tool_id":tool.tool_id if tool else "","face_reachable":face_ok and surface_ok,"operation_supported":op_ok,"head_clearance_ok":clear_ok,"transverse_reach_ok":reach_ok,"approach_ok":approach_ok,"rotational_requirement_satisfied":rot_ok,"minimum_boundary_distance_mm":min_dist,"required_head_clearance_mm":required}
            expected.append(expected_row)
            proof=proof_map.get(mark.mark_id)
            if proof is None:continue
            actual={"mark_id":proof.mark_id,"operation":proof.operation,"feasible":proof.feasible,"tool_id":proof.selected_tool_id,"face_reachable":proof.face_reachable,"operation_supported":proof.operation_supported,"head_clearance_ok":proof.head_clearance_ok,"transverse_reach_ok":proof.transverse_reach_ok,"approach_ok":proof.approach_ok,"rotational_requirement_satisfied":proof.rotational_requirement_satisfied}
            for key in ("operation","feasible","tool_id","face_reachable","operation_supported","head_clearance_ok","transverse_reach_ok","approach_ok","rotational_requirement_satisfied"):
                if actual[key]!=expected_row[key]:issues.append(_issue("CWS-MARK-020",f"Persisted capability proof mismatch voor {mark.mark_id}: {key}",mark,proof.selected_tool_id))
            if proof.capability_id!=capability.capability_id or proof.machine_id!=capability.machine_id:issues.append(_issue("CWS-MARK-020","Proof machine/capability identity mismatch",mark))
            issues.extend(local)
        snap=stable_sha256(_snapshot(project,assembly_id,capability));status="passed" if not any(i.blocking for i in issues) else "failed"
        report=IndependentMachineMarkingValidationReport(status,assembly_id,capability.capability_id,capability.machine_id,issues,expected,snap);report.report_hash=report.to_dict()["report_hash"];return report


__all__=["M5_VALIDATOR_VERSION","IndependentMachineMarkingValidationReport","IndependentMachineMarkingValidator"]
