"""Scribing M13 controller-adapter certification and owner-evidence layer.

M13 deliberately separates three concerns:

1. M12 may *rehearse* an installed adapter offline and compare it with a known
   expected output.  That remains non-production.
2. M13 ingests immutable owner/machine attestations for exact M12 golden cases
   and can issue a versioned adapter certificate when explicit evidence coverage
   is complete.
3. A certified adapter may generate an *offline controller-output package* only
   when the current project also has M11 production-marking release and a current
   M12 simulation.  Direct network/machine transfer remains outside this module
   and is always blocked.

The code never fabricates owner approval.  Template helpers always emit
``owner_approved = False`` and ``machine_observed = False``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
import difflib
import hashlib
import json
import re
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from cws_convertor.production_export.utils import atomic_directory, atomic_write, canonical_json_bytes, sha256_file
from cws_convertor.product import APP_VERSION, PROJECT_SCHEMA_VERSION
from .adapter_rehearsal import (
    AdapterRehearsalError,
    DEFAULT_MANUFACTURING_ADAPTER_REGISTRY,
    ManufacturingAdapterDescriptor,
    ManufacturingAdapterRegistry,
    compare_rehearsal_to_golden,
    validate_neutral_sequence_job,
    validate_persisted_adapter_rehearsal,
)
from .machine_marking_service import load_machine_marking_capability
from .release_gate import current_scribing_release
from .simulation_service import validate_persisted_manufacturing_simulation

M13_CERTIFICATION_CONTRACT_VERSION = "1.0"
M13_OWNER_ATTESTATION_FORMAT = "CWS_M13_OWNER_ADAPTER_ATTESTATION_V1"
M13_EVIDENCE_CASE_STATE_SCHEMA_VERSION = "1.0"
M13_CERTIFICATE_FORMAT = "CWS_M13_ADAPTER_CERTIFICATE_V1"
M13_CERTIFICATE_STATE_SCHEMA_VERSION = "1.0"
M13_REVOCATION_FORMAT = "CWS_M13_ADAPTER_CERTIFICATE_REVOCATION_V1"
M13_REVOCATION_SCHEMA_VERSION = "1.0"
M13_OUTPUT_DIFF_FORMAT = "CWS_M13_EXPECTED_ACTUAL_DIFF_V1"
M13_CERTIFIED_PACKAGE_FORMAT = "CWS_M13_CERTIFIED_SEQUENCE_PACKAGE_V1"
M13_CERTIFIED_PACKAGE_SCHEMA_VERSION = "1.0"
M13_HASH_VERSION = "cws-m13-adapter-certification-v1"

M13_CASE_TYPES = frozenset({"straight", "angle", "marking", "drilling", "mirrored", "flange_web", "other"})
_FULL_SHA_RE = re.compile(r"[0-9a-f]{40}")
_SHA256_RE = re.compile(r"[0-9a-f]{64}")


class AdapterCertificationError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def _valid_sha256(value: Any) -> bool:
    return bool(_SHA256_RE.fullmatch(str(value or "").lower()))


def _valid_full_git_sha(value: Any) -> bool:
    return bool(_FULL_SHA_RE.fullmatch(str(value or "").lower()))


def _parse_iso(value: Any, *, label: str) -> datetime:
    text = str(value or "").strip()
    if not text:
        raise AdapterCertificationError("CWS-CERT-001", f"{label} ontbreekt")
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise AdapterCertificationError("CWS-CERT-001", f"{label} is geen geldige ISO-8601 datum/tijd") from exc
    if dt.tzinfo is None:
        raise AdapterCertificationError("CWS-CERT-001", f"{label} moet timezone-aware zijn")
    return dt.astimezone(timezone.utc)


def _safe_relative_path(value: Any, *, label: str = "artifact") -> str:
    path = str(value or "").replace("\\", "/")
    pure = PurePosixPath(path)
    if not path or pure.is_absolute() or ".." in pure.parts or len(path) > 512:
        raise AdapterCertificationError("CWS-CERT-002", f"Onveilig {label}-pad: {path!r}")
    return pure.as_posix()


def _artifact_index(items: Iterable[Mapping[str, Any]], *, label: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for raw in items:
        if not isinstance(raw, Mapping):
            raise AdapterCertificationError("CWS-CERT-003", f"{label} bevat ongeldig artifactrecord")
        path = _safe_relative_path(raw.get("relative_path"), label=label)
        if path in result:
            raise AdapterCertificationError("CWS-CERT-003", f"{label} bevat dubbel artifactpad {path}")
        sha = str(raw.get("sha256") or "").lower()
        if not _valid_sha256(sha):
            raise AdapterCertificationError("CWS-CERT-003", f"{label} bevat ongeldige SHA-256 voor {path}")
        try:
            size = int(raw.get("size_bytes"))
        except (TypeError, ValueError) as exc:
            raise AdapterCertificationError("CWS-CERT-003", f"{label} bevat ongeldige grootte voor {path}") from exc
        if size < 0:
            raise AdapterCertificationError("CWS-CERT-003", f"{label} bevat negatieve grootte voor {path}")
        result[path] = {"relative_path": path, "sha256": sha, "size_bytes": size}
    return result


def _verify_artifact_root(index: Mapping[str, Mapping[str, Any]], root: str | Path, *, label: str) -> None:
    base = Path(root)
    if not base.is_dir():
        raise AdapterCertificationError("CWS-CERT-004", f"{label} bestaat niet of is geen map")
    for rel, meta in index.items():
        path = base.joinpath(*PurePosixPath(rel).parts)
        if not path.is_file():
            raise AdapterCertificationError("CWS-CERT-004", f"{label} mist artifact {rel}")
        if int(path.stat().st_size) != int(meta["size_bytes"]):
            raise AdapterCertificationError("CWS-CERT-004", f"{label} grootte mismatch voor {rel}")
        if sha256_file(path) != str(meta["sha256"]):
            raise AdapterCertificationError("CWS-CERT-004", f"{label} SHA-256 mismatch voor {rel}")


def _is_text(data: bytes) -> bool:
    if b"\x00" in data[:4096]:
        return False
    try:
        data.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return True


def _json_semantic_differences(a: Any, b: Any, *, prefix: str = "", limit: int = 50) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []

    def visit(left: Any, right: Any, path: str) -> None:
        if len(out) >= limit:
            return
        if type(left) is not type(right):
            out.append({"path": path or "$", "expected": left, "actual": right, "reason": "type_mismatch"})
            return
        if isinstance(left, dict):
            keys = sorted(set(left) | set(right))
            for key in keys:
                child = f"{path}.{key}" if path else str(key)
                if key not in left:
                    out.append({"path": child, "expected": "<missing>", "actual": right[key], "reason": "unexpected_key"})
                elif key not in right:
                    out.append({"path": child, "expected": left[key], "actual": "<missing>", "reason": "missing_key"})
                else:
                    visit(left[key], right[key], child)
                if len(out) >= limit:
                    return
            return
        if isinstance(left, list):
            if len(left) != len(right):
                out.append({"path": path or "$", "expected_length": len(left), "actual_length": len(right), "reason": "length_mismatch"})
            for i, (lv, rv) in enumerate(zip(left, right)):
                visit(lv, rv, f"{path}[{i}]" if path else f"[{i}]")
                if len(out) >= limit:
                    return
            return
        if left != right:
            out.append({"path": path or "$", "expected": left, "actual": right, "reason": "value_mismatch"})

    visit(a, b, prefix)
    return out


def _physical_diff(expected: Path, actual: Path, relative_path: str) -> dict[str, Any]:
    expected_bytes = expected.read_bytes()
    actual_bytes = actual.read_bytes()
    row: dict[str, Any] = {
        "relative_path": relative_path,
        "expected_sha256": hashlib.sha256(expected_bytes).hexdigest(),
        "actual_sha256": hashlib.sha256(actual_bytes).hexdigest(),
        "expected_size_bytes": len(expected_bytes),
        "actual_size_bytes": len(actual_bytes),
        "exact_bytes": expected_bytes == actual_bytes,
    }
    if expected_bytes == actual_bytes:
        row["diagnostic_kind"] = "exact"
        return row
    ext = PurePosixPath(relative_path).suffix.lower()
    if ext == ".json":
        try:
            left = json.loads(expected_bytes.decode("utf-8"))
            right = json.loads(actual_bytes.decode("utf-8"))
            differences = _json_semantic_differences(left, right)
            row.update({
                "diagnostic_kind": "json",
                "semantic_equal": not differences,
                "semantic_differences": differences,
            })
            return row
        except Exception:
            pass
    if len(expected_bytes) <= 2 * 1024 * 1024 and len(actual_bytes) <= 2 * 1024 * 1024 and _is_text(expected_bytes) and _is_text(actual_bytes):
        left_lines = expected_bytes.decode("utf-8").splitlines()
        right_lines = actual_bytes.decode("utf-8").splitlines()
        diff_lines = list(difflib.unified_diff(left_lines, right_lines, fromfile=f"expected/{relative_path}", tofile=f"actual/{relative_path}", lineterm=""))
        row.update({"diagnostic_kind": "text", "unified_diff": diff_lines[:200], "diff_truncated": len(diff_lines) > 200})
        return row
    mismatch = min(len(expected_bytes), len(actual_bytes))
    for i, (lv, rv) in enumerate(zip(expected_bytes, actual_bytes)):
        if lv != rv:
            mismatch = i
            break
    row.update({"diagnostic_kind": "binary", "first_mismatch_offset": mismatch})
    return row


def build_expected_actual_diff(
    rehearsal_manifest: Mapping[str, Any],
    golden_case: Mapping[str, Any],
    *,
    expected_root: str | Path | None = None,
    actual_root: str | Path | None = None,
) -> dict[str, Any]:
    """Create an explainable expected-vs-actual diagnostic report.

    Certification still requires exact SHA/size equality.  Text/JSON/binary
    diagnostics are explanatory only and never relax the exact-match gate.
    """
    rehearsal = dict(rehearsal_manifest or {})
    golden = dict(golden_case or {})
    base = compare_rehearsal_to_golden(rehearsal, golden)
    actual_index = _artifact_index(list(rehearsal.get("artifacts") or []), label="rehearsal")
    expected_index = _artifact_index(list(golden.get("expected_artifacts") or []), label="golden")
    if (expected_root is None) != (actual_root is None):
        raise AdapterCertificationError("CWS-CERT-004", "Expected-vs-actual physical diff vereist zowel expected_root als actual_root")
    if expected_root is not None and actual_root is not None:
        _verify_artifact_root(expected_index, expected_root, label="M13 expected artifacts")
        _verify_artifact_root(actual_index, actual_root, label="M13 actual artifacts")
    paths = sorted(set(expected_index) | set(actual_index))
    details: list[dict[str, Any]] = []
    for rel in paths:
        if rel not in expected_index:
            details.append({"relative_path": rel, "status": "unexpected", "actual": actual_index[rel]})
            continue
        if rel not in actual_index:
            details.append({"relative_path": rel, "status": "missing", "expected": expected_index[rel]})
            continue
        exp = expected_index[rel]
        act = actual_index[rel]
        if exp["sha256"] == act["sha256"] and int(exp["size_bytes"]) == int(act["size_bytes"]):
            details.append({"relative_path": rel, "status": "exact", "sha256": exp["sha256"], "size_bytes": exp["size_bytes"]})
            continue
        row: dict[str, Any] = {"relative_path": rel, "status": "mismatch", "expected": exp, "actual": act}
        if expected_root is not None and actual_root is not None:
            ep = Path(expected_root).joinpath(*PurePosixPath(rel).parts)
            ap = Path(actual_root).joinpath(*PurePosixPath(rel).parts)
            if ep.is_file() and ap.is_file():
                row["diagnostic"] = _physical_diff(ep, ap, rel)
        details.append(row)
    report = {
        "format": M13_OUTPUT_DIFF_FORMAT,
        "schema_version": M13_CERTIFICATION_CONTRACT_VERSION,
        "case_id": str(golden.get("case_id") or ""),
        "rehearsal_id": str(rehearsal.get("rehearsal_id") or ""),
        "exact_match": bool(base.get("exact_match")),
        "identity_mismatches": list(base.get("identity_mismatches") or []),
        "artifacts": details,
        "production_eligible": False,
        "machine_transfer": {"allowed": False},
    }
    report["report_hash"] = stable_sha256({k: v for k, v in report.items() if k != "report_hash"})
    return report


def owner_attestation_template(
    rehearsal_manifest: Mapping[str, Any],
    golden_case: Mapping[str, Any],
    *,
    case_type: str,
    operation_types: Iterable[str],
    downstream_software: str = "",
    notes: str = "",
) -> dict[str, Any]:
    """Create a hash-bound owner attestation template that is *never approved*."""
    rehearsal = dict(rehearsal_manifest or {})
    golden = dict(golden_case or {})
    compare = compare_rehearsal_to_golden(rehearsal, golden)
    if not bool(compare.get("exact_match")):
        raise AdapterCertificationError("CWS-CERT-005", "Owner attestation template vereist eerst een exact M12 golden match")
    case_type = str(case_type or "").strip().lower()
    if case_type not in M13_CASE_TYPES:
        raise AdapterCertificationError("CWS-CERT-005", f"Onbekend M13 case_type {case_type!r}")
    ops = tuple(sorted(set(str(x).strip() for x in operation_types if str(x).strip())))
    if not ops:
        raise AdapterCertificationError("CWS-CERT-005", "Owner attestation moet operation_types declareren")
    rehearsal_ops = set(str(x).strip() for x in rehearsal.get("operation_types") or [] if str(x).strip())
    if not rehearsal_ops:
        raise AdapterCertificationError("CWS-CERT-005", "M13 operation coverage vereist een M12 rehearsal met expliciete operation_types")
    if not set(ops).issubset(rehearsal_ops):
        raise AdapterCertificationError("CWS-CERT-005", f"Owner attestation claimt operations die niet in de rehearsal voorkwamen: {sorted(set(ops)-rehearsal_ops)}")
    adapter = dict(rehearsal.get("adapter") or {})
    payload = {
        "format": M13_OWNER_ATTESTATION_FORMAT,
        "schema_version": M13_CERTIFICATION_CONTRACT_VERSION,
        "case_id": str(golden.get("case_id") or ""),
        "case_type": case_type,
        "adapter_id": str(adapter.get("adapter_id") or ""),
        "adapter_descriptor_hash": str(adapter.get("descriptor_hash") or ""),
        "machine_id": str(adapter.get("machine_id") or ""),
        "controller_id": str(adapter.get("controller_id") or ""),
        "adapter_version": str(adapter.get("adapter_version") or ""),
        "operation_types": list(ops),
        "rehearsal_manifest_hash": str(rehearsal.get("manifest_hash") or ""),
        "golden_hash": str(golden.get("golden_hash") or ""),
        "compare_report_hash": str(compare.get("report_hash") or ""),
        "neutral_job_manifest_hash": str(rehearsal.get("neutral_job_manifest_hash") or ""),
        "owner_approved": False,
        "machine_observed": False,
        "approved_by": "",
        "approved_at": "",
        "approval_reference": "",
        "downstream_software": str(downstream_software or ""),
        "notes": str(notes or ""),
    }
    payload["attestation_hash"] = stable_sha256({k: v for k, v in payload.items() if k != "attestation_hash"})
    return payload


def _validate_owner_attestation(
    attestation: Mapping[str, Any],
    *,
    rehearsal: Mapping[str, Any],
    golden: Mapping[str, Any],
    compare: Mapping[str, Any],
    require_approved: bool,
) -> dict[str, Any]:
    raw = dict(attestation or {})
    if raw.get("format") != M13_OWNER_ATTESTATION_FORMAT or str(raw.get("schema_version") or "") != M13_CERTIFICATION_CONTRACT_VERSION:
        raise AdapterCertificationError("CWS-CERT-006", "Owner attestation format/schema ongeldig")
    stored = str(raw.get("attestation_hash") or "")
    if not _valid_sha256(stored) or stored != stable_sha256({k: v for k, v in raw.items() if k != "attestation_hash"}):
        raise AdapterCertificationError("CWS-CERT-006", "Owner attestation hash ongeldig")
    case_type = str(raw.get("case_type") or "").lower()
    if case_type not in M13_CASE_TYPES:
        raise AdapterCertificationError("CWS-CERT-006", "Owner attestation case_type ongeldig")
    ops = tuple(sorted(set(str(x).strip() for x in raw.get("operation_types") or [] if str(x).strip())))
    if not ops:
        raise AdapterCertificationError("CWS-CERT-006", "Owner attestation mist operation coverage")
    rehearsal_ops = set(str(x).strip() for x in rehearsal.get("operation_types") or [] if str(x).strip())
    if not rehearsal_ops or not set(ops).issubset(rehearsal_ops):
        raise AdapterCertificationError("CWS-CERT-006", "Owner attestation operation coverage is niet bewezen door de M12 rehearsal")
    adapter = dict(rehearsal.get("adapter") or {})
    expected = {
        "case_id": str(golden.get("case_id") or ""),
        "adapter_id": str(adapter.get("adapter_id") or ""),
        "adapter_descriptor_hash": str(adapter.get("descriptor_hash") or ""),
        "machine_id": str(adapter.get("machine_id") or ""),
        "controller_id": str(adapter.get("controller_id") or ""),
        "adapter_version": str(adapter.get("adapter_version") or ""),
        "rehearsal_manifest_hash": str(rehearsal.get("manifest_hash") or ""),
        "golden_hash": str(golden.get("golden_hash") or ""),
        "compare_report_hash": str(compare.get("report_hash") or ""),
        "neutral_job_manifest_hash": str(rehearsal.get("neutral_job_manifest_hash") or ""),
    }
    mismatches = {key: {"expected": val, "actual": str(raw.get(key) or "")} for key, val in expected.items() if str(raw.get(key) or "") != val}
    if mismatches:
        raise AdapterCertificationError("CWS-CERT-007", "Owner attestation binding mismatch", details={"mismatches": mismatches})
    if require_approved:
        if not bool(raw.get("owner_approved")):
            raise AdapterCertificationError("CWS-CERT-008", "Owner attestation is niet owner_approved")
        if not bool(raw.get("machine_observed")):
            raise AdapterCertificationError("CWS-CERT-008", "Owner attestation mist echte machine/controller-observatie")
        for key in ("approved_by", "approved_at", "approval_reference", "downstream_software"):
            if not str(raw.get(key) or "").strip():
                raise AdapterCertificationError("CWS-CERT-008", f"Owner attestation mist {key}")
        _parse_iso(raw.get("approved_at"), label="approved_at")
    return raw


def ingest_owner_adapter_evidence(
    project: ProjectModel,
    rehearsal_id: str,
    golden_case: Mapping[str, Any],
    owner_attestation: Mapping[str, Any],
    *,
    artifact_root: str | Path | None = None,
    user: str = "system",
) -> dict[str, Any]:
    """Persist one externally approved adapter evidence case.

    The function does not create or edit owner approval.  It only verifies an
    already-approved attestation and binds it to immutable M12/golden hashes.
    """
    state = validate_persisted_adapter_rehearsal(project, rehearsal_id, require_current=False, require_files=artifact_root is not None, artifact_root=artifact_root)
    rehearsal = dict(state.get("manifest") or {})
    golden = dict(golden_case or {})
    compare = compare_rehearsal_to_golden(rehearsal, golden)
    if not bool(compare.get("exact_match")):
        raise AdapterCertificationError("CWS-CERT-009", "M13 owner evidence vereist exact M12 rehearsal/golden resultaat", details={"comparison": compare})
    attestation = _validate_owner_attestation(owner_attestation, rehearsal=rehearsal, golden=golden, compare=compare, require_approved=True)
    evidence_id = "ace-" + stable_sha256({
        "case_id": attestation["case_id"],
        "rehearsal_manifest_hash": rehearsal["manifest_hash"],
        "golden_hash": golden["golden_hash"],
        "attestation_hash": attestation["attestation_hash"],
    })[:28]
    adapter = dict(rehearsal.get("adapter") or {})
    record = {
        "schema_version": M13_EVIDENCE_CASE_STATE_SCHEMA_VERSION,
        "phase": "M13",
        "evidence_id": evidence_id,
        "case_id": attestation["case_id"],
        "case_type": attestation["case_type"],
        "rehearsal_id": rehearsal_id,
        "rehearsal_manifest_hash": rehearsal["manifest_hash"],
        "golden_case": golden,
        "golden_hash": golden["golden_hash"],
        "comparison": compare,
        "compare_report_hash": compare["report_hash"],
        "owner_attestation": attestation,
        "attestation_hash": attestation["attestation_hash"],
        "adapter_id": adapter.get("adapter_id", ""),
        "adapter_descriptor_hash": adapter.get("descriptor_hash", ""),
        "machine_id": adapter.get("machine_id", ""),
        "controller_id": adapter.get("controller_id", ""),
        "adapter_version": adapter.get("adapter_version", ""),
        "operation_types": list(attestation["operation_types"]),
        "owner_approved": True,
        "machine_observed": True,
        "approved_by": attestation["approved_by"],
        "approved_at": attestation["approved_at"],
        "approval_reference": attestation["approval_reference"],
        "downstream_software": attestation["downstream_software"],
        "ingested_at": utc_now_iso(),
        "ingested_by": str(user or "system"),
        "production_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
    }
    record["state_hash"] = stable_sha256({k: v for k, v in record.items() if k != "state_hash"})
    existing = project.manufacturing_adapter_evidence_cases.get(evidence_id)
    if isinstance(existing, dict):
        # Evidence IDs are content-addressed by rehearsal/golden/attestation.
        # Re-ingesting the exact same externally signed evidence is therefore
        # idempotent; ingestion timestamp/user are audit metadata, not identity.
        validated_existing = validate_persisted_adapter_evidence(project, evidence_id)
        immutable_keys = (
            "case_id", "case_type", "rehearsal_id", "rehearsal_manifest_hash",
            "golden_hash", "compare_report_hash", "attestation_hash",
            "adapter_id", "adapter_descriptor_hash", "machine_id", "controller_id",
            "adapter_version", "operation_types", "approved_by", "approved_at",
            "approval_reference", "downstream_software",
        )
        if all(validated_existing.get(key) == record.get(key) for key in immutable_keys):
            return validated_existing
        raise ProjectValidationError(f"M13 evidence-ID collision voor {evidence_id}")
    project.manufacturing_adapter_evidence_cases[evidence_id] = record
    project.audit("manufacturing.adapter_owner_evidence_ingested", user=user, entity_id=evidence_id, after_hash=record["state_hash"], details={"case_id": record["case_id"], "case_type": record["case_type"], "adapter_id": record["adapter_id"]})
    return record


def validate_persisted_adapter_evidence(project: ProjectModel, evidence_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_evidence_cases.get(evidence_id)
    if not isinstance(raw, dict):
        raise ProjectValidationError(f"Onbekend M13 adapter evidence-record {evidence_id}")
    if raw.get("phase") != "M13" or str(raw.get("schema_version") or "") != M13_EVIDENCE_CASE_STATE_SCHEMA_VERSION:
        raise ProjectValidationError("M13 adapter evidence schema/phase mismatch")
    if str(raw.get("evidence_id") or "") != evidence_id:
        raise ProjectValidationError("M13 adapter evidence opslagkey/ID mismatch")
    if str(raw.get("state_hash") or "") != stable_sha256({k: v for k, v in raw.items() if k != "state_hash"}):
        raise ProjectValidationError("M13 adapter evidence state_hash ongeldig")
    if any(bool(raw.get(k)) for k in ("production_eligible", "machine_output_released", "direct_machine_transfer")):
        raise ProjectValidationError("M13 losse evidence-case mag geen productie vrijgeven")
    rehearsal_state = validate_persisted_adapter_rehearsal(project, str(raw.get("rehearsal_id") or ""), require_current=False, require_files=False)
    rehearsal = dict(rehearsal_state.get("manifest") or {})
    if str(rehearsal.get("manifest_hash") or "") != str(raw.get("rehearsal_manifest_hash") or ""):
        raise ProjectValidationError("M13 adapter evidence rehearsal hash mismatch")
    golden = dict(raw.get("golden_case") or {})
    compare = compare_rehearsal_to_golden(rehearsal, golden)
    if not bool(compare.get("exact_match")) or str(compare.get("report_hash") or "") != str(raw.get("compare_report_hash") or ""):
        raise ProjectValidationError("M13 adapter evidence golden compare mismatch")
    attestation = _validate_owner_attestation(dict(raw.get("owner_attestation") or {}), rehearsal=rehearsal, golden=golden, compare=compare, require_approved=True)
    if str(attestation.get("attestation_hash") or "") != str(raw.get("attestation_hash") or ""):
        raise ProjectValidationError("M13 adapter evidence attestation hash mismatch")
    bindings = {
        "case_id": str(attestation.get("case_id") or ""),
        "case_type": str(attestation.get("case_type") or ""),
        "adapter_id": str(attestation.get("adapter_id") or ""),
        "adapter_descriptor_hash": str(attestation.get("adapter_descriptor_hash") or ""),
        "machine_id": str(attestation.get("machine_id") or ""),
        "controller_id": str(attestation.get("controller_id") or ""),
        "adapter_version": str(attestation.get("adapter_version") or ""),
        "approved_by": str(attestation.get("approved_by") or ""),
        "approved_at": str(attestation.get("approved_at") or ""),
        "approval_reference": str(attestation.get("approval_reference") or ""),
        "downstream_software": str(attestation.get("downstream_software") or ""),
    }
    for key, expected in bindings.items():
        if str(raw.get(key) or "") != expected:
            raise ProjectValidationError(f"M13 adapter evidence top-level binding mismatch voor {key}")
    expected_ops = sorted(set(str(x) for x in attestation.get("operation_types") or []))
    if sorted(set(str(x) for x in raw.get("operation_types") or [])) != expected_ops:
        raise ProjectValidationError("M13 adapter evidence operation_types wijkt af van owner attestation")
    if not bool(raw.get("owner_approved")) or not bool(raw.get("machine_observed")):
        raise ProjectValidationError("M13 adapter evidence mist owner/machine approval")
    return raw


@dataclass(frozen=True)
class AdapterCertificationPolicy:
    required_case_types: tuple[str, ...] = ("straight", "angle", "marking")
    minimum_case_count: int = 3
    maximum_validity_days: int = 365
    require_operation_coverage: bool = True
    policy_hash: str = ""
    schema_version: str = M13_CERTIFICATION_CONTRACT_VERSION

    def __post_init__(self) -> None:
        case_types = tuple(sorted(set(str(x).strip().lower() for x in self.required_case_types if str(x).strip())))
        if not case_types or not set(case_types).issubset(M13_CASE_TYPES):
            raise ProjectValidationError("M13 certification policy bevat ongeldige required_case_types")
        if int(self.minimum_case_count) < len(case_types) or int(self.minimum_case_count) < 1:
            raise ProjectValidationError("M13 certification policy minimum_case_count is te laag")
        if not 1 <= int(self.maximum_validity_days) <= 3650:
            raise ProjectValidationError("M13 certification policy maximum_validity_days is ongeldig")
        object.__setattr__(self, "required_case_types", case_types)
        expected = stable_sha256(self.hash_payload())
        if self.policy_hash and self.policy_hash != expected:
            raise ProjectValidationError("M13 certification policy_hash ongeldig")
        object.__setattr__(self, "policy_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "required_case_types": list(self.required_case_types),
            "minimum_case_count": int(self.minimum_case_count),
            "maximum_validity_days": int(self.maximum_validity_days),
            "require_operation_coverage": bool(self.require_operation_coverage),
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "policy_hash": self.policy_hash}


def issue_adapter_certificate(
    project: ProjectModel,
    descriptor: ManufacturingAdapterDescriptor,
    evidence_ids: Iterable[str],
    *,
    capability_id: str,
    certification_scope_operations: Iterable[str],
    adapter_source_commit: str,
    adapter_artifact_name: str,
    adapter_artifact_sha256: str,
    issued_by: str,
    validity_days: int = 180,
    policy: AdapterCertificationPolicy | None = None,
    supersedes_certificate_id: str = "",
) -> dict[str, Any]:
    """Issue an immutable offline controller-output certificate.

    This is only possible with already-approved M13 owner evidence.  It enables
    *file generation* after the per-project M11 gate; direct transfer remains
    explicitly forbidden.
    """
    policy = policy or AdapterCertificationPolicy()
    ids = tuple(sorted(set(str(x).strip() for x in evidence_ids if str(x).strip())))
    if len(ids) < policy.minimum_case_count:
        raise AdapterCertificationError("CWS-CERT-010", f"Te weinig M13 evidence-cases: {len(ids)} < {policy.minimum_case_count}")
    evidence = [validate_persisted_adapter_evidence(project, eid) for eid in ids]
    for row in evidence:
        for key, expected in (
            ("adapter_id", descriptor.adapter_id),
            ("adapter_descriptor_hash", descriptor.descriptor_hash),
            ("machine_id", descriptor.machine_id),
            ("controller_id", descriptor.controller_id),
            ("adapter_version", descriptor.adapter_version),
        ):
            if str(row.get(key) or "") != str(expected):
                raise AdapterCertificationError("CWS-CERT-011", f"Evidence {row.get('evidence_id')} wijkt af op {key}")
    case_types = {str(x.get("case_type") or "") for x in evidence}
    missing_types = sorted(set(policy.required_case_types) - case_types)
    if missing_types:
        raise AdapterCertificationError("CWS-CERT-012", f"M13 certificering mist case types: {missing_types}")
    scope = tuple(sorted(set(str(x).strip() for x in certification_scope_operations if str(x).strip())))
    if not scope:
        raise AdapterCertificationError("CWS-CERT-013", "M13 certificering mist operation scope")
    if not set(scope).issubset(set(descriptor.supported_operation_types)):
        raise AdapterCertificationError("CWS-CERT-013", "M13 operation scope valt buiten adapterdescriptor")
    covered_ops = sorted({op for row in evidence for op in row.get("operation_types") or []})
    if policy.require_operation_coverage:
        missing_ops = sorted(set(scope) - set(covered_ops))
        if missing_ops:
            raise AdapterCertificationError("CWS-CERT-014", f"M13 evidence dekt operations niet: {missing_ops}")
    capability = load_machine_marking_capability(project, capability_id, require_current=True)
    if capability.machine_id != descriptor.machine_id:
        raise AdapterCertificationError("CWS-CERT-015", "M13 capability en adapter horen niet bij dezelfde machine-ID")
    if not _valid_full_git_sha(adapter_source_commit):
        raise AdapterCertificationError("CWS-CERT-016", "M13 adapter_source_commit moet een volledige 40-char Git SHA zijn")
    if not str(adapter_artifact_name or "").strip() or "/" in str(adapter_artifact_name) or "\\" in str(adapter_artifact_name):
        raise AdapterCertificationError("CWS-CERT-016", "M13 adapter_artifact_name moet een eenvoudige bestandsnaam zijn")
    if not _valid_sha256(adapter_artifact_sha256):
        raise AdapterCertificationError("CWS-CERT-016", "M13 adapter_artifact_sha256 is ongeldig")
    if not str(issued_by or "").strip():
        raise AdapterCertificationError("CWS-CERT-016", "M13 issued_by ontbreekt")
    validity_days = int(validity_days)
    if not 1 <= validity_days <= policy.maximum_validity_days:
        raise AdapterCertificationError("CWS-CERT-016", f"M13 validity_days moet 1..{policy.maximum_validity_days} zijn")
    issued_dt = datetime.now(timezone.utc).replace(microsecond=0)
    expires_dt = issued_dt + timedelta(days=validity_days)
    issue_seed = {
        "descriptor_hash": descriptor.descriptor_hash,
        "capability_hash": capability.capability_hash,
        "evidence_state_hashes": [str(x.get("state_hash") or "") for x in evidence],
        "scope": list(scope),
        "adapter_source_commit": adapter_source_commit,
        "adapter_artifact_sha256": adapter_artifact_sha256,
        "policy_hash": policy.policy_hash,
    }
    supersedes_certificate_id = str(supersedes_certificate_id or "").strip()
    if supersedes_certificate_id:
        issue_seed["supersedes_certificate_id"] = supersedes_certificate_id
    certificate_id = "cert-" + stable_sha256(issue_seed)[:28]
    certificate = {
        "format": M13_CERTIFICATE_FORMAT,
        "schema_version": M13_CERTIFICATE_STATE_SCHEMA_VERSION,
        "phase": "M13",
        "certificate_id": certificate_id,
        "status": "certified",
        "adapter": descriptor.to_dict(),
        "adapter_id": descriptor.adapter_id,
        "adapter_descriptor_hash": descriptor.descriptor_hash,
        "machine_id": descriptor.machine_id,
        "controller_id": descriptor.controller_id,
        "adapter_version": descriptor.adapter_version,
        "capability_id": capability.capability_id,
        "capability_hash": capability.capability_hash,
        "certification_scope_operations": list(scope),
        "evidence_case_ids": list(ids),
        "evidence_state_hashes": {str(x["evidence_id"]): str(x["state_hash"]) for x in evidence},
        "case_types_covered": sorted(case_types),
        "operation_types_covered": covered_ops,
        "policy": policy.to_dict(),
        "adapter_source_commit": adapter_source_commit.lower(),
        "adapter_artifact_name": str(adapter_artifact_name),
        "adapter_artifact_sha256": adapter_artifact_sha256.lower(),
        "cws_version": APP_VERSION,
        "project_schema_version": PROJECT_SCHEMA_VERSION,
        "issued_by": str(issued_by),
        "issued_at": issued_dt.isoformat().replace("+00:00", "Z"),
        "expires_at": expires_dt.isoformat().replace("+00:00", "Z"),
        "offline_controller_output_certified": True,
        "offline_controller_output_released": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M13_HASH_VERSION,
    }
    if supersedes_certificate_id:
        certificate["supersedes_certificate_id"] = supersedes_certificate_id
    certificate["certificate_hash"] = stable_sha256({k: v for k, v in certificate.items() if k != "certificate_hash"})
    existing = project.manufacturing_adapter_certificates.get(certificate_id)
    if isinstance(existing, dict) and str(existing.get("certificate_hash") or "") != certificate["certificate_hash"]:
        raise ProjectValidationError(f"M13 certificate-ID collision voor {certificate_id}")
    project.manufacturing_adapter_certificates[certificate_id] = certificate
    project.audit("manufacturing.adapter_certificate_issued", user=issued_by, entity_id=certificate_id, after_hash=certificate["certificate_hash"], details={"adapter_id": descriptor.adapter_id, "machine_id": descriptor.machine_id, "evidence_count": len(ids), "direct_machine_transfer": False})
    return certificate


def validate_persisted_adapter_revocation(project: ProjectModel, certificate_id: str) -> dict[str, Any] | None:
    raw = project.manufacturing_adapter_certificate_revocations.get(certificate_id)
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise ProjectValidationError("M13 certificate revocation-opslag ongeldig")
    if raw.get("format") != M13_REVOCATION_FORMAT or str(raw.get("schema_version") or "") != M13_REVOCATION_SCHEMA_VERSION:
        raise ProjectValidationError("M13 certificate revocation schema ongeldig")
    if str(raw.get("certificate_id") or "") != certificate_id:
        raise ProjectValidationError("M13 certificate revocation ID mismatch")
    if str(raw.get("revocation_hash") or "") != stable_sha256({k: v for k, v in raw.items() if k != "revocation_hash"}):
        raise ProjectValidationError("M13 certificate revocation hash ongeldig")
    if not str(raw.get("reason") or "").strip() or not str(raw.get("revoked_by") or "").strip() or not str(raw.get("revoked_at") or "").strip():
        raise ProjectValidationError("M13 certificate revocation mist reden/audit")
    _parse_iso(raw.get("revoked_at"), label="revoked_at")
    return raw


def validate_persisted_adapter_certificate(project: ProjectModel, certificate_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_adapter_certificates.get(certificate_id)
    if not isinstance(raw, dict):
        raise ProjectValidationError(f"Onbekend M13 adaptercertificaat {certificate_id}")
    if raw.get("format") != M13_CERTIFICATE_FORMAT or raw.get("phase") != "M13" or str(raw.get("schema_version") or "") != M13_CERTIFICATE_STATE_SCHEMA_VERSION:
        raise ProjectValidationError("M13 adaptercertificaat format/schema ongeldig")
    if str(raw.get("certificate_id") or "") != certificate_id:
        raise ProjectValidationError("M13 adaptercertificaat opslagkey/ID mismatch")
    stored_hash = str(raw.get("certificate_hash") or "")
    if not _valid_sha256(stored_hash) or stored_hash != stable_sha256({k: v for k, v in raw.items() if k != "certificate_hash"}):
        raise ProjectValidationError("M13 adaptercertificaat certificate_hash ongeldig")
    if str(raw.get("hash_version") or "") != M13_HASH_VERSION:
        raise ProjectValidationError("M13 adaptercertificaat hash_version ongeldig")
    if not bool(raw.get("offline_controller_output_certified")):
        raise ProjectValidationError("M13 adaptercertificaat mist offline-controller certificeringsflag")
    if bool(raw.get("offline_controller_output_released")) or bool(raw.get("machine_output_released")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M13 adaptercertificaat mag zonder projectgebonden M11 gate geen output/transfer vrijgeven")
    descriptor = ManufacturingAdapterDescriptor(**{
        "adapter_id": str(dict(raw.get("adapter") or {}).get("adapter_id") or ""),
        "name": str(dict(raw.get("adapter") or {}).get("name") or ""),
        "machine_id": str(dict(raw.get("adapter") or {}).get("machine_id") or ""),
        "controller_id": str(dict(raw.get("adapter") or {}).get("controller_id") or ""),
        "adapter_version": str(dict(raw.get("adapter") or {}).get("adapter_version") or ""),
        "output_extensions": tuple(dict(raw.get("adapter") or {}).get("output_extensions") or []),
        "supported_operation_types": tuple(dict(raw.get("adapter") or {}).get("supported_operation_types") or []),
        "description": str(dict(raw.get("adapter") or {}).get("description") or ""),
        "descriptor_hash": str(dict(raw.get("adapter") or {}).get("descriptor_hash") or ""),
        "contract_version": str(dict(raw.get("adapter") or {}).get("contract_version") or "1.0"),
    })
    if descriptor.descriptor_hash != str(raw.get("adapter_descriptor_hash") or ""):
        raise ProjectValidationError("M13 adaptercertificaat descriptor binding mismatch")
    if not _valid_full_git_sha(raw.get("adapter_source_commit")) or not _valid_sha256(raw.get("adapter_artifact_sha256")):
        raise ProjectValidationError("M13 adaptercertificaat source/artifact binding ongeldig")
    if not str(raw.get("issued_by") or "").strip():
        raise ProjectValidationError("M13 adaptercertificaat issued_by ontbreekt")
    issued = _parse_iso(raw.get("issued_at"), label="issued_at")
    expires = _parse_iso(raw.get("expires_at"), label="expires_at")
    if expires <= issued:
        raise ProjectValidationError("M13 adaptercertificaat expires_at ligt niet na issued_at")
    policy_raw = dict(raw.get("policy") or {})
    policy = AdapterCertificationPolicy(
        required_case_types=tuple(policy_raw.get("required_case_types") or []),
        minimum_case_count=int(policy_raw.get("minimum_case_count") or 0),
        maximum_validity_days=int(policy_raw.get("maximum_validity_days") or 0),
        require_operation_coverage=bool(policy_raw.get("require_operation_coverage", True)),
        policy_hash=str(policy_raw.get("policy_hash") or ""),
        schema_version=str(policy_raw.get("schema_version") or M13_CERTIFICATION_CONTRACT_VERSION),
    )
    evidence_ids = [str(x) for x in raw.get("evidence_case_ids") or []]
    if len(evidence_ids) < policy.minimum_case_count or len(evidence_ids) != len(set(evidence_ids)):
        raise ProjectValidationError("M13 adaptercertificaat evidence coverage ongeldig")
    evidence = [validate_persisted_adapter_evidence(project, eid) for eid in evidence_ids]
    expected_hashes = {str(x["evidence_id"]): str(x["state_hash"]) for x in evidence}
    if dict(raw.get("evidence_state_hashes") or {}) != expected_hashes:
        raise ProjectValidationError("M13 adaptercertificaat evidence hash binding mismatch")
    case_types = {str(x.get("case_type") or "") for x in evidence}
    if not set(policy.required_case_types).issubset(case_types):
        raise ProjectValidationError("M13 adaptercertificaat required case coverage ontbreekt")
    scope = tuple(str(x) for x in raw.get("certification_scope_operations") or [])
    if not scope or not set(scope).issubset(set(descriptor.supported_operation_types)):
        raise ProjectValidationError("M13 adaptercertificaat operation scope ongeldig")
    if policy.require_operation_coverage:
        covered = {str(op) for row in evidence for op in row.get("operation_types") or []}
        if not set(scope).issubset(covered):
            raise ProjectValidationError("M13 adaptercertificaat operation evidence coverage ontbreekt")
    capability = load_machine_marking_capability(project, str(raw.get("capability_id") or ""), require_current=require_current)
    if capability.machine_id != descriptor.machine_id or capability.capability_hash != str(raw.get("capability_hash") or ""):
        if require_current:
            raise ProjectValidationError("M13 adaptercertificaat machine capability is stale")
        # Historical certificates remain structurally readable. Stored hash is
        # still required to look like a hash even if current capability changed.
        if not _valid_sha256(raw.get("capability_hash")):
            raise ProjectValidationError("M13 adaptercertificaat capability_hash ongeldig")
    revocation = validate_persisted_adapter_revocation(project, certificate_id)
    if require_current:
        if str(raw.get("cws_version") or "") != APP_VERSION or str(raw.get("project_schema_version") or "") != PROJECT_SCHEMA_VERSION:
            raise ProjectValidationError(f"M13 adaptercertificaat {certificate_id} hoort bij andere CWS software/schema-versie")
        if revocation is not None:
            raise ProjectValidationError(f"M13 adaptercertificaat {certificate_id} is ingetrokken")
        supersessions = getattr(project, "manufacturing_adapter_certificate_supersessions", {})
        if isinstance(supersessions, dict) and certificate_id in supersessions:
            from cws_convertor.manufacturing.certification_ops import validate_persisted_certificate_supersession
            validate_persisted_certificate_supersession(project, certificate_id)
            raise ProjectValidationError(f"M13 adaptercertificaat {certificate_id} is superseded")
        if datetime.now(timezone.utc) >= expires:
            raise ProjectValidationError(f"M13 adaptercertificaat {certificate_id} is verlopen")
    return raw


def revoke_adapter_certificate(project: ProjectModel, certificate_id: str, *, reason: str, revoked_by: str) -> dict[str, Any]:
    certificate = validate_persisted_adapter_certificate(project, certificate_id, require_current=False)
    if not str(reason or "").strip() or not str(revoked_by or "").strip():
        raise AdapterCertificationError("CWS-CERT-017", "M13 revocation vereist reason en revoked_by")
    if certificate_id in project.manufacturing_adapter_certificate_revocations:
        existing = validate_persisted_adapter_revocation(project, certificate_id)
        assert existing is not None
        return existing
    record = {
        "format": M13_REVOCATION_FORMAT,
        "schema_version": M13_REVOCATION_SCHEMA_VERSION,
        "certificate_id": certificate_id,
        "certificate_hash": certificate["certificate_hash"],
        "reason": str(reason),
        "revoked_by": str(revoked_by),
        "revoked_at": utc_now_iso(),
        "machine_transfer": {"allowed": False},
    }
    record["revocation_hash"] = stable_sha256({k: v for k, v in record.items() if k != "revocation_hash"})
    project.manufacturing_adapter_certificate_revocations[certificate_id] = record
    project.audit("manufacturing.adapter_certificate_revoked", user=revoked_by, entity_id=certificate_id, before_hash=certificate["certificate_hash"], after_hash=record["revocation_hash"], details={"reason": reason})
    return record


def current_adapter_certificate(
    project: ProjectModel,
    *,
    adapter_id: str,
    machine_id: str = "",
    controller_id: str = "",
    capability_id: str = "",
) -> dict[str, Any] | None:
    rows = sorted(
        (dict(x) for x in project.manufacturing_adapter_certificates.values() if isinstance(x, Mapping)),
        key=lambda x: (str(x.get("issued_at") or ""), str(x.get("certificate_id") or "")),
        reverse=True,
    )
    for row in rows:
        if str(row.get("adapter_id") or "") != adapter_id:
            continue
        if machine_id and str(row.get("machine_id") or "") != machine_id:
            continue
        if controller_id and str(row.get("controller_id") or "") != controller_id:
            continue
        if capability_id and str(row.get("capability_id") or "") != capability_id:
            continue
        try:
            return validate_persisted_adapter_certificate(project, str(row.get("certificate_id") or ""), require_current=True)
        except ProjectValidationError:
            continue
    return None


def controller_output_release_state(
    project: ProjectModel,
    *,
    certificate_id: str,
    part_ids: Iterable[str],
    capability_id: str,
) -> dict[str, Any]:
    try:
        certificate = validate_persisted_adapter_certificate(project, certificate_id, require_current=True)
    except Exception as exc:
        return {
            "m13_certificate_id": certificate_id,
            "m13_certificate_current": False,
            "m11_release_id": "",
            "production_marking_released": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
            "reason": str(exc),
        }
    m11 = current_scribing_release(project, part_ids=part_ids, capability_id=capability_id)
    if not m11:
        return {
            "m13_certificate_id": certificate_id,
            "m13_certificate_hash": certificate["certificate_hash"],
            "m13_certificate_current": True,
            "m11_release_id": "",
            "production_marking_released": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
            "reason": "Current M11 production-marking release ontbreekt voor deze parts/capability.",
        }
    return {
        "m13_certificate_id": certificate_id,
        "m13_certificate_hash": certificate["certificate_hash"],
        "m13_certificate_current": True,
        "m11_release_id": str(m11.get("release_id") or ""),
        "m11_release_record_hash": str(m11.get("record_hash") or ""),
        "production_marking_released": True,
        "machine_output_released": True,
        "offline_controller_output_released": True,
        "direct_machine_transfer": False,
        "reason": "M11 + M13 permit offline certified controller-file generation only; direct transfer remains blocked.",
    }


def _validate_rendered_files(files: Mapping[str, bytes], descriptor: ManufacturingAdapterDescriptor) -> list[tuple[str, bytes]]:
    if not files:
        raise AdapterCertificationError("CWS-CERT-018", "Gecertificeerde adapter leverde geen uitvoer")
    accepted = set(descriptor.output_extensions)
    total = 0
    result: list[tuple[str, bytes]] = []
    seen: set[str] = set()
    for raw_name, raw_data in sorted(files.items()):
        rel = _safe_relative_path(raw_name, label="controller-output")
        if rel in seen:
            raise AdapterCertificationError("CWS-CERT-018", f"Dubbel controller-outputpad {rel}")
        seen.add(rel)
        data = bytes(raw_data)
        if len(data) > 64 * 1024 * 1024:
            raise AdapterCertificationError("CWS-CERT-018", f"Controller-outputbestand te groot: {rel}")
        total += len(data)
        if total > 256 * 1024 * 1024:
            raise AdapterCertificationError("CWS-CERT-018", "Totale controller-output overschrijdt 256 MiB")
        if PurePosixPath(rel).suffix.lower() not in accepted:
            raise AdapterCertificationError("CWS-CERT-018", f"Niet-gecertificeerde outputextensie: {rel}")
        result.append((rel, data))
    return result


def generate_certified_sequence_package(
    project: ProjectModel,
    simulation_id: str,
    neutral_sequence_job: dict[str, Any] | str | Path,
    adapter_id: str,
    certificate_id: str,
    output_dir: str | Path,
    *,
    registry: ManufacturingAdapterRegistry = DEFAULT_MANUFACTURING_ADAPTER_REGISTRY,
) -> dict[str, Any]:
    """Generate deterministic certified controller files *offline*.

    This is the strongest output boundary in M13.  It requires a current M12
    simulation, a current M11 production-marking release and a current M13
    certificate.  ``machine_transfer.allowed`` is always false.
    """
    certificate = validate_persisted_adapter_certificate(project, certificate_id, require_current=True)
    if str(certificate.get("adapter_id") or "") != adapter_id:
        raise AdapterCertificationError("CWS-CERT-019", "Certificate hoort niet bij gevraagde adapter-ID")
    adapter = registry.get(adapter_id)
    descriptor = adapter.descriptor
    if descriptor.descriptor_hash != str(certificate.get("adapter_descriptor_hash") or ""):
        raise AdapterCertificationError("CWS-CERT-019", "Runtime adapterdescriptor wijkt af van gecertificeerde descriptor")
    try:
        runtime_binding = registry.certification_binding(adapter_id, verify_physical=True)
    except AdapterRehearsalError as exc:
        raise AdapterCertificationError(
            "CWS-CERT-019",
            f"Runtime adapter physical code/artifact binding ongeldig: {exc}",
            details=getattr(exc, "details", {}),
        ) from exc
    if not runtime_binding:
        raise AdapterCertificationError("CWS-CERT-019", "Runtime adapter mist M13 code/artifact certification binding")
    if (
        str(runtime_binding.get("descriptor_hash") or "") != str(certificate.get("adapter_descriptor_hash") or "")
        or str(runtime_binding.get("source_commit") or "") != str(certificate.get("adapter_source_commit") or "")
        or str(runtime_binding.get("artifact_sha256") or "") != str(certificate.get("adapter_artifact_sha256") or "")
    ):
        raise AdapterCertificationError("CWS-CERT-019", "Runtime adaptercode/artifact wijkt af van gecertificeerde source/artifact binding")
    simulation = validate_persisted_manufacturing_simulation(project, simulation_id, require_current=True)
    report = dict(simulation.get("report") or {})
    if not bool(report.get("feasible")):
        raise AdapterCertificationError("CWS-CERT-019", "Current M12 simulation is niet feasible")
    job = validate_neutral_sequence_job(neutral_sequence_job)
    if str(job.get("sequence_id") or "") != str(simulation.get("sequence_id") or ""):
        raise AdapterCertificationError("CWS-CERT-019", "Neutral job en M12 simulation sequence mismatch")
    if str(job.get("sequence_hash") or "") != str(report.get("source_sequence_hash") or ""):
        raise AdapterCertificationError("CWS-CERT-019", "Neutral job sequence_hash wijkt af van M12 simulation")
    if str(job.get("machine_id") or "") != descriptor.machine_id:
        raise AdapterCertificationError("CWS-CERT-019", "Neutral job machine-ID wijkt af van certificaat")
    capability_id = str(job.get("capability_id") or "")
    if capability_id != str(certificate.get("capability_id") or ""):
        raise AdapterCertificationError("CWS-CERT-019", "Neutral job capability wijkt af van certificaat")
    operations = [dict(x) for x in job.get("operations") or [] if isinstance(x, Mapping)]
    op_types = {str(x.get("operation_type") or "") for x in operations}
    if not op_types.issubset(set(certificate.get("certification_scope_operations") or [])):
        missing = sorted(op_types - set(certificate.get("certification_scope_operations") or []))
        raise AdapterCertificationError("CWS-CERT-020", f"Neutral job bevat operations buiten certificeringsscope: {missing}")
    part_ids = sorted({str(x.get("part_id") or "") for x in operations if str(x.get("part_id") or "")})
    release = controller_output_release_state(project, certificate_id=certificate_id, part_ids=part_ids, capability_id=capability_id)
    if not bool(release.get("machine_output_released")):
        raise AdapterCertificationError("CWS-CERT-021", "M11+M13 release-state blokkeert controller-output", details=release)
    first = _validate_rendered_files(adapter.render(dict(job)), descriptor)
    second = _validate_rendered_files(adapter.render(dict(job)), descriptor)
    if [(n, hashlib.sha256(b).hexdigest(), len(b)) for n, b in first] != [(n, hashlib.sha256(b).hexdigest(), len(b)) for n, b in second]:
        raise AdapterCertificationError("CWS-CERT-022", "Gecertificeerde adapteroutput is niet deterministisch")
    package_id = "cpkg-" + stable_sha256({
        "certificate_hash": certificate["certificate_hash"],
        "m11_release_hash": release["m11_release_record_hash"],
        "simulation_hash": report.get("simulation_hash"),
        "neutral_job_manifest_hash": job.get("manifest_hash"),
    })[:28]
    final_root = Path(output_dir) / f"{adapter_id}_{package_id}"
    with atomic_directory(final_root) as root:
        artifacts: list[dict[str, Any]] = []
        for rel, data in first:
            target = root.joinpath(*PurePosixPath(rel).parts)
            atomic_write(target, data)
            artifacts.append({"relative_path": rel, "sha256": sha256_file(target), "size_bytes": len(data)})
        manifest = {
            "format": M13_CERTIFIED_PACKAGE_FORMAT,
            "schema_version": M13_CERTIFIED_PACKAGE_SCHEMA_VERSION,
            "package_id": package_id,
            "certificate_id": certificate_id,
            "certificate_hash": certificate["certificate_hash"],
            "adapter": descriptor.to_dict(),
            "adapter_artifact_sha256": certificate["adapter_artifact_sha256"],
            "m11_release_id": release["m11_release_id"],
            "m11_release_record_hash": release["m11_release_record_hash"],
            "simulation_id": simulation_id,
            "simulation_hash": report.get("simulation_hash"),
            "sequence_id": job.get("sequence_id"),
            "sequence_hash": job.get("sequence_hash"),
            "neutral_job_manifest_hash": job.get("manifest_hash"),
            "machine_id": descriptor.machine_id,
            "controller_id": descriptor.controller_id,
            "production_marking_released": True,
            "machine_output_released": True,
            "offline_controller_output_released": True,
            "direct_machine_transfer": False,
            "machine_transfer": {"allowed": False, "reason": "M13 certifies offline file generation only. Transfer requires a separate external controlled system."},
            "artifacts": artifacts,
        }
        manifest["manifest_hash"] = stable_sha256({k: v for k, v in manifest.items() if k != "manifest_hash"})
        atomic_write(root / "manifest.json", canonical_json_bytes(manifest))
    return {"root": str(final_root), "manifest": manifest}


def verify_certified_sequence_package(root: str | Path) -> dict[str, Any]:
    base = Path(root)
    manifest_path = base / "manifest.json"
    if not manifest_path.is_file():
        raise AdapterCertificationError("CWS-CERT-023", "M13 certified package mist manifest.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("format") != M13_CERTIFIED_PACKAGE_FORMAT or str(manifest.get("schema_version") or "") != M13_CERTIFIED_PACKAGE_SCHEMA_VERSION:
        raise AdapterCertificationError("CWS-CERT-023", "M13 certified package format/schema ongeldig")
    if str(manifest.get("manifest_hash") or "") != stable_sha256({k: v for k, v in manifest.items() if k != "manifest_hash"}):
        raise AdapterCertificationError("CWS-CERT-023", "M13 certified package manifest_hash ongeldig")
    if not bool(manifest.get("machine_output_released")) or bool(manifest.get("direct_machine_transfer")) or bool(dict(manifest.get("machine_transfer") or {}).get("allowed")):
        raise AdapterCertificationError("CWS-CERT-023", "M13 certified package releaseflags ongeldig")
    index = _artifact_index(list(manifest.get("artifacts") or []), label="certified package")
    _verify_artifact_root(index, base, label="M13 certified package")
    return {"valid": True, "package_id": manifest.get("package_id"), "artifact_count": len(index), "manifest_hash": manifest.get("manifest_hash"), "direct_machine_transfer": False}


__all__ = [name for name in globals() if not name.startswith("_")]
