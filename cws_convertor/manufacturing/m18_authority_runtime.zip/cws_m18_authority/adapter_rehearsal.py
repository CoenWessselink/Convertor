"""Non-production adapter rehearsal harness for Scribing M12.

This module lets trusted, installed adapter code be exercised against the full
M7 neutral manufacturing sequence *before* it can ever become a production
postprocessor.  Rehearsal output is quarantined, checksum-bound and explicitly
non-production.  It is not a security sandbox for arbitrary/untrusted Python.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
from typing import Any, Mapping, Protocol

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from cws_convertor.production_export.utils import atomic_directory, atomic_write, canonical_json_bytes, sha256_file
from .manufacturing_sequence_contracts import MANUFACTURING_SEQUENCE_NEUTRAL_JOB_SCHEMA_VERSION, SequenceOperationType
from .simulation_service import validate_persisted_manufacturing_simulation

M12_ADAPTER_CONTRACT_VERSION = "1.0"
M12_ADAPTER_REHEARSAL_FORMAT = "CWS_M12_ADAPTER_REHEARSAL_V1"
M12_ADAPTER_REHEARSAL_STATE_SCHEMA_VERSION = "1.0"
M12_GOLDEN_CASE_FORMAT = "CWS_M12_GOLDEN_CASE_V1"
M12_GOLDEN_COMPARE_SCHEMA_VERSION = "1.0"
M12_SEQUENCE_JOB_FORMAT = "cws-neutral-manufacturing-sequence"


class AdapterRehearsalError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


@dataclass(frozen=True)
class ManufacturingAdapterDescriptor:
    adapter_id: str
    name: str
    machine_id: str
    controller_id: str
    adapter_version: str
    output_extensions: tuple[str, ...]
    supported_operation_types: tuple[str, ...] = tuple(x.value for x in SequenceOperationType)
    description: str = ""
    descriptor_hash: str = ""
    contract_version: str = M12_ADAPTER_CONTRACT_VERSION

    def __post_init__(self) -> None:
        if self.contract_version != M12_ADAPTER_CONTRACT_VERSION:
            raise ProjectValidationError("Onbekend toekomstig M12 adaptercontract")
        if not all((self.adapter_id, self.name, self.machine_id, self.controller_id, self.adapter_version)):
            raise ProjectValidationError("M12 adapterdescriptor mist identiteit")
        normalized_extensions: list[str] = []
        for raw in self.output_extensions:
            ext = str(raw or "").strip().lower()
            if ext and not ext.startswith("."):
                ext = "." + ext
            if not re.fullmatch(r"\.[a-z0-9][a-z0-9._-]{0,15}", ext):
                raise ProjectValidationError(f"Ongeldige M12 adapter-outputextensie: {raw!r}")
            if ext in normalized_extensions:
                raise ProjectValidationError(f"Dubbele M12 adapter-outputextensie: {ext}")
            normalized_extensions.append(ext)
        if not normalized_extensions:
            raise ProjectValidationError("M12 adapter moet minimaal één outputextensie declareren")
        object.__setattr__(self, "output_extensions", tuple(normalized_extensions))

        known = {x.value for x in SequenceOperationType}
        if not self.supported_operation_types:
            raise ProjectValidationError("M12 adapter moet minimaal één operation type declareren")
        if not set(self.supported_operation_types).issubset(known):
            raise ProjectValidationError("M12 adapter noemt onbekende operation types")
        expected = stable_sha256(self.hash_payload())
        if self.descriptor_hash and self.descriptor_hash != expected:
            raise ProjectValidationError("M12 adapter descriptor_hash ongeldig")
        object.__setattr__(self, "descriptor_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "contract_version": self.contract_version,
            "adapter_id": self.adapter_id,
            "name": self.name,
            "machine_id": self.machine_id,
            "controller_id": self.controller_id,
            "adapter_version": self.adapter_version,
            "output_extensions": list(self.output_extensions),
            "supported_operation_types": list(self.supported_operation_types),
            "description": self.description,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "descriptor_hash": self.descriptor_hash, "production_enabled": False}


class ManufacturingAdapter(Protocol):
    descriptor: ManufacturingAdapterDescriptor

    def render(self, neutral_sequence_job: dict[str, Any]) -> dict[str, bytes]:
        """Render deterministic files without network or machine I/O."""


class ManufacturingAdapterRegistry:
    def __init__(self) -> None:
        self._adapters: dict[str, ManufacturingAdapter] = {}
        # Optional runtime code identity. M12 rehearsal does not require it;
        # M13 certified output does. Keeping it outside the descriptor avoids
        # conflating functional capability metadata with a physical code build.
        self._certification_bindings: dict[str, dict[str, str]] = {}

    def register(
        self,
        adapter: ManufacturingAdapter,
        *,
        source_commit: str = "",
        artifact_sha256: str = "",
        artifact_path: str | Path = "",
    ) -> None:
        d = adapter.descriptor
        if d.adapter_id in self._adapters:
            raise AdapterRehearsalError("CWS-SIM-101", f"Dubbele M12 adapter-ID {d.adapter_id}")
        source_commit = str(source_commit or "").strip().lower()
        artifact_sha256 = str(artifact_sha256 or "").strip().lower()
        artifact_path_text = str(artifact_path or "").strip()
        has_any_binding = bool(source_commit or artifact_sha256 or artifact_path_text)
        if has_any_binding and not (source_commit and artifact_sha256 and artifact_path_text):
            raise AdapterRehearsalError(
                "CWS-SIM-101",
                "Adapter runtime-binding vereist source_commit, artifact_sha256 en een fysiek artifact_path",
            )
        if source_commit:
            if not re.fullmatch(r"[0-9a-f]{40}", source_commit):
                raise AdapterRehearsalError("CWS-SIM-101", "Adapter runtime source_commit moet een volledige 40-char Git SHA zijn")
            if not re.fullmatch(r"[0-9a-f]{64}", artifact_sha256):
                raise AdapterRehearsalError("CWS-SIM-101", "Adapter runtime artifact_sha256 is ongeldig")
            physical = Path(artifact_path_text).expanduser().resolve()
            if not physical.is_file():
                raise AdapterRehearsalError("CWS-SIM-101", f"Adapter runtime artifact bestaat niet: {physical}")
            actual_sha = sha256_file(physical)
            if actual_sha != artifact_sha256:
                raise AdapterRehearsalError(
                    "CWS-SIM-101",
                    "Adapter runtime artifact_sha256 komt niet overeen met het fysieke artefact",
                    details={"expected": artifact_sha256, "actual": actual_sha, "artifact_path": str(physical)},
                )
            self._certification_bindings[d.adapter_id] = {
                "adapter_id": d.adapter_id,
                "descriptor_hash": d.descriptor_hash,
                "source_commit": source_commit,
                "artifact_sha256": artifact_sha256,
                "artifact_path": str(physical),
            }
        self._adapters[d.adapter_id] = adapter

    def get(self, adapter_id: str) -> ManufacturingAdapter:
        try:
            return self._adapters[adapter_id]
        except KeyError as exc:
            raise AdapterRehearsalError("CWS-SIM-102", f"Onbekende M12 adapter {adapter_id!r}") from exc

    def certification_binding(self, adapter_id: str, *, verify_physical: bool = True) -> dict[str, str] | None:
        binding = self._certification_bindings.get(adapter_id)
        if not binding:
            return None
        result = dict(binding)
        if verify_physical:
            physical = Path(str(result.get("artifact_path") or ""))
            if not physical.is_file():
                raise AdapterRehearsalError("CWS-SIM-101", f"Gecertificeerd adapterartefact ontbreekt: {physical}")
            actual_sha = sha256_file(physical)
            if actual_sha != str(result.get("artifact_sha256") or ""):
                raise AdapterRehearsalError(
                    "CWS-SIM-101",
                    "Gecertificeerd adapterartefact wijzigde na registratie",
                    details={"expected": result.get("artifact_sha256"), "actual": actual_sha, "artifact_path": str(physical)},
                )
        return result

    def descriptors(self) -> list[ManufacturingAdapterDescriptor]:
        return [self._adapters[k].descriptor for k in sorted(self._adapters)]


DEFAULT_MANUFACTURING_ADAPTER_REGISTRY = ManufacturingAdapterRegistry()


def validate_neutral_sequence_job(value: dict[str, Any] | str | Path) -> dict[str, Any]:
    if isinstance(value, dict):
        payload = dict(value)
    else:
        payload = json.loads(Path(value).read_text(encoding="utf-8"))
    errors: list[str] = []
    if str(payload.get("format") or "") != M12_SEQUENCE_JOB_FORMAT:
        errors.append("onbekend neutral manufacturing sequence format")
    if str(payload.get("schema_version") or "") != MANUFACTURING_SEQUENCE_NEUTRAL_JOB_SCHEMA_VERSION:
        errors.append("onbekende neutral manufacturing sequence schema-versie")
    stored = str(payload.get("manifest_hash") or "")
    if stored != stable_sha256({k: v for k, v in payload.items() if k != "manifest_hash"}):
        errors.append("neutral manufacturing sequence manifest_hash mismatch")
    if bool(dict(payload.get("machine_transfer") or {}).get("allowed")):
        errors.append("neutral manufacturing sequence mag geen machine-transfer toestaan")
    if bool(payload.get("machine_output_released")):
        errors.append("neutral manufacturing sequence mag geen machine-output vrijgeven")
    operations = list(payload.get("operations") or [])
    if not operations:
        errors.append("neutral manufacturing sequence bevat geen operations")
    ids = [str(x.get("operation_id") or "") for x in operations if isinstance(x, dict)]
    if not all(ids) or len(ids) != len(set(ids)):
        errors.append("neutral manufacturing sequence bevat lege/dubbele operation IDs")
    order = [str(x) for x in payload.get("linearized_operation_ids") or []]
    if set(order) != set(ids) or len(order) != len(ids):
        errors.append("neutral manufacturing sequence linearization mismatch")
    if errors:
        raise AdapterRehearsalError("CWS-SIM-103", "; ".join(errors), details={"errors": errors})
    return payload


def _validate_files(files: Mapping[str, bytes], descriptor: ManufacturingAdapterDescriptor) -> list[tuple[str, bytes]]:
    if not files:
        raise AdapterRehearsalError("CWS-SIM-104", "M12 adapter leverde geen uitvoer")
    accepted = {x.lower() if str(x).startswith(".") else "." + str(x).lower() for x in descriptor.output_extensions}
    total = 0
    seen: set[str] = set()
    result: list[tuple[str, bytes]] = []
    for raw_name, raw_data in sorted(files.items()):
        name = str(raw_name).replace("\\", "/")
        pure = PurePosixPath(name)
        if not name or pure.is_absolute() or ".." in pure.parts or len(name) > 512:
            raise AdapterRehearsalError("CWS-SIM-105", f"Onveilig rehearsal-pad: {raw_name!r}")
        name = pure.as_posix()
        if name in seen:
            raise AdapterRehearsalError("CWS-SIM-105", f"Dubbel rehearsal-pad: {name}")
        seen.add(name)
        data = bytes(raw_data)
        if len(data) > 64 * 1024 * 1024:
            raise AdapterRehearsalError("CWS-SIM-106", f"Rehearsal-bestand te groot: {name}")
        total += len(data)
        if total > 256 * 1024 * 1024:
            raise AdapterRehearsalError("CWS-SIM-106", "Totale rehearsal-output overschrijdt 256 MiB")
        if accepted and pure.suffix.lower() not in accepted:
            raise AdapterRehearsalError("CWS-SIM-107", f"Niet-geregistreerde rehearsal-extensie: {name}")
        result.append((name, data))
    return result


def rehearse_manufacturing_adapter(
    project: ProjectModel,
    simulation_id: str,
    neutral_sequence_job: dict[str, Any] | str | Path,
    adapter_id: str,
    output_dir: str | Path,
    *,
    registry: ManufacturingAdapterRegistry = DEFAULT_MANUFACTURING_ADAPTER_REGISTRY,
    user: str = "system",
    persist: bool = True,
) -> dict[str, Any]:
    sim_state = validate_persisted_manufacturing_simulation(project, simulation_id, require_current=True)
    sim_report = dict(sim_state.get("report") or {})
    if not bool(sim_report.get("feasible")):
        raise AdapterRehearsalError("CWS-SIM-108", "Alleen een feasible current M12 simulation mag naar adapter rehearsal")
    job = validate_neutral_sequence_job(neutral_sequence_job)
    if str(job.get("sequence_id") or "") != str(sim_state.get("sequence_id") or ""):
        raise AdapterRehearsalError("CWS-SIM-109", "Neutral job sequence_id wijkt af van M12 simulation")
    if str(job.get("sequence_hash") or "") != str(sim_report.get("source_sequence_hash") or ""):
        raise AdapterRehearsalError("CWS-SIM-109", "Neutral job sequence_hash wijkt af van M12 simulation")

    adapter = registry.get(adapter_id)
    descriptor = adapter.descriptor
    if str(job.get("machine_id") or "") != descriptor.machine_id:
        raise AdapterRehearsalError("CWS-SIM-110", "Neutral sequence machine-ID past niet op rehearsal-adapter")
    operation_types = {str(x.get("operation_type") or "") for x in list(job.get("operations") or []) if isinstance(x, dict)}
    unsupported = sorted(operation_types - set(descriptor.supported_operation_types))
    if unsupported:
        raise AdapterRehearsalError("CWS-SIM-111", f"Adapter ondersteunt sequence operations niet: {unsupported}")

    first = _validate_files(adapter.render(dict(job)), descriptor)
    second = _validate_files(adapter.render(dict(job)), descriptor)
    first_hashes = [(name, hashlib.sha256(data).hexdigest(), len(data)) for name, data in first]
    second_hashes = [(name, hashlib.sha256(data).hexdigest(), len(data)) for name, data in second]
    if first_hashes != second_hashes:
        raise AdapterRehearsalError("CWS-SIM-112", "M12 adapter rehearsal is niet byte-deterministisch")

    rehearsal_id = "rhr-" + stable_sha256({
        "adapter": descriptor.descriptor_hash,
        "neutral_job_manifest_hash": job.get("manifest_hash"),
        "simulation_hash": sim_report.get("simulation_hash"),
    })[:28]
    package_name = f"{descriptor.adapter_id}_{rehearsal_id}"
    final_root = Path(output_dir) / package_name
    with atomic_directory(final_root) as root:
        artifacts: list[dict[str, Any]] = []
        for name, data in first:
            target = root.joinpath(*PurePosixPath(name).parts)
            atomic_write(target, data)
            artifacts.append({"relative_path": name, "sha256": sha256_file(target), "size_bytes": len(data)})
        manifest = {
            "format": M12_ADAPTER_REHEARSAL_FORMAT,
            "schema_version": M12_ADAPTER_CONTRACT_VERSION,
            "rehearsal_id": rehearsal_id,
            "adapter": descriptor.to_dict(),
            "simulation_id": simulation_id,
            "simulation_hash": sim_report.get("simulation_hash"),
            "sequence_id": job.get("sequence_id"),
            "sequence_hash": job.get("sequence_hash"),
            "neutral_job_manifest_hash": job.get("manifest_hash"),
            "machine_id": descriptor.machine_id,
            "controller_id": descriptor.controller_id,
            "operation_types": sorted(operation_types),
            "deterministic": True,
            "production_eligible": False,
            "machine_output_released": False,
            "machine_transfer": {"allowed": False, "reason": "M12 adapter rehearsal only; not owner/controller validated."},
            "artifacts": artifacts,
        }
        manifest["manifest_hash"] = stable_sha256({k: v for k, v in manifest.items() if k != "manifest_hash"})
        atomic_write(root / "manifest.json", canonical_json_bytes(manifest))

    if persist:
        state = {
            "schema_version": M12_ADAPTER_REHEARSAL_STATE_SCHEMA_VERSION,
            "phase": "M12",
            "rehearsal_id": rehearsal_id,
            "simulation_id": simulation_id,
            "sequence_id": str(job.get("sequence_id") or ""),
            "status": "current",
            "adapter_descriptor_hash": descriptor.descriptor_hash,
            "neutral_job_manifest_hash": str(job.get("manifest_hash") or ""),
            "manifest": manifest,
            # Persist only a non-semantic portable hint. Absolute filesystem paths
            # are intentionally excluded from Project Model evidence.
            "package_dir_name": final_root.name,
            "created_at": utc_now_iso(),
            "created_by": user,
            "production_eligible": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
        }
        state["state_hash"] = stable_sha256({k: v for k, v in state.items() if k != "state_hash"})
        project.manufacturing_adapter_rehearsals[rehearsal_id] = state
        project.audit("manufacturing.adapter_rehearsal_created", user=user, entity_id=rehearsal_id, after_hash=state["state_hash"], details={"adapter_id": descriptor.adapter_id, "simulation_id": simulation_id, "artifact_count": len(artifacts)})
    return {"root": str(final_root), "manifest": manifest}


def validate_persisted_adapter_rehearsal(
    project: ProjectModel,
    rehearsal_id: str,
    *,
    require_current: bool = False,
    require_files: bool = False,
    artifact_root: str | Path | None = None,
) -> dict[str, Any]:
    state = project.manufacturing_adapter_rehearsals.get(rehearsal_id)
    if not isinstance(state, dict):
        raise ProjectValidationError(f"Onbekende M12 adapter rehearsal {rehearsal_id}")
    if str(state.get("schema_version") or "") != M12_ADAPTER_REHEARSAL_STATE_SCHEMA_VERSION or str(state.get("phase") or "") != "M12":
        raise ProjectValidationError("M12 adapter rehearsal schema/phase mismatch")
    if any(bool(state.get(k)) for k in ("production_eligible", "machine_output_released", "direct_machine_transfer")):
        raise ProjectValidationError("M12 adapter rehearsal mag geen productie vrijgeven")
    if str(state.get("state_hash") or "") != stable_sha256({k: v for k, v in state.items() if k != "state_hash"}):
        raise ProjectValidationError("M12 adapter rehearsal state_hash ongeldig")
    manifest = dict(state.get("manifest") or {})
    if str(manifest.get("format") or "") != M12_ADAPTER_REHEARSAL_FORMAT:
        raise ProjectValidationError("M12 adapter rehearsal manifest format mismatch")
    if str(manifest.get("manifest_hash") or "") != stable_sha256({k: v for k, v in manifest.items() if k != "manifest_hash"}):
        raise ProjectValidationError("M12 adapter rehearsal manifest_hash ongeldig")
    if bool(dict(manifest.get("machine_transfer") or {}).get("allowed")) or bool(manifest.get("production_eligible")) or bool(manifest.get("machine_output_released")):
        raise ProjectValidationError("M12 rehearsal manifest bevat verboden releaseflag")
    sim = validate_persisted_manufacturing_simulation(project, str(state.get("simulation_id") or ""), require_current=require_current)
    if str(dict(sim.get("report") or {}).get("simulation_hash") or "") != str(manifest.get("simulation_hash") or ""):
        raise ProjectValidationError("M12 rehearsal simulation_hash is stale")
    if require_current and str(state.get("status") or "") != "current":
        raise ProjectValidationError("M12 adapter rehearsal is niet current")
    if require_files:
        if artifact_root is None:
            raise ProjectValidationError("M12 fysieke rehearsal-verificatie vereist expliciete artifact_root; absolute paden worden niet in het project opgeslagen")
        root = Path(artifact_root)
        if not root.is_dir():
            raise ProjectValidationError("M12 artifact_root bestaat niet of is geen map")
        for item in list(manifest.get("artifacts") or []):
            relative = str(item.get("relative_path") or "")
            pure = PurePosixPath(relative)
            if not relative or pure.is_absolute() or ".." in pure.parts:
                raise ProjectValidationError(f"M12 rehearsal-artifactpad ongeldig: {relative!r}")
            path = root.joinpath(*pure.parts)
            if not path.is_file() or sha256_file(path) != str(item.get("sha256") or ""):
                raise ProjectValidationError(f"M12 rehearsal-artifact ontbreekt/wijkt af: {item.get('relative_path')}")
    return state


def _valid_sha256(value: Any) -> bool:
    return bool(re.fullmatch(r"[0-9a-f]{64}", str(value or "").lower()))


def _validate_artifact_index(items: list[Any], *, label: str) -> None:
    seen: set[str] = set()
    for raw in items:
        if not isinstance(raw, Mapping):
            raise AdapterRehearsalError("CWS-SIM-120", f"{label} bevat ongeldig artifactrecord")
        path = str(raw.get("relative_path") or "").replace("\\", "/")
        pure = PurePosixPath(path)
        if not path or pure.is_absolute() or ".." in pure.parts or len(path) > 512:
            raise AdapterRehearsalError("CWS-SIM-120", f"{label} bevat onveilig artifactpad: {path!r}")
        normalized = pure.as_posix()
        if normalized in seen:
            raise AdapterRehearsalError("CWS-SIM-120", f"{label} bevat dubbel artifactpad: {normalized}")
        seen.add(normalized)
        if not _valid_sha256(raw.get("sha256")):
            raise AdapterRehearsalError("CWS-SIM-120", f"{label} bevat ongeldige SHA-256 voor {normalized}")
        try:
            size = int(raw.get("size_bytes"))
        except (TypeError, ValueError) as exc:
            raise AdapterRehearsalError("CWS-SIM-120", f"{label} bevat ongeldige bestandsgrootte voor {normalized}") from exc
        if size < 0:
            raise AdapterRehearsalError("CWS-SIM-120", f"{label} bevat negatieve bestandsgrootte voor {normalized}")


def _validate_rehearsal_manifest_for_compare(rehearsal: dict[str, Any]) -> None:
    if str(rehearsal.get("format") or "") != M12_ADAPTER_REHEARSAL_FORMAT:
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal manifest format ongeldig")
    if str(rehearsal.get("schema_version") or "") != M12_ADAPTER_CONTRACT_VERSION:
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal manifest schema ongeldig")
    if str(rehearsal.get("manifest_hash") or "") != stable_sha256({k: v for k, v in rehearsal.items() if k != "manifest_hash"}):
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal manifest_hash ongeldig")
    if bool(rehearsal.get("production_eligible")) or bool(rehearsal.get("machine_output_released")) or bool(dict(rehearsal.get("machine_transfer") or {}).get("allowed")):
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal manifest bevat verboden production-releaseflag")
    adapter = dict(rehearsal.get("adapter") or {})
    if bool(adapter.get("production_enabled")):
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal adapterdescriptor mag production_enabled niet zetten")
    if not _valid_sha256(adapter.get("descriptor_hash")):
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal adapter descriptor_hash ongeldig")
    descriptor_payload = {k: adapter.get(k) for k in ("contract_version", "adapter_id", "name", "machine_id", "controller_id", "adapter_version", "output_extensions", "supported_operation_types", "description")}
    if str(adapter.get("descriptor_hash") or "") != stable_sha256(descriptor_payload):
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal adapter descriptor_hash mismatch")
    if not _valid_sha256(rehearsal.get("neutral_job_manifest_hash")):
        raise AdapterRehearsalError("CWS-SIM-120", "Rehearsal neutral_job_manifest_hash ongeldig")
    _validate_artifact_index(list(rehearsal.get("artifacts") or []), label="Rehearsal manifest")


def _validate_golden_case_for_compare(golden: dict[str, Any]) -> None:
    if str(golden.get("format") or "") != M12_GOLDEN_CASE_FORMAT:
        raise AdapterRehearsalError("CWS-SIM-120", "Golden case format ongeldig")
    if str(golden.get("schema_version") or "") != M12_ADAPTER_CONTRACT_VERSION:
        raise AdapterRehearsalError("CWS-SIM-120", "Golden case schema ongeldig")
    if not str(golden.get("case_id") or "").strip():
        raise AdapterRehearsalError("CWS-SIM-120", "Golden case mist case_id")
    stored_hash = str(golden.get("golden_hash") or "")
    if not _valid_sha256(stored_hash) or stored_hash != stable_sha256({k: v for k, v in golden.items() if k != "golden_hash"}):
        raise AdapterRehearsalError("CWS-SIM-120", "Golden case golden_hash ongeldig")
    for key in ("adapter_id", "machine_id", "controller_id", "adapter_version"):
        if not str(golden.get(key) or "").strip():
            raise AdapterRehearsalError("CWS-SIM-120", f"Golden case mist {key}")
    if not _valid_sha256(golden.get("neutral_job_manifest_hash")):
        raise AdapterRehearsalError("CWS-SIM-120", "Golden case neutral_job_manifest_hash ongeldig")
    _validate_artifact_index(list(golden.get("expected_artifacts") or []), label="Golden case")


def compare_rehearsal_to_golden(rehearsal_manifest: Mapping[str, Any], golden_case: Mapping[str, Any]) -> dict[str, Any]:
    rehearsal = dict(rehearsal_manifest or {})
    golden = dict(golden_case or {})
    _validate_rehearsal_manifest_for_compare(rehearsal)
    _validate_golden_case_for_compare(golden)

    identity_fields = ("adapter_id", "machine_id", "controller_id", "adapter_version")
    adapter = dict(rehearsal.get("adapter") or {})
    identity_mismatches = []
    for key in identity_fields:
        actual = str(adapter.get(key) or "")
        expected = str(golden.get(key) or "")
        if actual != expected:
            identity_mismatches.append({"field": key, "expected": expected, "actual": actual})
    if str(golden.get("neutral_job_manifest_hash") or "") != str(rehearsal.get("neutral_job_manifest_hash") or ""):
        identity_mismatches.append({"field": "neutral_job_manifest_hash", "expected": golden.get("neutral_job_manifest_hash"), "actual": rehearsal.get("neutral_job_manifest_hash")})

    actual = {str(x.get("relative_path") or ""): (str(x.get("sha256") or ""), int(x.get("size_bytes") or 0)) for x in list(rehearsal.get("artifacts") or [])}
    expected = {str(x.get("relative_path") or ""): (str(x.get("sha256") or ""), int(x.get("size_bytes") or 0)) for x in list(golden.get("expected_artifacts") or [])}
    missing = sorted(set(expected) - set(actual))
    unexpected = sorted(set(actual) - set(expected))
    mismatches = []
    for path in sorted(set(actual) & set(expected)):
        if actual[path] != expected[path]:
            mismatches.append({"relative_path": path, "expected_sha256": expected[path][0], "actual_sha256": actual[path][0], "expected_size_bytes": expected[path][1], "actual_size_bytes": actual[path][1]})
    exact = not identity_mismatches and not missing and not unexpected and not mismatches
    report = {
        "schema_version": M12_GOLDEN_COMPARE_SCHEMA_VERSION,
        "case_id": str(golden.get("case_id") or ""),
        "rehearsal_id": str(rehearsal.get("rehearsal_id") or ""),
        "exact_match": exact,
        "owner_approved": bool(golden.get("owner_approved", False)),
        "identity_mismatches": identity_mismatches,
        "missing_artifacts": missing,
        "unexpected_artifacts": unexpected,
        "artifact_mismatches": mismatches,
        "production_eligible": False,
        "machine_transfer": {"allowed": False},
    }
    report["report_hash"] = stable_sha256({k: v for k, v in report.items() if k != "report_hash"})
    return report


def golden_case_from_rehearsal(rehearsal_manifest: Mapping[str, Any], *, case_id: str, notes: str = "") -> dict[str, Any]:
    """Create a review template, never an owner approval."""
    rehearsal = dict(rehearsal_manifest or {})
    adapter = dict(rehearsal.get("adapter") or {})
    golden = {
        "format": M12_GOLDEN_CASE_FORMAT,
        "schema_version": M12_ADAPTER_CONTRACT_VERSION,
        "case_id": case_id,
        "adapter_id": adapter.get("adapter_id", ""),
        "machine_id": adapter.get("machine_id", ""),
        "controller_id": adapter.get("controller_id", ""),
        "adapter_version": adapter.get("adapter_version", ""),
        "neutral_job_manifest_hash": rehearsal.get("neutral_job_manifest_hash", ""),
        "expected_artifacts": [dict(x) for x in list(rehearsal.get("artifacts") or [])],
        "owner_approved": False,
        "approved_by": "",
        "approved_at": "",
        "notes": notes,
    }
    golden["golden_hash"] = stable_sha256({k: v for k, v in golden.items() if k != "golden_hash"})
    return golden


__all__ = [name for name in globals() if not name.startswith("_")]
