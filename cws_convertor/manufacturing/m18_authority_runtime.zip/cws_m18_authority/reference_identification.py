"""Scribing M4 hole-reference and identification generation.

M4 adds canonical, machine-neutral hole references and text identification to
validated M3 scribing.  It never serializes DSTV SI or controller syntax.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import Part, ProjectModel, ProjectValidationError, stable_sha256
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .service import load_faces, validate_persisted_face_state
from .contact_service import load_assembly_contacts
from .marking_contracts import (
    ManufacturingMark, ManufacturingRuleSet, MarkGeometry2D, MarkGeometryKind,
    MarkReviewStatus, MarkType, RuleValidationStatus, mark_set_hash,
)
from .marking_engine import marking_source_snapshot, ruleset_applies
from .marking_geometry import (
    canonical_segment, clip_segment_to_polygon, distance, inset_convex_polygon,
    line_face_outer_polygon, point_in_polygon, target_hole_zones, target_weld_zones,
)

M4_ENGINE_VERSION = "cws-hole-reference-identification-engine-1.0"
M4_ENGINE_SCHEMA_VERSION = "1.0"
M4_SOURCE_SNAPSHOT_VERSION = "cws-mark-m4-source-snapshot-v1"
M4_GEOMETRY_SCHEMA_VERSION = "1.1"

SCRIBE_TYPES = {MarkType.SCRIBE_LINE.value, MarkType.CONTOUR_SCRIBE.value, MarkType.REFERENCE_LINE.value}
HOLE_TYPES = {MarkType.HOLE_CENTER_CROSS.value, MarkType.POP_MARK.value, MarkType.CENTER_PUNCH.value}
TEXT_TYPES = {MarkType.POSITION_TEXT.value, MarkType.ASSEMBLY_TEXT.value, MarkType.PART_TEXT.value, MarkType.HARD_STAMP_REQUEST.value}


@dataclass
class M4GenerationIssue:
    code: str
    message: str
    blocking: bool = False
    part_id: str = ""
    face_id: str = ""
    feature_id: str = ""
    rule_id: str = ""
    suggested_remediation: str = ""
    severity: str = ""
    provenance: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "severity": self.severity or ("error" if self.blocking else "warning"),
            "blocking": self.blocking,
            "part_id": self.part_id,
            "face_id": self.face_id,
            "feature_id": self.feature_id,
            "rule_id": self.rule_id,
            "suggested_remediation": self.suggested_remediation,
            "provenance": dict(self.provenance) or {"engine": M4_ENGINE_VERSION},
        }


@dataclass
class M4GenerationReport:
    assembly_id: str
    ruleset_id: str
    ruleset_hash: str
    marks: list[ManufacturingMark]
    issues: list[M4GenerationIssue]
    source_snapshot_hash: str
    hole_feature_count: int = 0
    hole_mark_count: int = 0
    identification_mark_count: int = 0
    proof_status: str = "blocked"
    engine_version: str = M4_ENGINE_VERSION
    mark_set_hash: str = ""

    def __post_init__(self) -> None:
        self.hole_mark_count = sum(1 for item in self.marks if item.mark_type in HOLE_TYPES)
        self.identification_mark_count = sum(1 for item in self.marks if item.mark_type in TEXT_TYPES)
        self.mark_set_hash = mark_set_hash(self.assembly_id, self.ruleset_hash, self.marks)
        blockers = any(item.blocking for item in self.issues)
        self.proof_status = "exact" if self.marks and not blockers else ("review" if self.marks else "blocked")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": M4_ENGINE_SCHEMA_VERSION,
            "engine_version": self.engine_version,
            "assembly_id": self.assembly_id,
            "ruleset_id": self.ruleset_id,
            "ruleset_hash": self.ruleset_hash,
            "source_snapshot_hash": self.source_snapshot_hash,
            "mark_set_hash": self.mark_set_hash,
            "hole_feature_count": self.hole_feature_count,
            "hole_mark_count": self.hole_mark_count,
            "identification_mark_count": self.identification_mark_count,
            "proof_status": self.proof_status,
            "issues": [item.to_dict() for item in self.issues],
            "marks": [item.to_dict() for item in self.marks],
        }


def _feature_id(part: Part, index: int, raw: Mapping[str, Any]) -> str:
    explicit = str(raw.get("id") or raw.get("feature_id") or "").strip()
    if explicit:
        return explicit
    return "hole-" + stable_sha256({"part_id": part.internal_id, "index": index, "feature": dict(raw)})[:20]


def canonical_hole_features(part: Part) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, raw in enumerate(part.production_features):
        if not isinstance(raw, Mapping) or str(raw.get("kind") or "") != "hole":
            continue
        try:
            u = float(raw.get("x"))
            v = float(raw.get("q"))
            diameter = float(raw.get("diameter") or 0.0)
        except (TypeError, ValueError):
            continue
        if not all(math.isfinite(value) for value in (u, v, diameter)) or diameter <= 0:
            continue
        feature_id = _feature_id(part, index, raw)
        rows.append({
            "feature_id": feature_id,
            "part_id": part.internal_id,
            "face_ref": str(raw.get("manufacturing_face_id") or raw.get("face") or "").strip(),
            "u_mm": u,
            "v_mm": v,
            "diameter_mm": diameter,
            "depth_mm": float(raw.get("depth") or 0.0),
            "operation": str(raw.get("operation") or ""),
            "pattern_id": str(raw.get("pattern_id") or raw.get("group_id") or ""),
            "feature_hash": stable_sha256({"feature_id": feature_id, "feature": dict(raw)}),
            "raw": dict(raw),
        })
    return rows


def _face_aliases(face: ManufacturingFace) -> set[str]:
    aliases = {face.face_id, face.semantic_role}
    aliases.update(str(item.dstv_side) for item in face.dstv_side_candidates if item.dstv_side)
    return {item for item in aliases if item}


def resolve_feature_face(part: Part, feature: Mapping[str, Any]) -> ManufacturingFace:
    validate_persisted_face_state(part, require_current=True)
    faces = [face for face in load_faces(part) if face.surface_type == ManufacturingSurfaceType.PLANE.value]
    ref = str(feature.get("face_ref") or "").strip()
    if ref:
        matches = [face for face in faces if ref in _face_aliases(face)]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise ProjectValidationError(f"CWS-MARK-002 ambiguous face role voor hole feature {feature.get('feature_id')}: {ref}")
        raise ProjectValidationError(f"CWS-MARK-001 missing manufacturing face voor hole feature {feature.get('feature_id')}: {ref}")
    if len(faces) == 1:
        return faces[0]
    raise ProjectValidationError(f"CWS-MARK-002 hole feature {feature.get('feature_id')} heeft geen eenduidige face")


def _contact_polygons(project: ProjectModel, assembly_id: str, part_id: str, face_id: str) -> list[list[tuple[float, float]]]:
    out: list[list[tuple[float, float]]] = []
    try:
        contacts = load_assembly_contacts(project, assembly_id)
    except Exception:
        return out
    for patch in contacts:
        if patch.main_part_id == part_id and patch.main_face_id == face_id:
            pts = patch.projected_boundary_on_main_face
        elif patch.secondary_part_id == part_id and patch.secondary_face_id == face_id:
            pts = patch.projected_boundary_on_secondary_face
        else:
            continue
        if len(pts) >= 3:
            out.append([(float(p[0]), float(p[1])) for p in pts])
    return out


def _segment_hits_polygon(a, b, polygon) -> bool:
    clipped = clip_segment_to_polygon(a, b, polygon)
    return any(distance(*segment) > 1e-7 for segment in clipped)


def _point_in_rect(point: tuple[float, float], rect: tuple[float, float, float, float]) -> bool:
    u0, v0, u1, v1 = rect
    return u0 <= point[0] <= u1 and v0 <= point[1] <= v1


def _rect_intersects_circle(rect, center, radius) -> bool:
    u0, v0, u1, v1 = rect
    cu = min(max(center[0], u0), u1)
    cv = min(max(center[1], v0), v1)
    return math.hypot(cu-center[0], cv-center[1]) < radius - 1e-8


def _rect_intersects_rect(a, b) -> bool:
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])


def _segment_intersects_rect(a, b, rect) -> bool:
    u0, v0, u1, v1 = rect
    if _point_in_rect(a, rect) or _point_in_rect(b, rect):
        return True
    poly = [(u0,v0),(u1,v0),(u1,v1),(u0,v1)]
    return _segment_hits_polygon(a, b, poly)


def _text_box(anchor, text: str, height: float, orientation_deg: float, h_align: str, v_align: str) -> tuple[float,float,float,float]:
    # Canonical text is semantic intent, not glyph geometry.  The conservative
    # envelope is used only for collision-free placement; stroke encoding is a
    # later adapter concern.
    width = max(height * 0.65 * max(len(text), 1), height * 0.65)
    raw_h = height
    angle = math.radians(orientation_deg % 180.0)
    box_w = abs(width * math.cos(angle)) + abs(raw_h * math.sin(angle))
    box_h = abs(width * math.sin(angle)) + abs(raw_h * math.cos(angle))
    u, v = anchor
    if h_align == "middle":
        u0 = u - box_w/2
    elif h_align == "right":
        u0 = u - box_w
    else:
        u0 = u
    if v_align == "middle":
        v0 = v - box_h/2
    elif v_align in {"top", "baseline"}:
        v0 = v - box_h if v_align == "top" else v
    else:
        v0 = v
    return (u0, v0, u0+box_w, v0+box_h)


def _rect_inside_polygon(rect, polygon) -> bool:
    u0,v0,u1,v1 = rect
    samples=[(u0,v0),(u1,v0),(u1,v1),(u0,v1),((u0+u1)/2,(v0+v1)/2)]
    return all(point_in_polygon(p, polygon, 1e-7) for p in samples)


def _candidate_anchors(polygon: list[tuple[float,float]], step: float, h_pref: str, v_pref: str) -> list[tuple[float,float]]:
    us=[p[0] for p in polygon];vs=[p[1] for p in polygon]
    u0,u1=min(us),max(us);v0,v1=min(vs),max(vs)
    h_order={"left":[u0,(u0+u1)/2,u1],"middle":[(u0+u1)/2,u0,u1],"right":[u1,(u0+u1)/2,u0]}.get(h_pref,[u0,(u0+u1)/2,u1])
    v_order={"bottom":[v0,(v0+v1)/2,v1],"middle":[(v0+v1)/2,v0,v1],"top":[v1,(v0+v1)/2,v0],"baseline":[v0,(v0+v1)/2,v1]}.get(v_pref,[v0,(v0+v1)/2,v1])
    anchors=[(u,v) for v in v_order for u in h_order]
    step=max(float(step),1.0)
    v=v0
    while v<=v1+1e-8:
        u=u0
        while u<=u1+1e-8:
            anchors.append((u,v));u+=step
        v+=step
    unique=[];seen=set()
    for p in anchors:
        key=(round(p[0],7),round(p[1],7))
        if key not in seen:
            seen.add(key);unique.append(p)
    return unique


def _safe_template(template: str, values: Mapping[str, str]) -> str:
    class SafeValues(dict):
        def __missing__(self, key):
            raise ProjectValidationError(f"Onbekend identification templateveld {{{key}}}")
    try:
        return str(template).format_map(SafeValues(values)).strip()
    except (ValueError, KeyError) as exc:
        raise ProjectValidationError(f"Ongeldig identification template {template!r}: {exc}") from exc


def _identification_values(project: ProjectModel, assembly: Any, part: Part, text_rules: Mapping[str, Any]) -> dict[str, str]:
    batch_property=str(text_rules.get("batch_property") or "production_batch")
    sequence_property=str(text_rules.get("sequence_property") or "production_sequence")
    batch=str(part.properties.get(batch_property) or "")
    sequence=str(part.properties.get(sequence_property) or part.properties.get("sequence") or "")
    company_code=str(text_rules.get("company_code") or project.settings.get("company_code") or "")
    assembly_mark=str(assembly.assembly_mark or "")
    part_position=str(part.part_position or "")
    return {
        "project": project.project_name,
        "assembly_mark": assembly_mark,
        "part_position": part_position,
        "assembly_part": f"{assembly_mark}-{part_position}" if assembly_mark and part_position else (assembly_mark or part_position),
        "part_id": part.internal_id,
        "profile": part.profile,
        "material": part.material,
        "company_code": company_code,
        "batch": batch,
        "sequence": sequence,
    }


def m4_source_snapshot(project: ProjectModel, assembly_id: str, ruleset: ManufacturingRuleSet) -> dict[str, Any]:
    assembly = project.assemblies.get(assembly_id)
    if assembly is None:
        raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
    base = marking_source_snapshot(project, assembly_id, ruleset)
    parts={}
    for part_id in sorted(set(assembly.part_ids)):
        part=project.parts.get(part_id)
        if part is None: continue
        face_state=validate_persisted_face_state(part, require_current=True)
        parts[part_id]={
            "part_position": part.part_position,
            "mirrored": bool(part.mirrored),
            "quantity_total": int(part.quantity_total),
            "face_set_hash": face_state.get("face_set_hash", ""),
            "hole_features": [{k:v for k,v in item.items() if k != "raw"} for item in canonical_hole_features(part)],
            "identification_properties_hash": stable_sha256({
                "identification_code": part.properties.get("identification_code", "") if isinstance(part.properties,dict) else "",
                "marking_hole_zones": part.properties.get("marking_hole_zones", []) if isinstance(part.properties,dict) else [],
                "marking_weld_zones": part.properties.get("marking_weld_zones", []) if isinstance(part.properties,dict) else [],
                "mirror_identification_confirmed": part.properties.get("mirror_identification_confirmed", False) if isinstance(part.properties,dict) else False,
            }),
            "identification_template_values_hash": stable_sha256(
                _identification_values(project, assembly, part, dict(ruleset.text_identification_rules or {}))
            ),
        }
    return {
        "version": M4_SOURCE_SNAPSHOT_VERSION,
        "base_m3_source": base,
        "assembly_mark": assembly.assembly_mark,
        "assembly_quantity": int(assembly.quantity),
        "ruleset_id": ruleset.ruleset_id,
        "ruleset_hash": ruleset.ruleset_hash,
        "parts": parts,
    }


def m4_source_snapshot_hash(project: ProjectModel, assembly_id: str, ruleset: ManufacturingRuleSet) -> str:
    return stable_sha256(m4_source_snapshot(project, assembly_id, ruleset))


class HoleReferenceIdentificationEngine:
    def generate(
        self,
        project: ProjectModel,
        assembly_id: str,
        ruleset: ManufacturingRuleSet,
        *,
        existing_marks: Iterable[ManufacturingMark] = (),
    ) -> M4GenerationReport:
        if ruleset.validation_status != RuleValidationStatus.VALIDATED.value:
            raise ProjectValidationError("CWS-MARK-013 ruleset not validated")
        assembly=project.assemblies.get(assembly_id)
        if assembly is None:
            raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
        marks: list[ManufacturingMark]=[]
        issues: list[M4GenerationIssue]=[]
        occupied_lines: dict[tuple[str,str], list[tuple[tuple[float,float],tuple[float,float]]]]={}
        occupied_boxes: dict[tuple[str,str], list[tuple[float,float,float,float]]]={}
        for mark in existing_marks:
            if mark.geometry_2d.kind == MarkGeometryKind.LINE.value and len(mark.geometry_2d.points)==2:
                occupied_lines.setdefault((mark.target_part_id,mark.target_face_id),[]).append(tuple(mark.geometry_2d.points))

        hole_rules=dict(ruleset.hole_reference_rules or {})
        text_rules=dict(ruleset.text_identification_rules or {})
        hole_enabled=bool(hole_rules.get("enabled", False))
        text_enabled=bool(text_rules.get("enabled", False))
        hole_feature_count=0

        if hole_enabled:
            for part_id in sorted(set(assembly.part_ids)):
                part=project.parts.get(part_id)
                if part is None or not ruleset_applies(part,ruleset):
                    continue
                features=canonical_hole_features(part);hole_feature_count+=len(features)
                for feature in features:
                    fid=str(feature["feature_id"])
                    try:
                        face=resolve_feature_face(part,feature)
                        polygon=inset_convex_polygon(line_face_outer_polygon(face), max(0.0,float(ruleset.min_edge_distance_mm)))
                        if not polygon:
                            raise ProjectValidationError("Target face heeft geen bruikbare inset boundary")
                    except ProjectValidationError as exc:
                        code="CWS-MARK-002" if "ambiguous" in str(exc).lower() or "eenduidige" in str(exc).lower() else "CWS-MARK-001"
                        issues.append(M4GenerationIssue(code,str(exc),True,part_id,feature_id=fid,rule_id=ruleset.ruleset_id,suggested_remediation="Bevestig de canonical ManufacturingFace van het gat."));continue
                    u=float(feature["u_mm"]);v=float(feature["v_mm"]);diam=float(feature["diameter_mm"])
                    if not point_in_polygon((u,v), line_face_outer_polygon(face), 1e-7):
                        issues.append(M4GenerationIssue("CWS-MARK-005",f"Hole center {fid} ligt buiten target face",True,part_id,face.face_id,fid,ruleset.ruleset_id));continue
                    mode=str(hole_rules.get("mode") or "crosshair").lower()
                    profile_specific=hole_rules.get("profile_specific") or {}
                    if isinstance(profile_specific,Mapping):
                        override=profile_specific.get(str(part.profile_type or "").upper())
                        if isinstance(override,Mapping): mode=str(override.get("mode") or mode).lower()
                    hole_marks=[]
                    if mode in {"pop_mark","center_punch"}:
                        mark_type=MarkType.POP_MARK.value if mode=="pop_mark" else MarkType.CENTER_PUNCH.value
                        geom=MarkGeometry2D(MarkGeometryKind.POINT.value,points=((u,v),),schema_version=M4_GEOMETRY_SCHEMA_VERSION)
                        hole_marks.append((mark_type,geom,mode))
                    elif mode == "crosshair":
                        arm=max(float(hole_rules.get("arm_length_mm") or 12.0),0.0)
                        gap=max(float(hole_rules.get("gap_from_hole_mm") or 2.0),0.0)
                        minimum=max(float(hole_rules.get("minimum_arm_length_mm") or 4.0),0.0)
                        r=diam/2.0+gap
                        raw_segments=[((u-r-arm,v),(u-r,v)),((u+r,v),(u+r+arm,v)),((u,v-r-arm),(u,v-r)),((u,v+r),(u,v+r+arm))]
                        contact_polys=_contact_polygons(project,assembly_id,part_id,face.face_id)
                        welds=target_weld_zones(part,face,ruleset.weld_margin_mm)
                        for a,b in raw_segments:
                            clipped=clip_segment_to_polygon(a,b,polygon)
                            for p,q in clipped:
                                if distance(p,q)+1e-8 < minimum: continue
                                if any(_segment_hits_polygon(p,q,cp) for cp in contact_polys):
                                    continue
                                blocked=False
                                for zone in welds:
                                    if zone.get("kind")=="circle":
                                        c=zone["center"];rad=float(zone["radius_mm"])
                                        # point-segment distance
                                        dx=q[0]-p[0];dy=q[1]-p[1];den=dx*dx+dy*dy
                                        t=0.0 if den<=1e-18 else max(0.0,min(1.0,((c[0]-p[0])*dx+(c[1]-p[1])*dy)/den))
                                        nearest=(p[0]+t*dx,p[1]+t*dy)
                                        if distance(nearest,c)<rad-1e-8: blocked=True
                                    elif zone.get("kind")=="rect" and _segment_intersects_rect(p,q,tuple(zone["rect"])):
                                        blocked=True
                                if blocked: continue
                                geom=MarkGeometry2D(MarkGeometryKind.LINE.value,points=canonical_segment(p,q),schema_version=M4_GEOMETRY_SCHEMA_VERSION)
                                hole_marks.append((MarkType.HOLE_CENTER_CROSS.value,geom,"hole_center_reference"))
                    elif mode in {"none","disabled"}:
                        issues.append(M4GenerationIssue("CWS-MARK-011",f"Hole reference uitgeschakeld voor {fid}",False,part_id,face.face_id,fid,ruleset.ruleset_id))
                    else:
                        issues.append(M4GenerationIssue("CWS-MARK-013",f"Onbekende hole reference mode {mode!r}",True,part_id,face.face_id,fid,ruleset.ruleset_id));continue
                    if not hole_marks and mode not in {"none","disabled"}:
                        issues.append(M4GenerationIssue("CWS-MARK-011",f"Geen geldige hole reference-plaatsing voor {fid}",False,part_id,face.face_id,fid,ruleset.ruleset_id,"Pas marges/ruleset aan of bevestig handmatig."))
                    for mark_type,geom,purpose in hole_marks:
                        identity={"assembly_id":assembly_id,"part_id":part_id,"feature_id":fid,"face_id":face.face_id,"ruleset_hash":ruleset.ruleset_hash,"mark_type":mark_type,"geometry_hash":geom.geometry_hash()}
                        mark=ManufacturingMark(
                            mark_id="mk-"+stable_sha256(identity)[:24],part_id=part_id,assembly_id=assembly_id,
                            source_part_id=part_id,target_part_id=part_id,target_face_id=face.face_id,mark_type=mark_type,
                            geometry_2d=geom,purpose=purpose,generated_by_rule_id=ruleset.ruleset_id,source_contact_id="",
                            requested_operation="pop_mark" if mark_type==MarkType.POP_MARK.value else ("center_punch" if mark_type==MarkType.CENTER_PUNCH.value else "scribe"),
                            source_feature_ids=(fid,),machine_constraints={"machine_binding":"not_in_m4","requires_planar_face":True},
                            review_status=MarkReviewStatus.ACCEPTED.value,
                            provenance={"engine":M4_ENGINE_VERSION,"source_feature_hash":feature["feature_hash"],"coordinate_frame":"target_manufacturing_face_uv","machine_output":False},
                            target_face_geometry_hash=face.geometry_hash,ruleset_hash=ruleset.ruleset_hash,
                        )
                        marks.append(mark)
                        if geom.kind==MarkGeometryKind.LINE.value:
                            occupied_lines.setdefault((part_id,face.face_id),[]).append(tuple(geom.points))

        if text_enabled:
            preferred=[str(x) for x in text_rules.get("preferred_face_roles") or []]
            height=max(float(text_rules.get("text_height_mm") or 8.0),0.1)
            margin=max(float(text_rules.get("edge_margin_mm") or 10.0),0.0)
            hole_margin=max(float(text_rules.get("hole_margin_mm") or 5.0),0.0)
            mark_margin=max(float(text_rules.get("other_mark_margin_mm") or 3.0),0.0)
            step=max(float(text_rules.get("search_step_mm") or 5.0),1.0)
            h_align=str(text_rules.get("anchor_horizontal") or "left")
            v_align=str(text_rules.get("anchor_vertical") or "bottom")
            orientation=float(text_rules.get("orientation_deg") or 0.0)%360.0
            requests=[]
            if bool(text_rules.get("emit_assembly_text_on_main",True)) and assembly.main_part_id and assembly.assembly_mark:
                requests.append((assembly.main_part_id,MarkType.ASSEMBLY_TEXT.value,str(text_rules.get("assembly_template") or "{assembly_mark}"),"assembly_identification"))
            if bool(text_rules.get("emit_part_text",True)):
                for part_id in sorted(set(assembly.part_ids)):
                    part=project.parts.get(part_id)
                    if part is not None and part.part_position:
                        requests.append((part_id,MarkType.PART_TEXT.value,str(text_rules.get("part_template") or "{part_position}"),"part_identification"))
            if bool(text_rules.get("emit_position_text",False)):
                for part_id in sorted(set(assembly.part_ids)):
                    part=project.parts.get(part_id)
                    if part is not None:
                        requests.append((part_id,MarkType.POSITION_TEXT.value,str(text_rules.get("position_template") or "{assembly_mark}-{part_position}"),"position_identification"))
            for part_id,mark_type,template,purpose in requests:
                part=project.parts.get(part_id)
                if part is None or not ruleset_applies(part,ruleset): continue
                if part.mirrored:
                    if ruleset.mirror_policy=="block":
                        issues.append(M4GenerationIssue("CWS-MARK-012",f"Identification op gespiegeld part {part_id} is door ruleset geblokkeerd",True,part_id,rule_id=ruleset.ruleset_id));continue
                    if ruleset.mirror_policy=="explicit_only" and not bool(part.properties.get("mirror_identification_confirmed",False)):
                        issues.append(M4GenerationIssue("CWS-MARK-012",f"Mirror-equivalence voor identification op {part_id} is niet bevestigd",True,part_id,rule_id=ruleset.ruleset_id));continue
                values=_identification_values(project,assembly,part,text_rules)
                try:text=_safe_template(template,values)
                except ProjectValidationError as exc:
                    issues.append(M4GenerationIssue("CWS-MARK-013",str(exc),True,part_id,rule_id=ruleset.ruleset_id));continue
                if not text: continue
                try:validate_persisted_face_state(part,require_current=True)
                except ProjectValidationError as exc:
                    issues.append(M4GenerationIssue("CWS-MARK-001",str(exc),True,part_id,rule_id=ruleset.ruleset_id));continue
                faces=[f for f in load_faces(part) if f.surface_type==ManufacturingSurfaceType.PLANE.value]
                role_index={role:i for i,role in enumerate(preferred)}
                faces.sort(key=lambda f:(role_index.get(f.semantic_role,999),f.semantic_role,f.face_id))
                placement=None
                for face in faces:
                    try:poly=inset_convex_polygon(line_face_outer_polygon(face),margin)
                    except ProjectValidationError:continue
                    if not poly:continue
                    holezones=target_hole_zones(part,face,hole_margin)
                    weldzones=target_weld_zones(part,face,ruleset.weld_margin_mm)
                    contact_polys=_contact_polygons(project,assembly_id,part_id,face.face_id)
                    for anchor in _candidate_anchors(poly,step,h_align,v_align):
                        rect=_text_box(anchor,text,height,orientation,h_align,v_align)
                        if not _rect_inside_polygon(rect,poly): continue
                        if any(_rect_intersects_circle(rect,z["center"],float(z["radius_mm"])) for z in holezones): continue
                        blocked=False
                        for zone in weldzones:
                            if zone.get("kind")=="circle" and _rect_intersects_circle(rect,zone["center"],float(zone["radius_mm"])): blocked=True
                            if zone.get("kind")=="rect" and _rect_intersects_rect(rect,tuple(zone["rect"])): blocked=True
                        if blocked: continue
                        if any(any(_point_in_rect(p,rect) for p in cp) or any(point_in_polygon(corner,cp,1e-7) for corner in [(rect[0],rect[1]),(rect[2],rect[1]),(rect[2],rect[3]),(rect[0],rect[3])]) for cp in contact_polys): continue
                        expanded=(rect[0]-mark_margin,rect[1]-mark_margin,rect[2]+mark_margin,rect[3]+mark_margin)
                        if any(_segment_intersects_rect(a,b,expanded) for a,b in occupied_lines.get((part_id,face.face_id),[])): continue
                        if any(_rect_intersects_rect(expanded,other) for other in occupied_boxes.get((part_id,face.face_id),[])): continue
                        placement=(face,anchor,rect);break
                    if placement:break
                if placement is None:
                    issues.append(M4GenerationIssue("CWS-MARK-011",f"Geen vrije identification-plaatsing gevonden voor {part_id} / {text!r}",True,part_id,rule_id=ruleset.ruleset_id,suggested_remediation="Verruim face/marges of kies handmatig een valide anchor."));continue
                face,anchor,rect=placement
                geom=MarkGeometry2D(MarkGeometryKind.TEXT_ANCHOR.value,points=(anchor,),orientation_deg=orientation,anchor_horizontal=h_align,anchor_vertical=v_align,schema_version=M4_GEOMETRY_SCHEMA_VERSION)
                identity={"assembly_id":assembly_id,"part_id":part_id,"face_id":face.face_id,"ruleset_hash":ruleset.ruleset_hash,"mark_type":mark_type,"text":text,"geometry_hash":geom.geometry_hash()}
                mark=ManufacturingMark(
                    mark_id="mk-"+stable_sha256(identity)[:24],part_id=part_id,assembly_id=assembly_id,source_part_id=part_id,target_part_id=part_id,
                    target_face_id=face.face_id,mark_type=mark_type,geometry_2d=geom,purpose=purpose,generated_by_rule_id=ruleset.ruleset_id,source_contact_id="",
                    text_payload=text,text_height_mm=height,requested_operation="text_mark",machine_constraints={"machine_binding":"not_in_m4","glyph_geometry":"late_bound"},
                    review_status=MarkReviewStatus.ACCEPTED.value,
                    provenance={"engine":M4_ENGINE_VERSION,"text_semantics":"geometry_independent","placement_envelope_mm":list(rect),"mirror_safe":True,"mirrored_part":bool(part.mirrored),"coordinate_frame":"target_manufacturing_face_uv","machine_output":False},
                    target_face_geometry_hash=face.geometry_hash,ruleset_hash=ruleset.ruleset_hash,
                )
                marks.append(mark);occupied_boxes.setdefault((part_id,face.face_id),[]).append(rect)

        # Deterministic dedup by semantic source + geometry/content.
        dedup={}
        for mark in marks:
            key=(mark.target_part_id,mark.target_face_id,mark.mark_type,mark.text_payload,tuple(mark.source_feature_ids),mark.geometry_2d.geometry_hash())
            dedup.setdefault(key,mark)
        rows=sorted(dedup.values(),key=lambda m:(m.target_part_id,m.target_face_id,m.mark_type,m.text_payload,m.geometry_2d.geometry_hash(),m.mark_id))
        return M4GenerationReport(
            assembly_id=assembly_id,ruleset_id=ruleset.ruleset_id,ruleset_hash=ruleset.ruleset_hash,
            marks=rows,issues=issues,source_snapshot_hash=m4_source_snapshot_hash(project,assembly_id,ruleset),hole_feature_count=hole_feature_count,
        )


__all__=[
    "M4_ENGINE_VERSION","M4_ENGINE_SCHEMA_VERSION","M4_SOURCE_SNAPSHOT_VERSION","M4_GEOMETRY_SCHEMA_VERSION",
    "SCRIBE_TYPES","HOLE_TYPES","TEXT_TYPES","M4GenerationIssue","M4GenerationReport","canonical_hole_features",
    "resolve_feature_face","m4_source_snapshot","m4_source_snapshot_hash","HoleReferenceIdentificationEngine",
]
