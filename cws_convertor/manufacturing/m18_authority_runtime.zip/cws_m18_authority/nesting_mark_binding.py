"""Scribing M6: bind canonical marks to validated profile-nesting placements.

The engine is format/controller neutral.  It consumes current M4/M5 evidence and
one independently valid profile-nesting plan.  No DSTV SI or machine program is
created here.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from cws_convertor.optimization.profile_nesting.angle_geometry import build_orientation_variants
from cws_convertor.optimization.profile_nesting.angle_validator import validate_angle_plan
from cws_convertor.optimization.profile_nesting.serialization import input_snapshot_from_dict, plan_from_dict
from cws_convertor.optimization.profile_nesting.units import LengthKernel
from .contracts import ManufacturingFace
from .marking_contracts import ManufacturingMark, MarkGeometry2D, MarkGeometryKind
from .marking_service import load_assembly_marks, validate_persisted_mark_state
from .service import load_faces, validate_persisted_face_state
from .machine_marking_contracts import MarkCapabilityProof, ManufacturingMachineCapability, ReorientationPolicy
from .machine_marking_service import evaluation_id, load_machine_marking_capability, load_marking_tool, validate_persisted_machine_marking_evaluation
from .nesting_mark_binding_contracts import (
    BoundMarkGeometry3D, NestingMarkBindingIssue, NestingMarkBindingProof,
    NESTING_MARK_TRANSFORM_CONVENTION,
)

M6_ENGINE_VERSION = "cws-nesting-aware-mark-binding-m6-v1"
M6_SOURCE_SNAPSHOT_VERSION = "cws-nesting-mark-binding-source-v1"


def _issue(code: str, message: str, *, mark: ManufacturingMark | None = None, piece_id: str = "", bar_id: str = "", transition_id: str = "", blocking: bool = True, remediation: str = "", details: Mapping[str, Any] | None = None) -> NestingMarkBindingIssue:
    return NestingMarkBindingIssue(
        code=code, message=message, blocking=blocking, severity="error" if blocking else "warning",
        mark_id=mark.mark_id if mark else "", piece_instance_id=piece_id, bar_id=bar_id,
        transition_id=transition_id, suggested_remediation=remediation,
        provenance={"engine": M6_ENGINE_VERSION, **dict(details or {})},
    )


def _mat3_vec(matrix: Iterable[Iterable[float]], vector: Iterable[float]) -> tuple[float,float,float]:
    m=[tuple(float(v) for v in row) for row in matrix];v=tuple(float(x) for x in vector)
    if len(m)!=3 or any(len(r)!=3 for r in m) or len(v)!=3: raise ProjectValidationError("M6 vereist een 3x3 orientation matrix")
    return tuple(sum(m[i][j]*v[j] for j in range(3)) for i in range(3))  # type: ignore[return-value]


def _mat4_point(matrix: Iterable[Iterable[float]], point: Iterable[float]) -> tuple[float,float,float]:
    m=[tuple(float(v) for v in row) for row in matrix];p=tuple(float(x) for x in point)
    if len(m)!=4 or any(len(r)!=4 for r in m) or len(p)!=3: raise ProjectValidationError("M6 vereist een 4x4 machine transform")
    q=(*p,1.0)
    return tuple(sum(m[i][j]*q[j] for j in range(4)) for i in range(3))  # type: ignore[return-value]


def _mat4_vec(matrix: Iterable[Iterable[float]], vector: Iterable[float]) -> tuple[float,float,float]:
    m=[tuple(float(v) for v in row) for row in matrix];v=tuple(float(x) for x in vector)
    return tuple(sum(m[i][j]*v[j] for j in range(3)) for i in range(3))  # type: ignore[return-value]


def _bar_machine_transform(feed_direction: str, stock_length_mm: float) -> tuple[tuple[float,float,float,float],...]:
    key=str(feed_direction or "left_to_right")
    if key=="left_to_right":
        return ((1.0,0.0,0.0,0.0),(0.0,1.0,0.0,0.0),(0.0,0.0,1.0,0.0),(0.0,0.0,0.0,1.0))
    if key=="right_to_left":
        # Proper 180° rotation about machine Z, translated to stock end.
        return ((-1.0,0.0,0.0,float(stock_length_mm)),(0.0,-1.0,0.0,0.0),(0.0,0.0,1.0,0.0),(0.0,0.0,0.0,1.0))
    raise ProjectValidationError("CWS-MARK-043 bidirectional feed mist een expliciet gekozen machine-feedrichting")


def _face(project: ProjectModel, mark: ManufacturingMark) -> ManufacturingFace:
    part=project.parts.get(mark.target_part_id)
    if part is None: raise ProjectValidationError(f"CWS-MARK-001 target part {mark.target_part_id} ontbreekt")
    validate_persisted_face_state(part,require_current=True)
    matches=[f for f in load_faces(part) if f.face_id==mark.target_face_id]
    if len(matches)!=1: raise ProjectValidationError(f"CWS-MARK-001 ManufacturingFace {mark.target_face_id} ontbreekt/ambigu")
    if matches[0].geometry_hash!=mark.target_face_geometry_hash: raise ProjectValidationError(f"CWS-MARK-014 ManufacturingFace van mark {mark.mark_id} is stale")
    return matches[0]


def _geometry_part(mark: ManufacturingMark, face: ManufacturingFace) -> BoundMarkGeometry3D:
    """Convert face-local mark geometry to exact part-local 3D."""
    frame=face.local_frame
    def convert(g: MarkGeometry2D) -> BoundMarkGeometry3D:
        pts=tuple(frame.part_xyz(p[0],p[1],0.0) for p in g.points)
        center=frame.part_xyz(g.center[0],g.center[1],0.0) if g.center is not None else None
        return BoundMarkGeometry3D(
            kind=g.kind, points_xyz=pts, center_xyz=center, radius_mm=g.radius_mm,
            u_axis_xyz=frame.u_axis if g.kind in {MarkGeometryKind.CIRCLE.value,MarkGeometryKind.ARC.value} else None,
            v_axis_xyz=frame.v_axis if g.kind in {MarkGeometryKind.CIRCLE.value,MarkGeometryKind.ARC.value} else None,
            start_angle_deg=g.start_angle_deg,end_angle_deg=g.end_angle_deg,closed=g.closed,
            components=tuple(convert(c) for c in g.components), semantic_text=mark.text_payload if g.kind==MarkGeometryKind.TEXT_ANCHOR.value else "",
        )
    return convert(mark.geometry_2d)


def _transform_geometry(geometry: BoundMarkGeometry3D, *, orientation: Iterable[Iterable[float]] | None = None, translation=(0.0,0.0,0.0), machine: Iterable[Iterable[float]] | None = None) -> BoundMarkGeometry3D:
    t=tuple(float(x) for x in translation)
    def point(p):
        q=_mat3_vec(orientation,p) if orientation is not None else tuple(p)
        q=(q[0]+t[0],q[1]+t[1],q[2]+t[2])
        return _mat4_point(machine,q) if machine is not None else q
    def vector(v):
        q=_mat3_vec(orientation,v) if orientation is not None else tuple(v)
        return _mat4_vec(machine,q) if machine is not None else q
    return BoundMarkGeometry3D(
        kind=geometry.kind,points_xyz=tuple(point(p) for p in geometry.points_xyz),
        center_xyz=point(geometry.center_xyz) if geometry.center_xyz is not None else None,
        radius_mm=geometry.radius_mm,u_axis_xyz=vector(geometry.u_axis_xyz) if geometry.u_axis_xyz is not None else None,
        v_axis_xyz=vector(geometry.v_axis_xyz) if geometry.v_axis_xyz is not None else None,
        start_angle_deg=geometry.start_angle_deg,end_angle_deg=geometry.end_angle_deg,closed=geometry.closed,
        components=tuple(_transform_geometry(c,orientation=orientation,translation=translation,machine=machine) for c in geometry.components),semantic_text=geometry.semantic_text,
    )


def _geometry_points_for_extent(g: BoundMarkGeometry3D) -> list[tuple[float,float,float]]:
    pts=list(g.points_xyz)
    if g.center_xyz is not None:
        pts.append(g.center_xyz)
        if g.radius_mm>0 and g.u_axis_xyz is not None and g.v_axis_xyz is not None:
            # Analytic extrema of a full circle; for an arc endpoints plus cardinal
            # candidates are sufficient and conservative for clamp/reach gating.
            angles=[0,90,180,270]
            if g.kind==MarkGeometryKind.ARC.value: angles += [g.start_angle_deg,g.end_angle_deg]
            for deg in angles:
                a=math.radians(deg);pts.append(tuple(g.center_xyz[i]+g.radius_mm*(math.cos(a)*g.u_axis_xyz[i]+math.sin(a)*g.v_axis_xyz[i]) for i in range(3)))
    for c in g.components: pts.extend(_geometry_points_for_extent(c))
    return pts


def _text_envelope_bar_points(mark: ManufacturingMark, face: ManufacturingFace, orientation, translation, machine=None) -> list[tuple[float,float,float]]:
    raw=mark.provenance.get("placement_envelope_mm") if isinstance(mark.provenance,Mapping) else None
    if not isinstance(raw,(list,tuple)) or len(raw)!=4:return []
    try:u0,v0,u1,v1=(float(x) for x in raw)
    except Exception:return []
    part=[face.local_frame.part_xyz(u,v,0.0) for u,v in ((u0,v0),(u1,v0),(u1,v1),(u0,v1))]
    out=[]
    for p in part:
        q=_mat3_vec(orientation,p);q=(q[0]+translation[0],q[1]+translation[1],q[2]+translation[2]);out.append(_mat4_point(machine,q) if machine is not None else q)
    return out


def _zones_from_profile(profile: Mapping[str,Any]) -> list[tuple[str,float,float]]:
    out=[]
    for i,z in enumerate(profile.get("forbidden_clamp_zones") or []):
        try:a=float(z.get("start_mm"));b=float(z.get("end_mm"))
        except Exception:continue
        out.append((str(z.get("zone_id") or f"clamp-{i+1}"),min(a,b),max(a,b)))
    return out


def _zones_from_capability(capability: ManufacturingMachineCapability) -> list[tuple[str,float,float]]:
    out=[]
    rows=capability.sequence_constraints.get("gripper_zones_mm") or capability.sequence_constraints.get("forbidden_bar_zones_mm") or []
    for i,z in enumerate(rows if isinstance(rows,(list,tuple)) else []):
        if not isinstance(z,Mapping):continue
        try:a=float(z.get("start_mm"));b=float(z.get("end_mm"))
        except Exception:continue
        out.append((str(z.get("zone_id") or f"gripper-{i+1}"),min(a,b),max(a,b)))
    return out


def _interval_hit(a: float,b: float,zones: Iterable[tuple[str,float,float]]) -> list[str]:
    lo,hi=min(a,b),max(a,b);return [zid for zid,z0,z1 in zones if not (hi < z0-1e-9 or lo > z1+1e-9)]


def _variant_hash_for_marks(marks: Iterable[ManufacturingMark]) -> str:
    rows=[]
    for m in sorted(marks,key=lambda x:x.mark_id):
        rows.append({
            "target_part_id":m.target_part_id,"target_face_id":m.target_face_id,"target_face_geometry_hash":m.target_face_geometry_hash,
            "mark_type":m.mark_type,"geometry_2d":m.geometry_2d.canonical_dict(),"text_payload":m.text_payload,
            "text_height_mm":m.text_height_mm,"depth_mm":m.depth_mm,"requested_operation":m.requested_operation,
            "machine_constraints":dict(m.machine_constraints),"ruleset_hash":m.ruleset_hash,
        })
    return stable_sha256({"contract":"BasePartManufacturingIdentity+AssemblyDerivedMarkingVariant-v1","marks":rows})


def _profile_from_snapshot(snapshot: Mapping[str,Any], profile_id: str) -> dict[str,Any]:
    profiles=list(dict(snapshot.get("machine_snapshot") or {}).get("profiles") or [])
    matches=[dict(p) for p in profiles if str(p.get("profile_id") or "")==profile_id]
    if len(matches)!=1:raise ProjectValidationError(f"CWS-MARK-033 nesting machine profile {profile_id!r} ontbreekt/ambigu in snapshot")
    return matches[0]


def _run_context(project: ProjectModel, run_id: str):
    rec=project.profile_nesting_runs.get(run_id)
    if not isinstance(rec,dict):raise ProjectValidationError(f"CWS-MARK-030 onbekende profile-nesting run {run_id}")
    if not isinstance(rec.get("plan"),dict):raise ProjectValidationError(f"CWS-MARK-030 nestingrun {run_id} heeft geen plan")
    snapshot=input_snapshot_from_dict(dict(rec["input_snapshot"]));plan=plan_from_dict(dict(rec["plan"]));validation=validate_angle_plan(snapshot,plan)
    if not validation.valid:raise ProjectValidationError(f"CWS-MARK-042 nestingrun {run_id} faalt onafhankelijke planvalidatie")
    if str(dict(rec.get("validation_report") or {}).get("report_hash") or "") and str(dict(rec.get("validation_report") or {}).get("plan_hash") or "")!=plan.plan_hash:
        raise ProjectValidationError(f"CWS-MARK-042 persisted nesting validation hoort niet bij huidig plan")
    lines={str(x.get("demand_line_id") or ""):dict(x) for x in rec["input_snapshot"].get("demand_lines") or []}
    instances={str(x.get("instance_id") or ""):dict(x) for x in rec["input_snapshot"].get("piece_instances") or []}
    placements={}
    bars={}
    for bar in plan.bars:
        bars[bar.bar_id]=bar
        for p in bar.placements:placements[p.instance_id]=(bar,p)
    return rec,snapshot,plan,validation,lines,instances,placements,bars


def m6_source_snapshot(project: ProjectModel, run_id: str, assembly_id: str, capability_id: str) -> dict[str,Any]:
    rec,_snapshot,plan,validation,_lines,_instances,_placements,_bars=_run_context(project,run_id)
    m5id=evaluation_id(assembly_id,capability_id);m5=validate_persisted_machine_marking_evaluation(project,m5id,require_current=True)
    cap=load_machine_marking_capability(project,capability_id,require_current=True)
    mark_state=validate_persisted_mark_state(project,assembly_id,require_current=True)
    marks=load_assembly_marks(project,assembly_id)
    return {
        "schema_version":M6_SOURCE_SNAPSHOT_VERSION,"project_id":project.project_id,"run_id":run_id,"assembly_id":assembly_id,"capability_id":capability_id,
        "plan_hash":plan.plan_hash,"nesting_input_snapshot_hash":str(dict(rec.get("input_snapshot") or {}).get("snapshot_hash") or ""),
        "nesting_validation_hash":validation.report_hash,"nesting_machine_snapshot_hash":str(dict(rec.get("input_snapshot") or {}).get("machine_snapshot_hash") or ""),
        "m5_evaluation_id":m5id,"m5_state_hash":str(m5.get("state_hash") or ""),"m5_source_snapshot_hash":str(m5.get("source_snapshot_hash") or ""),
        "capability_hash":cap.capability_hash,"mark_set_hash":str(mark_state.get("mark_set_hash") or ""),"assembly_marking_variant_hash":_variant_hash_for_marks(marks),
        "target_part_manufacturing_hashes":{m.target_part_id:str(project.parts[m.target_part_id].manufacturing_hash) for m in marks if m.target_part_id in project.parts},
    }


def m6_source_snapshot_hash(project: ProjectModel, run_id: str, assembly_id: str, capability_id: str) -> str:
    return stable_sha256(m6_source_snapshot(project,run_id,assembly_id,capability_id))


@dataclass
class NestingMarkBindingReport:
    run_id: str
    assembly_id: str
    capability_id: str
    machine_id: str
    plan_hash: str
    source_snapshot_hash: str
    assembly_marking_variant_hash: str
    feasible: bool
    review_required: bool
    bindings: list[NestingMarkBindingProof]
    issues: list[NestingMarkBindingIssue]
    production_artifact_identities: dict[str,str]
    report_hash: str = ""

    def to_dict(self)->dict[str,Any]:
        from .nesting_mark_binding_contracts import nesting_mark_binding_report_hash
        raw={"schema_version":"1.0","phase":"M6","run_id":self.run_id,"assembly_id":self.assembly_id,"capability_id":self.capability_id,"machine_id":self.machine_id,
             "plan_hash":self.plan_hash,"source_snapshot_hash":self.source_snapshot_hash,"assembly_marking_variant_hash":self.assembly_marking_variant_hash,
             "feasible":self.feasible,"review_required":self.review_required,"bindings":[b.to_dict() for b in self.bindings],"issues":[i.to_dict() for i in self.issues],
             "production_artifact_identities":dict(self.production_artifact_identities),"requires_m7_sequence":True,"dstv_si_released":False,"machine_output_released":False}
        raw["report_hash"]=self.report_hash or nesting_mark_binding_report_hash(raw);return raw


class NestingAwareMarkBindingEngine:
    def bind(self, project: ProjectModel, run_id: str, assembly_id: str, capability_id: str) -> NestingMarkBindingReport:
        rec,snapshot,plan,_validation,lines,instances,placements,_bars=_run_context(project,run_id)
        mark_state=validate_persisted_mark_state(project,assembly_id,require_current=True)
        marks=load_assembly_marks(project,assembly_id)
        m5id=evaluation_id(assembly_id,capability_id);m5=validate_persisted_machine_marking_evaluation(project,m5id,require_current=True)
        capability=load_machine_marking_capability(project,capability_id,require_current=True)
        m5_proofs={str(row.get("mark_id") or ""):MarkCapabilityProof.from_dict(row) for row in dict(m5.get("report") or {}).get("proofs") or []}
        asm=project.assemblies.get(assembly_id)
        if asm is None:raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
        assembly_mark=str(asm.assembly_mark or "")
        variant_hash=_variant_hash_for_marks(marks)
        bindings=[];global_issues=[];artifact_ids={}
        # Cache exact placement candidates per target part and assembly context.
        candidates_by_part={}
        for iid,(bar,p) in placements.items():
            inst=instances.get(iid,{})
            ctx={str(x) for x in inst.get("assembly_context") or []}
            if assembly_mark and ctx and assembly_mark not in ctx:continue
            candidates_by_part.setdefault(p.part_id,[]).append((bar,p,inst))
        for mark in marks:
            m5p=m5_proofs.get(mark.mark_id)
            if m5p is None:
                global_issues.append(_issue("CWS-MARK-039","Actuele M5 proof ontbreekt",mark=mark));continue
            piece_candidates=candidates_by_part.get(mark.target_part_id,[])
            if not piece_candidates:
                global_issues.append(_issue("CWS-MARK-031",f"Geen geneste PieceInstance voor target part {mark.target_part_id} binnen assemblycontext {assembly_mark!r}",mark=mark,remediation="Nest/re-optimaliseer deze production instance of corrigeer assemblycontext."));continue
            for bar,p,inst in piece_candidates:
                local=[];line=lines.get(p.demand_line_id)
                if line is None:
                    local.append(_issue("CWS-MARK-032","Demand line ontbreekt in nesting snapshot",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id));continue
                profile=_profile_from_snapshot(rec["input_snapshot"],p.machine_profile_id)
                if str(profile.get("machine_id") or "")!=capability.machine_id or p.machine_id!=capability.machine_id:
                    local.append(_issue("CWS-MARK-033",f"Nesting machine {p.machine_id} wijkt af van marking capability {capability.machine_id}",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id))
                variants=build_orientation_variants(line,profile,kernel=LengthKernel(),require_exact=True)
                selected=[v for v in variants if v.variant.variant_id==p.orientation_id]
                if len(selected)!=1 or selected[0].variant.variant_hash!=p.orientation_hash:
                    local.append(_issue("CWS-MARK-032","Nesting orientation kan niet exact uit snapshot worden gereconstrueerd",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id))
                    continue
                orientation=selected[0].variant;matrix=tuple(tuple(float(v) for v in row) for row in orientation.transform["matrix"])
                k=LengthKernel();ref_start=k.units_to_mm(int(p.reference_start_units));ref_end=k.units_to_mm(int(p.reference_end_units));tx=ref_end if orientation.end_for_end else ref_start;translation=(tx,0.0,0.0)
                try:machine_tf=_bar_machine_transform(str(profile.get("feed_direction") or "left_to_right"),k.units_to_mm(int(bar.stock_length_units)))
                except ProjectValidationError as exc:
                    local.append(_issue("CWS-MARK-043",str(exc),mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id));machine_tf=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1))
                face=_face(project,mark);part_geo=_geometry_part(mark,face);bar_geo=_transform_geometry(part_geo,orientation=matrix,translation=translation);machine_geo=_transform_geometry(part_geo,orientation=matrix,translation=translation,machine=machine_tf)
                clearance_points=_geometry_points_for_extent(bar_geo)+_text_envelope_bar_points(mark,face,matrix,translation)
                xs=[q[0] for q in clearance_points] or [tx]
                tool=load_marking_tool(project,m5p.selected_tool_id) if m5p.selected_tool_id else None;radius=float(tool.physical_clearance_radius_mm if tool else 0.0)
                x0,x1=min(xs)-radius,max(xs)+radius
                clamp_hits=_interval_hit(x0,x1,_zones_from_profile(profile));gripper_hits=_interval_hit(x0,x1,_zones_from_capability(capability))
                clamp_ok=not clamp_hits;gripper_ok=not gripper_hits;reclamp=False
                if not clamp_ok or not gripper_ok:
                    explicit_reclamp=bool(capability.reclamp_supported and capability.sequence_constraints.get("reclamp_clears_forbidden_zones",False))
                    if explicit_reclamp:reclamp=True
                    else:local.append(_issue("CWS-MARK-034",f"Marking head envelope raakt clamp/gripper zone(s): {', '.join(clamp_hits+gripper_hits)}",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id,remediation="Herpositioneer/reclamp met expliciet gevalideerde alternatieve klemstand."))
                # Re-evaluate the face normal after the selected nesting orientation.
                oriented_n=_mat3_vec(matrix,face.local_frame.normal);machine_n=_mat4_vec(machine_tf,oriented_n)
                vectors=tuple(capability.canonical_approach_vectors_by_face_role.get(face.semantic_role,()))
                direct=True if not vectors else any(sum(float(a)*float(b) for a,b in zip(machine_n,v))>=1-1e-6 for v in vectors)
                reorient=False;approach_ok=direct
                review=bool(m5p.review_required)
                if not direct:
                    if capability.reorientation_policy in {ReorientationPolicy.AUTOMATIC.value,ReorientationPolicy.MANUAL.value} and capability.reclamp_supported:
                        reorient=True;approach_ok=True;reclamp=True;review = review or capability.reorientation_policy==ReorientationPolicy.MANUAL.value
                    else:local.append(_issue("CWS-MARK-036","Gekozen nestingorientation maakt target face onbereikbaar voor de gevalideerde machine approach",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id))
                # Inspect adjacent common cuts and exact transformed mark X extent.
                common_ids=[];precedence=[];common_ok=True;guard=float(capability.sequence_constraints.get("common_cut_mark_guard_mm",max(radius,1.0)) or max(radius,1.0))
                by_id={t.transition_id:t for t in bar.transitions}
                for tid in (p.transition_before_id,p.transition_after_id):
                    tr=by_id.get(tid)
                    if tr is None or not tr.common_cut:continue
                    cut_x=ref_start if tid==p.transition_before_id else ref_end
                    if min(abs(x-cut_x) for x in xs) <= guard+1e-9:
                        common_ids.append(tid)
                        if bool(mark.machine_constraints.get("blocks_common_cut")) or bool(mark.provenance.get("requires_distinct_end_reference") if isinstance(mark.provenance,Mapping) else False):
                            common_ok=False;local.append(_issue("CWS-MARK-035","Mark vereist een afzonderlijke eindreferentie en blokkeert de geplande common cut",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id,transition_id=tid))
                        elif bool(capability.sequence_constraints.get("mark_before_common_cut_supported",False)):
                            precedence.append(f"mark:{mark.mark_id}:before_common_cut:{tid}")
                        else:
                            common_ok=False;local.append(_issue("CWS-MARK-035","Mark ligt bij een common cut maar mark-before-common-cut is niet expliciet ondersteund",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id,transition_id=tid))
                precedence.append(f"mark:{mark.mark_id}:before_sever:{p.instance_id}")
                if not m5p.feasible:local.append(_issue("CWS-MARK-033","M5 static capability proof voor deze mark is niet feasible",mark=mark,piece_id=p.instance_id,bar_id=bar.bar_id))
                transform_hash=stable_sha256({"convention":NESTING_MARK_TRANSFORM_CONVENTION,"orientation_id":p.orientation_id,"orientation_hash":p.orientation_hash,"orientation_transform":[list(r) for r in matrix],"bar_translation_mm":list(translation),"bar_to_machine_transform":[list(r) for r in machine_tf],"bar_id":bar.bar_id,"plan_hash":plan.plan_hash})
                artifact_identity=stable_sha256({"contract":"ProductionArtifactIdentity-v1","base_manufacturing_hash":p.manufacturing_hash,"assembly_marking_variant_hash":variant_hash})
                instance_identity=stable_sha256({"contract":"ProductionInstanceIdentity-v1","production_artifact_identity":artifact_identity,"piece_instance_id":p.instance_id})
                artifact_ids[p.instance_id]=artifact_identity
                blocking=any(i.blocking for i in local)
                binding=NestingMarkBindingProof(
                    binding_id="nmb-"+stable_sha256({"run":run_id,"assembly":assembly_id,"capability":capability_id,"mark":mark.mark_id,"piece":p.instance_id})[:28],
                    run_id=run_id,assembly_id=assembly_id,capability_id=capability_id,machine_id=capability.machine_id,mark_id=mark.mark_id,mark_hash=mark.mark_hash,
                    m5_evaluation_id=m5id,m5_proof_hash=m5p.proof_hash,part_id=p.part_id,part_position=p.part_position,base_manufacturing_hash=p.manufacturing_hash,
                    piece_instance_id=p.instance_id,production_artifact_identity=artifact_identity,production_instance_identity=instance_identity,assembly_marking_variant_hash=variant_hash,
                    bar_id=bar.bar_id,sequence_index=p.sequence_index,orientation_id=p.orientation_id,orientation_hash=p.orientation_hash,orientation_transform=matrix,
                    bar_translation_mm=translation,bar_to_machine_transform=machine_tf,transform_chain_hash=transform_hash,target_face_id=face.face_id,target_face_role=face.semantic_role,
                    selected_tool_id=m5p.selected_tool_id,selected_tool_hash=m5p.selected_tool_hash,bar_geometry=bar_geo,machine_geometry=machine_geo,
                    feasible=not blocking,review_required=review or reorient or reclamp,transformed_face_reachable=approach_ok,clamp_clearance_ok=clamp_ok or reclamp,
                    gripper_clearance_ok=gripper_ok or reclamp,common_cut_ok=common_ok,must_execute_before_severing=True,reorientation_required=reorient,reclamp_required=reclamp,
                    common_cut_transition_ids=tuple(sorted(common_ids)),precedence_requirements=tuple(sorted(set(precedence))),issues=tuple(local),
                    evidence={"engine":M6_ENGINE_VERSION,"scope":"validated_nesting_plan","plan_hash":plan.plan_hash,"mark_x_extent_bar_mm":[min(xs),max(xs)],"head_clearance_radius_mm":radius,"clamp_hits":clamp_hits,"gripper_hits":gripper_hits,"oriented_face_normal_machine":list(machine_n)},
                )
                bindings.append(binding)
        issues=sorted({(i.code,i.mark_id,i.piece_instance_id,i.transition_id,i.message):i for i in global_issues+[x for b in bindings for x in b.issues]}.values(),key=lambda i:(i.code,i.mark_id,i.piece_instance_id,i.message))
        feasible=bool(bindings) and not global_issues and all(b.feasible for b in bindings)
        review=any(b.review_required for b in bindings) or any(not i.blocking for i in issues)
        source_hash=m6_source_snapshot_hash(project,run_id,assembly_id,capability_id)
        report=NestingMarkBindingReport(run_id,assembly_id,capability_id,capability.machine_id,plan.plan_hash,source_hash,variant_hash,feasible,review,bindings,issues,artifact_ids)
        raw=report.to_dict();report.report_hash=str(raw["report_hash"]);return report


__all__=[name for name in globals() if not name.startswith("_")]
