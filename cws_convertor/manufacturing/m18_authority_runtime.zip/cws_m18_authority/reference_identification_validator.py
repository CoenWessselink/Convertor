"""Independent M4 validator for hole references and identification marks.

The decisive M4 placement checks are intentionally reimplemented rather than
calling the M4 generator.  Text anchors may be user-edited as long as the
canonical semantics, face containment and exclusion rules remain valid.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .service import load_faces, validate_persisted_face_state
from .contact_service import load_assembly_contacts
from .marking_contracts import ManufacturingMark, ManufacturingRuleSet, MarkGeometryKind, MarkType
from .reference_identification import HOLE_TYPES, TEXT_TYPES, canonical_hole_features, m4_source_snapshot_hash

M4_VALIDATOR_VERSION = "cws-hole-reference-identification-validator-1.0"
M4_VALIDATION_SCHEMA_VERSION = "1.0"


def _distance(a,b): return math.hypot(b[0]-a[0],b[1]-a[1])
def _point_segment_distance(p,a,b):
    dx=b[0]-a[0];dy=b[1]-a[1];den=dx*dx+dy*dy
    if den<=1e-18:return _distance(p,a)
    t=max(0.0,min(1.0,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den))
    q=(a[0]+t*dx,a[1]+t*dy);return _distance(p,q)
def _point_on_segment(p,a,b,tol=1e-7):
    return abs((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]))<=tol*max(1.0,_distance(a,b)) and (p[0]-a[0])*(p[0]-b[0])+(p[1]-a[1])*(p[1]-b[1])<=tol*tol
def _point_in_polygon(p,poly,tol=1e-7):
    for i,a in enumerate(poly):
        if _point_on_segment(p,a,poly[(i+1)%len(poly)],tol):return True
    x,y=p;inside=False;j=len(poly)-1
    for i in range(len(poly)):
        xi,yi=poly[i];xj,yj=poly[j]
        if (yi>y)!=(yj>y):
            xint=(xj-xi)*(y-yi)/(yj-yi)+xi
            if x<xint:inside=not inside
        j=i
    return inside

def _outer_polygon(face:ManufacturingFace):
    loops=[loop for loop in face.boundary_loops_2d if not loop.is_hole]
    if len(loops)!=1 or any(seg.kind!="line" or seg.start is None for seg in loops[0].segments):return None
    return [(float(seg.start[0]),float(seg.start[1])) for seg in loops[0].segments]
def _edge_distance(p,poly): return min(_point_segment_distance(p,poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly)))
def _face_aliases(face): return {face.face_id,face.semantic_role,*[str(x.dstv_side) for x in face.dstv_side_candidates if x.dstv_side]}
def _feature_face(part,feature):
    faces=[f for f in load_faces(part) if f.surface_type==ManufacturingSurfaceType.PLANE.value]
    ref=str(feature.get("face_ref") or "")
    matches=[f for f in faces if (not ref or ref in _face_aliases(f))]
    if ref and len(matches)!=1:return None
    if not ref and len(matches)!=1:return None
    return matches[0] if matches else None

def _text_box(anchor,text,height,orientation,h_align,v_align):
    width=max(height*0.65*max(len(text),1),height*0.65);raw_h=height;angle=math.radians(orientation%180.0)
    bw=abs(width*math.cos(angle))+abs(raw_h*math.sin(angle));bh=abs(width*math.sin(angle))+abs(raw_h*math.cos(angle));u,v=anchor
    u0=u-bw/2 if h_align=="middle" else (u-bw if h_align=="right" else u)
    v0=v-bh/2 if v_align=="middle" else (v-bh if v_align=="top" else v)
    return (u0,v0,u0+bw,v0+bh)
def _rect_corners(rect):u0,v0,u1,v1=rect;return [(u0,v0),(u1,v0),(u1,v1),(u0,v1),((u0+u1)/2,(v0+v1)/2)]
def _rect_intersects_circle(rect,center,radius):
    u0,v0,u1,v1=rect;u=min(max(center[0],u0),u1);v=min(max(center[1],v0),v1);return math.hypot(u-center[0],v-center[1])<radius-1e-8
def _rect_intersects_rect(a,b):return not (a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1])
def _segment_intersects_rect(a,b,rect):
    # conservative sampled + edge-distance check, independent from generator clipping
    if any(rect[0]<=p[0]<=rect[2] and rect[1]<=p[1]<=rect[3] for p in (a,b)):return True
    for i in range(21):
        t=i/20;p=(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)
        if rect[0]<=p[0]<=rect[2] and rect[1]<=p[1]<=rect[3]:return True
    return False

def _hole_zones(part,face,margin):
    out=[];aliases=_face_aliases(face)
    for feature in canonical_hole_features(part):
        if feature.get("face_ref") and feature["face_ref"] not in aliases:continue
        out.append(((float(feature["u_mm"]),float(feature["v_mm"])),float(feature["diameter_mm"])/2+margin,str(feature["feature_id"])))
    return out

def _weld_zones(part,face,margin):
    rows=part.properties.get("marking_weld_zones",[]) if isinstance(part.properties,dict) else [];out=[];aliases=_face_aliases(face)
    for i,raw in enumerate(rows if isinstance(rows,list) else []):
        if not isinstance(raw,Mapping):continue
        ref=str(raw.get("face_id") or raw.get("semantic_role") or "")
        if ref and ref not in aliases:continue
        try:
            if str(raw.get("kind") or "circle")=="circle":out.append(("circle",(float(raw.get("u_mm")),float(raw.get("v_mm"))),float(raw.get("radius_mm") or 0)+margin,str(raw.get("id") or i)))
            else:out.append(("rect",(float(raw.get("u0_mm"))-margin,float(raw.get("v0_mm"))-margin,float(raw.get("u1_mm"))+margin,float(raw.get("v1_mm"))+margin),0.0,str(raw.get("id") or i)))
        except Exception:continue
    return out

def _contact_polygons(project,assembly_id,part_id,face_id):
    out=[]
    try:contacts=load_assembly_contacts(project,assembly_id)
    except Exception:return out
    for patch in contacts:
        pts=None
        if patch.main_part_id==part_id and patch.main_face_id==face_id:pts=patch.projected_boundary_on_main_face
        elif patch.secondary_part_id==part_id and patch.secondary_face_id==face_id:pts=patch.projected_boundary_on_secondary_face
        if pts and len(pts)>=3:out.append([(float(p[0]),float(p[1])) for p in pts])
    return out

def _safe_template(template,values):
    out=str(template)
    allowed=set(values)
    # Reject any braces that request a non-whitelisted token.
    import string
    for _,field,_,_ in string.Formatter().parse(out):
        if field and field not in allowed:raise ProjectValidationError(f"Onbekend identification templateveld {{{field}}}")
    return out.format_map(values).strip()

def _identification_values(project, assembly, part, text_rules):
    batch_property=str(text_rules.get("batch_property") or "production_batch")
    sequence_property=str(text_rules.get("sequence_property") or "production_sequence")
    batch=str(part.properties.get(batch_property) or "")
    sequence=str(part.properties.get(sequence_property) or part.properties.get("sequence") or "")
    company_code=str(text_rules.get("company_code") or project.settings.get("company_code") or "")
    assembly_mark=str(assembly.assembly_mark or "")
    part_position=str(part.part_position or "")
    return {
        "project":project.project_name,
        "assembly_mark":assembly_mark,
        "part_position":part_position,
        "assembly_part":f"{assembly_mark}-{part_position}" if assembly_mark and part_position else (assembly_mark or part_position),
        "part_id":part.internal_id,
        "profile":part.profile,
        "material":part.material,
        "company_code":company_code,
        "batch":batch,
        "sequence":sequence,
    }



@dataclass
class M4ValidationIssue:
    code:str
    message:str
    blocking:bool=True
    mark_id:str=""
    part_id:str=""
    face_id:str=""
    feature_id:str=""
    remediation:str=""
    severity:str=""
    provenance:Mapping[str,Any]=field(default_factory=dict)
    def to_dict(self):
        return {
            "code": self.code,
            "message": self.message,
            "severity": self.severity or ("error" if self.blocking else "warning"),
            "blocking": self.blocking,
            "mark_id": self.mark_id,
            "part_id": self.part_id,
            "face_id": self.face_id,
            "feature_id": self.feature_id,
            "remediation": self.remediation,
            "provenance": dict(self.provenance) or {"validator": M4_VALIDATOR_VERSION},
        }

@dataclass
class M4ValidationReport:
    assembly_id:str
    status:str
    ruleset_hash:str
    source_snapshot_hash:str
    mark_count:int
    issues:list[M4ValidationIssue]=field(default_factory=list)
    validator_version:str=M4_VALIDATOR_VERSION
    report_hash:str=""
    def __post_init__(self):
        expected=stable_sha256(self.to_dict(include_hash=False))
        if self.report_hash and self.report_hash!=expected:raise ProjectValidationError("M4 validation report_hash ongeldig")
        self.report_hash=expected
    def to_dict(self,*,include_hash=True):
        data={"schema_version":M4_VALIDATION_SCHEMA_VERSION,"assembly_id":self.assembly_id,"status":self.status,"ruleset_hash":self.ruleset_hash,"source_snapshot_hash":self.source_snapshot_hash,"mark_count":self.mark_count,"validator_version":self.validator_version,"issues":[x.to_dict() for x in self.issues]}
        if include_hash:data["report_hash"]=self.report_hash
        return data


class IndependentM4MarkValidator:
    def validate(self,project:ProjectModel,assembly_id:str,ruleset:ManufacturingRuleSet,marks:Iterable[ManufacturingMark],*,existing_scribe_marks:Iterable[ManufacturingMark]=())->M4ValidationReport:
        rows=list(marks);scribe=list(existing_scribe_marks);issues=[]
        assembly=project.assemblies.get(assembly_id)
        if assembly is None:return M4ValidationReport(assembly_id,"failed",ruleset.ruleset_hash,"",len(rows),[M4ValidationIssue("CWS-MARK-014","Assembly ontbreekt")])
        try:source_hash=m4_source_snapshot_hash(project,assembly_id,ruleset)
        except Exception as exc:return M4ValidationReport(assembly_id,"failed",ruleset.ruleset_hash,"",len(rows),[M4ValidationIssue("CWS-MARK-014",str(exc))])
        face_maps={}
        for part_id in assembly.part_ids:
            part=project.parts.get(part_id)
            if part is None:continue
            try:validate_persisted_face_state(part,require_current=True);face_maps[part_id]={f.face_id:f for f in load_faces(part)}
            except Exception as exc:issues.append(M4ValidationIssue("CWS-MARK-001",str(exc),part_id=part_id))
        feature_maps={part_id:{f["feature_id"]:f for f in canonical_hole_features(part)} for part_id,part in project.parts.items() if part_id in assembly.part_ids}
        actual_hole_counts={}
        actual_text={}
        all_lines={}
        for mark in [*scribe,*rows]:
            if mark.geometry_2d.kind==MarkGeometryKind.LINE.value and len(mark.geometry_2d.points)==2:all_lines.setdefault((mark.target_part_id,mark.target_face_id),[]).append(tuple(mark.geometry_2d.points))
        for mark in rows:
            def add(code,msg,blocking=True,feature_id="",rem=""):issues.append(M4ValidationIssue(code,msg,blocking,mark.mark_id,mark.target_part_id,mark.target_face_id,feature_id,rem))
            part=project.parts.get(mark.target_part_id);face=face_maps.get(mark.target_part_id,{}).get(mark.target_face_id)
            if part is None or face is None:add("CWS-MARK-001","Target part/face ontbreekt");continue
            if face.surface_type!=ManufacturingSurfaceType.PLANE.value:add("CWS-MARK-003","M4 target face is niet vlak")
            if face.geometry_hash!=mark.target_face_geometry_hash:add("CWS-MARK-014","Target face hash is stale")
            if mark.ruleset_hash!=ruleset.ruleset_hash:add("CWS-MARK-013","Ruleset hash mismatch")
            if mark.review_status!="accepted":add("CWS-MARK-020","M4 mark is niet accepted")
            poly=_outer_polygon(face)
            if not poly:add("CWS-MARK-003","Face boundary niet onafhankelijk valideerbaar");continue
            if mark.mark_type in HOLE_TYPES:
                if len(mark.source_feature_ids)!=1:add("CWS-MARK-020","Hole reference vereist exact één source feature");continue
                fid=mark.source_feature_ids[0];feature=feature_maps.get(part.internal_id,{}).get(fid)
                if not feature:add("CWS-MARK-014","Source hole feature ontbreekt/stale",feature_id=fid);continue
                expected_face=_feature_face(part,feature)
                if expected_face is None or expected_face.face_id!=face.face_id:add("CWS-MARK-002","Hole reference target face wijkt af",feature_id=fid)
                expected_hash=str(mark.provenance.get("source_feature_hash") or "")
                if expected_hash and expected_hash!=feature["feature_hash"]:add("CWS-MARK-014","Source hole feature hash is stale",feature_id=fid)
                u=float(feature["u_mm"]);v=float(feature["v_mm"]);r=float(feature["diameter_mm"])/2
                mode=str((ruleset.hole_reference_rules or {}).get("mode") or "crosshair").lower()
                actual_hole_counts[fid]=actual_hole_counts.get(fid,0)+1
                if mode=="crosshair":
                    if mark.mark_type!=MarkType.HOLE_CENTER_CROSS.value or mark.geometry_2d.kind!=MarkGeometryKind.LINE.value:add("CWS-MARK-020","Crosshair policy vereist line hole_center_cross",feature_id=fid);continue
                    a,b=mark.geometry_2d.points
                    # Horizontal/vertical, outside the physical hole, inside face.
                    if abs(a[0]-b[0])>1e-7 and abs(a[1]-b[1])>1e-7:add("CWS-MARK-020","Hole crosshair arm is niet orthogonaal",feature_id=fid)
                    if _point_segment_distance((u,v),a,b)<r-1e-7:add("CWS-MARK-006","Hole reference snijdt het gat",feature_id=fid)
                    if not all(_point_in_polygon(p,poly) for p in (a,b)):add("CWS-MARK-005","Hole reference ligt buiten face",feature_id=fid)
                    if min(_edge_distance(p,poly) for p in (a,b))+1e-6<ruleset.min_edge_distance_mm:add("CWS-MARK-005","Hole reference schendt edge clearance",feature_id=fid)
                elif mode in {"pop_mark","center_punch"}:
                    expected_type=MarkType.POP_MARK.value if mode=="pop_mark" else MarkType.CENTER_PUNCH.value
                    if mark.mark_type!=expected_type or mark.geometry_2d.kind!=MarkGeometryKind.POINT.value:add("CWS-MARK-020",f"{mode} policy vereist point {expected_type}",feature_id=fid)
                    elif _distance(mark.geometry_2d.points[0],(u,v))>1e-7:add("CWS-MARK-020",f"{mode} ligt niet op hole center",feature_id=fid)
            elif mark.mark_type in TEXT_TYPES:
                if mark.source_contact_id:add("CWS-MARK-020","Identification mark mag niet van ContactPatch afhangen")
                if mark.geometry_2d.kind!=MarkGeometryKind.TEXT_ANCHOR.value or len(mark.geometry_2d.points)!=1:add("CWS-MARK-011","Identification mist canonical text anchor");continue
                text_rules=dict(ruleset.text_identification_rules or {});height=float(mark.text_height_mm);anchor=mark.geometry_2d.points[0]
                values=_identification_values(project,assembly,part,text_rules)
                if mark.mark_type==MarkType.ASSEMBLY_TEXT.value:template=str(text_rules.get("assembly_template") or "{assembly_mark}")
                elif mark.mark_type==MarkType.PART_TEXT.value:template=str(text_rules.get("part_template") or "{part_position}")
                else:template=str(text_rules.get("position_template") or "{assembly_mark}-{part_position}")
                try:expected_text=_safe_template(template,values)
                except Exception as exc:add("CWS-MARK-013",str(exc));expected_text=""
                if expected_text and mark.text_payload!=expected_text:add("CWS-MARK-020",f"Identification text mismatch: verwacht {expected_text!r}")
                actual_text[(part.internal_id,mark.mark_type,mark.text_payload)]=actual_text.get((part.internal_id,mark.mark_type,mark.text_payload),0)+1
                if height<=0:add("CWS-MARK-011","Identification text height ontbreekt")
                orientation=mark.geometry_2d.orientation_deg%360.0
                if part.mirrored and ruleset.mirror_policy=="block":add("CWS-MARK-012","Mirrored identification is door ruleset geblokkeerd")
                if part.mirrored and ruleset.mirror_policy=="explicit_only" and not bool(part.properties.get("mirror_identification_confirmed",False)):add("CWS-MARK-012","Mirror-equivalence niet bevestigd")
                if not bool(mark.provenance.get("mirror_safe",False)):add("CWS-MARK-012","Identification mist mirror-safe provenance")
                rect=_text_box(anchor,mark.text_payload,height,orientation,mark.geometry_2d.anchor_horizontal,mark.geometry_2d.anchor_vertical)
                margin=float(text_rules.get("edge_margin_mm") or 10.0)
                if not all(_point_in_polygon(p,poly) and _edge_distance(p,poly)+1e-6>=margin for p in _rect_corners(rect)):add("CWS-MARK-011","Identification envelope schendt face/edge margin")
                hole_margin=float(text_rules.get("hole_margin_mm") or 5.0)
                for center,radius,fid in _hole_zones(part,face,hole_margin):
                    if _rect_intersects_circle(rect,center,radius):add("CWS-MARK-011",f"Identification overlapt hole zone {fid}")
                for kind,geom,radius,zid in _weld_zones(part,face,ruleset.weld_margin_mm):
                    if kind=="circle" and _rect_intersects_circle(rect,geom,radius):add("CWS-MARK-011",f"Identification overlapt weld zone {zid}")
                    if kind=="rect" and _rect_intersects_rect(rect,tuple(geom)):add("CWS-MARK-011",f"Identification overlapt weld zone {zid}")
                for cp in _contact_polygons(project,assembly_id,part.internal_id,face.face_id):
                    if any(_point_in_polygon(p,cp) for p in _rect_corners(rect)):add("CWS-MARK-011","Identification overlapt contact patch")
                expanded=(rect[0]-float(text_rules.get("other_mark_margin_mm") or 3.0),rect[1]-float(text_rules.get("other_mark_margin_mm") or 3.0),rect[2]+float(text_rules.get("other_mark_margin_mm") or 3.0),rect[3]+float(text_rules.get("other_mark_margin_mm") or 3.0))
                for a,b in all_lines.get((part.internal_id,face.face_id),[]):
                    # Skip the text itself; all_lines only contains line marks.
                    if _segment_intersects_rect(a,b,expanded):add("CWS-MARK-011","Identification overlapt andere mark")
            else:add("CWS-MARK-020",f"Mark type {mark.mark_type!r} hoort niet bij M4 reference/identification scope")
            try:
                if ManufacturingMark.from_dict(mark.to_dict()).mark_hash!=mark.mark_hash:add("CWS-MARK-020","Mark roundtrip/hash mismatch")
            except Exception as exc:add("CWS-MARK-020",f"Mark contract ongeldig: {exc}")

        # Completeness: each enabled valid hole must have the policy-required
        # count, and each requested identification intent exactly one mark.
        hole_rules=dict(ruleset.hole_reference_rules or {})
        if bool(hole_rules.get("enabled",False)):
            mode=str(hole_rules.get("mode") or "crosshair").lower();expected_count=4 if mode=="crosshair" else (1 if mode in {"pop_mark","center_punch"} else 0)
            for part_id in assembly.part_ids:
                part=project.parts.get(part_id)
                if part is None:continue
                for feature in canonical_hole_features(part):
                    face=_feature_face(part,feature)
                    if face is None:continue
                    count=actual_hole_counts.get(feature["feature_id"],0)
                    # Edge/contact clipping may remove individual cross arms;
                    # require at least one but never more than four. Full four is
                    # required when the center has comfortable clearance.
                    if mode=="crosshair":
                        poly=_outer_polygon(face)
                        comfortable=bool(poly) and _edge_distance((feature["u_mm"],feature["v_mm"]),poly) > feature["diameter_mm"]/2 + float(hole_rules.get("gap_from_hole_mm") or 2)+float(hole_rules.get("arm_length_mm") or 12)+ruleset.min_edge_distance_mm
                        required=4 if comfortable else 1
                        if count<required or count>4:issues.append(M4ValidationIssue("CWS-MARK-020",f"Hole {feature['feature_id']} heeft {count} reference arms; verwacht {required}..4",part_id=part_id,feature_id=feature["feature_id"]))
                    elif expected_count and count!=expected_count:issues.append(M4ValidationIssue("CWS-MARK-020",f"Hole {feature['feature_id']} heeft {count} marks; verwacht {expected_count}",part_id=part_id,feature_id=feature["feature_id"]))
        text_rules=dict(ruleset.text_identification_rules or {})
        if bool(text_rules.get("enabled",False)):
            expected=[]
            if bool(text_rules.get("emit_assembly_text_on_main",True)) and assembly.main_part_id and assembly.assembly_mark:
                part=project.parts.get(assembly.main_part_id)
                if part is not None:
                    try:
                        text=_safe_template(str(text_rules.get("assembly_template") or "{assembly_mark}"),_identification_values(project,assembly,part,text_rules))
                    except Exception as exc:
                        issues.append(M4ValidationIssue("CWS-MARK-013",str(exc),part_id=part.internal_id))
                    else:
                        expected.append((part.internal_id,MarkType.ASSEMBLY_TEXT.value,text))
            if bool(text_rules.get("emit_part_text",True)):
                for part_id in assembly.part_ids:
                    part=project.parts.get(part_id)
                    if part is not None and part.part_position:
                        try:
                            text=_safe_template(str(text_rules.get("part_template") or "{part_position}"),_identification_values(project,assembly,part,text_rules))
                        except Exception as exc:
                            issues.append(M4ValidationIssue("CWS-MARK-013",str(exc),part_id=part.internal_id))
                        else:
                            expected.append((part.internal_id,MarkType.PART_TEXT.value,text))
            if bool(text_rules.get("emit_position_text",False)):
                for part_id in assembly.part_ids:
                    part=project.parts.get(part_id)
                    if part is not None:
                        try:
                            text=_safe_template(str(text_rules.get("position_template") or "{assembly_mark}-{part_position}"),_identification_values(project,assembly,part,text_rules))
                        except Exception as exc:
                            issues.append(M4ValidationIssue("CWS-MARK-013",str(exc),part_id=part.internal_id))
                        else:
                            if text: expected.append((part.internal_id,MarkType.POSITION_TEXT.value,text))
            for key in expected:
                if actual_text.get(key,0)!=1:issues.append(M4ValidationIssue("CWS-MARK-020",f"Identification intent {key} komt {actual_text.get(key,0)}x voor; verwacht exact 1",part_id=key[0]))
        status="passed" if not any(i.blocking for i in issues) else "failed"
        return M4ValidationReport(assembly_id,status,ruleset.ruleset_hash,source_hash,len(rows),issues)

__all__=["M4_VALIDATOR_VERSION","M4_VALIDATION_SCHEMA_VERSION","M4ValidationIssue","M4ValidationReport","IndependentM4MarkValidator"]
