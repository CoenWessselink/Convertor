"""M9 DSTV marking adapter with explicit coordinate proof and semantic roundtrip.

This module intentionally implements only public DSTV/NC1 semantics that CWS can
independently verify.  Canonical ManufacturingFace coordinates are never assumed
to be DSTV coordinates: every target face requires an explicit, hash-bound 2D
mapping in ``Part.properties['dstv_marking_mapping']``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import hashlib
import json
import math
from typing import Any, Iterable, Mapping, Sequence

from converter import NC1Part, Numbering, SurfaceMark, Hole, parse_nc1
from cws_convertor.project.model import Part, ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from .contracts import ManufacturingFace
from .marking_contracts import ManufacturingMark, MarkGeometry2D, MarkGeometryKind, MarkReviewStatus, MarkType

DSTV_MARKING_ADAPTER_SCHEMA_VERSION = "1.0"
DSTV_MARKING_ROUNDTRIP_SCHEMA_VERSION = "1.0"
DSTV_MARKING_MAPPING_HASH_VERSION = "cws-dstv-marking-mapping-v1"
DSTV_MARKING_RECORD_HASH_VERSION = "cws-dstv-marking-record-v1"

_TEXT_TYPES = {
    MarkType.POSITION_TEXT.value,
    MarkType.ASSEMBLY_TEXT.value,
    MarkType.PART_TEXT.value,
    MarkType.HARD_STAMP_REQUEST.value,
}
_SURFACE_TYPES = {
    MarkType.SCRIBE_LINE.value,
    MarkType.CONTOUR_SCRIBE.value,
    MarkType.REFERENCE_LINE.value,
    MarkType.HOLE_CENTER_CROSS.value,
}
_POINT_TYPES = {MarkType.POP_MARK.value, MarkType.CENTER_PUNCH.value, MarkType.DATUM_MARK.value}


def _finite(value: Any, label: str) -> float:
    try:
        out = float(value)
    except Exception as exc:
        raise ProjectValidationError(f"{label} is geen geldig getal") from exc
    if not math.isfinite(out):
        raise ProjectValidationError(f"{label} moet eindig zijn")
    return out


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _ascii_text(value: str, *, max_len: int = 40) -> str:
    text = str(value or "").strip()
    if not text:
        raise ProjectValidationError("CWS-MARK-018 DSTV SI-tekst is leeg")
    try:
        text.encode("ascii")
    except UnicodeEncodeError as exc:
        raise ProjectValidationError("CWS-MARK-018 DSTV SI ondersteunt in deze adapter alleen ASCII-tekst") from exc
    if len(text) > max_len:
        raise ProjectValidationError(f"CWS-MARK-018 DSTV SI-tekst is langer dan {max_len} tekens")
    return text


@dataclass(frozen=True)
class DstvMarkingMapping:
    part_id: str
    face_id: str
    semantic_role: str
    dstv_side: str
    matrix_2d: tuple[tuple[float, float], tuple[float, float]]
    offset_mm: tuple[float, float] = (0.0, 0.0)
    datum: str = "s"
    proof_status: str = "user_confirmed"
    source: str = ""
    mapping_hash: str = ""
    schema_version: str = DSTV_MARKING_ADAPTER_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.part_id or not self.face_id:
            raise ProjectValidationError("CWS-MARK-010 DSTV marking mapping mist part/face")
        side = str(self.dstv_side or "").strip().lower()
        if side not in {"v", "h", "o", "u"}:
            raise ProjectValidationError(f"CWS-MARK-010 ongeldige DSTV-zijde {self.dstv_side!r}")
        object.__setattr__(self, "dstv_side", side)
        if self.proof_status not in {"exact", "user_confirmed"}:
            raise ProjectValidationError("CWS-MARK-010 DSTV mapping vereist exact/user_confirmed bewijs")
        rows = tuple(tuple(_finite(x, "DSTV matrix") for x in row) for row in self.matrix_2d)
        if len(rows) != 2 or any(len(row) != 2 for row in rows):
            raise ProjectValidationError("CWS-MARK-010 DSTV matrix_2d moet 2x2 zijn")
        a, b = rows[0]; c, d = rows[1]
        # A face-local -> DSTV map may rotate/refelect, but may not scale/skew.
        tol = 1e-6
        if abs(a*a + c*c - 1.0) > tol or abs(b*b + d*d - 1.0) > tol or abs(a*b + c*d) > tol:
            raise ProjectValidationError("CWS-MARK-010 DSTV matrix_2d moet orthonormaal zijn")
        det = a*d - b*c
        if abs(abs(det) - 1.0) > tol:
            raise ProjectValidationError("CWS-MARK-010 DSTV matrix_2d heeft ongeldige determinant")
        object.__setattr__(self, "matrix_2d", rows)
        off = tuple(_finite(x, "DSTV offset") for x in self.offset_mm)
        if len(off) != 2:
            raise ProjectValidationError("CWS-MARK-010 DSTV offset_mm moet twee waarden bevatten")
        object.__setattr__(self, "offset_mm", off)
        datum = str(self.datum or "").strip().lower()
        if datum not in {"", "o", "s", "u"}:
            raise ProjectValidationError("CWS-MARK-010 DSTV datum is ongeldig")
        object.__setattr__(self, "datum", datum)
        expected = stable_sha256(self.hash_payload())
        if self.mapping_hash and self.mapping_hash != expected:
            raise ProjectValidationError("CWS-MARK-010 DSTV mapping_hash klopt niet")
        object.__setattr__(self, "mapping_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": DSTV_MARKING_MAPPING_HASH_VERSION,
            "schema_version": self.schema_version,
            "part_id": self.part_id,
            "face_id": self.face_id,
            "semantic_role": self.semantic_role,
            "dstv_side": self.dstv_side,
            "matrix_2d": [list(x) for x in self.matrix_2d],
            "offset_mm": list(self.offset_mm),
            "datum": self.datum,
            "proof_status": self.proof_status,
            "source": self.source,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "mapping_hash": self.mapping_hash}

    def point(self, uv: tuple[float, float]) -> tuple[float, float]:
        u, v = (_finite(uv[0], "mark U"), _finite(uv[1], "mark V"))
        (a, b), (c, d) = self.matrix_2d
        return (a*u + b*v + self.offset_mm[0], c*u + d*v + self.offset_mm[1])

    def angle(self, angle_deg: float) -> float:
        theta = math.radians(_finite(angle_deg, "mark angle"))
        x, y = math.cos(theta), math.sin(theta)
        (a, b), (c, d) = self.matrix_2d
        out = math.degrees(math.atan2(c*x+d*y, a*x+b*y)) % 360.0
        return out


@dataclass(frozen=True)
class DstvMarkingRecord:
    mark_id: str
    block: str
    lines: tuple[str, ...]
    mapping_hash: str
    record_hash: str = ""

    def __post_init__(self) -> None:
        block = str(self.block).upper()
        if block not in {"SI", "PU", "KO", "BO"}:
            raise ProjectValidationError(f"CWS-MARK-018 unsupported DSTV marking block {block}")
        object.__setattr__(self, "block", block)
        if not self.lines:
            raise ProjectValidationError("CWS-MARK-018 leeg DSTV marking record")
        expected = stable_sha256({
            "hash_version": DSTV_MARKING_RECORD_HASH_VERSION,
            "mark_id": self.mark_id,
            "block": block,
            "lines": list(self.lines),
            "mapping_hash": self.mapping_hash,
        })
        if self.record_hash and self.record_hash != expected:
            raise ProjectValidationError("CWS-MARK-019 DSTV marking record_hash klopt niet")
        object.__setattr__(self, "record_hash", expected)

    def to_dict(self) -> dict[str, Any]:
        return {"mark_id": self.mark_id, "block": self.block, "lines": list(self.lines), "mapping_hash": self.mapping_hash, "record_hash": self.record_hash}


@dataclass(frozen=True)
class DstvMarkingRoundtripReport:
    artifact_id: str
    part_id: str
    input_path: str
    output_path: str
    input_sha256: str
    output_sha256: str
    input_geometry_hash: str
    output_geometry_hash: str
    record_hashes: tuple[str, ...]
    mapping_hashes: tuple[str, ...]
    semantic_marking_hash: str
    verified: bool
    created_at: str
    report_hash: str = ""
    schema_version: str = DSTV_MARKING_ROUNDTRIP_SCHEMA_VERSION

    def __post_init__(self) -> None:
        expected = stable_sha256(self.hash_payload())
        if self.report_hash and self.report_hash != expected:
            raise ProjectValidationError("CWS-MARK-019 DSTV roundtrip report_hash klopt niet")
        object.__setattr__(self, "report_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "artifact_id": self.artifact_id,
            "part_id": self.part_id,
            "input_path": self.input_path,
            "output_path": self.output_path,
            "input_sha256": self.input_sha256,
            "output_sha256": self.output_sha256,
            "input_geometry_hash": self.input_geometry_hash,
            "output_geometry_hash": self.output_geometry_hash,
            "record_hashes": list(self.record_hashes),
            "mapping_hashes": list(self.mapping_hashes),
            "semantic_marking_hash": self.semantic_marking_hash,
            "verified": bool(self.verified),
            "created_at": self.created_at,
            "dstv_standard_adapter_verified": bool(self.verified),
            "production_marking_released": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "report_hash": self.report_hash}


def _face_for_mark(part: Part, mark: ManufacturingMark) -> ManufacturingFace:
    for raw in part.manufacturing_faces or []:
        try:
            face = ManufacturingFace.from_dict(raw)
        except Exception:
            continue
        if face.face_id == mark.target_face_id:
            return face
    raise ProjectValidationError(f"CWS-MARK-001 mark {mark.mark_id} target face ontbreekt")


def resolve_explicit_dstv_marking_mapping(part: Part, face: ManufacturingFace) -> DstvMarkingMapping:
    root = part.properties.get("dstv_marking_mapping") if isinstance(part.properties, dict) else None
    if not isinstance(root, Mapping):
        raise ProjectValidationError(f"CWS-MARK-010 part {part.internal_id} mist expliciete dstv_marking_mapping")
    raw = root.get(face.face_id)
    if raw is None:
        raw = root.get(face.semantic_role)
    if not isinstance(raw, Mapping):
        raise ProjectValidationError(f"CWS-MARK-010 face {face.face_id}/{face.semantic_role} mist expliciete DSTV coordinate mapping")
    # Side may be repeated here or proven by the M1 explicit face adapter. Never infer.
    side = str(raw.get("side") or raw.get("dstv_side") or "").lower().strip()
    if not side:
        candidates = [x for x in face.dstv_side_candidates if x.proof_status in {"exact", "user_confirmed"}]
        unique = sorted({x.dstv_side for x in candidates})
        if len(unique) != 1:
            raise ProjectValidationError(f"CWS-MARK-010 face {face.face_id} heeft geen unieke expliciete DSTV side")
        side = unique[0]
    if "matrix_2d" not in raw:
        raise ProjectValidationError(f"CWS-MARK-010 face {face.face_id} mist matrix_2d; identiteit wordt niet gegokt")
    matrix = raw.get("matrix_2d")
    offset = raw.get("offset_mm") or (0.0, 0.0)
    return DstvMarkingMapping(
        part_id=part.internal_id,
        face_id=face.face_id,
        semantic_role=face.semantic_role,
        dstv_side=side,
        matrix_2d=tuple(tuple(float(v) for v in row) for row in matrix),
        offset_mm=tuple(float(v) for v in offset),
        datum=str(raw.get("datum") if raw.get("datum") is not None else "s"),
        proof_status=str(raw.get("proof_status") or "user_confirmed"),
        source=str(raw.get("source") or "part.properties.dstv_marking_mapping"),
        mapping_hash=str(raw.get("mapping_hash") or ""),
    )


def _surface_paths(geometry: MarkGeometry2D) -> list[tuple[tuple[float, float], ...]]:
    if geometry.kind == MarkGeometryKind.LINE.value:
        return [geometry.points]
    if geometry.kind == MarkGeometryKind.POLYLINE.value:
        pts = list(geometry.points)
        if geometry.closed and pts and pts[-1] != pts[0]:
            pts.append(pts[0])
        return [tuple(pts)]
    if geometry.kind == MarkGeometryKind.COMPOUND.value:
        out: list[tuple[tuple[float, float], ...]] = []
        for child in geometry.components:
            out.extend(_surface_paths(child))
        return out
    # Do not polygonize analytic curves silently.
    raise ProjectValidationError(f"CWS-MARK-018 DSTV KO/PU adapter ondersteunt geometry kind {geometry.kind!r} niet exact")


def _fmt_surface_line(face: str, x: float, datum: str, q: float, radius: float = 0.0) -> str:
    # Free format after col. 2 is standards-compliant; explicit spaces make the
    # parser and external inspection unambiguous.
    # Keep the two-column block indentation; blank face/datum fields remain explicit.
    return f"  {face or ' '} {x:.2f} {datum or ' '} {q:.2f} {radius:.2f}"


def _fmt_si_line(mapping: DstvMarkingMapping, x: float, q: float, angle: float, height: int, text: str, behavior: str) -> str:
    bits = [f"  {mapping.dstv_side}", f"{x:.2f}"]
    if mapping.datum:
        bits.append(mapping.datum)
    bits.extend([f"{q:.2f}", f"{angle:.2f}", str(height)])
    if behavior:
        bits.append(behavior)
    bits.append(text)
    return " ".join(bits)


def _fmt_bo_mark_line(mapping: DstvMarkingMapping, x: float, q: float) -> str:
    # Fixed-width BO layout to remain compatible with CWS' existing BO parser.
    return (
        "  " + mapping.dstv_side
        + f"{x:11.2f}"
        + (mapping.datum[:1] if mapping.datum else " ")
        + f"{q:10.2f}"
        + f"{0.0:11.2f}"
        + "m"
        + f"{0.0:10.2f}"
    )


class DstvMarkingAdapter:
    """Canonical manufacturing mark -> verified public DSTV marking blocks."""

    def records_for_mark(self, part: Part, mark: ManufacturingMark) -> tuple[DstvMarkingRecord, ...]:
        if mark.review_status != MarkReviewStatus.ACCEPTED.value or mark.suppression_reason:
            raise ProjectValidationError(f"CWS-MARK-018 mark {mark.mark_id} is niet accepted/current voor DSTV export")
        face = _face_for_mark(part, mark)
        mapping = resolve_explicit_dstv_marking_mapping(part, face)
        records: list[DstvMarkingRecord] = []

        if mark.mark_type in _TEXT_TYPES:
            if mark.geometry_2d.kind != MarkGeometryKind.TEXT_ANCHOR.value:
                raise ProjectValidationError(f"CWS-MARK-018 textmark {mark.mark_id} mist text_anchor geometry")
            height = _finite(mark.text_height_mm, "DSTV SI text height")
            if height <= 0 or abs(height - round(height)) > 1e-9:
                raise ProjectValidationError("CWS-MARK-018 DSTV SI text height moet een positieve hele millimeter zijn")
            text = _ascii_text(mark.text_payload)
            x, q = mapping.point(mark.geometry_2d.points[0])
            angle = mapping.angle(mark.geometry_2d.orientation_deg)
            behavior = str(mark.machine_constraints.get("dstv_turn_behavior") or "r").strip().lower()
            if behavior not in {"", "r", "z"}:
                raise ProjectValidationError("CWS-MARK-018 ongeldige DSTV SI turn behavior")
            line = _fmt_si_line(mapping, x, q, angle, int(round(height)), text, behavior)
            records.append(DstvMarkingRecord(mark.mark_id, "SI", (line,), mapping.mapping_hash))
            return tuple(records)

        if mark.mark_type in _SURFACE_TYPES:
            block = str(mark.machine_constraints.get("dstv_surface_block") or "KO").strip().upper()
            if block not in {"KO", "PU"}:
                raise ProjectValidationError("CWS-MARK-018 scribe mark vereist DSTV KO of PU output policy")
            paths = _surface_paths(mark.geometry_2d)
            for idx, path in enumerate(paths):
                lines=[]
                for pidx, uv in enumerate(path):
                    x, q = mapping.point(uv)
                    lines.append(_fmt_surface_line(mapping.dstv_side if pidx == 0 else "", x, mapping.datum if pidx == 0 else "", q, 0.0))
                records.append(DstvMarkingRecord(f"{mark.mark_id}:{idx}" if len(paths) > 1 else mark.mark_id, block, tuple(lines), mapping.mapping_hash))
            return tuple(records)

        if mark.mark_type in _POINT_TYPES:
            if mark.geometry_2d.kind not in {MarkGeometryKind.POINT.value, MarkGeometryKind.SYMBOL_ANCHOR.value}:
                raise ProjectValidationError(f"CWS-MARK-018 pointmark {mark.mark_id} heeft geen point geometry")
            x, q = mapping.point(mark.geometry_2d.points[0])
            records.append(DstvMarkingRecord(mark.mark_id, "BO", (_fmt_bo_mark_line(mapping, x, q),), mapping.mapping_hash))
            return tuple(records)

        raise ProjectValidationError(f"CWS-MARK-018 mark_type {mark.mark_type!r} kan niet veilig naar DSTV worden geschreven")

    def records_for_part(self, project: ProjectModel, part_id: str, mark_ids: Iterable[str] | None = None) -> tuple[DstvMarkingRecord, ...]:
        part = project.parts.get(part_id)
        if part is None:
            raise ProjectValidationError(f"Onbekend part {part_id}")
        wanted = set(mark_ids or [])
        records=[]
        marks=[]
        for mid, raw in project.manufacturing_marks.items():
            mark=ManufacturingMark.from_dict(raw)
            if mark.target_part_id != part_id or (wanted and mid not in wanted):
                continue
            marks.append(mark)
        for mark in sorted(marks, key=lambda m: (m.mark_type, m.mark_id)):
            records.extend(self.records_for_mark(part, mark))
        if not records:
            raise ProjectValidationError(f"CWS-MARK-018 part {part_id} heeft geen exporteerbare accepted marks")
        return tuple(records)


def _header_payload(part: NC1Part) -> dict[str, Any]:
    h=part.header
    return {name:getattr(h,name) for name in h.__dataclass_fields__}


def _geometry_payload(part: NC1Part) -> dict[str, Any]:
    contours=[]
    for c in part.contours:
        contours.append({"kind":c.kind,"face":c.face,"points":[{"x":p.x,"q":p.q,"datum":p.datum,"notch":p.notch,"radius":p.radius,"weld":list(p.weld)} for p in c.points]})
    holes=[]
    for h in part.holes:
        if h.operation == "m" and abs(h.diameter) <= 1e-9:
            continue
        holes.append({"face":h.face,"x":h.x,"q":h.q,"diameter":h.diameter,"datum":h.datum,"operation":h.operation,"depth":h.depth})
    return {"header":_header_payload(part),"contours":contours,"holes":holes}


def _parsed_mark_signatures(part: NC1Part) -> set[str]:
    out=set()
    for n in part.numberings:
        out.add(stable_sha256({"block":"SI","face":n.face,"x":round(n.x,2),"q":round(n.q,2),"datum":n.datum,"angle":round(n.angle_deg,2),"height":int(n.text_height_mm),"behavior":n.turn_behavior,"text":n.text}))
    for m in part.surface_marks:
        out.add(stable_sha256({"block":m.kind,"face":m.face,"points":[[round(p.x,2),round(p.q,2),p.datum,round(p.radius,2)] for p in m.points]}))
    for h in part.holes:
        if h.operation == "m" and abs(h.diameter) <= 1e-9:
            out.add(stable_sha256({"block":"BO","face":h.face,"x":round(h.x,2),"q":round(h.q,2),"datum":h.datum,"operation":"m","diameter":0.0}))
    return out


def _expected_record_signature(record: DstvMarkingRecord, scratch: Path) -> set[str]:
    # Reuse the independent public parser for semantic normalization.  Wrap only
    # this record in a minimal known-valid NC1 header.
    lines=[
        "ST","  CWS","  CWS","  1","  TMP","  S235JR","  1","  PL10","  B",
        "  1000.00","  100.00","  10.00","  10.00","  10.00","  0.00","  0.00","  0.00","  0.00","  0.00","  0.00","  0.00",
        record.block,*record.lines,"EN",
    ]
    scratch.write_text("\r\n".join(lines)+"\r\n",encoding="ascii",newline="")
    parsed=parse_nc1(scratch)
    return _parsed_mark_signatures(parsed)


def merge_dstv_marking(
    input_nc1: str | Path,
    output_nc1: str | Path,
    records: Sequence[DstvMarkingRecord],
    *,
    expected_input_sha256: str = "",
    report_timestamp: str = "",
    report_input_path: str = "",
    report_output_path: str = "",
) -> DstvMarkingRoundtripReport:
    source=Path(input_nc1).expanduser().resolve(); target=Path(output_nc1).expanduser().resolve()
    if not source.is_file():
        raise ProjectValidationError(f"CWS-MARK-019 NC1 bronbestand ontbreekt: {source}")
    input_sha=_sha256(source)
    if expected_input_sha256 and input_sha.lower() != str(expected_input_sha256).lower():
        raise ProjectValidationError("CWS-MARK-019 NC1 bron-SHA wijkt af van geregistreerd artefact")
    before=parse_nc1(source)
    before_geometry=stable_sha256(_geometry_payload(before))
    raw_lines=source.read_text(encoding="ascii",errors="strict").splitlines()
    try:
        en_idx=max(i for i,line in enumerate(raw_lines) if line.strip()=="EN")
    except ValueError as exc:
        raise ProjectValidationError("CWS-MARK-019 NC1 mist EN blok") from exc
    inject=[]
    # Exact textual block de-duplication prevents repeated CWS merges from
    # multiplying identical records while preserving unrelated existing marks.
    source_text="\n".join(raw_lines)
    for record in records:
        snippet="\n".join((record.block,*record.lines))
        if snippet in source_text:
            continue
        inject.extend((record.block,*record.lines))
    merged=raw_lines[:en_idx]+inject+raw_lines[en_idx:]
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("w",encoding="ascii",newline="") as handle:
        handle.write("\r\n".join(merged)+"\r\n")
    try:
        after=parse_nc1(target)
        after_geometry=stable_sha256(_geometry_payload(after))
        if before_geometry != after_geometry:
            raise ProjectValidationError("CWS-MARK-019 DSTV merge wijzigde bestaande header/contour/gatgeometrie")
        expected=set()
        scratch=target.parent/(target.name+".m9-record-check.tmp")
        try:
            for record in records:
                expected.update(_expected_record_signature(record,scratch))
        finally:
            scratch.unlink(missing_ok=True)
        actual=_parsed_mark_signatures(after)
        missing=expected-actual
        if missing:
            raise ProjectValidationError(f"CWS-MARK-019 DSTV re-import mist {len(missing)} gewenste marksemantiek")
    except Exception:
        target.unlink(missing_ok=True)
        raise
    output_sha=_sha256(target)
    artifact_id="dstvmark-"+stable_sha256({"input_sha256":input_sha,"output_sha256":output_sha,"records":[r.record_hash for r in records]})[:24]
    semantic_hash=stable_sha256(sorted(_parsed_mark_signatures(after)))
    return DstvMarkingRoundtripReport(
        artifact_id=artifact_id,
        part_id="",  # service binds project identity below
        input_path=report_input_path or str(source),output_path=report_output_path or str(target),input_sha256=input_sha,output_sha256=output_sha,
        input_geometry_hash=before_geometry,output_geometry_hash=after_geometry,
        record_hashes=tuple(r.record_hash for r in records),mapping_hashes=tuple(sorted({r.mapping_hash for r in records})),
        semantic_marking_hash=semantic_hash,verified=True,created_at=report_timestamp or utc_now_iso(),
    )


def current_nc1_artifact(part: Part) -> dict[str, Any] | None:
    workbench=part.workbench if isinstance(part.workbench,dict) else {}
    artifacts=workbench.get("artifacts") if isinstance(workbench,dict) else None
    candidates=[]
    if isinstance(artifacts,Mapping):
        for aid, raw in artifacts.items():
            if not isinstance(raw,Mapping): continue
            fmt=str(raw.get("format") or "").lower().lstrip(".")
            if fmt not in {"nc","nc1","dstv"}: continue
            if str(raw.get("status") or "current") != "current": continue
            if str(raw.get("manufacturing_hash") or "") != str(part.manufacturing_hash or ""): continue
            path=Path(str(raw.get("path") or "")).expanduser()
            if not path.is_file(): continue
            if str(raw.get("sha256") or "").lower() != _sha256(path).lower(): continue
            candidates.append({**dict(raw),"artifact_id":str(raw.get("artifact_id") or aid),"path":str(path.resolve())})
    return sorted(candidates,key=lambda x:x["artifact_id"])[-1] if candidates else None


def create_dstv_marked_artifact(project: ProjectModel, part_id: str, output_path: str | Path, *, user: str = "system", source_artifact: Mapping[str,Any] | None = None) -> dict[str, Any]:
    part=project.parts.get(part_id)
    if part is None: raise ProjectValidationError(f"Onbekend part {part_id}")
    artifact=dict(source_artifact or current_nc1_artifact(part) or {})
    if not artifact:
        raise ProjectValidationError(f"CWS-MARK-018 part {part_id} heeft geen current checksum-gebonden NC1 artefact")
    if str(artifact.get("manufacturing_hash") or "") != str(part.manufacturing_hash or ""):
        raise ProjectValidationError(f"CWS-MARK-014 NC1 artefact voor part {part_id} hoort niet bij huidige manufacturing_hash")
    records=DstvMarkingAdapter().records_for_part(project,part_id)
    report=merge_dstv_marking(artifact["path"],output_path,records,expected_input_sha256=str(artifact.get("sha256") or ""))
    bound=DstvMarkingRoundtripReport(
        artifact_id=report.artifact_id,part_id=part_id,input_path=report.input_path,output_path=report.output_path,
        input_sha256=report.input_sha256,output_sha256=report.output_sha256,input_geometry_hash=report.input_geometry_hash,
        output_geometry_hash=report.output_geometry_hash,record_hashes=report.record_hashes,mapping_hashes=report.mapping_hashes,
        semantic_marking_hash=report.semantic_marking_hash,verified=True,created_at=report.created_at,
    )
    state={
        "schema_version":"1.0","phase":"M9","part_id":part_id,"manufacturing_hash":part.manufacturing_hash,
        "source_artifact_id":str(artifact.get("artifact_id") or ""),"source_artifact_sha256":str(artifact.get("sha256") or ""),
        "roundtrip":bound.to_dict(),"created_by":user,"created_at":utc_now_iso(),
        "dstv_standard_adapter_verified":True,"production_marking_released":False,"machine_output_released":False,"direct_machine_transfer":False,
    }
    state["state_hash"]=stable_sha256({k:v for k,v in state.items() if k!="state_hash"})
    project.manufacturing_dstv_roundtrips[bound.artifact_id]=state
    project.audit("manufacturing.dstv_marking.roundtrip",user=user,entity_id=part_id,details={"artifact_id":bound.artifact_id,"output_sha256":bound.output_sha256})
    return state


def validate_persisted_dstv_roundtrip(project: ProjectModel, artifact_id: str, *, require_current: bool = True, require_file: bool = False) -> dict[str,Any]:
    raw=project.manufacturing_dstv_roundtrips.get(artifact_id)
    if not isinstance(raw,Mapping): raise ProjectValidationError(f"Onbekend M9 DSTV roundtrip {artifact_id}")
    state=dict(raw); stored=str(state.pop("state_hash","") or "")
    if not stored or stable_sha256(state)!=stored: raise ProjectValidationError(f"M9 DSTV roundtrip {artifact_id} state_hash ongeldig")
    if bool(raw.get("production_marking_released")) or bool(raw.get("machine_output_released")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M9 mag geen production/machine release claimen")
    pid=str(raw.get("part_id") or ""); part=project.parts.get(pid)
    if not part: raise ProjectValidationError(f"M9 DSTV roundtrip {artifact_id} verwijst naar onbekend part")
    if require_current and str(raw.get("manufacturing_hash") or "") != str(part.manufacturing_hash or ""):
        raise ProjectValidationError(f"M9 DSTV roundtrip {artifact_id} is stale")
    rt=dict(raw.get("roundtrip") or {})
    if not bool(rt.get("verified")): raise ProjectValidationError(f"M9 DSTV roundtrip {artifact_id} is niet verified")
    if require_file:
        path=Path(str(rt.get("output_path") or ""));
        if not path.is_file() or _sha256(path).lower()!=str(rt.get("output_sha256") or "").lower():
            raise ProjectValidationError(f"M9 DSTV roundtrip {artifact_id} outputbestand/hash ontbreekt")
    return dict(raw)


__all__=[name for name in globals() if not name.startswith("_")]
