"""M5 machine marking capability evaluation.

This module is the *candidate/evaluation* path.  It proves static capability in
canonical part coordinates.  The later M6 nesting binding must re-evaluate the
same mark after orientation + bar placement and is not allowed to inherit this
proof blindly.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from cws_convertor.optimization.profile_nesting.models import MachineOptimizationProfile
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .marking_contracts import ManufacturingMark, MarkGeometryKind, MarkType, ManufacturingRuleSet
from .marking_service import load_assembly_marks, load_ruleset, validate_persisted_mark_state
from .service import load_faces, validate_persisted_face_state
from .marking_geometry import line_face_outer_polygon, point_in_polygon, target_hole_zones, target_weld_zones
from .machine_marking_contracts import (
    InternalFacePolicy, MarkCapabilityIssue, MarkCapabilityProof, MarkingCapabilityValidationStatus,
    MarkingOperation, MarkingToolDefinition, ManufacturingMachineCapability, machine_marking_report_hash,
)

M5_ENGINE_VERSION = "cws-machine-marking-capability-m5-v1"
M5_SOURCE_SNAPSHOT_VERSION = "cws-machine-marking-source-v1"

_INTERNAL_FACE_ROLES = {
    "top_inner", "bottom_inner", "flange_a_inner", "flange_b_inner",
    "leg_a_inner", "leg_b_inner", "web_inner",
}


def _requested_operation(mark: ManufacturingMark) -> str:
    raw = str(mark.requested_operation or "").strip().lower()
    if raw == "scribe":
        return MarkingOperation.CONTOUR_SCRIBE.value if mark.mark_type == MarkType.CONTOUR_SCRIBE.value else MarkingOperation.SCRIBE_LINE.value
    if raw in {item.value for item in MarkingOperation}:
        return raw
    if raw == "text_mark": return MarkingOperation.TEXT_MARK.value
    if raw == "hard_stamp": return MarkingOperation.HARD_STAMP.value
    if mark.mark_type == MarkType.POP_MARK.value: return MarkingOperation.POP_MARK.value
    if mark.mark_type == MarkType.CENTER_PUNCH.value: return MarkingOperation.CENTER_PUNCH.value
    if mark.mark_type in {MarkType.POSITION_TEXT.value, MarkType.ASSEMBLY_TEXT.value, MarkType.PART_TEXT.value}: return MarkingOperation.TEXT_MARK.value
    if mark.mark_type == MarkType.HARD_STAMP_REQUEST.value: return MarkingOperation.HARD_STAMP.value
    return MarkingOperation.NONE.value


def _face_for_mark(project: ProjectModel, mark: ManufacturingMark) -> ManufacturingFace:
    part = project.parts.get(mark.target_part_id)
    if part is None:
        raise ProjectValidationError(f"CWS-MARK-001 target part {mark.target_part_id} ontbreekt")
    validate_persisted_face_state(part, require_current=True)
    matches = [face for face in load_faces(part) if face.face_id == mark.target_face_id]
    if len(matches) != 1:
        raise ProjectValidationError(f"CWS-MARK-001 ManufacturingFace {mark.target_face_id} ontbreekt of is ambigu")
    face = matches[0]
    if face.geometry_hash != mark.target_face_geometry_hash:
        raise ProjectValidationError(f"CWS-MARK-014 ManufacturingFace voor mark {mark.mark_id} is stale")
    return face


def _linked_profile(project: ProjectModel, capability: ManufacturingMachineCapability) -> MachineOptimizationProfile | None:
    if not capability.machine_profile_id:
        return None
    raw = project.profile_nesting_machine_profiles.get(capability.machine_profile_id)
    if not isinstance(raw, dict):
        raise ProjectValidationError(f"CWS-MARK-021 gekoppeld machineprofiel {capability.machine_profile_id} ontbreekt")
    fields = MachineOptimizationProfile.__dataclass_fields__
    profile = MachineOptimizationProfile(**{k: v for k, v in raw.items() if k in fields})
    if profile.machine_id != capability.machine_id:
        raise ProjectValidationError("CWS-MARK-021 machine-ID wijkt af tussen marking capability en nesting machine profile")
    return profile


def _linked_profile_hash(project: ProjectModel, capability: ManufacturingMachineCapability) -> str:
    profile = _linked_profile(project, capability)
    if profile is None:
        return ""
    return str(profile.configuration_hash or profile.refresh_hash())


def _tools_for_capability(project: ProjectModel, capability: ManufacturingMachineCapability) -> dict[str, MarkingToolDefinition]:
    tools: dict[str, MarkingToolDefinition] = {}
    for tool_id in capability.marking_tool_ids:
        raw = project.manufacturing_marking_tools.get(tool_id)
        if not isinstance(raw, dict):
            continue
        tools[tool_id] = MarkingToolDefinition.from_dict(raw)
    return tools


def effective_capability(project: ProjectModel, capability: ManufacturingMachineCapability) -> ManufacturingMachineCapability:
    tools = _tools_for_capability(project, capability)
    hashes = {tool_id: tool.tool_hash for tool_id, tool in tools.items()}
    return capability.with_effective_hash(tool_hashes=hashes, machine_profile_hash=_linked_profile_hash(project, capability))


def _issue(code: str, message: str, mark: ManufacturingMark, *, tool_id: str = "", blocking: bool = True,
           remediation: str = "", details: Mapping[str, Any] | None = None) -> MarkCapabilityIssue:
    return MarkCapabilityIssue(
        code=code, message=message, blocking=blocking, severity="error" if blocking else "warning",
        mark_id=mark.mark_id, part_id=mark.target_part_id, face_id=mark.target_face_id, tool_id=tool_id,
        suggested_remediation=remediation,
        provenance={"engine": M5_ENGINE_VERSION, **dict(details or {})},
    )


def _point_segment_distance(p, a, b) -> float:
    dx=b[0]-a[0];dy=b[1]-a[1];den=dx*dx+dy*dy
    if den <= 1e-18: return math.hypot(p[0]-a[0],p[1]-a[1])
    t=max(0.0,min(1.0,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den))
    q=(a[0]+t*dx,a[1]+t*dy)
    return math.hypot(p[0]-q[0],p[1]-q[1])


def _segment_segment_distance(a,b,c,d) -> float:
    # exact enough for bounded 2D line geometry; return 0 on intersection.
    def orient(p,q,r): return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    def on(p,q,r): return min(p[0],r[0])-1e-9<=q[0]<=max(p[0],r[0])+1e-9 and min(p[1],r[1])-1e-9<=q[1]<=max(p[1],r[1])+1e-9
    o1,o2,o3,o4=orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)
    if ((o1>1e-9 and o2<-1e-9) or (o1<-1e-9 and o2>1e-9)) and ((o3>1e-9 and o4<-1e-9) or (o3<-1e-9 and o4>1e-9)):
        return 0.0
    if abs(o1)<=1e-9 and on(a,c,b): return 0.0
    if abs(o2)<=1e-9 and on(a,d,b): return 0.0
    if abs(o3)<=1e-9 and on(c,a,d): return 0.0
    if abs(o4)<=1e-9 and on(c,b,d): return 0.0
    return min(_point_segment_distance(a,c,d),_point_segment_distance(b,c,d),_point_segment_distance(c,a,b),_point_segment_distance(d,a,b))


def _geometry_segments_and_points(mark: ManufacturingMark) -> tuple[list[tuple[tuple[float,float],tuple[float,float]]], list[tuple[float,float]]]:
    segments=[];points=[]
    def visit(g):
        if g.kind == MarkGeometryKind.LINE.value and len(g.points)==2: segments.append((g.points[0],g.points[1]))
        elif g.kind == MarkGeometryKind.POLYLINE.value:
            for i in range(len(g.points)-1): segments.append((g.points[i],g.points[i+1]))
            if g.closed and len(g.points)>2: segments.append((g.points[-1],g.points[0]))
        elif g.kind in {MarkGeometryKind.POINT.value,MarkGeometryKind.TEXT_ANCHOR.value,MarkGeometryKind.SYMBOL_ANCHOR.value} and g.points:
            points.append(g.points[0])
        elif g.kind == MarkGeometryKind.COMPOUND.value:
            for child in g.components: visit(child)
        elif g.kind in {MarkGeometryKind.CIRCLE.value,MarkGeometryKind.ARC.value} and g.center is not None:
            # conservative samples are only for reach/clearance; exact curved machine
            # execution remains a later adapter concern.
            steps=16
            start=0.0 if g.kind==MarkGeometryKind.CIRCLE.value else g.start_angle_deg
            end=360.0 if g.kind==MarkGeometryKind.CIRCLE.value else g.end_angle_deg
            sweep=(end-start)%360.0 if g.kind==MarkGeometryKind.ARC.value else 360.0
            samples=[]
            for i in range(steps+1):
                ang=math.radians(start+sweep*i/steps);samples.append((g.center[0]+g.radius_mm*math.cos(ang),g.center[1]+g.radius_mm*math.sin(ang)))
            for i in range(len(samples)-1):segments.append((samples[i],samples[i+1]))
    visit(mark.geometry_2d)
    # M4 semantic text has no glyph geometry; the placement envelope is deterministic
    # provenance and therefore usable for physical head clearance.
    rect=mark.provenance.get("placement_envelope_mm") if isinstance(mark.provenance,Mapping) else None
    if mark.geometry_2d.kind==MarkGeometryKind.TEXT_ANCHOR.value and isinstance(rect,(list,tuple)) and len(rect)==4:
        try:
            u0,v0,u1,v1=(float(x) for x in rect);corners=[(u0,v0),(u1,v0),(u1,v1),(u0,v1)]
            segments.extend((corners[i],corners[(i+1)%4]) for i in range(4));points.extend(corners)
        except Exception: pass
    return segments,points


def _geometry_bounds(mark: ManufacturingMark) -> tuple[float,float,float,float]:
    segments,points=_geometry_segments_and_points(mark)
    vals=[p for seg in segments for p in seg]+points
    if not vals:
        raise ProjectValidationError(f"Mark {mark.mark_id} heeft geen bereikbare 2D-geometrie")
    return (min(p[0] for p in vals),min(p[1] for p in vals),max(p[0] for p in vals),max(p[1] for p in vals))


def _minimum_boundary_distance(mark: ManufacturingMark, face: ManufacturingFace) -> float:
    polygon=line_face_outer_polygon(face);edges=[(polygon[i],polygon[(i+1)%len(polygon)]) for i in range(len(polygon))]
    segments,points=_geometry_segments_and_points(mark)
    distances=[]
    for p in points:distances.extend(_point_segment_distance(p,*edge) for edge in edges)
    for seg in segments:distances.extend(_segment_segment_distance(*seg,*edge) for edge in edges)
    return min(distances) if distances else 0.0


def _segment_hits_circle(a,b,center,radius) -> bool:
    return _point_segment_distance(center,a,b) < float(radius)-1e-8


def _point_in_rect(p,rect): return rect[0]-1e-9<=p[0]<=rect[2]+1e-9 and rect[1]-1e-9<=p[1]<=rect[3]+1e-9


def _segment_hits_rect(a,b,rect) -> bool:
    if _point_in_rect(a,rect) or _point_in_rect(b,rect):return True
    c=[(rect[0],rect[1]),(rect[2],rect[1]),(rect[2],rect[3]),(rect[0],rect[3])]
    return any(_segment_segment_distance(a,b,c[i],c[(i+1)%4])<=1e-9 for i in range(4))


def _head_collision(mark: ManufacturingMark, project: ProjectModel, face: ManufacturingFace, clearance: float,
                    capability: ManufacturingMachineCapability) -> tuple[bool,list[str]]:
    if clearance <= 1e-9 and not capability.forbidden_face_zones:
        return False,[]
    part=project.parts[mark.target_part_id];segments,points=_geometry_segments_and_points(mark);hits=[]
    # physical holes expanded by head clearance
    for zone in target_hole_zones(part,face,clearance):
        if any(_segment_hits_circle(a,b,zone["center"],zone["radius_mm"]) for a,b in segments) or any(math.hypot(p[0]-zone["center"][0],p[1]-zone["center"][1]) < zone["radius_mm"]-1e-8 for p in points):hits.append(str(zone["id"]))
    # explicit weld zones expanded by clearance
    for zone in target_weld_zones(part,face,clearance):
        if zone.get("kind")=="circle":
            if any(_segment_hits_circle(a,b,zone["center"],zone["radius_mm"]) for a,b in segments) or any(math.hypot(p[0]-zone["center"][0],p[1]-zone["center"][1]) < zone["radius_mm"]-1e-8 for p in points):hits.append(str(zone["id"]))
        elif zone.get("kind")=="rect":
            rect=tuple(zone["rect"])
            if any(_segment_hits_rect(a,b,rect) for a,b in segments) or any(_point_in_rect(p,rect) for p in points):hits.append(str(zone["id"]))
    for zone in capability.forbidden_face_zones.get(face.semantic_role,()):
        kind=str(zone.get("kind") or "")
        if kind=="circle":
            center=(float(zone.get("u_mm") or 0.0),float(zone.get("v_mm") or 0.0));radius=float(zone.get("radius_mm") or 0.0)+clearance
            if any(_segment_hits_circle(a,b,center,radius) for a,b in segments) or any(math.hypot(p[0]-center[0],p[1]-center[1]) < radius-1e-8 for p in points):hits.append(str(zone.get("id") or "machine-circle"))
        elif kind=="rect":
            rect=(float(zone.get("u0_mm") or 0.0)-clearance,float(zone.get("v0_mm") or 0.0)-clearance,float(zone.get("u1_mm") or 0.0)+clearance,float(zone.get("v1_mm") or 0.0)+clearance)
            rect=(min(rect[0],rect[2]),min(rect[1],rect[3]),max(rect[0],rect[2]),max(rect[1],rect[3]))
            if any(_segment_hits_rect(a,b,rect) for a,b in segments) or any(_point_in_rect(p,rect) for p in points):hits.append(str(zone.get("id") or "machine-rect"))
    return bool(hits),sorted(set(hits))


def _approach_matches(face: ManufacturingFace, capability: ManufacturingMachineCapability, tool: MarkingToolDefinition | None) -> bool:
    vectors=tuple(capability.canonical_approach_vectors_by_face_role.get(face.semantic_role,()))
    if not vectors and tool is not None:vectors=tool.approach_vectors
    if not vectors:return True
    normal=face.local_frame.normal
    return any(sum(a*b for a,b in zip(normal,v)) >= 1.0-1e-6 for v in vectors)


def _select_tool(project: ProjectModel, capability: ManufacturingMachineCapability, operation: str) -> tuple[MarkingToolDefinition | None,list[MarkCapabilityIssue]]:
    ids=tuple(capability.operation_tool_ids.get(operation,())) or capability.marking_tool_ids
    issues=[]
    for tool_id in ids:
        raw=project.manufacturing_marking_tools.get(tool_id)
        if not isinstance(raw,dict):continue
        tool=MarkingToolDefinition.from_dict(raw)
        if tool.status!="active" or tool.maintenance_status!="ok" or tool.validation_status!=MarkingCapabilityValidationStatus.VALIDATED.value:continue
        if tool.allowed_machine_ids and capability.machine_id not in tool.allowed_machine_ids:continue
        if tool.allowed_station_ids and capability.station_id not in tool.allowed_station_ids:continue
        if operation not in tool.supported_operations:continue
        return tool,issues
    return None,issues


def m5_source_snapshot(project: ProjectModel, assembly_id: str, capability: ManufacturingMachineCapability) -> dict[str,Any]:
    mark_state=validate_persisted_mark_state(project,assembly_id,require_current=True)
    ruleset=load_ruleset(project,str(mark_state.get("ruleset_id") or ""))
    effective=effective_capability(project,capability)
    tools=_tools_for_capability(project,capability)
    return {
        "schema_version":M5_SOURCE_SNAPSHOT_VERSION,
        "project_id":project.project_id,
        "assembly_id":assembly_id,
        "mark_set_hash":str(mark_state.get("mark_set_hash") or ""),
        "mark_source_snapshot_hash":str(mark_state.get("source_snapshot_hash") or ""),
        "ruleset_id":ruleset.ruleset_id,"ruleset_hash":ruleset.ruleset_hash,
        "capability_id":effective.capability_id,"machine_id":effective.machine_id,
        "machine_marking_capability_hash":effective.capability_hash,
        "marking_tool_hashes":{k:v.tool_hash for k,v in sorted(tools.items())},
        "linked_machine_profile_hash":_linked_profile_hash(project,effective),
    }


def m5_source_snapshot_hash(project: ProjectModel, assembly_id: str, capability: ManufacturingMachineCapability) -> str:
    return stable_sha256(m5_source_snapshot(project,assembly_id,capability))


@dataclass
class MachineMarkingEvaluationReport:
    assembly_id: str
    capability_id: str
    machine_id: str
    capability_hash: str
    mark_set_hash: str
    source_snapshot_hash: str
    feasible: bool
    review_required: bool
    proofs: list[MarkCapabilityProof]
    issues: list[MarkCapabilityIssue]
    report_hash: str = ""

    def to_dict(self)->dict[str,Any]:
        payload={
            "schema_version":"1.0","phase":"M5","assembly_id":self.assembly_id,"capability_id":self.capability_id,
            "machine_id":self.machine_id,"machine_marking_capability_hash":self.capability_hash,"mark_set_hash":self.mark_set_hash,
            "source_snapshot_hash":self.source_snapshot_hash,"feasible":self.feasible,"review_required":self.review_required,
            "proofs":[p.to_dict() for p in self.proofs],"issues":[i.to_dict() for i in self.issues],
            "requires_m6_rebind":True,"dstv_si_released":False,"machine_output_released":False,
        }
        payload["report_hash"]=self.report_hash or machine_marking_report_hash(payload)
        return payload


class MachineMarkingCapabilityEngine:
    def evaluate(self, project: ProjectModel, assembly_id: str, capability: ManufacturingMachineCapability) -> MachineMarkingEvaluationReport:
        state=validate_persisted_mark_state(project,assembly_id,require_current=True)
        ruleset=load_ruleset(project,str(state.get("ruleset_id") or ""))
        if ruleset.validation_status!="validated":raise ProjectValidationError("CWS-MARK-013 ruleset not validated")
        capability=effective_capability(project,capability)
        marks=load_assembly_marks(project,assembly_id)
        global_issues=[];proofs=[]
        if not capability.enabled or capability.validation_status!=MarkingCapabilityValidationStatus.VALIDATED.value:
            # explicit blocker, never silently treat a draft machine as usable.
            for mark in marks:global_issues.append(_issue("CWS-MARK-021",f"Machine marking capability {capability.capability_id} is niet gevalideerd",mark,remediation="Valideer het machineprofiel met eigenaar-/machine-evidence."))
        if ruleset.applicable_machine_ids and capability.machine_id not in ruleset.applicable_machine_ids:
            for mark in marks:global_issues.append(_issue("CWS-MARK-024",f"Ruleset {ruleset.ruleset_id} is niet vrijgegeven voor machine {capability.machine_id}",mark,remediation="Koppel een gevalideerde machine aan de ruleset."))
        for mark in marks:
            issues=[];operation=_requested_operation(mark)
            try:face=_face_for_mark(project,mark)
            except ProjectValidationError as exc:
                issues.append(_issue("CWS-MARK-001",str(exc),mark));
                proofs.append(MarkCapabilityProof(mark.mark_id,capability.machine_id,capability.capability_id,operation,mark.target_part_id,mark.target_face_id,"","",False,False,issues=tuple(issues),evidence={"engine":M5_ENGINE_VERSION}));continue
            operation_supported=operation in capability.supported_mark_operations and (not capability.supported_mark_types or mark.mark_type in capability.supported_mark_types)
            if not operation_supported:issues.append(_issue("CWS-MARK-009",f"Machine {capability.machine_id} ondersteunt {operation}/{mark.mark_type} niet",mark,remediation="Kies een machine/tool die dit marktype expliciet ondersteunt."))
            face_reachable=face.semantic_role in capability.supported_face_roles and face.semantic_role not in capability.forbidden_face_roles
            if face.semantic_role in _INTERNAL_FACE_ROLES and capability.internal_face_policy==InternalFacePolicy.BLOCKED.value:face_reachable=False
            if not face_reachable:issues.append(_issue("CWS-MARK-008",f"ManufacturingFace {face.semantic_role} is niet bereikbaar op machine {capability.machine_id}",mark,remediation="Kies een andere oriëntatie/machine of valideer een expliciete face capability."))
            review_required=face.semantic_role in _INTERNAL_FACE_ROLES and capability.internal_face_policy==InternalFacePolicy.REVIEW.value
            surface_ok=face.surface_type in capability.supported_surface_types
            rotational_ok=True
            if face.surface_type==ManufacturingSurfaceType.CYLINDER.value:
                rotational_ok=capability.rotational_marking_supported
                if not rotational_ok:issues.append(_issue("CWS-MARK-025","Cylindrische markering vereist expliciete rotational marking capability",mark,remediation="Gebruik een machine met gevalideerde rotational marking."))
            elif not surface_ok:issues.append(_issue("CWS-MARK-008",f"Surface type {face.surface_type} wordt niet ondersteund",mark))
            tool,_=_select_tool(project,capability,operation)
            if tool is None:
                issues.append(_issue("CWS-MARK-022",f"Geen actieve, gevalideerde marking tool voor operation {operation}",mark,remediation="Registreer/valideer een geschikte marking tool."))
            approach_ok=_approach_matches(face,capability,tool)
            if not approach_ok:issues.append(_issue("CWS-MARK-008",f"Tool approach vector kan face {face.semantic_role} niet bereiken",mark,tool_id=tool.tool_id if tool else ""))
            transverse_ok=True
            try:u0,v0,u1,v1=_geometry_bounds(mark)
            except ProjectValidationError as exc:
                issues.append(_issue("CWS-MARK-008",str(exc),mark));u0=v0=u1=v1=0.0;transverse_ok=False
            if capability.min_reachable_u_mm is not None and u0 < capability.min_reachable_u_mm-1e-8:transverse_ok=False
            if capability.max_reachable_u_mm is not None and u1 > capability.max_reachable_u_mm+1e-8:transverse_ok=False
            if capability.min_reachable_v_mm is not None and v0 < capability.min_reachable_v_mm-1e-8:transverse_ok=False
            if capability.max_reachable_v_mm is not None and v1 > capability.max_reachable_v_mm+1e-8:transverse_ok=False
            if not transverse_ok:issues.append(_issue("CWS-MARK-008","Mark ligt buiten het gevalideerde machine-reach envelope",mark,tool_id=tool.tool_id if tool else "",details={"mark_bounds_uv":[u0,v0,u1,v1]}))
            head_clearance_ok=True;minimum_distance=0.0;clearance=0.0;collision_ids=[]
            if face.surface_type==ManufacturingSurfaceType.PLANE.value:
                try:
                    minimum_distance=_minimum_boundary_distance(mark,face)
                    clearance=max(float(capability.face_role_clearance_mm.get(face.semantic_role,0.0)),float(tool.minimum_edge_distance_mm if tool else 0.0),float(tool.physical_clearance_radius_mm if tool else 0.0))
                    if minimum_distance+1e-8 < clearance:
                        head_clearance_ok=False;issues.append(_issue("CWS-MARK-023",f"Marking head clearance {minimum_distance:.3f} mm < vereist {clearance:.3f} mm",mark,tool_id=tool.tool_id if tool else "",remediation="Verplaats mark, kies kleinere head of andere face."))
                    hit,collision_ids=_head_collision(mark,project,face,float(tool.physical_clearance_radius_mm if tool else 0.0),capability)
                    if hit:
                        head_clearance_ok=False;issues.append(_issue("CWS-MARK-023",f"Marking head collision envelope raakt verboden zone(s): {', '.join(collision_ids)}",mark,tool_id=tool.tool_id if tool else ""))
                except ProjectValidationError as exc:
                    head_clearance_ok=False;issues.append(_issue("CWS-MARK-023",str(exc),mark,tool_id=tool.tool_id if tool else ""))
            if tool is not None and mark.depth_mm > 0.0 and tool.maximum_mark_depth_mm > 0.0 and mark.depth_mm > tool.maximum_mark_depth_mm+1e-9:
                issues.append(_issue("CWS-MARK-022",f"Gevraagde markdiepte {mark.depth_mm:g} mm overschrijdt toolmaximum {tool.maximum_mark_depth_mm:g} mm",mark,tool_id=tool.tool_id))
            blocking=any(i.blocking for i in issues) or any(i.blocking and i.mark_id==mark.mark_id for i in global_issues)
            proof_issues=tuple([i for i in global_issues if i.mark_id==mark.mark_id]+issues)
            proof=MarkCapabilityProof(
                mark_id=mark.mark_id,machine_id=capability.machine_id,capability_id=capability.capability_id,operation=operation,
                target_part_id=mark.target_part_id,target_face_id=mark.target_face_id,target_face_role=face.semantic_role,target_surface_type=face.surface_type,
                feasible=not blocking,review_required=review_required or any(not i.blocking for i in proof_issues),
                selected_tool_id=tool.tool_id if tool else "",selected_tool_hash=tool.tool_hash if tool else "",face_reachable=face_reachable and surface_ok,
                operation_supported=operation_supported,head_clearance_ok=head_clearance_ok,transverse_reach_ok=transverse_ok,approach_ok=approach_ok,
                rotational_requirement_satisfied=rotational_ok,requires_m6_rebind=True,issues=proof_issues,
                evidence={"engine":M5_ENGINE_VERSION,"scope":"canonical_pre_nesting","mark_bounds_uv_mm":[u0,v0,u1,v1],"minimum_boundary_distance_mm":minimum_distance,"required_head_clearance_mm":clearance,"collision_zone_ids":collision_ids,"face_geometry_hash":face.geometry_hash,"mark_hash":mark.mark_hash},
            )
            proofs.append(proof)
        issues=sorted({(i.code,i.mark_id,i.message,i.tool_id):i for p in proofs for i in p.issues}.values(),key=lambda i:(i.code,i.mark_id,i.message))
        feasible=bool(proofs) and all(p.feasible for p in proofs)
        review=any(p.review_required for p in proofs)
        snapshot=m5_source_snapshot(project,assembly_id,capability);snapshot_hash=stable_sha256(snapshot)
        report=MachineMarkingEvaluationReport(assembly_id,capability.capability_id,capability.machine_id,capability.capability_hash,str(state.get("mark_set_hash") or ""),snapshot_hash,feasible,review,proofs,issues)
        raw=report.to_dict();report.report_hash=str(raw["report_hash"]);return report


__all__=[name for name in globals() if not name.startswith("_")]
