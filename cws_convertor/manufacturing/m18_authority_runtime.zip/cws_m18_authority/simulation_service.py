"""Persistence and stale handling for Scribing M12 offline simulations."""
from __future__ import annotations

from typing import Any

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from .manufacturing_sequence_contracts import ManufacturingSequencePlan
from .manufacturing_sequence_service import validate_persisted_manufacturing_sequence
from .simulation_contracts import M12_SIMULATION_STATE_SCHEMA_VERSION, ManufacturingSimulationReport
from .simulation_engine import M12_PHASE, simulate_sequence
from .simulation_validator import IndependentManufacturingSimulationValidator


def _state_hash(state: dict[str, Any]) -> str:
    return stable_sha256({k: v for k, v in state.items() if k != "state_hash"})


def create_manufacturing_simulation(
    project: ProjectModel,
    sequence_id: str,
    *,
    user: str = "system",
    persist: bool = True,
) -> tuple[ManufacturingSimulationReport, dict[str, Any]]:
    sequence_state = validate_persisted_manufacturing_sequence(project, sequence_id, require_current=True)
    sequence = ManufacturingSequencePlan.from_dict(dict(sequence_state.get("sequence") or {}))
    sequence_state_hash = str(sequence_state.get("state_hash") or "")
    report = simulate_sequence(project, sequence, source_sequence_state_hash=sequence_state_hash)
    validation = IndependentManufacturingSimulationValidator().validate(
        project, sequence, report, expected_sequence_state_hash=sequence_state_hash
    )
    if validation.status != "passed":
        raise ProjectValidationError("CWS-SIM-090 onafhankelijke M12 simulationvalidatie mismatch")

    state = {
        "schema_version": M12_SIMULATION_STATE_SCHEMA_VERSION,
        "phase": M12_PHASE,
        "simulation_id": report.simulation_id,
        "sequence_id": sequence.sequence_id,
        "machine_id": sequence.machine_id,
        "status": "current",
        "feasible": bool(report.feasible),
        "review_required": bool(report.review_required),
        "source_sequence_hash": sequence.sequence_hash,
        "source_sequence_state_hash": sequence_state_hash,
        "report": report.to_dict(),
        "independent_validation": validation.to_dict(),
        "created_at": utc_now_iso(),
        "created_by": user,
        "production_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
    }
    state["state_hash"] = _state_hash(state)
    if persist:
        previous = dict(project.manufacturing_simulations.get(report.simulation_id) or {})
        project.manufacturing_simulations[report.simulation_id] = state
        project.audit(
            "manufacturing.simulation_created",
            user=user,
            entity_id=report.simulation_id,
            before_hash=str(previous.get("state_hash") or ""),
            after_hash=state["state_hash"],
            details={
                "sequence_id": sequence.sequence_id,
                "machine_id": sequence.machine_id,
                "event_count": len(report.events),
                "feasible": report.feasible,
                "production_eligible": False,
            },
        )
    return report, validation.to_dict()


def invalidate_manufacturing_simulations(
    project: ProjectModel,
    *,
    reason: str,
    user: str = "system",
    sequence_id: str | None = None,
) -> None:
    now = utc_now_iso()
    for simulation_id, state in project.manufacturing_simulations.items():
        if not isinstance(state, dict):
            continue
        if sequence_id and str(state.get("sequence_id") or "") != sequence_id:
            continue
        if str(state.get("status") or "") == "stale":
            continue
        state["status"] = "stale"
        state["stale_reason"] = reason
        state["stale_at"] = now
        state["state_hash"] = _state_hash(state)
        project.audit(
            "manufacturing.simulation_invalidated",
            user=user,
            entity_id=simulation_id,
            after_hash=state["state_hash"],
            details={"reason": reason, "sequence_id": state.get("sequence_id", "")},
        )


def validate_persisted_manufacturing_simulation(
    project: ProjectModel,
    simulation_id: str,
    *,
    require_current: bool = False,
) -> dict[str, Any]:
    state = project.manufacturing_simulations.get(simulation_id)
    if not isinstance(state, dict):
        raise ProjectValidationError(f"Onbekende M12 simulation {simulation_id}")
    if str(state.get("schema_version") or "") != M12_SIMULATION_STATE_SCHEMA_VERSION:
        raise ProjectValidationError("Onbekend toekomstig M12 simulation-state schema")
    if str(state.get("phase") or "") != M12_PHASE:
        raise ProjectValidationError("M12 simulation-state phase mismatch")
    if any(bool(state.get(k)) for k in ("production_eligible", "machine_output_released", "direct_machine_transfer")):
        raise ProjectValidationError("M12 simulation mag geen production/machine-output/direct-transfer vrijgeven")
    if str(state.get("state_hash") or "") != _state_hash(state):
        raise ProjectValidationError("M12 simulation state_hash ongeldig")

    report = ManufacturingSimulationReport.from_dict(dict(state.get("report") or {}))
    if report.simulation_id != simulation_id or report.sequence_id != str(state.get("sequence_id") or ""):
        raise ProjectValidationError("M12 simulation identity mismatch")
    validation = dict(state.get("independent_validation") or {})
    stored_report_hash = str(validation.get("report_hash") or "")
    if stored_report_hash != stable_sha256({k: v for k, v in validation.items() if k != "report_hash"}):
        raise ProjectValidationError("M12 independent validation hash ongeldig")
    if str(validation.get("status") or "") != "passed":
        raise ProjectValidationError("M12 persisted independent validation is niet passed")

    sequence_state = validate_persisted_manufacturing_sequence(project, report.sequence_id, require_current=require_current)
    sequence = ManufacturingSequencePlan.from_dict(dict(sequence_state.get("sequence") or {}))
    if report.source_sequence_hash != sequence.sequence_hash:
        raise ProjectValidationError("CWS-SIM-091 M12 simulation bindt niet meer aan current sequence_hash")
    if report.source_sequence_state_hash != str(sequence_state.get("state_hash") or ""):
        if require_current:
            raise ProjectValidationError("CWS-SIM-092 M12 simulation is stale door gewijzigd M7 state_hash")
    if require_current and str(state.get("status") or "") != "current":
        raise ProjectValidationError(f"M12 simulation {simulation_id} heeft status {state.get('status')}")

    current_validation = IndependentManufacturingSimulationValidator().validate(
        project,
        sequence,
        report,
        expected_sequence_state_hash=str(sequence_state.get("state_hash") or ""),
    )
    if current_validation.status != "passed":
        raise ProjectValidationError("CWS-SIM-093 M12 simulation faalt current onafhankelijke validatie")
    return state


def current_simulations_for_sequence(project: ProjectModel, sequence_id: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for simulation_id, state in sorted(project.manufacturing_simulations.items()):
        if not isinstance(state, dict) or str(state.get("sequence_id") or "") != sequence_id:
            continue
        try:
            validate_persisted_manufacturing_simulation(project, simulation_id, require_current=True)
        except Exception:
            continue
        rows.append(dict(state))
    return rows


__all__ = [name for name in globals() if not name.startswith("_")]
