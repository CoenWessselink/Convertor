"""Transactional M5 machine marking capability configuration + evaluation."""
from __future__ import annotations

from dataclasses import replace
from typing import Any, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from .machine_marking_contracts import (
    MarkCapabilityProof, MarkingCapabilityValidationStatus, MarkingToolDefinition, ManufacturingMachineCapability,
    machine_marking_report_hash,
)
from .machine_marking import MachineMarkingCapabilityEngine, effective_capability, m5_source_snapshot, m5_source_snapshot_hash
from .machine_marking_validator import IndependentMachineMarkingValidator
from .marking_service import validate_persisted_mark_state

M5_EVALUATION_STATE_SCHEMA_VERSION="1.0"


def register_marking_tool(project:ProjectModel,tool:MarkingToolDefinition,*,user:str="system",replace_existing:bool=True)->MarkingToolDefinition:
    if tool.tool_id in project.manufacturing_marking_tools and not replace_existing:return MarkingToolDefinition.from_dict(project.manufacturing_marking_tools[tool.tool_id])
    previous=dict(project.manufacturing_marking_tools.get(tool.tool_id) or {})
    project.manufacturing_marking_tools[tool.tool_id]=tool.to_dict()
    project.audit("manufacturing.marking_tool_registered",user=user,entity_id=tool.tool_id,before_hash=str(previous.get("tool_hash") or ""),after_hash=tool.tool_hash,details={"validation_status":tool.validation_status})
    invalidate_machine_marking_evaluations(project,reason=f"marking_tool_changed:{tool.tool_id}",user=user)
    return tool


def load_marking_tool(project:ProjectModel,tool_id:str)->MarkingToolDefinition:
    raw=project.manufacturing_marking_tools.get(tool_id)
    if not isinstance(raw,dict):raise ProjectValidationError(f"Onbekende MarkingTool {tool_id}")
    return MarkingToolDefinition.from_dict(raw)


def register_machine_marking_capability(project:ProjectModel,capability:ManufacturingMachineCapability,*,user:str="system",replace_existing:bool=True)->ManufacturingMachineCapability:
    # Require all referenced tool records before calculating the effective hash.
    missing=[tid for tid in capability.marking_tool_ids if tid not in project.manufacturing_marking_tools]
    if missing:raise ProjectValidationError(f"Machine marking capability verwijst naar ontbrekende tools: {missing}")
    effective=effective_capability(project,capability)
    if capability.capability_id in project.manufacturing_machine_capabilities and not replace_existing:
        return ManufacturingMachineCapability.from_dict(project.manufacturing_machine_capabilities[capability.capability_id])
    previous=dict(project.manufacturing_machine_capabilities.get(capability.capability_id) or {})
    project.manufacturing_machine_capabilities[capability.capability_id]=effective.to_dict()
    project.audit("manufacturing.machine_marking_capability_registered",user=user,entity_id=capability.capability_id,before_hash=str(previous.get("capability_hash") or ""),after_hash=effective.capability_hash,details={"machine_id":effective.machine_id,"validation_status":effective.validation_status})
    invalidate_machine_marking_evaluations(project,reason=f"machine_capability_changed:{capability.capability_id}",user=user)
    return effective


def load_machine_marking_capability(project:ProjectModel,capability_id:str,*,require_current:bool=True)->ManufacturingMachineCapability:
    raw=project.manufacturing_machine_capabilities.get(capability_id)
    if not isinstance(raw,dict):raise ProjectValidationError(f"Onbekende machine marking capability {capability_id}")
    stored=ManufacturingMachineCapability.from_dict(raw);effective=effective_capability(project,stored)
    if require_current and stored.capability_hash!=effective.capability_hash:
        raise ProjectValidationError(f"CWS-MARK-027 machine marking capability {capability_id} is stale")
    return effective


def evaluation_id(assembly_id:str,capability_id:str)->str:
    return "mce-"+stable_sha256({"assembly_id":assembly_id,"capability_id":capability_id})[:24]


def invalidate_machine_marking_evaluations(project:ProjectModel,*,reason:str,user:str="system",assembly_id:str|None=None,capability_id:str|None=None)->None:
    now=utc_now_iso()
    for eid,state in project.manufacturing_machine_mark_evaluations.items():
        if not isinstance(state,dict):continue
        if assembly_id and str(state.get("assembly_id") or "")!=assembly_id:continue
        if capability_id and str(state.get("capability_id") or "")!=capability_id:continue
        if state.get("status") in {"stale","blocked"}:continue
        state["status"]="stale";state["stale_reason"]=reason;state["stale_at"]=now
        state["state_hash"]=stable_sha256({k:v for k,v in state.items() if k!="state_hash"})
        project.audit("manufacturing.machine_marking_evaluation_invalidated",user=user,entity_id=eid,after_hash=state["state_hash"],details={"reason":reason})
    # Any static M5 dependency change invalidates its downstream M6 bar bindings.
    try:
        from .nesting_mark_binding_service import invalidate_nesting_mark_bindings
        invalidate_nesting_mark_bindings(project,reason=f"m5_invalidated:{reason}",user=user,assembly_id=assembly_id,capability_id=capability_id)
    except ImportError:
        pass


def evaluate_assembly_machine(project:ProjectModel,assembly_id:str,capability_id:str,*,user:str="system",persist:bool=True):
    validate_persisted_mark_state(project,assembly_id,require_current=True)
    capability=load_machine_marking_capability(project,capability_id,require_current=True)
    report=MachineMarkingCapabilityEngine().evaluate(project,assembly_id,capability)
    independent=IndependentMachineMarkingValidator().validate(project,assembly_id,capability,report.proofs)
    # Independent validation is a hard gate.  A machine may be infeasible and
    # still have a *valid* proof, therefore validator success is about agreement,
    # not about all marks being feasible.  We persist both states explicitly.
    proof_consistent=not any(i.code=="CWS-MARK-020" for i in independent.issues)
    if not proof_consistent:
        raise ProjectValidationError("CWS-MARK-020 independent machine marking validation mismatch")
    if persist:
        eid=evaluation_id(assembly_id,capability_id);previous=dict(project.manufacturing_machine_mark_evaluations.get(eid) or {})
        raw_report=report.to_dict();raw_validation=independent.to_dict()
        state={
            "schema_version":M5_EVALUATION_STATE_SCHEMA_VERSION,"phase":"M5","evaluation_id":eid,"assembly_id":assembly_id,"capability_id":capability_id,"machine_id":capability.machine_id,
            "status":"current" if proof_consistent else "blocked","feasible":report.feasible,"review_required":report.review_required,
            "machine_marking_capability_hash":capability.capability_hash,"mark_set_hash":report.mark_set_hash,"source_snapshot_hash":report.source_snapshot_hash,
            "source_snapshot":m5_source_snapshot(project,assembly_id,capability),"report":raw_report,"independent_validation":raw_validation,
            "proof_ids":[p.proof_hash for p in report.proofs],"evaluated_at":utc_now_iso(),"evaluated_by":user,
            "requires_m6_rebind":True,"dstv_si_released":False,"machine_output_released":False,
        }
        state["state_hash"]=stable_sha256({k:v for k,v in state.items() if k!="state_hash"})
        project.manufacturing_machine_mark_evaluations[eid]=state
        project.audit("manufacturing.machine_marking_evaluated",user=user,entity_id=eid,before_hash=str(previous.get("state_hash") or ""),after_hash=state["state_hash"],details={"assembly_id":assembly_id,"capability_id":capability_id,"feasible":report.feasible,"proof_count":len(report.proofs),"requires_m6_rebind":True})
    return report,independent


def validate_persisted_machine_marking_evaluation(project:ProjectModel,eid:str,*,require_current:bool=False)->dict[str,Any]:
    state=project.manufacturing_machine_mark_evaluations.get(eid)
    if not isinstance(state,dict):raise ProjectValidationError(f"Onbekende M5 evaluation {eid}")
    if str(state.get("schema_version") or "")!=M5_EVALUATION_STATE_SCHEMA_VERSION:raise ProjectValidationError(f"Onbekend toekomstig M5 evaluation schema {state.get('schema_version')!r}")
    expected_state_hash=stable_sha256({k:v for k,v in state.items() if k!="state_hash"})
    if str(state.get("state_hash") or "")!=expected_state_hash:raise ProjectValidationError(f"M5 evaluation {eid} state_hash ongeldig")
    assembly_id=str(state.get("assembly_id") or "");capability_id=str(state.get("capability_id") or "")
    if evaluation_id(assembly_id,capability_id)!=eid:raise ProjectValidationError(f"M5 evaluation {eid} identity mismatch")
    # Historical M5 evaluations are audit evidence and must remain structurally
    # readable after marks/tools/capabilities change.  Therefore project-level
    # validation (require_current=False) validates the immutable record itself,
    # while only a production/current-use check rebinds it to today's project.
    capability=load_machine_marking_capability(project,capability_id,require_current=require_current)
    report=dict(state.get("report") or {})
    if not report:
        raise ProjectValidationError(f"M5 evaluation {eid} mist report")
    report_hash=str(report.get("report_hash") or "")
    report_payload={k:v for k,v in report.items() if k!="report_hash"}
    if report_hash!=machine_marking_report_hash(report_payload):
        raise ProjectValidationError(f"M5 evaluation {eid} report_hash ongeldig")
    proofs=[MarkCapabilityProof.from_dict(row) for row in report.get("proofs") or []]
    if list(state.get("proof_ids") or []) != [p.proof_hash for p in proofs]:
        raise ProjectValidationError(f"M5 evaluation {eid} proof_ids mismatch")
    stored_validation=dict(state.get("independent_validation") or {})
    if not stored_validation:
        raise ProjectValidationError(f"M5 evaluation {eid} mist independent_validation")
    stored_validation_hash=str(stored_validation.get("report_hash") or "")
    validation_payload={k:v for k,v in stored_validation.items() if k!="report_hash"}
    if stored_validation_hash!=stable_sha256(validation_payload):
        raise ProjectValidationError(f"M5 evaluation {eid} independent_validation hash ongeldig")
    if require_current:
        current_source=m5_source_snapshot_hash(project,assembly_id,capability)
        if str(state.get("source_snapshot_hash") or "")!=current_source:
            raise ProjectValidationError(f"CWS-MARK-027 M5 evaluation {eid} is stale")
        validator=IndependentMachineMarkingValidator().validate(project,assembly_id,capability,proofs)
        if any(i.code=="CWS-MARK-020" for i in validator.issues):
            raise ProjectValidationError(f"CWS-MARK-020 M5 evaluation {eid} faalt onafhankelijke proof-validatie")
        if state.get("status")!="current":
            raise ProjectValidationError(f"M5 evaluation {eid} heeft status {state.get('status')}")
    return state


__all__=[name for name in globals() if not name.startswith("_")]
