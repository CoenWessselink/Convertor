"""Independent validator for persisted M2 contact geometry.

The validator deliberately does not call ContactGeometryEngine._resolve_pair or
its clipping routine.  It verifies persisted evidence from the canonical face
frames, polygons, project graph and relation objects.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .service import load_faces, validate_persisted_face_state
from .contact_contracts import ContactPatch, ContactProofStatus, validate_contact_set
from .contact_geometry import contact_source_snapshot_hash

CONTACT_VALIDATOR_VERSION = "cws-contact-validator-1.0"
CONTACT_VALIDATION_SCHEMA_VERSION = "1.0"


def _dot(a, b): return sum(float(x)*float(y) for x,y in zip(a,b))
def _sub(a,b): return tuple(float(x)-float(y) for x,y in zip(a,b))
def _transform_point(transform, point):
    matrix=transform.matrix; p=tuple(float(x) for x in point)
    return tuple(sum(float(matrix[r][c])*(p[c] if c<3 else 1.0) for c in range(4)) for r in range(3))

def _area(points: Iterable[tuple[float,float]]) -> float:
    pts=list(points)
    if len(pts)<3:return 0.0
    return abs(0.5*sum(pts[i][0]*pts[(i+1)%len(pts)][1]-pts[(i+1)%len(pts)][0]*pts[i][1] for i in range(len(pts))))

def _line_polygon(face: ManufacturingFace) -> list[tuple[float,float]] | None:
    outer=[loop for loop in face.boundary_loops_2d if not loop.is_hole]
    if len(outer)!=1 or any(loop.is_hole for loop in face.boundary_loops_2d):return None
    if any(seg.kind!="line" or seg.start is None for seg in outer[0].segments):return None
    return [(float(seg.start[0]),float(seg.start[1])) for seg in outer[0].segments]

def _point_on_segment(p,a,b,tol):
    cross=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    if abs(cross)>tol*max(1.0,math.hypot(b[0]-a[0],b[1]-a[1])):return False
    dot=(p[0]-a[0])*(p[0]-b[0])+(p[1]-a[1])*(p[1]-b[1])
    return dot<=tol*tol

def _inside_polygon(point, polygon, tol):
    if not polygon:return False
    for i,a in enumerate(polygon):
        if _point_on_segment(point,a,polygon[(i+1)%len(polygon)],tol):return True
    x,y=point; inside=False
    j=len(polygon)-1
    for i in range(len(polygon)):
        xi,yi=polygon[i]; xj,yj=polygon[j]
        if ((yi>y)!=(yj>y)):
            xint=(xj-xi)*(y-yi)/(yj-yi)+xi
            if x<xint:inside=not inside
        j=i
    return inside

@dataclass
class ContactValidationIssue:
    code:str
    message:str
    contact_id:str=""
    blocking:bool=True
    def to_dict(self)->dict[str,Any]:return {"code":self.code,"message":self.message,"contact_id":self.contact_id,"blocking":self.blocking}

@dataclass
class ContactValidationReport:
    assembly_id:str
    status:str
    contact_set_hash:str
    source_snapshot_hash:str
    validator_version:str=CONTACT_VALIDATOR_VERSION
    issues:list[ContactValidationIssue]=field(default_factory=list)
    patch_count:int=0
    report_hash:str=""
    def __post_init__(self):
        payload=self.to_dict(include_hash=False); expected=stable_sha256(payload)
        if self.report_hash and self.report_hash!=expected:raise ProjectValidationError("Contact validation report_hash ongeldig")
        self.report_hash=expected
    def to_dict(self,*,include_hash:bool=True)->dict[str,Any]:
        data={"schema_version":CONTACT_VALIDATION_SCHEMA_VERSION,"assembly_id":self.assembly_id,"status":self.status,"contact_set_hash":self.contact_set_hash,"source_snapshot_hash":self.source_snapshot_hash,"validator_version":self.validator_version,"patch_count":self.patch_count,"issues":[x.to_dict() for x in self.issues]}
        if include_hash:data["report_hash"]=self.report_hash
        return data

class IndependentContactValidator:
    def validate(self,project:ProjectModel,assembly_id:str,patches:Iterable[ContactPatch])->ContactValidationReport:
        assembly=project.assemblies.get(assembly_id)
        if assembly is None:raise ProjectValidationError(f"Onbekende assembly {assembly_id}")
        rows=list(patches); issues:list[ContactValidationIssue]=[]
        try:set_hash=validate_contact_set(assembly_id,rows)
        except ProjectValidationError as exc:
            return ContactValidationReport(assembly_id,"failed","",contact_source_snapshot_hash(project,assembly_id),issues=[ContactValidationIssue("CWS-MARK-002",str(exc))],patch_count=len(rows))
        face_maps:dict[str,dict[str,ManufacturingFace]]={}
        for part_id in set([assembly.main_part_id,*assembly.part_ids]):
            part=project.parts.get(part_id)
            if part is None:continue
            try:validate_persisted_face_state(part,require_current=True)
            except ProjectValidationError as exc:
                issues.append(ContactValidationIssue("CWS-MARK-003",f"Faces van {part_id} niet actueel: {exc}"))
                continue
            face_maps[part_id]={f.face_id:f for f in load_faces(part)}
        for patch in rows:
            self._validate_patch(project,assembly,patch,face_maps,issues)
        status="passed" if not any(x.blocking for x in issues) else "failed"
        return ContactValidationReport(assembly_id,status,set_hash,contact_source_snapshot_hash(project,assembly_id),issues=issues,patch_count=len(rows))

    def _validate_patch(self,project,assembly,patch,face_maps,issues):
        def add(code,msg,blocking=True):issues.append(ContactValidationIssue(code,msg,patch.contact_id,blocking))
        if patch.main_part_id!=assembly.main_part_id:add("CWS-MARK-004","Contact main_part komt niet overeen met assembly main_part")
        if patch.main_part_id not in assembly.part_ids or patch.secondary_part_id not in assembly.part_ids:add("CWS-MARK-005","Contactpart hoort niet bij assembly")
        main=project.parts.get(patch.main_part_id); secondary=project.parts.get(patch.secondary_part_id)
        mf=face_maps.get(patch.main_part_id,{}).get(patch.main_face_id); sf=face_maps.get(patch.secondary_part_id,{}).get(patch.secondary_face_id)
        if not main or not secondary or not mf or not sf:
            add("CWS-MARK-006","Contact verwijst naar ontbrekend part of ManufacturingFace"); return
        if mf.geometry_hash!=patch.main_face_geometry_hash or sf.geometry_hash!=patch.secondary_face_geometry_hash:add("CWS-MARK-008","Contact is niet gebonden aan actuele face geometry hash")
        if mf.surface_type!=ManufacturingSurfaceType.PLANE.value or sf.surface_type!=ManufacturingSurfaceType.PLANE.value:add("CWS-MARK-009","M2-contactvalidator accepteert alleen vlakke contactfaces")
        main_poly=_line_polygon(mf); sec_poly=_line_polygon(sf)
        if not main_poly or not sec_poly:add("CWS-MARK-010","Contactface heeft geen ondersteunde analytische lijnboundary"); return
        mg=mf.local_frame.transformed(main.global_placement); sg=sf.local_frame.transformed(secondary.global_placement)
        tol=patch.tolerance_profile.point_tolerance_mm
        area=_area(patch.projected_boundary_on_main_face)
        if abs(area-patch.area_mm2)>max(1e-4,patch.area_mm2*1e-8):add("CWS-MARK-011","Opgeslagen contactoppervlak wijkt af van onafhankelijke polygonberekening")
        if len(patch.exact_intersection_geometry)!=len(patch.projected_boundary_on_main_face):add("CWS-MARK-012","Contactgeometrie/projectie puntcount mismatch");return
        if patch.intersection_frame != "main_part_local": add("CWS-MARK-025","Contact intersection frame is niet main_part_local"); return
        for i,local_point in enumerate(patch.exact_intersection_geometry):
            point=_transform_point(main.global_placement, local_point)
            mu,mv,mn=mg.local_uvn(point); su,sv,sn=sg.local_uvn(point)
            expm=patch.projected_boundary_on_main_face[i]; exps=patch.projected_boundary_on_secondary_face[i]
            if math.hypot(mu-expm[0],mv-expm[1])>tol:add("CWS-MARK-013",f"Main-face projectiepunt {i} wijkt af")
            if math.hypot(su-exps[0],sv-exps[1])>tol:add("CWS-MARK-014",f"Secondary-face projectiepunt {i} wijkt af")
            if abs(mn)>tol:add("CWS-MARK-015",f"Contactpunt {i} ligt niet op main face")
            if not _inside_polygon((mu,mv),main_poly,tol):add("CWS-MARK-016",f"Contactpunt {i} ligt buiten main face")
            if not _inside_polygon((su,sv),sec_poly,tol):add("CWS-MARK-017",f"Contactprojectiepunt {i} ligt buiten secondary face")
            if patch.proof_status==ContactProofStatus.EXACT.value and abs(sn)>tol:add("CWS-MARK-018",f"Exact contactpunt {i} ligt niet op secondary face")
        normals=_dot(mg.normal,sg.normal)
        gap=abs(_dot(_sub(sg.origin_mm,mg.origin_mm),mg.normal))
        if abs(gap-patch.gap_mm)>tol:add("CWS-MARK-019","Opgeslagen contactgap wijkt af van actuele face planes")
        if patch.proof_status==ContactProofStatus.EXACT.value:
            cos_tol=math.cos(math.radians(patch.tolerance_profile.angular_tolerance_deg))
            if normals>-cos_tol:add("CWS-MARK-020","Exact contact heeft geen tegengestelde face normals")
            if gap>patch.tolerance_profile.plane_distance_mm:add("CWS-MARK-021","Exact contact overschrijdt plane-distance tolerantie")
        pair={patch.main_part_id,patch.secondary_part_id}
        for wid in patch.weld_ids:
            weld=project.welds.get(wid)
            if weld is None or not pair.issubset(set(weld.connected_part_ids)):add("CWS-MARK-022",f"Weldrelatie {wid} koppelt de contactparts niet")
        for fid in patch.fastener_ids:
            fastener=project.fasteners.get(fid)
            if fastener is None or not pair.issubset(set(fastener.connected_part_ids)):add("CWS-MARK-023",f"Fastenerrelatie {fid} koppelt de contactparts niet")
        try:
            restored=ContactPatch.from_dict(patch.to_dict())
            if restored.contact_hash!=patch.contact_hash:add("CWS-MARK-024","ContactPatch roundtrip/hash mismatch")
        except ProjectValidationError as exc:add("CWS-MARK-024",f"ContactPatch contract ongeldig: {exc}")

__all__=["CONTACT_VALIDATOR_VERSION","CONTACT_VALIDATION_SCHEMA_VERSION","ContactValidationIssue","ContactValidationReport","IndependentContactValidator"]
