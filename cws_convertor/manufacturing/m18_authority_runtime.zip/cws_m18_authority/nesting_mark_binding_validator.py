"""Independent validator for Scribing M6 nesting-aware mark bindings.

This module deliberately reconstructs the transform chain from persisted source
records instead of calling :class:`NestingAwareMarkBindingEngine`.  A blocked
binding can be valid evidence; validator success means the persisted proof agrees
with independently reconstructed source truth.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from cws_convertor.optimization.profile_nesting.angle_geometry import build_orientation_variants
from cws_convertor.optimization.profile_nesting.angle_validator import validate_angle_plan
from cws_convertor.optimization.profile_nesting.serialization import input_snapshot_from_dict, plan_from_dict
from cws_convertor.optimization.profile_nesting.units import LengthKernel
from .marking_contracts import ManufacturingMark, MarkGeometryKind
from .marking_service import load_assembly_marks, validate_persisted_mark_state
from .service import load_faces, validate_persisted_face_state
from .machine_marking_contracts import MarkCapabilityProof, ReorientationPolicy
from .machine_marking_service import evaluation_id, load_machine_marking_capability, load_marking_tool, validate_persisted_machine_marking_evaluation
from .nesting_mark_binding_contracts import BoundMarkGeometry3D, NestingMarkBindingIssue, NestingMarkBindingProof, NESTING_MARK_TRANSFORM_CONVENTION

M6_VALIDATOR_VERSION="cws-independent-nesting-mark-binding-validator-v1"


def _issue(message: str, *, mark_id="", piece_id="", code="CWS-MARK-039"):
    return NestingMarkBindingIssue(code=code,message=message,blocking=True,severity="error",mark_id=mark_id,piece_instance_id=piece_id,provenance={"validator":M6_VALIDATOR_VERSION})


def _mv3(m,v):
    return tuple(sum(float(m[i][j])*float(v[j]) for j in range(3)) for i in range(3))

def _mp4(m,p):
    q=(float(p[0]),float(p[1]),float(p[2]),1.0);return tuple(sum(float(m[i][j])*q[j] for j in range(4)) for i in range(3))

def _vv4(m,v):return tuple(sum(float(m[i][j])*float(v[j]) for j in range(3)) for i in range(3))

def _machine_tf(feed, stock):
    if feed=="left_to_right":return ((1.,0.,0.,0.),(0.,1.,0.,0.),(0.,0.,1.,0.),(0.,0.,0.,1.))
    if feed=="right_to_left":return ((-1.,0.,0.,float(stock)),(0.,-1.,0.,0.),(0.,0.,1.,0.),(0.,0.,0.,1.))
    return None


def _face(project, mark):
    part=project.parts[mark.target_part_id];validate_persisted_face_state(part,require_current=True)
    rows=[f for f in load_faces(part) if f.face_id==mark.target_face_id]
    if len(rows)!=1:raise ProjectValidationError("M6 validator face ambiguity")
    return rows[0]


def _variant_hash(marks):
    rows=[]
    for m in sorted(marks,key=lambda x:x.mark_id):
        rows.append({"target_part_id":m.target_part_id,"target_face_id":m.target_face_id,"target_face_geometry_hash":m.target_face_geometry_hash,"mark_type":m.mark_type,"geometry_2d":m.geometry_2d.canonical_dict(),"text_payload":m.text_payload,"text_height_mm":m.text_height_mm,"depth_mm":m.depth_mm,"requested_operation":m.requested_operation,"machine_constraints":dict(m.machine_constraints),"ruleset_hash":m.ruleset_hash})
    return stable_sha256({"contract":"BasePartManufacturingIdentity+AssemblyDerivedMarkingVariant-v1","marks":rows})


def _convert(mark, face, matrix, translation, mtf=None):
    def point(uv):
        p=face.local_frame.part_xyz(float(uv[0]),float(uv[1]),0.0);q=_mv3(matrix,p);q=(q[0]+translation[0],q[1]+translation[1],q[2]+translation[2]);return _mp4(mtf,q) if mtf is not None else q
    def vec(v):
        q=_mv3(matrix,v);return _vv4(mtf,q) if mtf is not None else q
    def rec(g):
        return BoundMarkGeometry3D(kind=g.kind,points_xyz=tuple(point(p) for p in g.points),center_xyz=point(g.center) if g.center is not None else None,radius_mm=g.radius_mm,u_axis_xyz=vec(face.local_frame.u_axis) if g.kind in {MarkGeometryKind.CIRCLE.value,MarkGeometryKind.ARC.value} else None,v_axis_xyz=vec(face.local_frame.v_axis) if g.kind in {MarkGeometryKind.CIRCLE.value,MarkGeometryKind.ARC.value} else None,start_angle_deg=g.start_angle_deg,end_angle_deg=g.end_angle_deg,closed=g.closed,components=tuple(rec(c) for c in g.components),semantic_text=mark.text_payload if g.kind==MarkGeometryKind.TEXT_ANCHOR.value else "")
    return rec(mark.geometry_2d)


def _points(g):
    out=list(g.points_xyz)
    if g.center_xyz is not None:
        out.append(g.center_xyz)
        if g.radius_mm and g.u_axis_xyz and g.v_axis_xyz:
            for deg in [0,90,180,270,g.start_angle_deg,g.end_angle_deg]:
                a=math.radians(deg);out.append(tuple(g.center_xyz[i]+g.radius_mm*(math.cos(a)*g.u_axis_xyz[i]+math.sin(a)*g.v_axis_xyz[i]) for i in range(3)))
    for c in g.components:out+=_points(c)
    return out


def _text_envelope_points(mark, face, matrix, translation):
    """Independently reconstruct the semantic text envelope in the bar frame."""
    raw=mark.provenance.get("placement_envelope_mm") if isinstance(mark.provenance,Mapping) else None
    if not isinstance(raw,(list,tuple)) or len(raw)!=4:
        return []
    try:
        u0,v0,u1,v1=(float(x) for x in raw)
    except Exception:
        return []
    out=[]
    for u,v in ((u0,v0),(u1,v0),(u1,v1),(u0,v1)):
        q=_mv3(matrix,face.local_frame.part_xyz(u,v,0.0))
        out.append((q[0]+translation[0],q[1]+translation[1],q[2]+translation[2]))
    return out


def _common_cut_expectation(mark, bar, placement, xs, ref_start, ref_end, capability, radius):
    by_id={t.transition_id:t for t in bar.transitions}
    common_ids=[]
    precedence=[f"mark:{mark.mark_id}:before_sever:{placement.instance_id}"]
    common_ok=True
    guard=float(capability.sequence_constraints.get("common_cut_mark_guard_mm",max(radius,1.0)) or max(radius,1.0))
    for tid in (placement.transition_before_id,placement.transition_after_id):
        tr=by_id.get(tid)
        if tr is None or not tr.common_cut:
            continue
        cut_x=ref_start if tid==placement.transition_before_id else ref_end
        if xs and min(abs(x-cut_x) for x in xs) <= guard+1e-9:
            common_ids.append(tid)
            blocks=bool(mark.machine_constraints.get("blocks_common_cut")) or bool(mark.provenance.get("requires_distinct_end_reference") if isinstance(mark.provenance,Mapping) else False)
            if blocks:
                common_ok=False
            elif bool(capability.sequence_constraints.get("mark_before_common_cut_supported",False)):
                precedence.append(f"mark:{mark.mark_id}:before_common_cut:{tid}")
            else:
                common_ok=False
    return common_ok,tuple(sorted(common_ids)),tuple(sorted(set(precedence)))


def _zones(profile):
    out=[]
    for i,z in enumerate(profile.get("forbidden_clamp_zones") or []):
        try:a,b=float(z.get("start_mm")),float(z.get("end_mm"));out.append((str(z.get("zone_id") or i),min(a,b),max(a,b)))
        except Exception:pass
    return out

def _grippers(cap):
    out=[];rows=cap.sequence_constraints.get("gripper_zones_mm") or cap.sequence_constraints.get("forbidden_bar_zones_mm") or []
    for i,z in enumerate(rows if isinstance(rows,(list,tuple)) else []):
        try:a,b=float(z.get("start_mm")),float(z.get("end_mm"));out.append((str(z.get("zone_id") or i),min(a,b),max(a,b)))
        except Exception:pass
    return out

def _hit(a,b,zs):return [i for i,x0,x1 in zs if not (max(a,b)<x0-1e-9 or min(a,b)>x1+1e-9)]


@dataclass
class IndependentNestingMarkBindingValidationReport:
    status:str
    run_id:str
    assembly_id:str
    capability_id:str
    issues:list[NestingMarkBindingIssue]
    expected_binding_ids:list[str]
    source_snapshot_hash:str
    report_hash:str=""
    def to_dict(self):
        raw={"schema_version":"1.0","validator":M6_VALIDATOR_VERSION,"status":self.status,"run_id":self.run_id,"assembly_id":self.assembly_id,"capability_id":self.capability_id,"issues":[i.to_dict() for i in self.issues],"expected_binding_ids":self.expected_binding_ids,"source_snapshot_hash":self.source_snapshot_hash}
        raw["report_hash"]=self.report_hash or stable_sha256(raw);return raw


class IndependentNestingMarkBindingValidator:
    def validate(self,project:ProjectModel,run_id:str,assembly_id:str,capability_id:str,bindings:list[NestingMarkBindingProof]|tuple[NestingMarkBindingProof,...]):
        from .nesting_mark_binding import m6_source_snapshot_hash
        rec=project.profile_nesting_runs.get(run_id)
        if not isinstance(rec,dict) or not isinstance(rec.get("plan"),dict):raise ProjectValidationError("CWS-MARK-030 nestingrun ontbreekt")
        snapshot=input_snapshot_from_dict(dict(rec["input_snapshot"]));plan=plan_from_dict(dict(rec["plan"]));pv=validate_angle_plan(snapshot,plan)
        if not pv.valid:raise ProjectValidationError("CWS-MARK-042 nesting plan faalt onafhankelijke validatie")
        cap=load_machine_marking_capability(project,capability_id,require_current=True);m5id=evaluation_id(assembly_id,capability_id);m5=validate_persisted_machine_marking_evaluation(project,m5id,require_current=True)
        m5proofs={str(r.get("mark_id") or ""):MarkCapabilityProof.from_dict(r) for r in dict(m5.get("report") or {}).get("proofs") or []}
        validate_persisted_mark_state(project,assembly_id,require_current=True);marks=load_assembly_marks(project,assembly_id);variant_hash=_variant_hash(marks);asm=project.assemblies[assembly_id];amark=str(asm.assembly_mark or "")
        lines={str(x.get("demand_line_id") or ""):dict(x) for x in rec["input_snapshot"].get("demand_lines") or []};instances={str(x.get("instance_id") or ""):dict(x) for x in rec["input_snapshot"].get("piece_instances") or []}
        placements=[]
        for bar in plan.bars:
            for p in bar.placements:
                ctx={str(x) for x in instances.get(p.instance_id,{}).get("assembly_context") or []}
                if amark and ctx and amark not in ctx:continue
                placements.append((bar,p))
        expected_pairs=[]
        for m in marks:
            for bar,p in placements:
                if p.part_id==m.target_part_id:expected_pairs.append((m,bar,p))
        expected_ids=sorted("nmb-"+stable_sha256({"run":run_id,"assembly":assembly_id,"capability":capability_id,"mark":m.mark_id,"piece":p.instance_id})[:28] for m,b,p in expected_pairs)
        actual={b.binding_id:b for b in bindings};issues=[]
        if sorted(actual)!=expected_ids:issues.append(_issue(f"Binding set mismatch; missing={sorted(set(expected_ids)-set(actual))}, extra={sorted(set(actual)-set(expected_ids))}"))
        profiles={str(p.get("profile_id") or ""):dict(p) for p in dict(rec["input_snapshot"].get("machine_snapshot") or {}).get("profiles") or []};kernel=LengthKernel()
        for mark,bar,p in expected_pairs:
            bid="nmb-"+stable_sha256({"run":run_id,"assembly":assembly_id,"capability":capability_id,"mark":mark.mark_id,"piece":p.instance_id})[:28];binding=actual.get(bid)
            if binding is None:continue
            profile=profiles.get(p.machine_profile_id);line=lines.get(p.demand_line_id)
            if profile is None or line is None:issues.append(_issue("Snapshot machine/demand ontbreekt",mark_id=mark.mark_id,piece_id=p.instance_id));continue
            variants=build_orientation_variants(line,profile,kernel=kernel,require_exact=True);vs=[v for v in variants if v.variant.variant_id==p.orientation_id and v.variant.variant_hash==p.orientation_hash]
            if len(vs)!=1:issues.append(_issue("Orientation reconstructie mismatch",mark_id=mark.mark_id,piece_id=p.instance_id));continue
            v=vs[0].variant;matrix=tuple(tuple(float(x) for x in row) for row in v.transform["matrix"]);tx=kernel.units_to_mm(p.reference_end_units if v.end_for_end else p.reference_start_units);translation=(tx,0.,0.);mtf=_machine_tf(str(profile.get("feed_direction") or "left_to_right"),kernel.units_to_mm(bar.stock_length_units))
            if mtf is None:issues.append(_issue("Feedrichting kan niet onafhankelijk worden gebonden",mark_id=mark.mark_id,piece_id=p.instance_id,code="CWS-MARK-043"));continue
            face=_face(project,mark);bar_geo=_convert(mark,face,matrix,translation,None);machine_geo=_convert(mark,face,matrix,translation,mtf)
            transform_hash=stable_sha256({"convention":NESTING_MARK_TRANSFORM_CONVENTION,"orientation_id":p.orientation_id,"orientation_hash":p.orientation_hash,"orientation_transform":[list(r) for r in matrix],"bar_translation_mm":list(translation),"bar_to_machine_transform":[list(r) for r in mtf],"bar_id":bar.bar_id,"plan_hash":plan.plan_hash})
            artifact=stable_sha256({"contract":"ProductionArtifactIdentity-v1","base_manufacturing_hash":p.manufacturing_hash,"assembly_marking_variant_hash":variant_hash});instance=stable_sha256({"contract":"ProductionInstanceIdentity-v1","production_artifact_identity":artifact,"piece_instance_id":p.instance_id})
            checks={"run_id":run_id,"assembly_id":assembly_id,"capability_id":capability_id,"machine_id":cap.machine_id,"mark_hash":mark.mark_hash,"m5_evaluation_id":m5id,"m5_proof_hash":m5proofs[mark.mark_id].proof_hash,"part_id":p.part_id,"base_manufacturing_hash":p.manufacturing_hash,"piece_instance_id":p.instance_id,"production_artifact_identity":artifact,"production_instance_identity":instance,"assembly_marking_variant_hash":variant_hash,"bar_id":bar.bar_id,"sequence_index":p.sequence_index,"orientation_id":p.orientation_id,"orientation_hash":p.orientation_hash,"transform_chain_hash":transform_hash,"target_face_id":face.face_id,"bar_geometry_hash":bar_geo.geometry_hash,"machine_geometry_hash":machine_geo.geometry_hash}
            actual_checks={"run_id":binding.run_id,"assembly_id":binding.assembly_id,"capability_id":binding.capability_id,"machine_id":binding.machine_id,"mark_hash":binding.mark_hash,"m5_evaluation_id":binding.m5_evaluation_id,"m5_proof_hash":binding.m5_proof_hash,"part_id":binding.part_id,"base_manufacturing_hash":binding.base_manufacturing_hash,"piece_instance_id":binding.piece_instance_id,"production_artifact_identity":binding.production_artifact_identity,"production_instance_identity":binding.production_instance_identity,"assembly_marking_variant_hash":binding.assembly_marking_variant_hash,"bar_id":binding.bar_id,"sequence_index":binding.sequence_index,"orientation_id":binding.orientation_id,"orientation_hash":binding.orientation_hash,"transform_chain_hash":binding.transform_chain_hash,"target_face_id":binding.target_face_id,"bar_geometry_hash":binding.bar_geometry.geometry_hash,"machine_geometry_hash":binding.machine_geometry.geometry_hash}
            for key,val in checks.items():
                if actual_checks.get(key)!=val:issues.append(_issue(f"Persisted M6 binding mismatch {bid}: {key}",mark_id=mark.mark_id,piece_id=p.instance_id))
            # Independently prove essential collision/reach booleans.
            pts=_points(bar_geo)+_text_envelope_points(mark,face,matrix,translation)
            tool=load_marking_tool(project,m5proofs[mark.mark_id].selected_tool_id) if m5proofs[mark.mark_id].selected_tool_id else None
            rad=float(tool.physical_clearance_radius_mm if tool else 0.0)
            xs=[x[0] for x in pts] or [tx]
            clamp=not _hit(min(xs)-rad,max(xs)+rad,_zones(profile));grip=not _hit(min(xs)-rad,max(xs)+rad,_grippers(cap))
            reclamp=bool((not clamp or not grip) and cap.reclamp_supported and cap.sequence_constraints.get("reclamp_clears_forbidden_zones",False))
            expected_clamp=clamp or reclamp;expected_grip=grip or reclamp
            n=_vv4(mtf,_mv3(matrix,face.local_frame.normal));vecs=tuple(cap.canonical_approach_vectors_by_face_role.get(face.semantic_role,()));direct=True if not vecs else any(sum(float(a)*float(b) for a,b in zip(n,w))>=1-1e-6 for w in vecs);reorient=not direct and cap.reorientation_policy in {ReorientationPolicy.AUTOMATIC.value,ReorientationPolicy.MANUAL.value} and cap.reclamp_supported;approach=direct or reorient
            if binding.clamp_clearance_ok!=expected_clamp or binding.gripper_clearance_ok!=expected_grip or binding.transformed_face_reachable!=approach or binding.reorientation_required!=reorient or binding.reclamp_required!=(reclamp or reorient):
                issues.append(_issue(f"Persisted M6 reach/clamp proof mismatch {bid}",mark_id=mark.mark_id,piece_id=p.instance_id))
            expected_common_ok,expected_common_ids,expected_precedence=_common_cut_expectation(mark,bar,p,xs,kernel.units_to_mm(p.reference_start_units),kernel.units_to_mm(p.reference_end_units),cap,rad)
            if binding.common_cut_ok!=expected_common_ok or tuple(binding.common_cut_transition_ids)!=expected_common_ids or tuple(binding.precedence_requirements)!=expected_precedence:
                issues.append(_issue(f"Persisted M6 common-cut/precedence proof mismatch {bid}",mark_id=mark.mark_id,piece_id=p.instance_id,code="CWS-MARK-035"))
            # Feasibility is independently reconstructed from current M5 + M6 hard constraints.
            machine_match=str(profile.get("machine_id") or "")==cap.machine_id and p.machine_id==cap.machine_id
            expected_feasible=bool(m5proofs[mark.mark_id].feasible and machine_match and expected_clamp and expected_grip and approach and expected_common_ok)
            if binding.feasible!=expected_feasible:issues.append(_issue(f"Persisted M6 feasible flag mismatch {bid}",mark_id=mark.mark_id,piece_id=p.instance_id))
        source_hash=m6_source_snapshot_hash(project,run_id,assembly_id,capability_id);status="passed" if not issues else "failed";report=IndependentNestingMarkBindingValidationReport(status,run_id,assembly_id,capability_id,issues,expected_ids,source_hash);report.report_hash=report.to_dict()["report_hash"];return report


__all__=[name for name in globals() if not name.startswith("_")]
