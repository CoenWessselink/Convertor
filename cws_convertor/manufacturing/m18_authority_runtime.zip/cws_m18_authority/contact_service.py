"""Project-bound persistence/orchestration for Scribing M2 contact geometry."""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from cws_convertor.project.model import ProjectModel, ProjectValidationError, utc_now_iso
from .contact_contracts import (
    CONTACT_STATE_SCHEMA_VERSION,
    ContactPatch,
    ContactProofStatus,
    validate_contact_set,
)
from .contact_geometry import (
    CONTACT_GEOMETRY_ENGINE_SCHEMA_VERSION,
    CONTACT_GEOMETRY_ENGINE_VERSION,
    ContactGeometryEngine,
    ContactGeometryReport,
    contact_source_snapshot,
    contact_source_snapshot_hash,
)
from .contact_validator import CONTACT_VALIDATOR_VERSION, IndependentContactValidator


def load_assembly_contacts(project: ProjectModel, assembly_id: str) -> list[ContactPatch]:
    state = dict(project.manufacturing_contact_states.get(assembly_id) or {})
    ids = list(state.get("contact_ids") or [])
    return [ContactPatch.from_dict(project.manufacturing_contact_patches[cid]) for cid in ids if cid in project.manufacturing_contact_patches]


def validate_persisted_contact_state(project: ProjectModel, assembly_id: str, *, require_current: bool = False) -> dict[str, Any]:
    state = dict(project.manufacturing_contact_states.get(assembly_id) or {})
    if not state:
        return {"status": "not_resolved", "patch_count": 0, "current": False}
    if str(state.get("schema_version") or "") != CONTACT_STATE_SCHEMA_VERSION:
        raise ProjectValidationError(f"Assembly {assembly_id} heeft onbekend contact state-schema")
    if str(state.get("engine_schema_version") or "") != CONTACT_GEOMETRY_ENGINE_SCHEMA_VERSION:
        raise ProjectValidationError(f"Assembly {assembly_id} heeft onbekend contact-engine-schema")
    if str(state.get("assembly_id") or "") != assembly_id:
        raise ProjectValidationError("Contact state verwijst naar verkeerde assembly")
    status = str(state.get("status") or "")
    if status not in {"current", "review", "blocked", "stale"}:
        raise ProjectValidationError(f"Onbekende contact state-status {status!r}")
    ids = [str(x) for x in state.get("contact_ids") or []]
    missing = [cid for cid in ids if cid not in project.manufacturing_contact_patches]
    if missing:
        raise ProjectValidationError(f"Contact state van {assembly_id} verwijst naar ontbrekende patches: {missing}")
    patches = [ContactPatch.from_dict(project.manufacturing_contact_patches[cid]) for cid in ids]
    for patch in patches:
        if patch.assembly_id != assembly_id:
            raise ProjectValidationError(f"Contact {patch.contact_id} hoort niet bij assembly {assembly_id}")
    actual_set_hash = validate_contact_set(assembly_id, patches) if patches else ""
    if actual_set_hash != str(state.get("contact_set_hash") or ""):
        raise ProjectValidationError(f"Contact set hash ongeldig voor assembly {assembly_id}")
    current_source = contact_source_snapshot_hash(project, assembly_id)
    current = status in {"current", "review"} and current_source == str(state.get("source_snapshot_hash") or "")
    if status in {"current", "review"} and not current:
        raise ProjectValidationError(f"Contact geometry van assembly {assembly_id} is als actueel gemarkeerd maar broninputs zijn gewijzigd")
    if require_current and not current:
        raise ProjectValidationError(f"Contact geometry van assembly {assembly_id} is niet actueel")
    validation = dict(state.get("validation") or {})
    if patches and validation:
        report_hash = str(validation.get("report_hash") or "")
        payload = dict(validation); payload.pop("report_hash", None)
        from cws_convertor.project.model import stable_sha256
        if report_hash and stable_sha256(payload) != report_hash:
            raise ProjectValidationError(f"Contact validation report hash ongeldig voor assembly {assembly_id}")
    return {
        "status": status,
        "patch_count": len(patches),
        "contact_set_hash": actual_set_hash,
        "source_snapshot_hash": current_source,
        "current": current,
        "proof_status": str(state.get("proof_status") or ""),
        "unresolved_ambiguities": list(state.get("unresolved_ambiguities") or []),
        "warnings": list(state.get("warnings") or []),
        "validation": validation,
    }


def invalidate_contacts_for_part(project: ProjectModel, part_id: str, *, reason: str = "part_or_face_changed") -> list[str]:
    invalidated: list[str] = []
    for assembly_id, state in project.manufacturing_contact_states.items():
        assembly = project.assemblies.get(assembly_id)
        if assembly is None or part_id not in assembly.part_ids:
            continue
        if not isinstance(state, dict) or str(state.get("status") or "") not in {"current", "review"}:
            continue
        state["status"] = "stale"
        state["stale_reason"] = reason
        state["stale_at"] = utc_now_iso()
        invalidated.append(assembly_id)
        try:
            from .marking_service import invalidate_marks_for_assembly
            invalidate_marks_for_assembly(project, assembly_id, reason=f"contact_stale:{reason}")
        except ImportError:
            pass
    return invalidated


def refresh_contact_staleness(project: ProjectModel, *, reason: str = "contact_source_snapshot_changed") -> list[str]:
    """Mark current/review contact states stale when their source snapshot changed.

    This is intentionally a state transition, not silent recomputation.  The
    old ContactPatch evidence stays available for audit/compare, but cannot be
    consumed as current manufacturing intent.
    """
    stale: list[str] = []
    for assembly_id, state in project.manufacturing_contact_states.items():
        if not isinstance(state, dict) or str(state.get("status") or "") not in {"current", "review"}:
            continue
        try:
            actual = contact_source_snapshot_hash(project, assembly_id)
        except Exception:
            actual = ""
        if actual and actual == str(state.get("source_snapshot_hash") or ""):
            continue
        state["status"] = "stale"
        state["stale_reason"] = reason
        state["stale_at"] = utc_now_iso()
        stale.append(assembly_id)
        try:
            from .marking_service import invalidate_marks_for_assembly
            invalidate_marks_for_assembly(project, assembly_id, reason=f"contact_stale:{reason}")
        except ImportError:
            pass
    return stale


def remove_assembly_contacts(project: ProjectModel, assembly_id: str) -> None:
    state = dict(project.manufacturing_contact_states.get(assembly_id) or {})
    for contact_id in list(state.get("contact_ids") or []):
        project.manufacturing_contact_patches.pop(str(contact_id), None)
    project.manufacturing_contact_states.pop(assembly_id, None)


class ContactGeometryService:
    def __init__(self, engine: ContactGeometryEngine | None = None, validator: IndependentContactValidator | None = None) -> None:
        self.engine = engine or ContactGeometryEngine()
        self.validator = validator or IndependentContactValidator()

    def resolve_assembly(self, project: ProjectModel, assembly_id: str, *, user: str = "system", persist: bool = True) -> ContactGeometryReport:
        report = self.engine.resolve_assembly(project, assembly_id)
        validation = self.validator.validate(project, assembly_id, report.patches)
        if report.patches and validation.status != "passed":
            raise ProjectValidationError(
                f"Onafhankelijke contactvalidatie faalde voor assembly {assembly_id}: "
                + "; ".join(item.message for item in validation.issues if item.blocking)
            )
        if persist:
            previous = deepcopy(project.manufacturing_contact_states.get(assembly_id) or {})
            try:
                from .marking_service import invalidate_marks_for_assembly
                invalidate_marks_for_assembly(project, assembly_id, reason="contact_geometry_reresolved")
            except ImportError:
                pass
            remove_assembly_contacts(project, assembly_id)
            for patch in report.patches:
                project.manufacturing_contact_patches[patch.contact_id] = patch.to_dict()
            if report.proof_status == ContactProofStatus.EXACT.value and report.patches:
                status = "current"
            elif report.patches:
                status = "review"
            else:
                status = "blocked"
            state = {
                "schema_version": CONTACT_STATE_SCHEMA_VERSION,
                "engine_schema_version": CONTACT_GEOMETRY_ENGINE_SCHEMA_VERSION,
                "engine_version": CONTACT_GEOMETRY_ENGINE_VERSION,
                "validator_version": CONTACT_VALIDATOR_VERSION,
                "assembly_id": assembly_id,
                "status": status,
                "proof_status": report.proof_status,
                "contact_ids": [item.contact_id for item in report.patches],
                "contact_set_hash": report.contact_set_hash,
                "source_snapshot_hash": report.source_snapshot_hash,
                "source_snapshot": contact_source_snapshot(project, assembly_id),
                "candidate_count": report.candidate_count,
                "unresolved_ambiguities": list(report.unresolved_ambiguities),
                "warnings": list(report.warnings),
                "validation": validation.to_dict(),
                "resolved_at": utc_now_iso(),
                "resolved_by": user or "system",
            }
            project.manufacturing_contact_states[assembly_id] = state
            validate_persisted_contact_state(project, assembly_id)
            project.audit(
                "manufacturing_contacts.resolved",
                user=user or "system",
                entity_id=assembly_id,
                before_hash=str(previous.get("contact_set_hash") or ""),
                after_hash=report.contact_set_hash,
                details={
                    "engine_version": CONTACT_GEOMETRY_ENGINE_VERSION,
                    "validator_version": CONTACT_VALIDATOR_VERSION,
                    "patch_count": len(report.patches),
                    "proof_status": report.proof_status,
                    "validation_status": validation.status,
                    "unresolved_ambiguities": list(report.unresolved_ambiguities),
                },
            )
        return report

    def current_contacts(self, project: ProjectModel, assembly_id: str, *, require_current: bool = True) -> list[ContactPatch]:
        validate_persisted_contact_state(project, assembly_id, require_current=require_current)
        return load_assembly_contacts(project, assembly_id)


__all__ = [
    "ContactGeometryService",
    "load_assembly_contacts",
    "validate_persisted_contact_state",
    "invalidate_contacts_for_part",
    "refresh_contact_staleness",
    "remove_assembly_contacts",
]
