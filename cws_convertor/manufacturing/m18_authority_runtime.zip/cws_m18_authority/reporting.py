"""M10 reporting for manufacturing faces, scribing/marking and export evidence."""
from __future__ import annotations

from pathlib import Path
from datetime import datetime
import csv
import json
from typing import Any, Iterable

from cws_convertor.project.model import ProjectModel, stable_sha256, utc_now_iso

M10_REPORT_SCHEMA_VERSION="1.0"


def _rows(project: ProjectModel, part_ids: Iterable[str] | None = None, *, purchased_item_ids: Iterable[str] | None = None, fastener_ids: Iterable[str] | None = None, weld_ids: Iterable[str] | None = None) -> dict[str,list[dict[str,Any]]]:
    selected=set(part_ids or project.parts.keys())
    selected_purchased=set(purchased_item_ids or ())
    selected_fasteners=set(fastener_ids or ())
    selected_welds=set(weld_ids or ())
    tables={name:[] for name in (
        "Manufacturing Faces","Contact Patches","Scribing Marks","Hole References","Identification",
        "Machine Reachability","Sequence","Simulation","Adapter Rehearsal","Adapter SDK","Certification Batches","Lab Compatibility","Lab Campaigns","Lab Impacts","Lab Artifact Diffs","Lab Candidates","Fleet Sites","Fleet Bindings","Fleet Policies","Approval Signers","External Approvals","Recertification Queue","Deployment Bundles","Airgap Stations","Deployment Control Policies","Rollout Plans","Rollback References","Release Requests","Operator Approvals","Airgap Exports","Import Receipts","Deployment Receipts","Deployment Acknowledgements","Stage Withdrawals","Media Devices","Media Custody Policies","Media Custody Sessions","Media Custody Events","Station Reconciliations","Rollback Drills","Deployment Closures","Adapter Evidence","Adapter Certificates","Certificate Lifecycle","Certificate Revocations","Certificate Supersessions","Suppressed Marks","Marking Validation","Output Mapping","Purchased Items","Fasteners","Welds","Audit",
    )}
    for pid in sorted(selected):
        part=project.parts.get(pid)
        if not part: continue
        for face in part.manufacturing_faces or []:
            tables["Manufacturing Faces"].append({
                "part_id":pid,"part_position":part.part_position,"face_id":face.get("face_id",""),"semantic_role":face.get("semantic_role",""),
                "surface_type":face.get("surface_type",""),"area_mm2":face.get("area_mm2",0),"proof_status":face.get("proof_status",""),
                "geometry_hash":face.get("geometry_hash",""),"dstv_candidates":",".join(str(x.get("dstv_side") or "") for x in face.get("dstv_side_candidates") or []),
            })
    for cid,patch in sorted(project.manufacturing_contact_patches.items()):
        if str(patch.get("main_part_id") or "") not in selected and str(patch.get("secondary_part_id") or "") not in selected: continue
        tables["Contact Patches"].append({"contact_id":cid,"assembly_id":patch.get("assembly_id",""),"main_part_id":patch.get("main_part_id",""),"secondary_part_id":patch.get("secondary_part_id",""),"main_face_id":patch.get("main_face_id",""),"secondary_face_id":patch.get("secondary_face_id",""),"relation_type":patch.get("relation_type",""),"proof_status":patch.get("proof_status",""),"contact_hash":patch.get("contact_hash","")})
    hole_types={"hole_center_cross","pop_mark","center_punch"};text_types={"position_text","assembly_text","part_text","hard_stamp_request"}
    for mid,mark in sorted(project.manufacturing_marks.items()):
        pid=str(mark.get("target_part_id") or mark.get("part_id") or "")
        if pid not in selected: continue
        row={"mark_id":mid,"assembly_id":mark.get("assembly_id",""),"part_id":pid,"mark_type":mark.get("mark_type",""),"target_face_id":mark.get("target_face_id",""),"source_part_id":mark.get("source_part_id",""),"purpose":mark.get("purpose",""),"text":mark.get("text_payload",""),"status":mark.get("review_status",""),"requested_operation":mark.get("requested_operation",""),"mark_hash":mark.get("mark_hash","")}
        tables["Scribing Marks"].append(row)
        if row["mark_type"] in hole_types: tables["Hole References"].append(dict(row))
        if row["mark_type"] in text_types: tables["Identification"].append(dict(row))
    for eid,state in sorted(project.manufacturing_machine_mark_evaluations.items()):
        for proof in dict(state.get("report") or state.get("evaluation") or {}).get("proofs") or []:
            pid=str(proof.get("part_id") or proof.get("target_part_id") or "")
            if pid and pid not in selected: continue
            tables["Machine Reachability"].append({"evaluation_id":eid,"assembly_id":state.get("assembly_id",""),"mark_id":proof.get("mark_id",""),"part_id":pid,"operation":proof.get("operation",""),"face":proof.get("target_face_role") or proof.get("target_face_id",""),"tool":proof.get("selected_tool_id",""),"feasible":proof.get("feasible",False),"review_required":proof.get("review_required",False),"proof_hash":proof.get("proof_hash","")})
    for sid,state in sorted(project.manufacturing_sequences.items()):
        seq=dict(state.get("sequence") or {})
        for op in seq.get("operations") or []:
            if str(op.get("part_id") or "") and str(op.get("part_id")) not in selected: continue
            tables["Sequence"].append({"sequence_id":sid,"operation_id":op.get("operation_id",""),"type":op.get("operation_type",""),"bar_id":op.get("bar_id",""),"piece_instance_id":op.get("piece_instance_id",""),"part_id":op.get("part_id",""),"face_id":op.get("face_id",""),"mark_id":op.get("mark_id",""),"position_mm":op.get("position_mm"),"tool_id":op.get("tool_id",""),"feasible":op.get("feasible",False),"operation_hash":op.get("operation_hash","")})
    for sim_id,state in sorted(project.manufacturing_simulations.items()):
        seq_id=str(state.get("sequence_id") or "");seq_state=dict(project.manufacturing_sequences.get(seq_id) or {});seq=dict(seq_state.get("sequence") or {})
        ops={str(x.get("operation_id") or ""):dict(x) for x in seq.get("operations") or [] if isinstance(x,dict)}
        report=dict(state.get("report") or {})
        for event in report.get("events") or []:
            if not isinstance(event,dict):continue
            op=ops.get(str(event.get("operation_id") or ""),{});pid=str(op.get("part_id") or "")
            if pid and pid not in selected:continue
            tables["Simulation"].append({"simulation_id":sim_id,"sequence_id":seq_id,"event_index":event.get("event_index",0),"operation_id":event.get("operation_id",""),"operation_type":event.get("operation_type",""),"bar_id":event.get("bar_id",""),"piece_instance_id":event.get("piece_instance_id",""),"part_id":pid,"result":event.get("result",""),"state_before_hash":event.get("state_before_hash",""),"state_after_hash":event.get("state_after_hash",""),"simulation_feasible":report.get("feasible",False),"simulation_hash":report.get("simulation_hash","")})
    for rehearsal_id,state in sorted(project.manufacturing_adapter_rehearsals.items()):
        sim_id=str(state.get("simulation_id") or "");sim=dict(project.manufacturing_simulations.get(sim_id) or {});seq_id=str(sim.get("sequence_id") or "");seq=dict(dict(project.manufacturing_sequences.get(seq_id) or {}).get("sequence") or {})
        part_set={str(x.get("part_id") or "") for x in seq.get("operations") or [] if isinstance(x,dict) and str(x.get("part_id") or "")}
        if selected and part_set and not (part_set & selected):continue
        manifest=dict(state.get("manifest") or {});adapter=dict(manifest.get("adapter") or {})
        artifacts=list(manifest.get("artifacts") or []) or [{}]
        for artifact in artifacts:
            tables["Adapter Rehearsal"].append({"rehearsal_id":rehearsal_id,"simulation_id":sim_id,"sequence_id":seq_id,"adapter_id":adapter.get("adapter_id",""),"machine_id":manifest.get("machine_id",""),"controller_id":manifest.get("controller_id",""),"deterministic":manifest.get("deterministic",False),"production_eligible":False,"machine_output_released":False,"artifact":artifact.get("relative_path",""),"artifact_sha256":artifact.get("sha256",""),"manifest_hash":manifest.get("manifest_hash","")})

    for manifest_id,state in sorted(project.manufacturing_adapter_sdk_manifests.items()):
        tables["Adapter SDK"].append({
            "manifest_id":manifest_id,"adapter_id":state.get("adapter_id",""),"adapter_version":state.get("adapter_version",""),
            "machine_id":state.get("machine_id",""),"controller_id":state.get("controller_id",""),"sdk_api_version":state.get("sdk_api_version",""),
            "entrypoint":state.get("entrypoint",""),"features":",".join(str(x) for x in state.get("features") or []),
            "diagnostic_extensions":",".join(str(x) for x in state.get("diagnostic_extensions") or []),
            "adapter_source_commit":state.get("adapter_source_commit",""),"adapter_artifact_sha256":state.get("adapter_artifact_sha256",""),
            "manifest_hash":state.get("manifest_hash",""),"state_hash":state.get("state_hash",""),"machine_output_released":False,"direct_machine_transfer":False,
        })
    for batch_id,state in sorted(project.manufacturing_adapter_certification_batches.items()):
        cases=list(state.get("cases") or []) or [{}]
        for case in cases:
            tables["Certification Batches"].append({
                "batch_id":batch_id,"adapter_id":state.get("adapter_id",""),"case_id":case.get("case_id",""),
                "candidate_case_type":case.get("candidate_case_type",""),"owner_attested":False,"exact_match":case.get("exact_match",False),
                "mismatch_count":case.get("mismatch_count",0),"rehearsal_id":case.get("rehearsal_id",""),
                "rehearsal_manifest_hash":case.get("rehearsal_manifest_hash",""),"golden_hash":case.get("golden_hash",""),
                "diff_report_hash":case.get("diff_report_hash",""),"sdk_semantic_equal":dict(case.get("sdk_diagnostics") or {}).get("semantic_equal"),
                "batch_hash":state.get("batch_hash",""),"certification_eligible":False,"direct_machine_transfer":False,
            })

    for matrix_id,state in sorted(project.manufacturing_adapter_lab_matrices.items()):
        rows=list(state.get("rows") or []) or [{}]
        for row in rows:
            tables["Lab Compatibility"].append({
                "matrix_id":matrix_id,"adapter_id":row.get("adapter_id",""),"adapter_version":row.get("adapter_version",""),
                "machine_id":row.get("machine_id",""),"controller_id":row.get("controller_id",""),"manifest_id":row.get("manifest_id",""),
                "review_status":row.get("review_status",""),"golden_batch_count":row.get("golden_batch_count",0),
                "exact_golden_batch_count":row.get("exact_golden_batch_count",0),"current_certificate_count":row.get("current_certificate_count",0),
                "capability_compatible":row.get("capability_compatible_with_current_certificate",False),
                "capabilities":row.get("capabilities",[]),"certificates":row.get("certificates",[]),"row_hash":row.get("row_hash",""),
                "certification_eligible":False,"direct_machine_transfer":False,
            })
    for campaign_id,state in sorted(project.manufacturing_adapter_lab_campaigns.items()):
        batches=list(state.get("adapter_batches") or []) or [{}]
        for row in batches:
            tables["Lab Campaigns"].append({
                "campaign_id":campaign_id,"adapter_id":row.get("adapter_id",""),"case_count":row.get("case_count",0),
                "exact_count":row.get("exact_count",0),"all_exact":row.get("all_exact",False),"source_batch_hash":row.get("source_batch_hash",""),
                "campaign_hash":state.get("campaign_hash",""),"owner_attested":False,"certification_eligible":False,"direct_machine_transfer":False,
            })
    for impact_id,state in sorted(project.manufacturing_adapter_lab_impacts.items()):
        rows=list(state.get("impacted") or []) or [{}]
        for row in rows:
            tables["Lab Impacts"].append({
                "impact_id":impact_id,"changed_kind":state.get("changed_kind",""),"changed_id":state.get("changed_id",""),
                "object_type":row.get("object_type",""),"object_id":row.get("object_id",""),"adapter_id":row.get("adapter_id",""),
                "current_status":row.get("current_status",""),"impact":row.get("impact",""),"reasons":row.get("reasons",[]),
                "requires_recertification_review":state.get("requires_recertification_review",False),"impact_hash":state.get("impact_hash",""),
                "direct_machine_transfer":False,
            })
    for diff_id,state in sorted(project.manufacturing_adapter_lab_diffs.items()):
        rows=list(state.get("artifacts") or []) or [{}]
        for row in rows:
            tables["Lab Artifact Diffs"].append({
                "diff_id":diff_id,"relative_path":row.get("relative_path",""),"status":row.get("status",""),"exact":row.get("exact",False),
                "review_mode":row.get("review_mode",""),"expected_sha256":row.get("expected_sha256",""),"actual_sha256":row.get("actual_sha256",""),
                "review":row.get("review",{}),"report_hash":state.get("report_hash",""),"state_hash":state.get("state_hash",""),
                "certification_eligible":False,"direct_machine_transfer":False,
            })
    for candidate_id,state in sorted(project.manufacturing_adapter_lab_candidates.items()):
        tables["Lab Candidates"].append({
            "candidate_id":candidate_id,"campaign_id":state.get("campaign_id",""),"matrix_id":state.get("matrix_id",""),
            "output_name":state.get("output_name",""),"output_sha256":state.get("output_sha256",""),"file_count":state.get("file_count",0),
            "impact_ids":state.get("impact_ids",[]),"review_diff_hashes":state.get("review_diff_hashes",[]),
            "review_only":state.get("review_only",False),"owner_attested":False,"certification_eligible":False,
            "machine_output_released":False,"direct_machine_transfer":False,"state_hash":state.get("state_hash",""),
        })

    for site_id,state in sorted(project.manufacturing_fleet_sites.items()):
        tables["Fleet Sites"].append({"site_id":site_id,"name":state.get("name",""),"country_code":state.get("country_code",""),"timezone":state.get("timezone",""),"environment":state.get("environment",""),"status":state.get("status",""),"site_hash":state.get("site_hash",""),"direct_machine_transfer":False})
    for binding_id,state in sorted(project.manufacturing_fleet_machine_bindings.items()):
        current=False;reason=""
        try:
            from .fleet_governance import validate_persisted_fleet_machine_binding
            validate_persisted_fleet_machine_binding(project,binding_id,require_current=True);current=True
        except Exception as exc: reason=str(exc)
        tables["Fleet Bindings"].append({"binding_id":binding_id,"site_id":state.get("site_id",""),"machine_id":state.get("machine_id",""),"controller_id":state.get("controller_id",""),"capability_id":state.get("capability_id",""),"adapter_id":state.get("adapter_id",""),"current_certificate_id":state.get("current_certificate_id",""),"current":current,"current_reason":reason,"binding_hash":state.get("binding_hash",""),"direct_machine_transfer":False})
    for policy_id,state in sorted(project.manufacturing_fleet_policies.items()):
        tables["Fleet Policies"].append({"policy_id":policy_id,"policy_name":state.get("policy_name",""),"site_ids":state.get("site_ids",[]),"trusted_signer_ids":state.get("trusted_signer_ids",[]),"allowed_adapter_ids":state.get("allowed_adapter_ids",[]),"max_approval_age_hours":state.get("maximum_approval_age_hours",0),"max_bundle_age_hours":state.get("maximum_bundle_age_hours",0),"offline_deployment_only":state.get("offline_deployment_bundle_only",False),"policy_hash":state.get("policy_hash",""),"direct_machine_transfer":False})
    for signer_id,state in sorted(project.manufacturing_fleet_trusted_signers.items()):
        tables["Approval Signers"].append({"signer_id":signer_id,"organization":state.get("organization",""),"algorithm":state.get("algorithm",""),"public_key_fingerprint_sha256":state.get("public_key_fingerprint_sha256",""),"valid_from":state.get("valid_from",""),"expires_at":state.get("expires_at",""),"status":state.get("status",""),"signer_hash":state.get("signer_hash",""),"direct_machine_transfer":False})
    for approval_id,state in sorted(project.manufacturing_fleet_external_approvals.items()):
        payload=dict(state.get("payload") or {})
        tables["External Approvals"].append({"approval_id":approval_id,"signer_id":state.get("signer_id",""),"signature_verified":state.get("signature_verified",False),"site_id":payload.get("site_id",""),"binding_id":payload.get("binding_id",""),"certificate_id":payload.get("certificate_id",""),"certified_package_id":payload.get("certified_package_id",""),"issued_at":payload.get("issued_at",""),"expires_at":payload.get("expires_at",""),"approved_action":payload.get("approved_action",""),"approval_hash":state.get("approval_hash",""),"direct_machine_transfer":False})
    for queue_id,state in sorted(project.manufacturing_fleet_recertification_queues.items()):
        entries=list(state.get("entries") or []) or [{}]
        for item in entries:
            tables["Recertification Queue"].append({"queue_id":queue_id,"queue_item_id":item.get("queue_item_id",""),"site_id":item.get("site_id",""),"binding_id":item.get("binding_id",""),"machine_id":item.get("machine_id",""),"adapter_id":item.get("adapter_id",""),"priority":item.get("priority",""),"action":item.get("action",""),"blocking":item.get("blocking",False),"reasons":item.get("reasons",[]),"queue_hash":state.get("queue_hash",""),"direct_machine_transfer":False})
    for deployment_id,state in sorted(project.manufacturing_fleet_deployments.items()):
        tables["Deployment Bundles"].append({"deployment_id":deployment_id,"bundle_filename":state.get("bundle_filename",""),"bundle_sha256":state.get("bundle_sha256",""),"bundle_size_bytes":state.get("bundle_size_bytes",0),"binding_id":state.get("binding_id",""),"policy_id":state.get("policy_id",""),"approval_id":state.get("approval_id",""),"certificate_id":state.get("certificate_id",""),"offline_deployment_bundle_released":state.get("offline_deployment_bundle_released",False),"operator_release_required":state.get("operator_release_required",True),"deployment_transport_authorized":False,"direct_machine_transfer":False,"deployment_record_hash":state.get("deployment_record_hash","")})

    for station_id,state in sorted(project.manufacturing_deployment_stations.items()):
        tables["Airgap Stations"].append({"station_id":station_id,"site_id":state.get("site_id",""),"name":state.get("name",""),"station_signer_id":state.get("station_signer_id",""),"media_policy":state.get("media_policy",""),"status":state.get("status",""),"station_hash":state.get("station_hash",""),"network_controller_transport":False,"direct_machine_transfer":False})
    for policy_id,state in sorted(project.manufacturing_deployment_control_policies.items()):
        tables["Deployment Control Policies"].append({"policy_id":policy_id,"policy_name":state.get("policy_name",""),"fleet_policy_id":state.get("fleet_policy_id",""),"site_ids":state.get("site_ids",[]),"operator_signers":list(dict(state.get("operator_signer_snapshots") or {})),"handoff_signers":list(dict(state.get("handoff_signer_snapshots") or {})),"station_signers":list(dict(state.get("station_signer_snapshots") or {})),"ack_signers":list(dict(state.get("acknowledgement_signer_snapshots") or {})),"minimum_operator_approvals":state.get("minimum_operator_approvals",0),"minimum_acknowledgements":state.get("minimum_acknowledgements",0),"maximum_stage_age_hours":state.get("maximum_stage_age_hours",0),"policy_hash":state.get("policy_hash",""),"deployment_transport_authorized":False,"direct_machine_transfer":False})
    for plan_id,state in sorted(project.manufacturing_deployment_rollout_plans.items()):
        for wave in list(state.get("waves") or []) or [{}]:
            tables["Rollout Plans"].append({"plan_id":plan_id,"plan_name":state.get("plan_name",""),"policy_id":state.get("policy_id",""),"wave_id":wave.get("wave_id",""),"sequence_index":wave.get("sequence_index",0),"site_id":wave.get("site_id",""),"binding_ids":wave.get("binding_ids",[]),"window_start":wave.get("window_start",""),"window_end":wave.get("window_end",""),"requires_previous_wave_ack":wave.get("requires_previous_wave_ack",False),"wave_hash":wave.get("wave_hash",""),"plan_hash":state.get("plan_hash",""),"direct_machine_transfer":False})
    for rollback_id,state in sorted(project.manufacturing_deployment_rollback_references.items()):
        tables["Rollback References"].append({"rollback_id":rollback_id,"binding_id":state.get("binding_id",""),"initial_deployment":state.get("initial_deployment",False),"previous_deployment_id":state.get("previous_deployment_id",""),"previous_bundle_sha256":state.get("previous_bundle_sha256",""),"immutable_rollback_reference":state.get("immutable_rollback_reference",False),"rollback_hash":state.get("rollback_hash",""),"direct_machine_transfer":False})
    for request_id,state in sorted(project.manufacturing_deployment_release_requests.items()):
        tables["Release Requests"].append({"release_request_id":request_id,"deployment_id":state.get("deployment_id",""),"binding_id":state.get("binding_id",""),"control_policy_id":state.get("control_policy_id",""),"rollout_plan_id":state.get("rollout_plan_id",""),"wave_id":state.get("wave_id",""),"rollback_id":state.get("rollback_id",""),"minimum_operator_approvals":state.get("minimum_operator_approvals",0),"release_request_hash":state.get("release_request_hash",""),"operator_release_required":True,"deployment_transport_authorized":False,"direct_machine_transfer":False})
    for approval_id,state in sorted(project.manufacturing_deployment_operator_approvals.items()):
        payload=dict(state.get("payload") or {})
        tables["Operator Approvals"].append({"operator_approval_id":approval_id,"release_request_id":payload.get("release_request_id",""),"signer_id":state.get("signer_id",""),"decision":payload.get("decision",""),"issued_at":payload.get("issued_at",""),"expires_at":payload.get("expires_at",""),"signature_verified":state.get("signature_verified",False),"operator_approval_hash":state.get("operator_approval_hash",""),"deployment_transport_authorized":False,"direct_machine_transfer":False})
    for export_id,state in sorted(project.manufacturing_deployment_airgap_exports.items()):
        tables["Airgap Exports"].append({"airgap_export_id":export_id,"release_request_id":state.get("release_request_id",""),"deployment_id":state.get("deployment_id",""),"station_id":state.get("station_id",""),"wave_id":state.get("wave_id",""),"bundle_filename":state.get("bundle_filename",""),"bundle_sha256":state.get("bundle_sha256",""),"not_before":state.get("not_before",""),"expires_at":state.get("expires_at",""),"verified":state.get("verified",False),"withdrawn":state.get("withdrawn",False),"independent_station_verification_required":True,"airgap_export_record_hash":state.get("airgap_export_record_hash",""),"deployment_transport_authorized":False,"direct_machine_transfer":False})
    for receipt_id,state in sorted(project.manufacturing_deployment_import_receipts.items()):
        payload=dict(state.get("payload") or {})
        tables["Import Receipts"].append({"import_receipt_id":receipt_id,"airgap_export_id":payload.get("airgap_export_id",""),"station_id":payload.get("station_id",""),"signer_id":state.get("signer_id",""),"imported_at":payload.get("imported_at",""),"independent_verification_passed":payload.get("independent_verification_passed",False),"nested_m16_package_valid":payload.get("nested_m16_package_valid",False),"controller_files_applied":False,"machine_observed_by_cws":False,"import_receipt_hash":state.get("import_receipt_hash",""),"direct_machine_transfer":False})
    for receipt_id,state in sorted(project.manufacturing_deployment_receipts.items()):
        payload=dict(state.get("payload") or {})
        tables["Deployment Receipts"].append({"deployment_receipt_id":receipt_id,"import_receipt_id":payload.get("import_receipt_id",""),"binding_id":payload.get("binding_id",""),"deployment_id":payload.get("deployment_id",""),"wave_id":payload.get("wave_id",""),"station_id":payload.get("station_id",""),"signer_id":state.get("signer_id",""),"deployed_at":payload.get("deployed_at",""),"operator_reported_deployment_completed":payload.get("operator_reported_deployment_completed",False),"rollback_ready":payload.get("rollback_ready",False),"machine_observed_by_cws":False,"deployment_receipt_hash":state.get("deployment_receipt_hash",""),"direct_machine_transfer":False})
    for ack_id,state in sorted(project.manufacturing_deployment_acknowledgements.items()):
        payload=dict(state.get("payload") or {})
        tables["Deployment Acknowledgements"].append({"acknowledgement_id":ack_id,"deployment_receipt_id":payload.get("deployment_receipt_id",""),"binding_id":payload.get("binding_id",""),"wave_id":payload.get("wave_id",""),"signer_id":state.get("signer_id",""),"acknowledgement_type":payload.get("acknowledgement_type",""),"acknowledged_at":payload.get("acknowledged_at",""),"immutable_acknowledgement":payload.get("immutable_acknowledgement",False),"machine_observed_by_cws":False,"acknowledgement_hash":state.get("acknowledgement_hash",""),"direct_machine_transfer":False})
    for withdrawal_id,state in sorted(project.manufacturing_deployment_withdrawals.items()):
        payload=dict(state.get("payload") or {})
        tables["Stage Withdrawals"].append({"withdrawal_id":withdrawal_id,"airgap_export_id":state.get("airgap_export_id",""),"signer_id":state.get("signer_id",""),"reason":payload.get("reason",""),"withdrawn_at":payload.get("withdrawn_at",""),"stage_use_prohibited":state.get("stage_use_prohibited",False),"requires_physical_withdrawal_notice_delivery":payload.get("requires_physical_withdrawal_notice_delivery",False),"withdrawal_hash":state.get("withdrawal_hash",""),"deployment_transport_authorized":False,"direct_machine_transfer":False})

    for media_id,state in sorted(project.manufacturing_media_devices.items()):
        identity=dict(state.get("identity") or {})
        tables["Media Devices"].append({"media_id":media_id,"site_id":state.get("site_id",""),"label":state.get("label",""),"manufacturer":identity.get("manufacturer",""),"model":identity.get("model",""),"serial_sha256":identity.get("serial_number_sha256",""),"filesystem_uuid_sha256":identity.get("filesystem_uuid_sha256",""),"capacity_bytes":identity.get("capacity_bytes",0),"physical_identity_hash":state.get("physical_identity_hash",""),"status":state.get("status",""),"media_hash":state.get("media_hash",""),"direct_machine_transfer":False})
    for policy_id,state in sorted(project.manufacturing_media_custody_policies.items()):
        tables["Media Custody Policies"].append({"policy_id":policy_id,"policy_name":state.get("policy_name",""),"station_id":state.get("station_id",""),"site_id":state.get("site_id",""),"custodians":list(dict(state.get("custodian_signer_snapshots") or {})),"minimum_checkout_custodians":state.get("minimum_checkout_custodians",0),"minimum_checkin_custodians":state.get("minimum_checkin_custodians",0),"require_seal":state.get("require_seal",False),"require_station_reconciliation":state.get("require_station_reconciliation",False),"require_rollback_drill_for_closure":state.get("require_rollback_drill_for_closure",False),"policy_hash":state.get("policy_hash",""),"direct_machine_transfer":False})
    for session_id,state in sorted(project.manufacturing_media_custody_sessions.items()):
        try:
            from .deployment_assurance import custody_session_status
            status=custody_session_status(project,session_id)
        except Exception:
            status={}
        tables["Media Custody Sessions"].append({"session_id":session_id,"media_id":state.get("media_id",""),"station_id":state.get("station_id",""),"airgap_export_id":state.get("airgap_export_id",""),"release_request_id":state.get("release_request_id",""),"seal_id_sha256":state.get("seal_id_sha256",""),"checkout_complete":status.get("checkout_complete",False),"checkin_complete":status.get("checkin_complete",False),"event_count":status.get("event_count",0),"session_hash":state.get("session_hash",""),"direct_machine_transfer":False})
    for event_id,state in sorted(project.manufacturing_media_custody_events.items()):
        payload=dict(state.get("payload") or {})
        tables["Media Custody Events"].append({"custody_event_id":event_id,"session_id":payload.get("session_id",""),"media_id":payload.get("media_id",""),"sequence_index":payload.get("sequence_index",0),"event_type":payload.get("event_type",""),"signer_id":state.get("signer_id",""),"previous_event_id":payload.get("previous_event_id",""),"observed_at":payload.get("observed_at",""),"signature_verified":state.get("signature_verified",False),"custody_event_hash":state.get("custody_event_hash",""),"machine_observed_by_cws":False,"direct_machine_transfer":False})
    for reconciliation_id,state in sorted(project.manufacturing_station_reconciliations.items()):
        tables["Station Reconciliations"].append({"reconciliation_id":reconciliation_id,"station_id":state.get("station_id",""),"blocking_issue_count":state.get("blocking_issue_count",0),"reconciliation_passed":state.get("reconciliation_passed",False),"issue_codes":[x.get("code","") for x in state.get("issues") or []],"reconciled_at":state.get("reconciled_at",""),"source_snapshot_hash":state.get("source_snapshot_hash",""),"reconciliation_hash":state.get("reconciliation_hash",""),"machine_observed_by_cws":False,"direct_machine_transfer":False})
    for drill_id,state in sorted(project.manufacturing_rollback_drills.items()):
        payload=dict(state.get("payload") or {})
        tables["Rollback Drills"].append({"rollback_drill_id":drill_id,"rollback_id":payload.get("rollback_id",""),"binding_id":payload.get("binding_id",""),"station_id":payload.get("station_id",""),"signer_id":state.get("signer_id",""),"result":payload.get("result",""),"performed_at":payload.get("performed_at",""),"steps":payload.get("steps",[]),"signature_verified":state.get("signature_verified",False),"rollback_drill_hash":state.get("rollback_drill_hash",""),"machine_observed_by_cws":False,"direct_machine_transfer":False})
    for closure_id,state in sorted(project.manufacturing_deployment_closures.items()):
        tables["Deployment Closures"].append({"closure_id":closure_id,"deployment_receipt_id":state.get("deployment_receipt_id",""),"binding_id":state.get("binding_id",""),"airgap_export_id":state.get("airgap_export_id",""),"station_id":state.get("station_id",""),"media_id":state.get("media_id",""),"custody_session_id":state.get("custody_session_id",""),"closure_status":state.get("closure_status",""),"immutable_closure":state.get("immutable_closure",False),"closed_at":state.get("closed_at",""),"closure_hash":state.get("closure_hash",""),"machine_observed_by_cws":False,"direct_machine_transfer":False})

    for evidence_id,state in sorted(project.manufacturing_adapter_evidence_cases.items()):
        tables["Adapter Evidence"].append({
            "evidence_id": evidence_id, "case_id": state.get("case_id", ""), "case_type": state.get("case_type", ""),
            "adapter_id": state.get("adapter_id", ""), "adapter_version": state.get("adapter_version", ""),
            "machine_id": state.get("machine_id", ""), "controller_id": state.get("controller_id", ""),
            "operation_types": ",".join(str(x) for x in state.get("operation_types") or []),
            "owner_approved": state.get("owner_approved", False), "machine_observed": state.get("machine_observed", False),
            "approved_by": state.get("approved_by", ""), "approved_at": state.get("approved_at", ""),
            "approval_reference": state.get("approval_reference", ""), "downstream_software": state.get("downstream_software", ""),
            "rehearsal_manifest_hash": state.get("rehearsal_manifest_hash", ""), "golden_hash": state.get("golden_hash", ""),
            "attestation_hash": state.get("attestation_hash", ""), "state_hash": state.get("state_hash", ""),
            "machine_output_released": False, "direct_machine_transfer": False,
        })
    for certificate_id,state in sorted(project.manufacturing_adapter_certificates.items()):
        revoked = certificate_id in project.manufacturing_adapter_certificate_revocations
        current = False; current_reason = ""
        try:
            from .adapter_certification import validate_persisted_adapter_certificate
            validate_persisted_adapter_certificate(project, certificate_id, require_current=True); current = True
        except Exception as exc:
            current_reason = str(exc)
        tables["Adapter Certificates"].append({
            "certificate_id": certificate_id, "status": state.get("status", ""), "current": current, "current_reason": current_reason,
            "revoked": revoked, "adapter_id": state.get("adapter_id", ""), "adapter_version": state.get("adapter_version", ""),
            "machine_id": state.get("machine_id", ""), "controller_id": state.get("controller_id", ""),
            "capability_id": state.get("capability_id", ""), "capability_hash": state.get("capability_hash", ""),
            "certification_scope_operations": ",".join(str(x) for x in state.get("certification_scope_operations") or []),
            "evidence_case_ids": ",".join(str(x) for x in state.get("evidence_case_ids") or []),
            "adapter_source_commit": state.get("adapter_source_commit", ""), "adapter_artifact_sha256": state.get("adapter_artifact_sha256", ""),
            "issued_by": state.get("issued_by", ""), "issued_at": state.get("issued_at", ""), "expires_at": state.get("expires_at", ""),
            "certificate_hash": state.get("certificate_hash", ""), "offline_controller_output_certified": state.get("offline_controller_output_certified", False),
            "machine_output_released": False, "direct_machine_transfer": False,
        })
    try:
        from .certification_ops import certificate_lifecycle_status
        for certificate_id in sorted(project.manufacturing_adapter_certificates):
            lifecycle=certificate_lifecycle_status(project,certificate_id)
            tables["Certificate Lifecycle"].append(dict(lifecycle))
    except Exception as exc:
        tables["Certificate Lifecycle"].append({"status":"report_error","reason":str(exc),"direct_machine_transfer":False})

    for certificate_id,state in sorted(project.manufacturing_adapter_certificate_revocations.items()):
        tables["Certificate Revocations"].append({
            "certificate_id": certificate_id, "certificate_hash": state.get("certificate_hash", ""), "reason": state.get("reason", ""),
            "revoked_by": state.get("revoked_by", ""), "revoked_at": state.get("revoked_at", ""),
            "revocation_hash": state.get("revocation_hash", ""), "direct_machine_transfer": False,
        })

    for previous_id,state in sorted(project.manufacturing_adapter_certificate_supersessions.items()):
        tables["Certificate Supersessions"].append({
            "previous_certificate_id":previous_id,"previous_certificate_hash":state.get("previous_certificate_hash",""),
            "new_certificate_id":state.get("new_certificate_id",""),"new_certificate_hash":state.get("new_certificate_hash",""),
            "reason":state.get("reason",""),"superseded_by":state.get("superseded_by",""),"superseded_at":state.get("superseded_at",""),
            "supersession_hash":state.get("supersession_hash",""),"direct_machine_transfer":False,
        })

    for aid,state in sorted(project.manufacturing_mark_states.items()):
        for sup in state.get("suppressions") or []:
            pid=str(sup.get("target_part_id") or "")
            if pid not in selected: continue
            tables["Suppressed Marks"].append({"assembly_id":aid,"suppression_id":sup.get("suppression_id",""),"part_id":pid,"face_id":sup.get("target_face_id",""),"code":sup.get("code",""),"reason":sup.get("reason",""),"rule_id":sup.get("rule_id","")})
        val=dict(state.get("validation") or {})
        tables["Marking Validation"].append({"assembly_id":aid,"status":val.get("status",""),"mark_set_hash":state.get("mark_set_hash",""),"ruleset_hash":state.get("ruleset_hash",""),"accepted_count":state.get("accepted_count",0),"issue_count":len(val.get("issues") or []),"source_snapshot_hash":state.get("source_snapshot_hash","")})
    for xid,state in sorted(project.manufacturing_dstv_roundtrips.items()):
        pid=str(state.get("part_id") or "")
        if pid not in selected: continue
        rt=dict(state.get("roundtrip") or {})
        from .release_gate import scribing_release_manifest_state
        release=scribing_release_manifest_state(project,part_ids=[pid])
        tables["Output Mapping"].append({"artifact_id":xid,"part_id":pid,"phase":"M9/M11","input_sha256":rt.get("input_sha256",""),"output_sha256":rt.get("output_sha256",""),"geometry_preserved":rt.get("input_geometry_hash")==rt.get("output_geometry_hash"),"verified":rt.get("verified",False),"mapping_hashes":",".join(rt.get("mapping_hashes") or []),"m11_release_id":release.get("m11_release_id",""),"production_marking_released":release.get("production_marking_released",False),"machine_output_released":False})
    for pid in sorted(selected_purchased):
        item=project.purchased_items.get(pid)
        if item:
            tables["Purchased Items"].append({"purchased_item_id":pid,"name":item.name,"article_number":item.article_number,"supplier":item.supplier,"manufacturer":item.manufacturer,"material":item.material,"grade":item.grade,"quantity":item.quantity,"unit":item.unit,"purchase_status":item.purchase_status,"assembly_ids":",".join(item.assembly_ids)})
    for fid in sorted(selected_fasteners):
        item=project.fasteners.get(fid)
        if item:
            tables["Fasteners"].append({"fastener_id":fid,"name":item.name,"type":item.fastener_type,"diameter_mm":item.diameter_mm,"grade":item.grade,"length_mm":item.length_mm,"standard":item.standard,"quantity":item.quantity,"connected_part_ids":",".join(item.connected_part_ids)})
    for wid in sorted(selected_welds):
        item=project.welds.get(wid)
        if item:
            tables["Welds"].append({"weld_id":wid,"name":item.name,"type":item.weld_type,"size_mm":item.size_mm,"length_mm":item.length_mm,"process":item.process,"side":item.side,"location":item.location,"connected_part_ids":",".join(item.connected_part_ids)})
    for event in project.audit_log:
        entity=str(getattr(event,"entity_id","") or "")
        if entity and entity not in selected and entity not in project.assemblies: continue
        tables["Audit"].append({"timestamp":getattr(event,"timestamp","") or getattr(event,"timestamp_utc","") or "","action":getattr(event,"action","") or getattr(event,"event_type","") or "","user":getattr(event,"user","") or "","entity_id":entity,"before_hash":getattr(event,"before_hash","") or "","after_hash":getattr(event,"after_hash","") or "","details":json.dumps(getattr(event,"details",{}) or {},ensure_ascii=False,sort_keys=True)})
    return tables


def write_manufacturing_report_xlsx(project: ProjectModel, path: str|Path, *, part_ids: Iterable[str]|None=None, purchased_item_ids: Iterable[str]|None=None, fastener_ids: Iterable[str]|None=None, weld_ids: Iterable[str]|None=None) -> Path:
    import xlsxwriter
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tables=_rows(project,part_ids,purchased_item_ids=purchased_item_ids,fastener_ids=fastener_ids,weld_ids=weld_ids)
    wb=xlsxwriter.Workbook(str(path),{"constant_memory":True});wb.set_properties({"created":datetime(1980,1,1)})
    header=wb.add_format({"bold":True,"bg_color":"#D9EAF7","border":1,"text_wrap":True,"valign":"top"})
    body=wb.add_format({"border":1,"valign":"top"});wrap=wb.add_format({"border":1,"text_wrap":True,"valign":"top"});num=wb.add_format({"border":1,"num_format":"0.00","valign":"top"})
    for name,rows in tables.items():
        ws=wb.add_worksheet(name[:31]);headers=[]
        for row in rows:
            for key in row:
                if key not in headers:headers.append(key)
        if not headers:headers=["status"];rows=[{"status":"no rows"}]
        normalized_rows=[]
        for row in rows:
            normalized={}
            for key in headers:
                value=row.get(key,"")
                if isinstance(value,(dict,list,tuple)):value=json.dumps(value,ensure_ascii=False,sort_keys=True)
                normalized[key]=value
            normalized_rows.append(normalized)
        for c,key in enumerate(headers):ws.write(0,c,key,header)
        for r,row in enumerate(normalized_rows,1):
            for c,key in enumerate(headers):
                value=row.get(key,"")
                if isinstance(value,float):fmt=num
                elif key in {"details","reason","purpose","mapping_hashes","connected_part_ids","assembly_ids","operation_types","certification_scope_operations","evidence_case_ids","current_reason","features","diagnostic_extensions","capabilities","certificates","reasons","review","impact_ids","review_diff_hashes"}:fmt=wrap
                else:fmt=body
                ws.write(r,c,value,fmt)
        ws.freeze_panes(1,0);ws.autofilter(0,0,len(normalized_rows),len(headers)-1)
        for c,key in enumerate(headers):
            lengths=[len(str(row.get(key,""))) for row in normalized_rows]
            observed=max([len(key)]+lengths)+2
            if key.endswith("_hash") or "sha256" in key:
                width=min(68,max(24,observed))
            elif key.endswith("_id") or key in {"mark_id","face_id","artifact_id"}:
                width=min(34,max(16,observed))
            elif key in {"details","reason","purpose","mapping_hashes","connected_part_ids","assembly_ids","operation_types","certification_scope_operations","evidence_case_ids","current_reason","features","diagnostic_extensions","capabilities","certificates","reasons","review","impact_ids","review_diff_hashes"}:
                width=min(48,max(18,observed))
            else:
                width=min(34,max(12,observed))
            ws.set_column(c,c,width)
    wb.close();return path


def write_manufacturing_report_csv(project: ProjectModel, directory: str|Path, *, part_ids: Iterable[str]|None=None, purchased_item_ids: Iterable[str]|None=None, fastener_ids: Iterable[str]|None=None, weld_ids: Iterable[str]|None=None) -> Path:
    root=Path(directory);root.mkdir(parents=True,exist_ok=True)
    for name,rows in _rows(project,part_ids,purchased_item_ids=purchased_item_ids,fastener_ids=fastener_ids,weld_ids=weld_ids).items():
        if not rows: continue
        headers=[]
        for row in rows:
            for key in row:
                if key not in headers:headers.append(key)
        p=root/(name.lower().replace(" ","_")+".csv")
        with p.open("w",encoding="utf-8-sig",newline="") as handle:
            writer=csv.DictWriter(handle,fieldnames=headers);writer.writeheader()
            for row in rows: writer.writerow({k:(json.dumps(v,ensure_ascii=False,sort_keys=True) if isinstance(v,(dict,list,tuple)) else v) for k,v in row.items()})
    return root


def write_scribing_pdf(project: ProjectModel, path: str|Path, *, part_ids: Iterable[str]|None=None) -> Path:
    """Generate a deterministic review PDF with face-local mark overlays.

    It is explicitly a review artifact: no production or machine-release claim.
    """
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);selected=set(part_ids or project.parts.keys())
    c=canvas.Canvas(str(path),pagesize=A4,pageCompression=0,invariant=1);page_w,page_h=A4
    for pid in sorted(selected):
        part=project.parts.get(pid)
        if not part:continue
        marks=[m for m in project.manufacturing_marks.values() if str(m.get("target_part_id") or "")==pid]
        faces={str(f.get("face_id") or ""):f for f in part.manufacturing_faces or []}
        groups={}
        for m in marks:groups.setdefault(str(m.get("target_face_id") or ""),[]).append(m)
        if not groups:groups={"":[]}
        for face_id,face_marks in sorted(groups.items()):
            face=faces.get(face_id,{})
            c.setFont("Helvetica-Bold",12);c.drawString(15*mm,page_h-15*mm,f"CWS Scribing Review - {part.part_position or pid}")
            c.setFont("Helvetica",8);c.drawString(15*mm,page_h-21*mm,f"Part {pid} | Face {face.get('semantic_role') or face_id or '-'} | Manufacturing {part.manufacturing_hash[:16]}")
            c.drawString(15*mm,page_h-26*mm,"REVIEW ONLY - machine output/release is blocked until external owner/Windows evidence")
            # Collect line endpoints from exact line boundary/mark geometry only.
            points=[];segments=[]
            for loop in face.get("boundary_loops_2d") or []:
                for seg in loop.get("segments") or []:
                    if seg.get("kind")=="line" and seg.get("start") and seg.get("end"):
                        a=tuple(map(float,seg["start"]));b=tuple(map(float,seg["end"]));points.extend((a,b));segments.append((a,b,"face"))
            for mark in face_marks:
                geom=dict(mark.get("geometry_2d") or {});kind=str(geom.get("kind") or "")
                if kind=="line" and len(geom.get("points") or [])==2:
                    a=tuple(map(float,geom["points"][0]));b=tuple(map(float,geom["points"][1]));points.extend((a,b));segments.append((a,b,"mark"))
                elif kind=="polyline":
                    ps=[tuple(map(float,p)) for p in geom.get("points") or []];points.extend(ps)
                    segments.extend((ps[i],ps[i+1],"mark") for i in range(len(ps)-1))
                elif kind in {"point","text_anchor","symbol_anchor"} and geom.get("points"):
                    p=tuple(map(float,geom["points"][0]));points.append(p);segments.append((p,p,"point"))
            if not points:points=[(0,0),(100,100)]
            minx=min(p[0] for p in points);maxx=max(p[0] for p in points);miny=min(p[1] for p in points);maxy=max(p[1] for p in points);dx=max(1,maxx-minx);dy=max(1,maxy-miny)
            x0,y0=20*mm,35*mm;boxw,boxh=170*mm,220*mm;scale=min(boxw/dx,boxh/dy)
            def xy(p):return x0+(p[0]-minx)*scale,y0+(p[1]-miny)*scale
            c.setLineWidth(0.4)
            for a,b,kind in segments:
                ax,ay=xy(a);bx,by=xy(b)
                if kind=="face":c.setDash(2,2);c.setLineWidth(0.5)
                elif kind=="mark":c.setDash();c.setLineWidth(1.2)
                else:c.setDash();c.setLineWidth(1.0)
                if kind=="point":c.circle(ax,ay,1.5*mm,stroke=1,fill=0)
                else:c.line(ax,ay,bx,by)
            c.setDash();c.setFont("Helvetica",7);c.drawString(15*mm,12*mm,f"Marks: {len(face_marks)} | Project state {project.modified_at or project.created_at} | report schema {M10_REPORT_SCHEMA_VERSION}")
            c.showPage()
    c.save();return path


def reporting_manifest(project: ProjectModel, files: Iterable[str|Path], *, part_ids: Iterable[str]|None=None, capability_id: str="") -> dict[str,Any]:
    import hashlib
    from .release_gate import scribing_release_manifest_state
    rows=[]
    for raw in files:
        p=Path(raw);rows.append({"name":p.name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"size":p.stat().st_size})
    release=scribing_release_manifest_state(project,part_ids=part_ids,capability_id=capability_id)
    payload={"schema_version":M10_REPORT_SCHEMA_VERSION,"project_id":project.project_id,"created_at":project.modified_at or project.created_at,"files":rows,**release}
    payload["manifest_hash"]=stable_sha256(payload);return payload

__all__=[name for name in globals() if not name.startswith("_")]
