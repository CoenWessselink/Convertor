"""Independent structural validator for persisted Scribing M12 simulations."""
from __future__ import annotations

from typing import Any
import math

from cws_convertor.project.model import ProjectModel, stable_sha256
from .manufacturing_sequence_contracts import ManufacturingSequencePlan, SequenceOperationType
from .simulation_contracts import ManufacturingSimulationReport, SimulationValidationReport


def _independent_blank_bar() -> dict[str, Any]:
    return {
        "loaded": False,
        "clamped": False,
        "unloaded": False,
        "stock_length_mm": None,
        "orientation_changes": 0,
        "reclamps": 0,
        "cut_operation_ids": [],
        "cut_positions_mm": [],
        "processed_operation_ids": [],
        "executed_mark_ids": [],
        "drilled_feature_ids": [],
        "severed_piece_ids": [],
        "unloaded_piece_ids": [],
    }


def _independent_state_hash(states: dict[str, dict[str, Any]]) -> str:
    # Kept local to the independent validator on purpose: do not import the
    # simulation engine's state/hash helpers.
    canonical: dict[str, Any] = {}
    for bar_id in sorted(states):
        row = dict(states[bar_id])
        row["cut_operation_ids"] = list(row.get("cut_operation_ids") or [])
        row["processed_operation_ids"] = list(row.get("processed_operation_ids") or [])
        row["executed_mark_ids"] = list(row.get("executed_mark_ids") or [])
        row["drilled_feature_ids"] = list(row.get("drilled_feature_ids") or [])
        row["severed_piece_ids"] = list(row.get("severed_piece_ids") or [])
        row["unloaded_piece_ids"] = list(row.get("unloaded_piece_ids") or [])
        row["cut_positions_mm"] = [float(x) for x in row.get("cut_positions_mm") or []]
        canonical[bar_id] = row
    return stable_sha256(canonical)


def _independently_replay_feasible_state_chain(sequence: ManufacturingSequencePlan, report: ManufacturingSimulationReport) -> tuple[bool, dict[str, Any]]:
    if not report.feasible:
        return True, {"skipped": "report is blocked/review evidence; exact state-chain replay is mandatory for feasible evidence"}
    op_map = {x.operation_id: x for x in sequence.operations}
    states: dict[str, dict[str, Any]] = {}
    mismatches: list[dict[str, Any]] = []
    mark_types = {
        SequenceOperationType.SCRIBE.value,
        SequenceOperationType.IDENTIFY.value,
        SequenceOperationType.HOLE_REFERENCE.value,
        SequenceOperationType.POP_MARK.value,
        SequenceOperationType.CENTER_PUNCH.value,
    }
    cut_types = {
        SequenceOperationType.SAW_START.value,
        SequenceOperationType.SAW_END.value,
        SequenceOperationType.COMMON_CUT.value,
    }
    process_types = mark_types | {SequenceOperationType.DRILL.value}

    for event in report.events:
        op = op_map.get(event.operation_id)
        if op is None:
            mismatches.append({"operation_id": event.operation_id, "reason": "missing_operation"})
            continue
        bar = states.setdefault(op.bar_id, _independent_blank_bar())
        before = _independent_state_hash(states)
        if event.state_before_hash != before:
            mismatches.append({"operation_id": op.operation_id, "field": "state_before_hash", "expected": before, "actual": event.state_before_hash})

        # A feasible replay cannot contain a blocked event.  Warning/review
        # events still apply state exactly as the engine does.
        if event.result == "blocked":
            mismatches.append({"operation_id": op.operation_id, "reason": "blocked_event_in_feasible_report"})
        kind = op.operation_type
        if kind == SequenceOperationType.LOAD_BAR.value:
            bar["loaded"] = True
            raw_length = dict(op.parameters).get("stock_length_mm")
            if raw_length is not None:
                length = float(raw_length)
                if not math.isfinite(length) or length <= 0:
                    mismatches.append({"operation_id": op.operation_id, "reason": "invalid_stock_length"})
                else:
                    bar["stock_length_mm"] = length
        elif kind == SequenceOperationType.CLAMP.value:
            bar["clamped"] = True
        elif kind == SequenceOperationType.RECLAMP.value:
            bar["reclamps"] += 1
        elif kind == SequenceOperationType.REORIENT.value:
            bar["orientation_changes"] += 1

        if kind in cut_types:
            if op.position_mm is None:
                mismatches.append({"operation_id": op.operation_id, "reason": "missing_cut_position"})
            else:
                bar["cut_operation_ids"].append(op.operation_id)
                bar["cut_positions_mm"].append(float(op.position_mm))
        if kind in process_types:
            bar["processed_operation_ids"].append(op.operation_id)
            if op.mark_id:
                bar["executed_mark_ids"].append(op.mark_id)
            if op.feature_id:
                bar["drilled_feature_ids"].append(op.feature_id)
        if kind == SequenceOperationType.SEVER_PIECE.value:
            bar["severed_piece_ids"].append(op.piece_instance_id)
        elif kind == SequenceOperationType.UNLOAD_PIECE.value:
            bar["unloaded_piece_ids"].append(op.piece_instance_id)
        elif kind == SequenceOperationType.UNLOAD_BAR.value:
            bar["unloaded"] = True
            bar["clamped"] = False

        after = _independent_state_hash(states)
        if event.state_after_hash != after:
            mismatches.append({"operation_id": op.operation_id, "field": "state_after_hash", "expected": after, "actual": event.state_after_hash})

    expected_final_hash = _independent_state_hash(states)
    if report.final_state_hash != expected_final_hash:
        mismatches.append({"field": "final_state_hash_replay", "expected": expected_final_hash, "actual": report.final_state_hash})
    if stable_sha256({k: states[k] for k in sorted(states)}) != stable_sha256(dict(report.final_bar_states or {})):
        mismatches.append({"field": "final_bar_states_replay", "reason": "reconstructed final state differs"})
    return not mismatches, {"mismatch_count": len(mismatches), "mismatches": mismatches[:20]}


class IndependentManufacturingSimulationValidator:
    def validate(
        self,
        project: ProjectModel,
        sequence: ManufacturingSequencePlan,
        report: ManufacturingSimulationReport,
        *,
        expected_sequence_state_hash: str,
    ) -> SimulationValidationReport:
        checks: list[dict[str, Any]] = []

        def add(check_id: str, passed: bool, message: str, details: dict[str, Any] | None = None) -> None:
            checks.append({"check_id": check_id, "status": "passed" if passed else "failed", "message": message, "details": details or {}})

        add("identity", report.sequence_id == sequence.sequence_id and report.machine_id == sequence.machine_id, "Simulation/sequence-identiteit is gebonden")
        add("source_sequence_hash", report.source_sequence_hash == sequence.sequence_hash, "Simulation bindt aan exact M7 sequence_hash")
        add("source_state_hash", report.source_sequence_state_hash == expected_sequence_state_hash, "Simulation bindt aan exact persisted M7 state_hash")
        add("safety_flags", not report.production_eligible and not report.machine_output_released and not report.direct_machine_transfer, "M12 kan geen productie- of transferflag vrijgeven")

        op_map = {x.operation_id: x for x in sequence.operations}
        order = list(sequence.linearized_operation_ids)
        event_ids = [x.operation_id for x in report.events]
        add("event_coverage", event_ids == order and len(event_ids) == len(op_map), "Iedere M7 operation heeft exact één M12 event")

        event_match = True
        event_hashes = True
        event_indices = True
        for i, event in enumerate(report.events):
            op = op_map.get(event.operation_id)
            if op is None or event.operation_type != op.operation_type or event.bar_id != op.bar_id or event.piece_instance_id != op.piece_instance_id or event.operation_hash != op.operation_hash:
                event_match = False
            if event.event_index != i:
                event_indices = False
            try:
                expected = stable_sha256(event.hash_payload())
                if event.event_hash != expected:
                    event_hashes = False
            except Exception:
                event_hashes = False
        add("event_binding", event_match, "Events verwijzen naar exacte M7 operations")
        add("event_indices", event_indices, "Event-indexering is volledig en monotonic")
        add("event_hashes", event_hashes, "Alle event hashes zijn canonical geldig")

        state_chain_ok, state_chain_details = _independently_replay_feasible_state_chain(sequence, report)
        add("independent_state_chain", state_chain_ok, "Feasible M12 events reconstrueren exact dezelfde state-before/state-after-keten zonder enginehelpers", state_chain_details)

        positions = {op_id: i for i, op_id in enumerate(order)}
        deps_ok = all(
            d.predecessor_id in positions
            and d.successor_id in positions
            and positions[d.predecessor_id] < positions[d.successor_id]
            for d in sequence.dependencies
        )
        add("dependency_order", deps_ok, "Alle M7 dependencies worden in replayvolgorde gerespecteerd")

        final_states = dict(report.final_bar_states or {})
        final_hash_ok = report.final_state_hash == stable_sha256(final_states)
        add("final_state_hash", final_hash_ok, "Final replaystate hash is geldig")
        lifecycle_ok = True
        for bar_id, raw in final_states.items():
            bar = dict(raw or {})
            if not bool(bar.get("loaded")) or not bool(bar.get("unloaded")) or bool(bar.get("clamped")):
                lifecycle_ok = False
            severed = set(str(x) for x in bar.get("severed_piece_ids") or [])
            unloaded = set(str(x) for x in bar.get("unloaded_piece_ids") or [])
            if severed != unloaded:
                lifecycle_ok = False
            if len(unloaded) != len(list(bar.get("unloaded_piece_ids") or [])):
                lifecycle_ok = False
        add("final_lifecycle", lifecycle_ok, "Alle gereplayde pieces en bars eindigen volledig uitgeladen")

        marks_ok = True
        for event in report.events:
            if event.operation_type not in {
                SequenceOperationType.SCRIBE.value,
                SequenceOperationType.IDENTIFY.value,
                SequenceOperationType.HOLE_REFERENCE.value,
                SequenceOperationType.POP_MARK.value,
                SequenceOperationType.CENTER_PUNCH.value,
            }:
                continue
            op = op_map.get(event.operation_id)
            if op is None or not op.mark_id or op.mark_id not in project.manufacturing_marks:
                marks_ok = False
                break
        add("canonical_mark_refs", marks_ok, "Alle markevents verwijzen naar current canonical marks")

        issue_consistency = report.feasible == (sequence.feasible and not any(x.blocking for x in report.issues) and all(x.result != "blocked" for x in report.events))
        add("feasibility_consistency", issue_consistency, "M12 feasibility volgt uitsluitend sequence + blocking replayissues")

        simulation_hash_ok = report.simulation_hash == stable_sha256(report.hash_payload())
        add("simulation_hash", simulation_hash_ok, "Simulation report hash is canonical geldig")

        passed = all(x["status"] == "passed" for x in checks)
        return SimulationValidationReport(report.simulation_id, "passed" if passed else "failed", tuple(checks))


__all__ = ["IndependentManufacturingSimulationValidator"]
