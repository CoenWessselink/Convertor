"""Deterministic standard-profile -> canonical ManufacturingFace resolver (M1)."""
from __future__ import annotations
from dataclasses import dataclass, field
import math
from typing import Any, Mapping
from profile_database import ProfileDatabase, normalise_name
from cws_convertor.project.model import Part, stable_sha256
from .contracts import *
from .dstv_faces import DstvFaceMappingAdapter, ExplicitDstvFaceMappingAdapter

FACE_RESOLVER_VERSION="cws-manufacturing-face-resolver-1.0"
FACE_RESOLUTION_SCHEMA_VERSION="1.0"

@dataclass(frozen=True)
class SectionDefinition:
    profile_type:str
    designation:str
    height_mm:float=0.0
    width_mm:float=0.0
    flange_thickness_mm:float=0.0
    web_thickness_mm:float=0.0
    wall_thickness_mm:float=0.0
    diameter_mm:float=0.0
    radius_mm:float=0.0
    proof_status:str=FaceProofStatus.EXACT.value
    source:str=""
    source_payload:Mapping[str,Any]=field(default_factory=dict)

@dataclass
class FaceResolutionReport:
    part_id:str
    faces:list[ManufacturingFace]
    proof_status:str
    unresolved_ambiguities:list[str]=field(default_factory=list)
    warnings:list[str]=field(default_factory=list)
    resolver_version:str=FACE_RESOLVER_VERSION
    source_geometry_hash:str=""
    source_manufacturing_hash:str=""
    @property
    def face_set_hash(self)->str: return face_set_hash(self.part_id,self.faces) if self.faces else ""
    def to_state_dict(self)->dict[str,Any]:
        return {"resolver_schema_version":FACE_RESOLUTION_SCHEMA_VERSION,"resolver_version":self.resolver_version,"part_id":self.part_id,"status":"current" if self.faces and self.proof_status!="blocked" else "blocked","proof_status":self.proof_status,"face_count":len(self.faces),"face_set_hash":self.face_set_hash,"source_geometry_hash":self.source_geometry_hash,"source_manufacturing_hash":self.source_manufacturing_hash,"unresolved_ambiguities":list(self.unresolved_ambiguities),"warnings":list(self.warnings)}

class ManufacturingFaceResolver:
    def __init__(self,dstv_adapter:DstvFaceMappingAdapter|None=None)->None:
        self.dstv_adapter=dstv_adapter or ExplicitDstvFaceMappingAdapter()

    def resolve(self,part:Part)->FaceResolutionReport:
        section=self._section(part)
        if section is None:
            return FaceResolutionReport(part.internal_id,[],FaceProofStatus.BLOCKED.value,["Profiel-/doorsnedegeometrie is onvoldoende bepaald; canonical faces worden niet gegokt."],source_geometry_hash=part.geometry_hash,source_manufacturing_hash=part.manufacturing_hash)
        p=section.profile_type.upper().strip()
        if p in {"I","HEA","HEB","HEM","IPE"}: faces=self._i(part,section)
        elif p in {"U","C","UPN","UPE"}: faces=self._u(part,section)
        elif p in {"L","ANGLE"}: faces=self._l(part,section)
        elif p in {"M","RHS","SHS","BOX"}: faces=self._rhs(part,section)
        elif p in {"B","PL","PLATE","STRIP","FLAT"}: faces=self._plate(part,section)
        elif p in {"RO","RU","CHS","ROUND","TUBE"}: faces=self._round(part,section)
        elif p in {"T","TEE"}: faces=self._t(part,section)
        else:
            return FaceResolutionReport(part.internal_id,[],FaceProofStatus.BLOCKED.value,[f"Profieltype {p or '?'} heeft in M1 geen bewezen face-resolver."],source_geometry_hash=part.geometry_hash,source_manufacturing_hash=part.manufacturing_hash)
        proof=FaceProofStatus.EXACT.value
        if any(f.proof_status==FaceProofStatus.REVIEW.value for f in faces): proof=FaceProofStatus.REVIEW.value
        if any(f.proof_status==FaceProofStatus.BLOCKED.value for f in faces): proof=FaceProofStatus.BLOCKED.value
        return FaceResolutionReport(part.internal_id,faces,proof,[],[],source_geometry_hash=part.geometry_hash,source_manufacturing_hash=part.manufacturing_hash)

    def _section(self,part:Part)->SectionDefinition|None:
        props=part.properties if isinstance(part.properties,dict) else {}
        explicit=props.get("manufacturing_section") or props.get("profile_dimensions")
        if isinstance(explicit,dict):
            return self._from_map(part,explicit,str(explicit.get("source") or "part_property"),str(explicit.get("proof_status") or "exact"))
        canonical=part.canonical()
        if canonical is not None:
            h=canonical.header
            data={"profile_type":h.profile_type,"designation":h.profile,"height_mm":h.dim1,"width_mm":h.dim2,"flange_thickness_mm":h.dim3,"web_thickness_mm":h.dim4,"radius_mm":h.radius}
            sec=self._from_map(part,data,"canonical_header","exact")
            if sec and self._usable(sec): return sec
        key=normalise_name(part.normalized_profile or part.profile)
        if key:
            db=ProfileDatabase(writable_copy=False)
            matches={normalise_name(x.designation):x for x in db.profiles if key in x.search_names}
            if len(matches)==1:
                x=next(iter(matches.values()))
                data={"profile_type":x.profile_type,"designation":x.designation,"height_mm":x.dim1,"width_mm":x.dim2,"flange_thickness_mm":x.dim3,"web_thickness_mm":x.dim4,"radius_mm":x.radius}
                if x.profile_type=="M": data["wall_thickness_mm"]=min(v for v in (x.dim3,x.dim4) if v>0) if any(v>0 for v in (x.dim3,x.dim4)) else 0
                if x.profile_type in {"RO","RU"}: data["diameter_mm"]=x.dim1; data["wall_thickness_mm"]=x.dim3 or x.dim4
                sec=self._from_map(part,data,"profile_database","exact")
                if sec and self._usable(sec): return sec
        # Only plate/flat may use exact-looking source bbox as a review fallback.
        if (part.profile_type or "").upper() in {"B","PL","PLATE"}:
            cad=(part.geometry_descriptor or {}).get("cad_metrics",{}) if isinstance(part.geometry_descriptor,dict) else {}
            bbox=cad.get("bbox_mm") if isinstance(cad,dict) else None
            if isinstance(bbox,(list,tuple)) and len(bbox)>=3:
                dims=sorted(float(v) for v in bbox[:3])
                length=float(part.length_mm or max(dims)); section_dims=sorted(dims)[:2]
                return SectionDefinition("B",part.profile or "PLATE",height_mm=max(section_dims),width_mm=min(section_dims),proof_status=FaceProofStatus.REVIEW.value,source="source_bbox_review",source_payload={"bbox_mm":list(bbox),"length_mm":length})
        return None

    def _from_map(self,part:Part,d:Mapping[str,Any],source:str,proof:str)->SectionDefinition:
        f=lambda *names: next((float(d[n]) for n in names if d.get(n) not in {None,""}),0.0)
        p=str(d.get("profile_type") or part.profile_type or "").upper()
        return SectionDefinition(p,str(d.get("designation") or part.profile or p),f("height_mm","height","dim1"),f("width_mm","width","dim2"),f("flange_thickness_mm","tf_mm","dim3"),f("web_thickness_mm","tw_mm","dim4"),f("wall_thickness_mm","t_mm"),f("diameter_mm","diameter"),f("radius_mm","radius"),proof,source,dict(d))
    def _usable(self,s:SectionDefinition)->bool:
        p=s.profile_type
        if p in {"I","U","C","L","T"}: return s.height_mm>0 and s.width_mm>0 and s.flange_thickness_mm>0 and s.web_thickness_mm>0
        if p=="M": return s.height_mm>0 and s.width_mm>0 and (s.wall_thickness_mm>0 or s.flange_thickness_mm>0 or s.web_thickness_mm>0)
        if p in {"RO","RU"}: return (s.diameter_mm or s.height_mm)>0
        return s.height_mm>0 and s.width_mm>0

    def _id(self,part:Part,role:str,orientation:str,source_ref:str)->str:
        return "mf-"+stable_sha256({"part_id":part.internal_id,"role":role,"orientation":orientation,"source_ref":source_ref})[:24]
    def _face(self,part:Part,section:SectionDefinition,role:str,origin, u,v,n, area:float, *, loops=(),surface="plane",orientation="longitudinal",surface_parameters=None,proof=None,source_ref=None)->ManufacturingFace:
        ref=source_ref or f"section:{section.designation}:{role}:origin={tuple(origin)}:normal={tuple(n)}"
        frame=FaceLocalFrame(tuple(origin),tuple(u),tuple(v),tuple(n))
        base=ManufacturingFace(self._id(part,role,orientation,ref),part.internal_id,role,"canonical_production_surface",ref,frame,surface,tuple(loops),float(max(area,0)),orientation,"material",("unknown",),dict(surface_parameters or {}),(),{},proof or section.proof_status,{"resolver":FACE_RESOLVER_VERSION,"section_source":section.source,"section_designation":section.designation},1.0 if (proof or section.proof_status)=="exact" else .75)
        candidates=self.dstv_adapter.candidates(part,role)
        if not candidates: return base
        d=base.to_dict(); d["dstv_side_candidates"]=[x.to_dict() for x in candidates]; d["geometry_hash"]=""
        return ManufacturingFace.from_dict(d)
    def _rect_long(self,part,s,role,origin,vaxis,normal,span,proof=None):
        L=float(part.length_mm); return self._face(part,s,role,origin,(1,0,0),vaxis,normal,L*span,loops=(rectangle_loop(0,-span/2,L,span/2),),proof=proof)
    def _end(self,part,s,role,finish,points,area,holes=(),proof=None):
        x=float(part.length_mm) if finish else 0.0; n=(1,0,0) if finish else (-1,0,0); v=(0,0,1) if finish else (0,0,-1)
        mapped_points=[(float(y), float(z) if finish else -float(z)) for y,z in points]
        loops=[polygon_loop(mapped_points)]; loops.extend(holes)
        return self._face(part,s,role,(x,0,0),(0,1,0),v,n,area,loops=tuple(loops),orientation="end",proof=proof)

    def _i(self,part,s):
        L=part.length_mm; h=s.height_mm; b=s.width_mm; tf=s.flange_thickness_mm; tw=s.web_thickness_mm
        if min(L,h,b,tf,tw)<=0 or 2*tf>=h or tw>=b: return []
        pr=s.proof_status if s.radius_mm<=0 else FaceProofStatus.REVIEW.value
        faces=[self._rect_long(part,s,"top_outer",(0,0,h/2),(0,1,0),(0,0,1),b),self._rect_long(part,s,"bottom_outer",(0,0,-h/2),(0,-1,0),(0,0,-1),b),self._rect_long(part,s,"web_left",(0,-tw/2,0),(0,0,1),(0,-1,0),h-2*tf,pr),self._rect_long(part,s,"web_right",(0,tw/2,0),(0,0,-1),(0,1,0),h-2*tf,pr)]
        half=(b-tw)/2
        for side,cy in (("left",-(tw/2+half/2)),("right",tw/2+half/2)):
            faces.append(self._rect_long(part,s,"top_inner",(0,cy,h/2-tf),(0,-1,0),(0,0,-1),half,pr))
            faces.append(self._rect_long(part,s,"bottom_inner",(0,cy,-h/2+tf),(0,1,0),(0,0,1),half,pr))
        pts=[(-b/2,-h/2),(b/2,-h/2),(b/2,-h/2+tf),(tw/2,-h/2+tf),(tw/2,h/2-tf),(b/2,h/2-tf),(b/2,h/2),(-b/2,h/2),(-b/2,h/2-tf),(-tw/2,h/2-tf),(-tw/2,-h/2+tf),(-b/2,-h/2+tf)]
        area=2*b*tf+(h-2*tf)*tw
        faces += [self._end(part,s,"end_start",False,pts,area,proof=pr),self._end(part,s,"end_finish",True,pts,area,proof=pr)]
        return faces
    def _u(self,part,s):
        L=part.length_mm; h=s.height_mm; b=s.width_mm; tf=s.flange_thickness_mm; tw=s.web_thickness_mm
        if min(L,h,b,tf,tw)<=0: return []
        pr=s.proof_status if s.radius_mm<=0 else FaceProofStatus.REVIEW.value
        y0=-b/2; y1=b/2; inner=y0+tw
        faces=[self._rect_long(part,s,"web_outer",(0,y0,0),(0,0,1),(0,-1,0),h),self._rect_long(part,s,"web_inner",(0,inner,0),(0,0,-1),(0,1,0),h-2*tf,pr),self._rect_long(part,s,"flange_a_outer",(0,0,h/2),(0,1,0),(0,0,1),b),self._rect_long(part,s,"flange_a_inner",(0,(inner+y1)/2,h/2-tf),(0,-1,0),(0,0,-1),y1-inner,pr),self._rect_long(part,s,"flange_b_outer",(0,0,-h/2),(0,-1,0),(0,0,-1),b),self._rect_long(part,s,"flange_b_inner",(0,(inner+y1)/2,-h/2+tf),(0,1,0),(0,0,1),y1-inner,pr)]
        pts=[(y0,-h/2),(y1,-h/2),(y1,-h/2+tf),(inner,-h/2+tf),(inner,h/2-tf),(y1,h/2-tf),(y1,h/2),(y0,h/2)]
        area=2*b*tf+(h-2*tf)*tw
        return faces+[self._end(part,s,"end_start",False,pts,area,proof=pr),self._end(part,s,"end_finish",True,pts,area,proof=pr)]
    def _l(self,part,s):
        L=part.length_mm; h=s.height_mm; b=s.width_mm; th=s.flange_thickness_mm; tv=s.web_thickness_mm
        if min(L,h,b,th,tv)<=0: return []
        pr=s.proof_status if s.radius_mm<=0 else FaceProofStatus.REVIEW.value
        faces=[self._rect_long(part,s,"leg_a_outer",(0,0,-h/2),(0,-1,0),(0,0,-1),b),self._rect_long(part,s,"leg_a_inner",(0,tv/2,-h/2+th),(0,1,0),(0,0,1),b-tv,pr),self._rect_long(part,s,"leg_b_outer",(0,-b/2,0),(0,0,1),(0,-1,0),h),self._rect_long(part,s,"leg_b_inner",(0,-b/2+tv,th/2),(0,0,-1),(0,1,0),h-th,pr)]
        pts=[(-b/2,-h/2),(b/2,-h/2),(b/2,-h/2+th),(-b/2+tv,-h/2+th),(-b/2+tv,h/2),(-b/2,h/2)]
        area=b*th+h*tv-th*tv
        return faces+[self._end(part,s,"end_start",False,pts,area,proof=pr),self._end(part,s,"end_finish",True,pts,area,proof=pr)]
    def _rhs(self,part,s):
        L=part.length_mm; h=s.height_mm; b=s.width_mm; t=s.wall_thickness_mm or (min(x for x in (s.flange_thickness_mm,s.web_thickness_mm) if x>0) if any(x>0 for x in (s.flange_thickness_mm,s.web_thickness_mm)) else 0)
        if min(L,h,b,t)<=0 or 2*t>=min(h,b): return []
        pr=s.proof_status if s.radius_mm<=0 else FaceProofStatus.REVIEW.value
        faces=[self._rect_long(part,s,"top_outer",(0,0,h/2),(0,1,0),(0,0,1),b,pr),self._rect_long(part,s,"bottom_outer",(0,0,-h/2),(0,-1,0),(0,0,-1),b,pr),self._rect_long(part,s,"web_left",(0,-b/2,0),(0,0,1),(0,-1,0),h,pr),self._rect_long(part,s,"web_right",(0,b/2,0),(0,0,-1),(0,1,0),h,pr)]
        outer=[(-b/2,-h/2),(b/2,-h/2),(b/2,h/2),(-b/2,h/2)]
        inner=rectangle_loop(-b/2+t,-h/2+t,b/2-t,h/2-t,is_hole=True)
        area=b*h-(b-2*t)*(h-2*t)
        faces += [self._end(part,s,"end_start",False,outer,area,holes=(inner,),proof=pr),self._end(part,s,"end_finish",True,outer,area,holes=(inner,),proof=pr)]
        return faces
    def _plate(self,part,s):
        L=part.length_mm; width=s.height_mm; t=s.width_mm
        if min(L,width,t)<=0:return []
        pr=s.proof_status
        return [self._rect_long(part,s,"plate_front",(0,0,t/2),(0,1,0),(0,0,1),width,pr),self._rect_long(part,s,"plate_back",(0,0,-t/2),(0,-1,0),(0,0,-1),width,pr),self._rect_long(part,s,"web_left",(0,-width/2,0),(0,0,1),(0,-1,0),t,pr),self._rect_long(part,s,"web_right",(0,width/2,0),(0,0,-1),(0,1,0),t,pr),self._end(part,s,"end_start",False,[(-width/2,-t/2),(width/2,-t/2),(width/2,t/2),(-width/2,t/2)],width*t,proof=pr),self._end(part,s,"end_finish",True,[(-width/2,-t/2),(width/2,-t/2),(width/2,t/2),(-width/2,t/2)],width*t,proof=pr)]
    def _round(self,part,s):
        L=part.length_mm; d=s.diameter_mm or s.height_mm; t=s.wall_thickness_mm or s.flange_thickness_mm or s.web_thickness_mm; r=d/2
        if min(L,d)<=0:return []
        inner=max(r-t,0) if s.profile_type in {"RO","CHS","TUBE"} and t>0 else 0
        circ=math.pi*d; area_long=circ*L
        round_face=self._face(part,s,"round_surface",(0,r,0),(1,0,0),(0,0,1),(0,-1,0),area_long,loops=(rectangle_loop(0,0,L,circ),),surface="cylinder",orientation="cylindrical_unwrapped",surface_parameters={"radius_mm":r,"axis":"X","u_coordinate":"axial_length","v_coordinate":"arc_length_from_seam","seam_reference_part_local":"+Y"})
        end_area=math.pi*(r*r-inner*inner); holes=((circle_loop(inner,is_hole=True),) if inner>0 else ())
        start=self._face(part,s,"end_start",(0,0,0),(0,1,0),(0,0,-1),(-1,0,0),end_area,loops=(circle_loop(r),)+holes,orientation="end")
        finish=self._face(part,s,"end_finish",(L,0,0),(0,1,0),(0,0,1),(1,0,0),end_area,loops=(circle_loop(r),)+holes,orientation="end")
        return [round_face,start,finish]
    def _t(self,part,s):
        # Bounded exact T profile: flange at +Z, web centered under it.
        L=part.length_mm; h=s.height_mm; b=s.width_mm; tf=s.flange_thickness_mm; tw=s.web_thickness_mm
        if min(L,h,b,tf,tw)<=0:return []
        pr=s.proof_status if s.radius_mm<=0 else FaceProofStatus.REVIEW.value
        faces=[self._rect_long(part,s,"top_outer",(0,0,h/2),(0,1,0),(0,0,1),b),self._rect_long(part,s,"top_inner",(0,-(b+tw)/4,h/2-tf),(0,-1,0),(0,0,-1),(b-tw)/2,pr),self._rect_long(part,s,"top_inner",(0,(b+tw)/4,h/2-tf),(0,-1,0),(0,0,-1),(b-tw)/2,pr),self._rect_long(part,s,"web_left",(0,-tw/2,(tf-h)/2),(0,0,1),(0,-1,0),h-tf,pr),self._rect_long(part,s,"web_right",(0,tw/2,(tf-h)/2),(0,0,-1),(0,1,0),h-tf,pr)]
        pts=[(-tw/2,-h/2),(tw/2,-h/2),(tw/2,h/2-tf),(b/2,h/2-tf),(b/2,h/2),(-b/2,h/2),(-b/2,h/2-tf),(-tw/2,h/2-tf)]
        area=b*tf+(h-tf)*tw
        return faces+[self._end(part,s,"end_start",False,pts,area,proof=pr),self._end(part,s,"end_finish",True,pts,area,proof=pr)]
