"""Offline production-simulation contracts for Scribing M12.

M12 replays an already validated M7 manufacturing sequence as a deterministic
state machine.  It is deliberately controller neutral.  A passed simulation is
*evidence*, never permission to emit proprietary machine programs or transfer a
job to a machine.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Mapping

from cws_convertor.project.model import ProjectValidationError, stable_sha256

M12_SIMULATION_SCHEMA_VERSION = "1.0"
M12_SIMULATION_STATE_SCHEMA_VERSION = "1.0"
M12_SIMULATION_VALIDATION_SCHEMA_VERSION = "1.0"
M12_SIMULATION_HASH_VERSION = "cws-manufacturing-simulation-v1"
M12_SIMULATION_EVENT_HASH_VERSION = "cws-manufacturing-simulation-event-v1"


@dataclass(frozen=True)
class SimulationIssue:
    code: str
    message: str
    blocking: bool = True
    severity: str = "error"
    operation_id: str = ""
    bar_id: str = ""
    piece_instance_id: str = ""
    mark_id: str = ""
    suggested_remediation: str = ""
    provenance: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "blocking": bool(self.blocking),
            "severity": self.severity,
            "operation_id": self.operation_id,
            "bar_id": self.bar_id,
            "piece_instance_id": self.piece_instance_id,
            "mark_id": self.mark_id,
            "suggested_remediation": self.suggested_remediation,
            "provenance": dict(self.provenance),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SimulationIssue":
        return cls(
            code=str(value.get("code") or ""),
            message=str(value.get("message") or ""),
            blocking=bool(value.get("blocking", True)),
            severity=str(value.get("severity") or "error"),
            operation_id=str(value.get("operation_id") or ""),
            bar_id=str(value.get("bar_id") or ""),
            piece_instance_id=str(value.get("piece_instance_id") or ""),
            mark_id=str(value.get("mark_id") or ""),
            suggested_remediation=str(value.get("suggested_remediation") or ""),
            provenance=dict(value.get("provenance") or {}),
        )


@dataclass(frozen=True)
class SimulationEvent:
    event_index: int
    operation_id: str
    operation_type: str
    bar_id: str
    piece_instance_id: str = ""
    result: str = "passed"
    state_before_hash: str = ""
    state_after_hash: str = ""
    operation_hash: str = ""
    observations: Mapping[str, Any] = field(default_factory=dict)
    event_hash: str = ""

    def __post_init__(self) -> None:
        if int(self.event_index) < 0 or not self.operation_id or not self.operation_type or not self.bar_id:
            raise ProjectValidationError("M12 simulation event mist verplichte identiteit")
        if self.result not in {"passed", "blocked", "review"}:
            raise ProjectValidationError(f"Onbekend M12 event-resultaat {self.result!r}")
        expected = stable_sha256(self.hash_payload())
        if self.event_hash and self.event_hash != expected:
            raise ProjectValidationError(f"M12 event {self.operation_id} heeft ongeldige hash")
        object.__setattr__(self, "event_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": M12_SIMULATION_EVENT_HASH_VERSION,
            "event_index": int(self.event_index),
            "operation_id": self.operation_id,
            "operation_type": self.operation_type,
            "bar_id": self.bar_id,
            "piece_instance_id": self.piece_instance_id,
            "result": self.result,
            "state_before_hash": self.state_before_hash,
            "state_after_hash": self.state_after_hash,
            "operation_hash": self.operation_hash,
            "observations": dict(self.observations),
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "event_hash": self.event_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SimulationEvent":
        return cls(
            event_index=int(value.get("event_index") or 0),
            operation_id=str(value.get("operation_id") or ""),
            operation_type=str(value.get("operation_type") or ""),
            bar_id=str(value.get("bar_id") or ""),
            piece_instance_id=str(value.get("piece_instance_id") or ""),
            result=str(value.get("result") or "passed"),
            state_before_hash=str(value.get("state_before_hash") or ""),
            state_after_hash=str(value.get("state_after_hash") or ""),
            operation_hash=str(value.get("operation_hash") or ""),
            observations=dict(value.get("observations") or {}),
            event_hash=str(value.get("event_hash") or ""),
        )


@dataclass(frozen=True)
class ManufacturingSimulationReport:
    simulation_id: str
    sequence_id: str
    machine_id: str
    source_sequence_hash: str
    source_sequence_state_hash: str
    operation_order: tuple[str, ...]
    events: tuple[SimulationEvent, ...]
    issues: tuple[SimulationIssue, ...]
    final_bar_states: Mapping[str, Any]
    feasible: bool
    review_required: bool
    simulated_total_seconds: float
    final_state_hash: str
    production_eligible: bool = False
    machine_output_released: bool = False
    direct_machine_transfer: bool = False
    simulation_hash: str = ""
    schema_version: str = M12_SIMULATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != M12_SIMULATION_SCHEMA_VERSION:
            raise ProjectValidationError(f"Onbekend toekomstig M12 simulation schema {self.schema_version!r}")
        if not self.simulation_id or not self.sequence_id or not self.machine_id:
            raise ProjectValidationError("M12 simulation mist verplichte identiteit")
        if self.production_eligible or self.machine_output_released or self.direct_machine_transfer:
            raise ProjectValidationError("M12 simulation mag geen production/machine-output/direct-transfer vrijgeven")
        if tuple(x.operation_id for x in self.events) != tuple(self.operation_order):
            raise ProjectValidationError("M12 eventvolgorde wijkt af van operation_order")
        total_seconds = float(self.simulated_total_seconds)
        if not math.isfinite(total_seconds) or total_seconds < 0:
            raise ProjectValidationError("M12 simulated_total_seconds moet finite en niet-negatief zijn")
        expected = stable_sha256(self.hash_payload())
        if self.simulation_hash and self.simulation_hash != expected:
            raise ProjectValidationError("M12 simulation_hash ongeldig")
        object.__setattr__(self, "simulation_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": M12_SIMULATION_HASH_VERSION,
            "schema_version": self.schema_version,
            "simulation_id": self.simulation_id,
            "sequence_id": self.sequence_id,
            "machine_id": self.machine_id,
            "source_sequence_hash": self.source_sequence_hash,
            "source_sequence_state_hash": self.source_sequence_state_hash,
            "operation_order": list(self.operation_order),
            "events": [x.to_dict() for x in self.events],
            "issues": [x.to_dict() for x in self.issues],
            "final_bar_states": dict(self.final_bar_states),
            "feasible": bool(self.feasible),
            "review_required": bool(self.review_required),
            "simulated_total_seconds": float(self.simulated_total_seconds),
            "final_state_hash": self.final_state_hash,
            "production_eligible": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "simulation_hash": self.simulation_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ManufacturingSimulationReport":
        return cls(
            simulation_id=str(value.get("simulation_id") or ""),
            sequence_id=str(value.get("sequence_id") or ""),
            machine_id=str(value.get("machine_id") or ""),
            source_sequence_hash=str(value.get("source_sequence_hash") or ""),
            source_sequence_state_hash=str(value.get("source_sequence_state_hash") or ""),
            operation_order=tuple(str(x) for x in value.get("operation_order") or ()),
            events=tuple(SimulationEvent.from_dict(x) for x in value.get("events") or ()),
            issues=tuple(SimulationIssue.from_dict(x) for x in value.get("issues") or ()),
            final_bar_states=dict(value.get("final_bar_states") or {}),
            feasible=bool(value.get("feasible")),
            review_required=bool(value.get("review_required")),
            simulated_total_seconds=float(value.get("simulated_total_seconds") or 0.0),
            final_state_hash=str(value.get("final_state_hash") or ""),
            production_eligible=bool(value.get("production_eligible", False)),
            machine_output_released=bool(value.get("machine_output_released", False)),
            direct_machine_transfer=bool(value.get("direct_machine_transfer", False)),
            simulation_hash=str(value.get("simulation_hash") or ""),
            schema_version=str(value.get("schema_version") or M12_SIMULATION_SCHEMA_VERSION),
        )


@dataclass(frozen=True)
class SimulationValidationReport:
    simulation_id: str
    status: str
    checks: tuple[Mapping[str, Any], ...]
    report_hash: str = ""
    schema_version: str = M12_SIMULATION_VALIDATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != M12_SIMULATION_VALIDATION_SCHEMA_VERSION:
            raise ProjectValidationError("Onbekend toekomstig M12 validation schema")
        if self.status not in {"passed", "failed"}:
            raise ProjectValidationError("Ongeldige M12 validation status")
        expected = stable_sha256(self.hash_payload())
        if self.report_hash and self.report_hash != expected:
            raise ProjectValidationError("M12 validation report_hash ongeldig")
        object.__setattr__(self, "report_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "simulation_id": self.simulation_id,
            "status": self.status,
            "checks": [dict(x) for x in self.checks],
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "report_hash": self.report_hash}


__all__ = [name for name in globals() if not name.startswith("_")]
