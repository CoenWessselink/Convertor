"""Frozen CWS Scribing M18 authority runtime.

Internal compatibility runtime for Unified U2. Canonical M1-M8 remains cws_convertor.manufacturing.
"""
M18_ORIGIN_VERSION="0.8.30-beta-dev"
M18_ORIGIN_COMMIT="b04b1c203583295e8c5ed018d75de68b2319c839"
