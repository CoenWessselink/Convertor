"""Independent validator for Scribing M3 ManufacturingMark records.

Decisive face containment, clearance and exclusion checks are implemented here
independently from marking_geometry/marking_engine to avoid a common-mode bug.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from .contracts import ManufacturingFace, ManufacturingSurfaceType
from .service import load_faces, validate_persisted_face_state
from .contact_service import load_assembly_contacts, validate_persisted_contact_state
from .marking_contracts import (
    ManufacturingMark, ManufacturingRuleSet, MarkGeometryKind, MarkReviewStatus, MarkType,
    PredicateOperator, RulePredicate, validate_mark_set,
)
from .marking_engine import marking_source_snapshot_hash

MARK_VALIDATOR_VERSION="cws-manufacturing-mark-validator-1.0"
MARK_VALIDATION_SCHEMA_VERSION="1.0"


def _dist(a,b):return math.hypot(b[0]-a[0],b[1]-a[1])
def _point_on_segment(p,a,b,tol=1e-7):
    cross=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    if abs(cross)>tol*max(1.0,_dist(a,b)):return False
    return (p[0]-a[0])*(p[0]-b[0])+(p[1]-a[1])*(p[1]-b[1])<=tol*tol

def _point_in_polygon(p,poly,tol=1e-7):
    for i,a in enumerate(poly):
        if _point_on_segment(p,a,poly[(i+1)%len(poly)],tol):return True
    x,y=p;inside=False;j=len(poly)-1
    for i in range(len(poly)):
        xi,yi=poly[i];xj,yj=poly[j]
        if (yi>y)!=(yj>y):
            xint=(xj-xi)*(y-yi)/(yj-yi)+xi
            if x<xint:inside=not inside
        j=i
    return inside

def _outer_polygon(face:ManufacturingFace):
    loops=[loop for loop in face.boundary_loops_2d if not loop.is_hole]
    if len(loops)!=1:return None
    if any(seg.kind!="line" or seg.start is None for seg in loops[0].segments):return None
    return [(float(seg.start[0]),float(seg.start[1])) for seg in loops[0].segments]

def _point_segment_distance(p,a,b):
    dx=b[0]-a[0];dy=b[1]-a[1];den=dx*dx+dy*dy
    if den<=1e-18:return _dist(p,a)
    t=max(0.0,min(1.0,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den))
    q=(a[0]+t*dx,a[1]+t*dy);return _dist(p,q)

def _edge_distance(p,poly):return min(_point_segment_distance(p,poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly)))
def _segment_circle_distance(a,b,c):return _point_segment_distance(c,a,b)

def _feature_holes(part,face,margin):
    sides={str(x.get("dstv_side") or "") for x in [c.to_dict() for c in face.dstv_side_candidates]};zones=[]
    explicit=part.properties.get("marking_hole_zones",[]) if isinstance(part.properties,dict) else []
    for i,raw in enumerate(explicit if isinstance(explicit,list) else []):
        if not isinstance(raw,dict):continue
        ref=str(raw.get("face_id") or raw.get("semantic_role") or "")
        if ref and ref not in {face.face_id,face.semantic_role,*sides}:continue
        try:u=float(raw.get("u_mm"));v=float(raw.get("v_mm"));d=float(raw.get("diameter_mm") or 0)
        except Exception:continue
        if d>0:zones.append(((u,v),d/2+margin,str(raw.get("id") or f"explicit-{i}")))
    for i,raw in enumerate(part.production_features):
        if not isinstance(raw,dict) or raw.get("kind")!="hole":continue
        ref=str(raw.get("face") or "")
        if ref and ref not in {face.face_id,face.semantic_role,*sides}:continue
        try:u=float(raw.get("x"));v=float(raw.get("q"));d=float(raw.get("diameter") or 0)
        except Exception:continue
        if d>0:zones.append(((u,v),d/2+margin,str(raw.get("id") or f"feature-{i}")))
    return zones

def _weld_zones(part,face,margin):
    sides={c.dstv_side for c in face.dstv_side_candidates};zones=[]
    rawlist=part.properties.get("marking_weld_zones",[]) if isinstance(part.properties,dict) else []
    for i,raw in enumerate(rawlist if isinstance(rawlist,list) else []):
        if not isinstance(raw,dict):continue
        ref=str(raw.get("face_id") or raw.get("semantic_role") or "")
        if ref and ref not in {face.face_id,face.semantic_role,*sides}:continue
        kind=str(raw.get("kind") or "circle")
        try:
            if kind=="circle":zones.append(("circle",(float(raw.get("u_mm")),float(raw.get("v_mm"))),float(raw.get("radius_mm") or 0)+margin,str(raw.get("id") or i)))
            elif kind=="rect":zones.append(("rect",(float(raw.get("u0_mm"))-margin,float(raw.get("v0_mm"))-margin,float(raw.get("u1_mm"))+margin,float(raw.get("v1_mm"))+margin),0.0,str(raw.get("id") or i)))
        except Exception:continue
    return zones

def _segment_intersects_rect(a,b,rect):
    u0,v0,u1,v1=rect;u0,u1=sorted((u0,u1));v0,v1=sorted((v0,v1))
    if u0<=a[0]<=u1 and v0<=a[1]<=v1:return True
    if u0<=b[0]<=u1 and v0<=b[1]<=v1:return True
    # Liang-Barsky independently.
    dx=b[0]-a[0];dy=b[1]-a[1];p=[-dx,dx,-dy,dy];q=[a[0]-u0,u1-a[0],a[1]-v0,v1-a[1]];t0=0.0;t1=1.0
    for pi,qi in zip(p,q):
        if abs(pi)<1e-12:
            if qi<0:return False
            continue
        r=qi/pi
        if pi<0:t0=max(t0,r)
        else:t1=min(t1,r)
        if t0>t1:return False
    return True

def _validator_rule_value(part, path: str):
    path = str(path or "").strip()
    if path.startswith("properties."):
        current: Any = part.properties
        for token in path.split(".")[1:]:
            if not isinstance(current, Mapping):
                return None
            current = current.get(token)
        return current
    allowed = {
        "profile_type", "profile", "normalized_profile", "material", "material_grade",
        "part_type", "mirrored", "status", "classification_status", "part_position",
    }
    if path not in allowed:
        raise ProjectValidationError(f"Ruleset predicate field {path!r} is niet toegestaan")
    return getattr(part, path)

def _validator_predicate_matches(part, predicate: RulePredicate) -> bool:
    actual = _validator_rule_value(part, predicate.field_path)
    expected = predicate.value
    if predicate.operator == PredicateOperator.EQ.value:
        return actual == expected
    if predicate.operator == PredicateOperator.NE.value:
        return actual != expected
    values = expected if isinstance(expected, (list, tuple, set)) else [expected]
    if predicate.operator == PredicateOperator.IN.value:
        return actual in values
    if predicate.operator == PredicateOperator.NOT_IN.value:
        return actual not in values
    if predicate.operator == PredicateOperator.EXISTS.value:
        return (actual is not None) == bool(expected if expected is not None else True)
    raise ProjectValidationError(f"Onbekende predicate operator {predicate.operator!r}")

def _validator_ruleset_applies(part, ruleset: ManufacturingRuleSet) -> bool:
    if ruleset.applicable_profile_types:
        tokens = {str(part.profile_type or "").upper(), str(part.part_type or "").upper()}
        if not any(str(item).upper() in tokens for item in ruleset.applicable_profile_types):
            return False
    if ruleset.inclusion_predicates and not all(_validator_predicate_matches(part, item) for item in ruleset.inclusion_predicates):
        return False
    if any(_validator_predicate_matches(part, item) for item in ruleset.exclusion_predicates):
        return False
    return True

def _canonical_pair(a, b):
    a=(float(a[0]),float(a[1]));b=(float(b[0]),float(b[1]))
    return (a,b) if a<=b else (b,a)

def _segment_key(a,b,mark_type):
    a,b=_canonical_pair(a,b)
    return (str(mark_type), tuple(round(x,7) for x in (*a,*b)))

def _signed_area(poly):
    return 0.5*sum(poly[i][0]*poly[(i+1)%len(poly)][1]-poly[(i+1)%len(poly)][0]*poly[i][1] for i in range(len(poly)))

def _line_line(p1,p2,p3,p4):
    x1,y1=p1;x2,y2=p2;x3,y3=p3;x4,y4=p4
    den=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4)
    if abs(den)<1e-12:return None
    return (((x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4))/den,((x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4))/den)

def _independent_inset(poly,margin):
    margin=max(0.0,float(margin))
    if margin<=1e-12:return list(poly)
    if len(poly)<3:return []
    orientation=1.0 if _signed_area(poly)>0 else -1.0
    shifted=[]
    for i,a in enumerate(poly):
        b=poly[(i+1)%len(poly)];dx=b[0]-a[0];dy=b[1]-a[1];ln=math.hypot(dx,dy)
        if ln<=1e-12:return []
        nx=orientation*(-dy/ln);ny=orientation*(dx/ln)
        shifted.append(((a[0]+nx*margin,a[1]+ny*margin),(b[0]+nx*margin,b[1]+ny*margin)))
    out=[]
    for i in range(len(shifted)):
        p=_line_line(shifted[(i-1)%len(shifted)][0],shifted[(i-1)%len(shifted)][1],shifted[i][0],shifted[i][1])
        if p is None:return []
        out.append(p)
    if abs(_signed_area(out))<=1e-10:return []
    return out

def _segment_cross_t(a,b,c,d):
    rx=b[0]-a[0];ry=b[1]-a[1];sx=d[0]-c[0];sy=d[1]-c[1];den=rx*sy-ry*sx
    if abs(den)<1e-12:return None
    qx=c[0]-a[0];qy=c[1]-a[1];t=(qx*sy-qy*sx)/den;u=(qx*ry-qy*rx)/den
    if -1e-10<=t<=1+1e-10 and -1e-10<=u<=1+1e-10:return max(0.0,min(1.0,t))
    return None

def _at(a,b,t):return (a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)

def _independent_clip(a,b,poly):
    ts=[0.0,1.0]
    for i,c in enumerate(poly):
        t=_segment_cross_t(a,b,c,poly[(i+1)%len(poly)])
        if t is not None:ts.append(t)
    ts=sorted(set(round(x,12) for x in ts));out=[]
    for l,r in zip(ts,ts[1:]):
        if r-l<=1e-12:continue
        if _point_in_polygon(_at(a,b,(l+r)/2),poly):
            p,q=_canonical_pair(_at(a,b,l),_at(a,b,r))
            if _dist(p,q)>1e-8:out.append((p,q))
    return out

def _blocked_circle_intervals(a,b,center,radius):
    dx=b[0]-a[0];dy=b[1]-a[1];fx=a[0]-center[0];fy=a[1]-center[1];aa=dx*dx+dy*dy
    if aa<=1e-18:return []
    bb=2*(fx*dx+fy*dy);cc=fx*fx+fy*fy-radius*radius;disc=bb*bb-4*aa*cc
    roots=[]
    if disc>=0:
        root=math.sqrt(max(0.0,disc));roots=[(-bb-root)/(2*aa),(-bb+root)/(2*aa)]
    ts=[0.0,1.0]+[max(0.0,min(1.0,t)) for t in roots if -1e-10<=t<=1+1e-10];ts=sorted(set(round(t,12) for t in ts));res=[]
    for l,r in zip(ts,ts[1:]):
        if r-l>1e-12 and _dist(_at(a,b,(l+r)/2),center)<radius-1e-8:res.append((l,r))
    return res

def _blocked_rect_intervals(a,b,rect):
    u0,v0,u1,v1=rect;u0,u1=sorted((u0,u1));v0,v1=sorted((v0,v1));poly=[(u0,v0),(u1,v0),(u1,v1),(u0,v1)]
    pieces=_independent_clip(a,b,poly);dx=b[0]-a[0];dy=b[1]-a[1];out=[]
    def param(p):
        if abs(dx)>=abs(dy) and abs(dx)>1e-12:return (p[0]-a[0])/dx
        if abs(dy)>1e-12:return (p[1]-a[1])/dy
        return 0.0
    for p,q in pieces:out.append(tuple(sorted((max(0,min(1,param(p))),max(0,min(1,param(q)))))))
    return out

def _subtract_blocked(a,b,intervals):
    items=[]
    for l,r in intervals:
        l=max(0.0,min(1.0,l));r=max(0.0,min(1.0,r));l,r=(l,r) if l<=r else (r,l)
        if r-l>1e-12:items.append((l,r))
    items.sort();merged=[]
    for l,r in items:
        if not merged or l>merged[-1][1]+1e-12:merged.append([l,r])
        else:merged[-1][1]=max(merged[-1][1],r)
    cur=0.0;out=[]
    for l,r in merged:
        if l>cur+1e-12:out.append(_canonical_pair(_at(a,b,cur),_at(a,b,l)))
        cur=max(cur,r)
    if cur<1-1e-12:out.append(_canonical_pair(_at(a,b,cur),b))
    return [x for x in out if _dist(*x)>1e-8]

def _independent_merge(segments,tol=1e-7):
    work=[_canonical_pair(*x) for x in segments if _dist(*x)>tol];changed=True
    while changed:
        changed=False
        for i,(a,b) in enumerate(work):
            dx=b[0]-a[0];dy=b[1]-a[1];ln=math.hypot(dx,dy)
            if ln<=tol:continue
            ux,uy=dx/ln,dy/ln
            for j in range(i+1,len(work)):
                c,d=work[j]
                if abs(dx*(c[1]-a[1])-dy*(c[0]-a[0]))>tol*ln or abs(dx*(d[1]-a[1])-dy*(d[0]-a[0]))>tol*ln:continue
                t0=(c[0]-a[0])*ux+(c[1]-a[1])*uy;t1=(d[0]-a[0])*ux+(d[1]-a[1])*uy;lo2,hi2=sorted((t0,t1))
                if lo2>ln+tol or hi2<-tol:continue
                lo=min(0.0,lo2);hi=max(ln,hi2);work[i]=_canonical_pair((a[0]+ux*lo,a[1]+uy*lo),(a[0]+ux*hi,a[1]+uy*hi));work.pop(j);changed=True;break
            if changed:break
    unique={tuple(round(v,9) for p in seg for v in p):seg for seg in work}
    return [unique[k] for k in sorted(unique)]

def _independent_policy_segments(contact,ruleset):
    pts=[tuple(map(float,p)) for p in contact.projected_boundary_on_main_face]
    source=[_canonical_pair(pts[i],pts[(i+1)%len(pts)]) for i in range(len(pts))]
    policy=ruleset.contour_policy
    mark_type=MarkType.REFERENCE_LINE.value if policy=="center_reference" else MarkType.CONTOUR_SCRIBE.value
    if policy=="corners_only":
        selected=[]
        for a,b in source:
            total=_dist(a,b)
            if total<=2*ruleset.corner_mark_length_mm+ruleset.min_line_length_mm:selected.append((a,b));continue
            ux=(b[0]-a[0])/total;uy=(b[1]-a[1])/total
            selected.extend([_canonical_pair(a,(a[0]+ux*ruleset.corner_mark_length_mm,a[1]+uy*ruleset.corner_mark_length_mm)),_canonical_pair((b[0]-ux*ruleset.corner_mark_length_mm,b[1]-uy*ruleset.corner_mark_length_mm),b)])
    elif policy=="minimum_line_set":
        ordered=sorted(source,key=lambda seg:(-_dist(*seg),seg));selected=ordered[:1]
        if ordered:
            a,b=ordered[0];dx=b[0]-a[0];dy=b[1]-a[1];ln=max(_dist(a,b),1e-12)
            for c,d in ordered[1:]:
                ex=d[0]-c[0];ey=d[1]-c[1];eln=max(_dist(c,d),1e-12)
                if abs((dx*ex+dy*ey)/(ln*eln))<0.95:selected.append((c,d));break
    elif policy=="center_reference":
        u0=min(p[0] for p in pts);u1=max(p[0] for p in pts);v0=min(p[1] for p in pts);v1=max(p[1] for p in pts)
        selected=[_canonical_pair((u0,(v0+v1)/2),(u1,(v0+v1)/2))] if (u1-u0)>=(v1-v0) else [_canonical_pair(((u0+u1)/2,v0),((u0+u1)/2,v1))]
    elif policy=="company_template":
        template=dict(ruleset.contact_rules.get("company_template") or {});selected=[source[i] for i in list(template.get("edge_indices") or []) if 0<=i<len(source)]
    else:selected=source
    rows=[(mark_type,x) for x in selected]
    if ruleset.generate_reference_line and policy!="center_reference":
        u0=min(p[0] for p in pts);u1=max(p[0] for p in pts);v0=min(p[1] for p in pts);v1=max(p[1] for p in pts)
        center=_canonical_pair((u0,(v0+v1)/2),(u1,(v0+v1)/2)) if (u1-u0)>=(v1-v0) else _canonical_pair(((u0+u1)/2,v0),((u0+u1)/2,v1))
        rows.append((MarkType.REFERENCE_LINE.value,center))
    return rows

def _independent_final_expected(part,face,contact,ruleset):
    poly=_outer_polygon(face)
    if not poly:return set()
    safe=_independent_inset(poly,ruleset.min_edge_distance_mm)
    if not safe:return set()
    holes=_feature_holes(part,face,ruleset.hole_margin_mm);welds=_weld_zones(part,face,ruleset.weld_margin_mm)
    if contact.weld_ids and ruleset.weld_margin_mm>0 and ruleset.require_explicit_weld_geometry and not welds:return set()
    grouped={}
    for mark_type,seg in _independent_policy_segments(contact,ruleset):grouped.setdefault(mark_type,[]).append(seg)
    result=set()
    for mark_type,segments in grouped.items():
        for a,b in _independent_merge(segments):
            pieces=_independent_clip(a,b,safe)
            after=[]
            for p,q in pieces:
                intervals=[]
                for center,radius,_ in holes:intervals.extend(_blocked_circle_intervals(p,q,center,radius))
                after.extend(_subtract_blocked(p,q,intervals))
            pieces=after
            after=[]
            for p,q in pieces:
                intervals=[]
                for kind,geom,radius,_ in welds:
                    if kind=="circle":intervals.extend(_blocked_circle_intervals(p,q,geom,radius))
                    else:intervals.extend(_blocked_rect_intervals(p,q,geom))
                after.extend(_subtract_blocked(p,q,intervals))
            pieces=[] if (ruleset.avoid_contact_surface and contact.weld_ids) else after
            pieces=[x for x in pieces if _dist(*x)+1e-9>=ruleset.min_line_length_mm]
            if ruleset.segment_straight_lines:
                segmented=[]
                for p,q in pieces:
                    total=_dist(p,q);ux=(q[0]-p[0])/total;uy=(q[1]-p[1])/total;cursor=0.0
                    while cursor<total-1e-8:
                        end=min(total,cursor+ruleset.segment_length_mm)
                        if end-cursor+1e-9>=ruleset.min_line_length_mm:segmented.append(_canonical_pair((p[0]+ux*cursor,p[1]+uy*cursor),(p[0]+ux*end,p[1]+uy*end)))
                        cursor=end+ruleset.segment_gap_mm
                pieces=segmented
            for p,q in pieces:result.add(_segment_key(p,q,mark_type))
    return result

@dataclass
class MarkValidationIssue:
    code:str
    message:str
    mark_id:str=""
    blocking:bool=True
    object_ids:tuple[str,...]=()
    face_id:str=""
    rule_id:str=""
    suggested_remediation:str=""
    def to_dict(self):return {"code":self.code,"message":self.message,"mark_id":self.mark_id,"blocking":self.blocking,"object_ids":list(self.object_ids),"face_id":self.face_id,"rule_id":self.rule_id,"suggested_remediation":self.suggested_remediation}

@dataclass
class MarkValidationReport:
    assembly_id:str
    status:str
    ruleset_hash:str
    mark_set_hash:str
    source_snapshot_hash:str
    issues:list[MarkValidationIssue]=field(default_factory=list)
    mark_count:int=0
    validator_version:str=MARK_VALIDATOR_VERSION
    report_hash:str=""
    def __post_init__(self):
        expected=stable_sha256(self.to_dict(include_hash=False))
        if self.report_hash and self.report_hash!=expected:raise ProjectValidationError("Mark validation report_hash ongeldig")
        self.report_hash=expected
    def to_dict(self,*,include_hash=True):
        data={"schema_version":MARK_VALIDATION_SCHEMA_VERSION,"assembly_id":self.assembly_id,"status":self.status,"ruleset_hash":self.ruleset_hash,"mark_set_hash":self.mark_set_hash,"source_snapshot_hash":self.source_snapshot_hash,"mark_count":self.mark_count,"validator_version":self.validator_version,"issues":[x.to_dict() for x in self.issues]}
        if include_hash:data["report_hash"]=self.report_hash
        return data

class IndependentManufacturingMarkValidator:
    def validate(self,project:ProjectModel,assembly_id:str,ruleset:ManufacturingRuleSet,marks:Iterable[ManufacturingMark])->MarkValidationReport:
        rows=list(marks);issues=[]
        try:
            validate_persisted_contact_state(project,assembly_id,require_current=True)
            set_hash=validate_mark_set(assembly_id,ruleset.ruleset_hash,rows)
            source_hash=marking_source_snapshot_hash(project,assembly_id,ruleset)
        except ProjectValidationError as exc:
            return MarkValidationReport(assembly_id,"failed",ruleset.ruleset_hash,"","",[MarkValidationIssue("CWS-MARK-014",str(exc))],len(rows))
        contacts={p.contact_id:p for p in load_assembly_contacts(project,assembly_id)}
        face_maps={}
        for part_id in {m.target_part_id for m in rows}:
            part=project.parts.get(part_id)
            if part is None:continue
            try:validate_persisted_face_state(part,require_current=True)
            except ProjectValidationError as exc:
                issues.append(MarkValidationIssue("CWS-MARK-001",f"Manufacturing Faces van {part_id} niet actueel: {exc}",object_ids=(part_id,)))
                continue
            face_maps[part_id]={f.face_id:f for f in load_faces(part)}
        ids=set()
        for mark in rows:
            def add(code,msg,blocking=True,rem=""):
                issues.append(MarkValidationIssue(code,msg,mark.mark_id,blocking,(mark.source_part_id,mark.target_part_id),mark.target_face_id,mark.generated_by_rule_id,rem))
            if mark.mark_id in ids:add("CWS-MARK-020","Dubbele mark-ID in set")
            ids.add(mark.mark_id)
            part=project.parts.get(mark.target_part_id);face=face_maps.get(mark.target_part_id,{}).get(mark.target_face_id);contact=contacts.get(mark.source_contact_id)
            if not part or not face:add("CWS-MARK-001","Target part/ManufacturingFace ontbreekt");continue
            if face.surface_type!=ManufacturingSurfaceType.PLANE.value:add("CWS-MARK-003","M3 mark ligt niet op een ondersteunde vlakke face")
            if face.geometry_hash!=mark.target_face_geometry_hash:add("CWS-MARK-014","Target face hash is stale")
            if not contact:add("CWS-MARK-004","Source ContactPatch ontbreekt");continue
            if contact.contact_hash!=mark.source_contact_hash:add("CWS-MARK-014","Source ContactPatch hash is stale")
            if contact.main_part_id != mark.target_part_id or contact.secondary_part_id != mark.source_part_id:
                add("CWS-MARK-004","Mark source/target part mapping wijkt af van de bewezen ContactPatch")
            if contact.main_face_id != mark.target_face_id:
                add("CWS-MARK-004","Mark target face wijkt af van de bewezen ContactPatch main face")
            if ruleset.exact_contacts_only and contact.proof_status != "exact":
                add("CWS-MARK-004","Ruleset vereist exact contactbewijs")
            if mark.ruleset_hash!=ruleset.ruleset_hash:add("CWS-MARK-013","Ruleset hash mismatch")
            try:
                if not _validator_ruleset_applies(part, ruleset):
                    add("CWS-MARK-013","Ruleset is niet van toepassing op target part")
            except ProjectValidationError as exc:
                add("CWS-MARK-013",f"Ruleset predicate ongeldig: {exc}")
            if mark.review_status != MarkReviewStatus.ACCEPTED.value:
                add("CWS-MARK-020","Persisted M3 mark heeft geen accepted review status")
            if mark.requested_operation != "scribe":
                add("CWS-MARK-020","M3 mark requested_operation moet 'scribe' zijn")
            if mark.mark_type not in {MarkType.SCRIBE_LINE.value, MarkType.CONTOUR_SCRIBE.value, MarkType.REFERENCE_LINE.value}:
                add("CWS-MARK-020",f"Mark type {mark.mark_type!r} hoort niet bij de M3 scribing-scope")
            if mark.text_payload or mark.text_height_mm or mark.depth_mm:
                add("CWS-MARK-020","Tekst/depth payload hoort pas bij latere markingfasen, niet bij M3")
            if mark.geometry_2d.kind!=MarkGeometryKind.LINE.value:
                add("CWS-MARK-003","M3 validator ondersteunt alleen line geometry voor gegenereerde scribe/reference marks");continue
            try:a,b=mark.geometry_2d.points
            except Exception:add("CWS-MARK-005","Marklijn mist twee punten");continue
            if not all(math.isfinite(float(v)) for p in (a,b) for v in p):add("CWS-MARK-005","Marklijn bevat niet-eindige coördinaten");continue
            length=_dist(a,b)
            if length+1e-8<ruleset.min_line_length_mm:add("CWS-MARK-005",f"Marklijn {length:.3f} mm is korter dan minimum")
            poly=_outer_polygon(face)
            if not poly:add("CWS-MARK-003","Target face heeft geen onafhankelijk valideerbare lijnboundary");continue
            samples=[a,b,((a[0]+b[0])/2,(a[1]+b[1])/2)]
            if not all(_point_in_polygon(p,poly) for p in samples):add("CWS-MARK-005","Marklijn ligt buiten target face")
            if ruleset.min_edge_distance_mm>0 and min(_edge_distance(p,poly) for p in samples)+1e-6<ruleset.min_edge_distance_mm:add("CWS-MARK-005","Marklijn schendt minimum edge clearance")
            for center,radius,zid in _feature_holes(part,face,ruleset.hole_margin_mm):
                if _segment_circle_distance(a,b,center)<radius-1e-6:add("CWS-MARK-006",f"Marklijn snijdt uitgesloten hole zone {zid}")
            weldzones=_weld_zones(part,face,ruleset.weld_margin_mm)
            if contact.weld_ids and ruleset.weld_margin_mm>0 and ruleset.require_explicit_weld_geometry and not weldzones:add("CWS-MARK-007","Weld margin actief zonder exacte weld exclusion-geometrie")
            for kind,geom,radius,zid in weldzones:
                if kind=="circle" and _segment_circle_distance(a,b,geom)<radius-1e-6:add("CWS-MARK-007",f"Marklijn snijdt weld exclusion {zid}")
                if kind=="rect" and _segment_intersects_rect(a,b,geom):add("CWS-MARK-007",f"Marklijn snijdt weld exclusion {zid}")
            if ruleset.avoid_contact_surface and contact.weld_ids:add("CWS-MARK-007","Ruleset verbiedt markering op gelast contactoppervlak")
            try:
                restored=ManufacturingMark.from_dict(mark.to_dict())
                if restored.mark_hash!=mark.mark_hash:add("CWS-MARK-020","Mark roundtrip/hash mismatch")
            except ProjectValidationError as exc:add("CWS-MARK-020",f"Mark contract ongeldig: {exc}")
        # Independently reconstruct the complete M3 output set from current
        # contact facts and rules.  This catches both fabricated in-face lines
        # and silently deleted valid marks even when their hashes were rebuilt.
        actual_by_contact: dict[str, set[tuple[str, tuple[float, ...]]]] = {}
        for mark in rows:
            if mark.geometry_2d.kind == MarkGeometryKind.LINE.value and len(mark.geometry_2d.points) == 2:
                actual_by_contact.setdefault(mark.source_contact_id, set()).add(
                    _segment_key(mark.geometry_2d.points[0], mark.geometry_2d.points[1], mark.mark_type)
                )
        expected_by_contact: dict[str, set[tuple[str, tuple[float, ...]]]] = {}
        for contact_id, contact in contacts.items():
            if ruleset.exact_contacts_only and contact.proof_status != "exact":
                continue
            part = project.parts.get(contact.main_part_id)
            face = face_maps.get(contact.main_part_id, {}).get(contact.main_face_id)
            if part is None or face is None:
                continue
            try:
                if not _validator_ruleset_applies(part, ruleset):
                    continue
                expected_by_contact[contact_id] = _independent_final_expected(part, face, contact, ruleset)
            except Exception as exc:
                issues.append(MarkValidationIssue("CWS-MARK-020", f"Onafhankelijke expected-set reconstructie faalde: {exc}", object_ids=(contact.main_part_id, contact.secondary_part_id), face_id=contact.main_face_id, rule_id=ruleset.ruleset_id))
        for contact_id in sorted(set(actual_by_contact) | set(expected_by_contact)):
            actual = actual_by_contact.get(contact_id, set())
            expected = expected_by_contact.get(contact_id, set())
            missing = expected - actual
            unexpected = actual - expected
            if missing:
                issues.append(MarkValidationIssue("CWS-MARK-020", f"{len(missing)} verwachte M3 marksegment(en) ontbreken voor contact {contact_id}", object_ids=(contact_id,), rule_id=ruleset.ruleset_id))
            if unexpected:
                issues.append(MarkValidationIssue("CWS-MARK-020", f"{len(unexpected)} niet-afleidbare M3 marksegment(en) aanwezig voor contact {contact_id}", object_ids=(contact_id,), rule_id=ruleset.ruleset_id))
        status="passed" if not any(i.blocking for i in issues) else "failed"
        return MarkValidationReport(assembly_id,status,ruleset.ruleset_hash,set_hash,source_hash,issues,len(rows))

__all__=["MARK_VALIDATOR_VERSION","MARK_VALIDATION_SCHEMA_VERSION","MarkValidationIssue","MarkValidationReport","IndependentManufacturingMarkValidator"]
