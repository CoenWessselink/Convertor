"""Persistence, stale handling and release gate for Scribing M7."""
from __future__ import annotations
from typing import Any
from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from .manufacturing_sequence import ManufacturingSequencePlanner, build_sequence_neutral_job, m7_source_snapshot, m7_source_snapshot_hash, sequence_id
from .manufacturing_sequence_contracts import MANUFACTURING_SEQUENCE_STATE_SCHEMA_VERSION, ManufacturingSequencePlan
from .manufacturing_sequence_validator import IndependentManufacturingSequenceValidator

M7_PHASE="M7"

def _state_hash(state:dict[str,Any])->str:return stable_sha256({k:v for k,v in state.items() if k!="state_hash"})

def create_manufacturing_sequence(project:ProjectModel,run_id:str,assembly_id:str,capability_id:str,*,user:str="system",persist:bool=True):
    sequence=ManufacturingSequencePlanner().build(project,run_id,assembly_id,capability_id)
    validation=IndependentManufacturingSequenceValidator().validate(project,sequence)
    if validation.status!="passed":raise ProjectValidationError("CWS-MARK-020 onafhankelijke M7 sequencevalidatie mismatch")
    neutral=build_sequence_neutral_job(project,sequence)
    if persist:
        sid=sequence.sequence_id; previous=dict(project.manufacturing_sequences.get(sid) or {})
        state={"schema_version":MANUFACTURING_SEQUENCE_STATE_SCHEMA_VERSION,"phase":M7_PHASE,"sequence_id":sid,"run_id":run_id,"assembly_id":assembly_id,"capability_id":capability_id,"binding_set_id":sequence.binding_set_id,"machine_id":sequence.machine_id,"status":"current","feasible":sequence.feasible,"review_required":sequence.review_required,"source_snapshot":m7_source_snapshot(project,run_id,assembly_id,capability_id),"source_snapshot_hash":sequence.source_snapshot_hash,"sequence":sequence.to_dict(),"independent_validation":validation.to_dict(),"neutral_job":neutral,"created_at":utc_now_iso(),"created_by":user,"requires_m8_scope":True,"dstv_si_released":False,"machine_output_released":False,"direct_machine_transfer":False}
        state["state_hash"]=_state_hash(state);project.manufacturing_sequences[sid]=state
        project.audit("manufacturing.sequence_created",user=user,entity_id=sid,before_hash=str(previous.get("state_hash") or ""),after_hash=state["state_hash"],details={"run_id":run_id,"assembly_id":assembly_id,"operation_count":len(sequence.operations),"dependency_count":len(sequence.dependencies),"feasible":sequence.feasible,"requires_m8_scope":True})
    return sequence,validation,neutral

def invalidate_manufacturing_sequences(project:ProjectModel,*,reason:str,user:str="system",run_id:str|None=None,assembly_id:str|None=None,capability_id:str|None=None)->None:
    now=utc_now_iso()
    for sid,state in project.manufacturing_sequences.items():
        if not isinstance(state,dict):continue
        if run_id and str(state.get("run_id") or "")!=run_id:continue
        if assembly_id and str(state.get("assembly_id") or "")!=assembly_id:continue
        if capability_id and str(state.get("capability_id") or "")!=capability_id:continue
        if state.get("status")=="stale":continue
        state["status"]="stale";state["stale_reason"]=reason;state["stale_at"]=now;state["state_hash"]=_state_hash(state)
        project.audit("manufacturing.sequence_invalidated",user=user,entity_id=sid,after_hash=state["state_hash"],details={"reason":reason})
        try:
            from .simulation_service import invalidate_manufacturing_simulations
            invalidate_manufacturing_simulations(project, reason=f"m7_invalidated:{reason}", user=user, sequence_id=sid)
        except ImportError:
            pass

def validate_persisted_manufacturing_sequence(project:ProjectModel,sid:str,*,require_current:bool=False)->dict[str,Any]:
    state=project.manufacturing_sequences.get(sid)
    if not isinstance(state,dict):raise ProjectValidationError(f"Onbekende M7 sequence {sid}")
    if str(state.get("schema_version") or "")!=MANUFACTURING_SEQUENCE_STATE_SCHEMA_VERSION:raise ProjectValidationError("Onbekend toekomstig M7 state schema")
    if str(state.get("phase") or "")!=M7_PHASE:raise ProjectValidationError("M7 state phase mismatch")
    if any(bool(state.get(k)) for k in ("dstv_si_released","machine_output_released","direct_machine_transfer")):raise ProjectValidationError("M7 mag geen productieoutput vrijgeven")
    if str(state.get("state_hash") or "")!=_state_hash(state):raise ProjectValidationError("M7 state_hash ongeldig")
    seq=ManufacturingSequencePlan.from_dict(dict(state.get("sequence") or {}))
    if seq.sequence_id!=sid or sequence_id(seq.run_id,seq.assembly_id,seq.capability_id)!=sid:raise ProjectValidationError("M7 sequence identity mismatch")
    validation=dict(state.get("independent_validation") or {});stored=str(validation.get("report_hash") or "");payload={k:v for k,v in validation.items() if k!="report_hash"}
    if stored!=stable_sha256(payload):raise ProjectValidationError("M7 independent validation hash ongeldig")
    neutral=dict(state.get("neutral_job") or {});mh=str(neutral.get("manifest_hash") or "")
    if mh!=stable_sha256({k:v for k,v in neutral.items() if k!="manifest_hash"}) or bool(dict(neutral.get("machine_transfer") or {}).get("allowed")):raise ProjectValidationError("M7 neutral job ongeldig")
    if require_current:
        if state.get("status")!="current":raise ProjectValidationError(f"M7 sequence {sid} heeft status {state.get('status')}")
        if str(state.get("source_snapshot_hash") or "")!=m7_source_snapshot_hash(project,seq.run_id,seq.assembly_id,seq.capability_id):raise ProjectValidationError(f"CWS-MARK-015 M7 sequence {sid} is stale")
        current=IndependentManufacturingSequenceValidator().validate(project,seq)
        if current.status!="passed":raise ProjectValidationError("CWS-MARK-020 M7 sequence faalt onafhankelijke validatie")
    return state

__all__=[name for name in globals() if not name.startswith("_")]
