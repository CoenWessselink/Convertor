"""M18 deployment assurance and removable-media custody.

M18 sits above M17 controlled deployment. It records physical/removable-media
identity, dual-custody checkout/check-in, signed chain-of-custody events,
offline station reconciliation, operator-reported rollback drills and immutable
deployment closure. It never performs controller/network/PLC/machine transport
and never claims that CWS observed a physical machine.
"""
from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
import hashlib
from typing import Any, Iterable, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from cws_convertor.product import APP_VERSION, PROJECT_SCHEMA_VERSION
from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from cws_convertor.production_export.utils import canonical_json_bytes
from .fleet_governance import validate_persisted_fleet_site, validate_persisted_trusted_signer
from .controlled_deployment import (
    validate_persisted_airgap_station,
    validate_persisted_airgap_export,
    validate_persisted_deployment_acknowledgement,
    validate_persisted_deployment_control_policy,
    validate_persisted_deployment_receipt,
    validate_persisted_import_receipt,
    validate_persisted_release_request,
    validate_persisted_rollback_reference,
)

M18_CONTRACT_VERSION = "1.0"
M18_HASH_VERSION = "cws-m18-deployment-assurance-v1"
M18_MEDIA_FORMAT = "CWS_M18_REMOVABLE_MEDIA_V1"
M18_POLICY_FORMAT = "CWS_M18_MEDIA_CUSTODY_POLICY_V1"
M18_SESSION_FORMAT = "CWS_M18_MEDIA_CUSTODY_SESSION_V1"
M18_EVENT_PAYLOAD_FORMAT = "CWS_M18_CUSTODY_EVENT_PAYLOAD_V1"
M18_EVENT_FORMAT = "CWS_M18_SIGNED_CUSTODY_EVENT_V1"
M18_RECONCILIATION_FORMAT = "CWS_M18_STATION_RECONCILIATION_V1"
M18_DRILL_PAYLOAD_FORMAT = "CWS_M18_ROLLBACK_DRILL_PAYLOAD_V1"
M18_DRILL_FORMAT = "CWS_M18_SIGNED_ROLLBACK_DRILL_V1"
M18_CLOSURE_FORMAT = "CWS_M18_DEPLOYMENT_CLOSURE_V1"
M18_DASHBOARD_FORMAT = "CWS_M18_DEPLOYMENT_ASSURANCE_DASHBOARD_V1"

_ALLOWED_EVENT_TYPES = {
    "seal_applied",
    "checkout_attestation",
    "handoff",
    "seal_broken",
    "seal_verified_on_checkin",
    "checkin_attestation",
    "media_retired",
}


class DeploymentAssuranceError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def _hash_record(value: Mapping[str, Any], field: str) -> str:
    return stable_sha256({k: v for k, v in value.items() if k != field})


def _parse_iso(value: Any, *, label: str) -> datetime:
    text = str(value or "").strip()
    if not text:
        raise DeploymentAssuranceError("CWS-MEDIA-001", f"{label} ontbreekt")
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise DeploymentAssuranceError("CWS-MEDIA-001", f"{label} is geen geldige ISO-8601 datum/tijd") from exc
    if dt.tzinfo is None:
        raise DeploymentAssuranceError("CWS-MEDIA-001", f"{label} moet timezone-aware zijn")
    return dt.astimezone(timezone.utc)


def _store_immutable(store: dict[str, dict[str, Any]], key: str, record: dict[str, Any], hash_field: str) -> dict[str, Any]:
    old = store.get(key)
    if isinstance(old, Mapping):
        if str(old.get(hash_field) or "") != str(record.get(hash_field) or ""):
            raise ProjectValidationError(f"M18 immutable record-ID collision voor {key}")
        return dict(old)
    store[key] = record
    return record


def _verify_signature(public_key_pem: str, payload: Mapping[str, Any], signature_base64: str) -> None:
    try:
        key = serialization.load_pem_public_key(str(public_key_pem).encode("ascii"))
        if not isinstance(key, Ed25519PublicKey):
            raise TypeError("not ed25519")
        signature = base64.b64decode(str(signature_base64 or ""), validate=True)
        key.verify(signature, canonical_json_bytes(payload))
    except (InvalidSignature, ValueError, TypeError) as exc:
        raise DeploymentAssuranceError("CWS-MEDIA-002", "Ed25519 signature verification failed") from exc


def _identity_digest(value: Any) -> str:
    text = str(value or "").strip()
    return hashlib.sha256(text.encode("utf-8")).hexdigest() if text else ""


def register_removable_media(
    project: ProjectModel,
    *,
    media_id: str,
    site_id: str,
    label: str,
    manufacturer: str,
    model: str,
    serial_number: str,
    filesystem_uuid: str = "",
    capacity_bytes: int = 0,
    user: str = "system",
) -> dict[str, Any]:
    site = validate_persisted_fleet_site(project, str(site_id))
    media_id = str(media_id or "").strip()
    if not media_id or not str(label or "").strip() or not str(serial_number or "").strip():
        raise DeploymentAssuranceError("CWS-MEDIA-003", "Media vereist media_id, label en fysieke serial identity")
    identity = {
        "manufacturer": str(manufacturer or "").strip(),
        "model": str(model or "").strip(),
        "serial_number_sha256": _identity_digest(serial_number),
        "filesystem_uuid_sha256": _identity_digest(filesystem_uuid),
        "capacity_bytes": max(0, int(capacity_bytes or 0)),
    }
    record = {
        "format": M18_MEDIA_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "media_id": media_id,
        "site_id": site["site_id"],
        "site_hash": site["site_hash"],
        "label": str(label).strip(),
        "media_type": "removable_media",
        "identity": identity,
        "physical_identity_hash": stable_sha256(identity),
        "status": "active",
        "network_controller_transport": False,
        "machine_observed_by_cws": False,
        "direct_machine_transfer": False,
        "created_for_cws_version": APP_VERSION,
        "created_for_project_schema": PROJECT_SCHEMA_VERSION,
        "hash_version": M18_HASH_VERSION,
    }
    record["media_hash"] = _hash_record(record, "media_hash")
    result = _store_immutable(project.manufacturing_media_devices, media_id, record, "media_hash")
    project.audit("manufacturing.media_registered", user=user, entity_id=media_id, after_hash=result["media_hash"], details={"site_id": site["site_id"], "direct_machine_transfer": False})
    return result


def validate_persisted_removable_media(project: ProjectModel, media_id: str, *, require_active: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_media_devices.get(media_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M18_MEDIA_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION:
        raise ProjectValidationError(f"M18 media {media_id} ontbreekt/ongeldig")
    if str(raw.get("media_id") or "") != media_id or str(raw.get("media_hash") or "") != _hash_record(raw, "media_hash"):
        raise ProjectValidationError("M18 media identity/hash ongeldig")
    site = validate_persisted_fleet_site(project, str(raw.get("site_id") or ""))
    if str(raw.get("site_hash") or "") != site["site_hash"]:
        raise ProjectValidationError("M18 media site snapshot stale")
    identity = dict(raw.get("identity") or {})
    if str(raw.get("physical_identity_hash") or "") != stable_sha256(identity):
        raise ProjectValidationError("M18 physical media identity hash ongeldig")
    if require_active and str(raw.get("status") or "") != "active":
        raise ProjectValidationError("M18 media is niet actief")
    if bool(raw.get("network_controller_transport")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M18 media veiligheidsflags ongeldig")
    return dict(raw)


def create_media_custody_policy(
    project: ProjectModel,
    *,
    policy_name: str,
    station_id: str,
    custodian_signer_ids: Iterable[str],
    minimum_checkout_custodians: int = 2,
    minimum_checkin_custodians: int = 2,
    require_seal: bool = True,
    require_station_reconciliation: bool = True,
    require_rollback_drill_for_closure: bool = True,
    maximum_rollback_drill_age_hours: int = 720,
    user: str = "system",
) -> dict[str, Any]:
    station = validate_persisted_airgap_station(project, str(station_id), require_current=True)
    signer_ids = sorted({str(x).strip() for x in custodian_signer_ids if str(x).strip()})
    if not str(policy_name or "").strip() or len(signer_ids) < 2:
        raise DeploymentAssuranceError("CWS-MEDIA-004", "M18 custody policy vereist naam en minimaal twee custodians")
    snapshots: dict[str, str] = {}
    for signer_id in signer_ids:
        signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
        snapshots[signer_id] = signer["signer_hash"]
    out_min = max(2, int(minimum_checkout_custodians or 2))
    in_min = max(2, int(minimum_checkin_custodians or 2))
    if out_min > len(signer_ids) or in_min > len(signer_ids):
        raise DeploymentAssuranceError("CWS-MEDIA-004", "M18 custody minimum overschrijdt aantal custodians")
    record = {
        "format": M18_POLICY_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "policy_name": str(policy_name).strip(),
        "station_id": station["station_id"],
        "station_hash": station["station_hash"],
        "site_id": station["site_id"],
        "custodian_signer_snapshots": snapshots,
        "minimum_checkout_custodians": out_min,
        "minimum_checkin_custodians": in_min,
        "require_seal": bool(require_seal),
        "require_station_reconciliation": bool(require_station_reconciliation),
        "require_rollback_drill_for_closure": bool(require_rollback_drill_for_closure),
        "maximum_rollback_drill_age_hours": max(1, int(maximum_rollback_drill_age_hours or 720)),
        "operator_reported_evidence_only": True,
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "created_for_cws_version": APP_VERSION,
        "created_for_project_schema": PROJECT_SCHEMA_VERSION,
        "hash_version": M18_HASH_VERSION,
    }
    policy_id = "custody-policy-" + stable_sha256(record)[:24]
    record["policy_id"] = policy_id
    record["policy_hash"] = _hash_record(record, "policy_hash")
    result = _store_immutable(project.manufacturing_media_custody_policies, policy_id, record, "policy_hash")
    project.audit("manufacturing.media_custody_policy", user=user, entity_id=policy_id, after_hash=result["policy_hash"], details={"station_id": station["station_id"], "direct_machine_transfer": False})
    return result


def validate_persisted_media_custody_policy(project: ProjectModel, policy_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_media_custody_policies.get(policy_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M18_POLICY_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION:
        raise ProjectValidationError(f"M18 custody policy {policy_id} ontbreekt/ongeldig")
    if str(raw.get("policy_id") or "") != policy_id or str(raw.get("policy_hash") or "") != _hash_record(raw, "policy_hash"):
        raise ProjectValidationError("M18 custody policy identity/hash ongeldig")
    station = validate_persisted_airgap_station(project, str(raw.get("station_id") or ""), require_current=require_current)
    if str(raw.get("station_hash") or "") != station["station_hash"]:
        raise ProjectValidationError("M18 custody policy station snapshot stale")
    snapshots = dict(raw.get("custodian_signer_snapshots") or {})
    if len(snapshots) < 2:
        raise ProjectValidationError("M18 custody policy heeft onvoldoende custodians")
    for signer_id, signer_hash in snapshots.items():
        signer = validate_persisted_trusted_signer(project, str(signer_id), require_current=require_current)
        if str(signer_hash) != signer["signer_hash"]:
            raise ProjectValidationError("M18 custody policy signer snapshot stale")
    if int(raw.get("minimum_checkout_custodians") or 0) < 2 or int(raw.get("minimum_checkin_custodians") or 0) < 2:
        raise ProjectValidationError("M18 custody policy dual-control minima ongeldig")
    if not bool(raw.get("operator_reported_evidence_only")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M18 custody policy veiligheidsflags ongeldig")
    return dict(raw)


def create_media_custody_session(
    project: ProjectModel,
    *,
    media_id: str,
    policy_id: str,
    airgap_export_id: str,
    seal_id: str = "",
    user: str = "system",
) -> dict[str, Any]:
    media = validate_persisted_removable_media(project, media_id, require_active=True)
    policy = validate_persisted_media_custody_policy(project, policy_id, require_current=True)
    export = validate_persisted_airgap_export(project, airgap_export_id, require_current=True)
    if media["site_id"] != policy["site_id"] or export["station_id"] != policy["station_id"]:
        raise DeploymentAssuranceError("CWS-MEDIA-005", "Media/policy/export site-station binding mismatch")
    if bool(policy.get("require_seal")) and not str(seal_id or "").strip():
        raise DeploymentAssuranceError("CWS-MEDIA-005", "M18 policy vereist physical seal_id")
    record = {
        "format": M18_SESSION_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "media_id": media_id,
        "media_hash": media["media_hash"],
        "physical_identity_hash": media["physical_identity_hash"],
        "policy_id": policy_id,
        "policy_hash": policy["policy_hash"],
        "station_id": policy["station_id"],
        "airgap_export_id": airgap_export_id,
        "airgap_export_record_hash": export["airgap_export_record_hash"],
        "release_request_id": export["release_request_id"],
        "seal_id_sha256": _identity_digest(seal_id),
        "opened_at": utc_now_iso(),
        "operator_release_required": True,
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "hash_version": M18_HASH_VERSION,
    }
    session_id = "custody-" + stable_sha256({"media": media["media_hash"], "export": export["airgap_export_record_hash"], "policy": policy["policy_hash"]})[:28]
    record["session_id"] = session_id
    record["session_hash"] = _hash_record(record, "session_hash")
    result = _store_immutable(project.manufacturing_media_custody_sessions, session_id, record, "session_hash")
    project.audit("manufacturing.media_custody_session", user=user, entity_id=session_id, after_hash=result["session_hash"], details={"media_id": media_id, "airgap_export_id": airgap_export_id})
    return result


def validate_persisted_media_custody_session(project: ProjectModel, session_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_media_custody_sessions.get(session_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M18_SESSION_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION:
        raise ProjectValidationError(f"M18 custody session {session_id} ontbreekt/ongeldig")
    if str(raw.get("session_id") or "") != session_id or str(raw.get("session_hash") or "") != _hash_record(raw, "session_hash"):
        raise ProjectValidationError("M18 custody session identity/hash ongeldig")
    media = validate_persisted_removable_media(project, str(raw.get("media_id") or ""), require_active=require_current)
    policy = validate_persisted_media_custody_policy(project, str(raw.get("policy_id") or ""), require_current=require_current)
    export = validate_persisted_airgap_export(project, str(raw.get("airgap_export_id") or ""), require_current=require_current)
    if str(raw.get("media_hash") or "") != media["media_hash"] or str(raw.get("physical_identity_hash") or "") != media["physical_identity_hash"] or str(raw.get("policy_hash") or "") != policy["policy_hash"] or str(raw.get("airgap_export_record_hash") or "") != export["airgap_export_record_hash"]:
        raise ProjectValidationError("M18 custody session snapshot stale")
    if bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M18 custody session veiligheidsflags ongeldig")
    return dict(raw)


def _events_for_session(project: ProjectModel, session_id: str) -> list[dict[str, Any]]:
    rows = []
    for event_id in project.manufacturing_media_custody_events:
        raw = project.manufacturing_media_custody_events[event_id]
        if isinstance(raw, Mapping) and str(dict(raw.get("payload") or {}).get("session_id") or "") == session_id:
            rows.append(validate_persisted_media_custody_event(project, str(event_id), require_current=False))
    rows.sort(key=lambda x: int(dict(x.get("payload") or {}).get("sequence_index") or 0))
    return rows


def validate_media_custody_chain(project: ProjectModel, session_id: str, *, require_current: bool = False) -> list[dict[str, Any]]:
    """Independently validate the full signed event chain for one custody session."""
    session = validate_persisted_media_custody_session(project, session_id, require_current=require_current)
    policy = validate_persisted_media_custody_policy(project, session["policy_id"], require_current=require_current)
    events = _events_for_session(project, session_id)
    checkout: set[str] = set()
    checkin: set[str] = set()
    previous: dict[str, Any] | None = None
    for expected_index, event in enumerate(events):
        payload = dict(event.get("payload") or {})
        if int(payload.get("sequence_index", -1)) != expected_index:
            raise ProjectValidationError("M18 custody chain sequence is niet aaneengesloten")
        if str(payload.get("session_id") or "") != session_id or str(payload.get("session_hash") or "") != session["session_hash"]:
            raise ProjectValidationError("M18 custody chain session snapshot mismatch")
        if str(payload.get("media_id") or "") != session["media_id"] or str(payload.get("physical_identity_hash") or "") != session["physical_identity_hash"] or str(payload.get("airgap_export_id") or "") != session["airgap_export_id"]:
            raise ProjectValidationError("M18 custody chain media/export snapshot mismatch")
        signer_id = str(event.get("signer_id") or "")
        if signer_id not in dict(policy.get("custodian_signer_snapshots") or {}):
            raise ProjectValidationError("M18 custody chain signer is niet toegestaan door policy")
        if previous is None:
            if str(payload.get("previous_event_id") or "") or str(payload.get("previous_event_hash") or ""):
                raise ProjectValidationError("Eerste M18 custody event heeft onverwachte previous link")
        else:
            if str(payload.get("previous_event_id") or "") != previous["custody_event_id"] or str(payload.get("previous_event_hash") or "") != previous["custody_event_hash"]:
                raise ProjectValidationError("M18 custody chain previous-event link mismatch")
        event_type = str(payload.get("event_type") or "")
        if event_type not in _ALLOWED_EVENT_TYPES:
            raise ProjectValidationError("M18 custody chain event type ongeldig")
        checkout_complete = len(checkout) >= int(policy["minimum_checkout_custodians"])
        checkin_complete = len(checkin) >= int(policy["minimum_checkin_custodians"])
        if event_type == "checkout_attestation":
            if signer_id in checkout:
                raise ProjectValidationError("M18 custody chain duplicate checkout custodian")
            checkout.add(signer_id)
        elif event_type in {"handoff", "seal_broken", "checkin_attestation", "seal_verified_on_checkin"}:
            if not checkout_complete:
                raise ProjectValidationError(f"M18 custody chain {event_type} vóór completed checkout")
            if event_type == "checkin_attestation":
                if signer_id in checkin:
                    raise ProjectValidationError("M18 custody chain duplicate checkin custodian")
                checkin.add(signer_id)
        elif event_type == "media_retired" and not checkin_complete:
            raise ProjectValidationError("M18 custody chain media retirement vóór completed check-in")
        previous = event
    return events


def custody_session_status(project: ProjectModel, session_id: str) -> dict[str, Any]:
    session = validate_persisted_media_custody_session(project, session_id, require_current=False)
    policy = validate_persisted_media_custody_policy(project, session["policy_id"], require_current=False)
    events = validate_media_custody_chain(project, session_id, require_current=False)
    checkout = {e["signer_id"] for e in events if dict(e["payload"]).get("event_type") == "checkout_attestation"}
    checkin = {e["signer_id"] for e in events if dict(e["payload"]).get("event_type") == "checkin_attestation"}
    event_types = [str(dict(e["payload"]).get("event_type") or "") for e in events]
    return {
        "session_id": session_id,
        "event_count": len(events),
        "checkout_custodians": sorted(checkout),
        "checkin_custodians": sorted(checkin),
        "checkout_complete": len(checkout) >= int(policy["minimum_checkout_custodians"]),
        "checkin_complete": len(checkin) >= int(policy["minimum_checkin_custodians"]),
        "seal_applied": "seal_applied" in event_types,
        "seal_verified_on_checkin": "seal_verified_on_checkin" in event_types,
        "closed_media_loop": len(checkout) >= int(policy["minimum_checkout_custodians"]) and len(checkin) >= int(policy["minimum_checkin_custodians"]),
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
    }


def media_custody_event_signing_payload(
    project: ProjectModel,
    *,
    session_id: str,
    signer_id: str,
    event_type: str,
    event_nonce: str,
    notes: str = "",
    handoff_to_signer_id: str = "",
    observed_at: str | None = None,
) -> dict[str, Any]:
    session = validate_persisted_media_custody_session(project, session_id, require_current=True)
    policy = validate_persisted_media_custody_policy(project, session["policy_id"], require_current=True)
    event_type = str(event_type or "").strip()
    if event_type not in _ALLOWED_EVENT_TYPES:
        raise DeploymentAssuranceError("CWS-MEDIA-006", f"Onbekend custody event_type: {event_type}")
    if signer_id not in dict(policy.get("custodian_signer_snapshots") or {}):
        raise DeploymentAssuranceError("CWS-MEDIA-006", "Custody signer niet toegestaan door policy")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    events = _events_for_session(project, session_id)
    previous = events[-1] if events else None
    status = custody_session_status(project, session_id)
    if event_type in {"handoff", "seal_broken", "checkin_attestation", "seal_verified_on_checkin"} and not status["checkout_complete"]:
        raise DeploymentAssuranceError("CWS-MEDIA-006", f"{event_type} vereist completed dual-custody checkout")
    if event_type == "checkin_attestation" and signer_id in status["checkin_custodians"]:
        raise DeploymentAssuranceError("CWS-MEDIA-006", "Dezelfde custodian mag check-in niet dubbel attesteren")
    if event_type == "checkout_attestation" and signer_id in status["checkout_custodians"]:
        raise DeploymentAssuranceError("CWS-MEDIA-006", "Dezelfde custodian mag checkout niet dubbel attesteren")
    if event_type == "media_retired" and not status["checkin_complete"]:
        raise DeploymentAssuranceError("CWS-MEDIA-006", "Media retirement vereist completed check-in")
    payload = {
        "format": M18_EVENT_PAYLOAD_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "session_id": session_id,
        "session_hash": session["session_hash"],
        "media_id": session["media_id"],
        "physical_identity_hash": session["physical_identity_hash"],
        "airgap_export_id": session["airgap_export_id"],
        "event_type": event_type,
        "sequence_index": len(events),
        "previous_event_id": str(previous.get("custody_event_id") or "") if previous else "",
        "previous_event_hash": str(previous.get("custody_event_hash") or "") if previous else "",
        "signer_id": signer_id,
        "signer_hash": signer["signer_hash"],
        "handoff_to_signer_id": str(handoff_to_signer_id or "").strip(),
        "event_nonce": str(event_nonce or "").strip(),
        "notes": str(notes or "").strip(),
        "observed_at": _parse_iso(observed_at or utc_now_iso(), label="observed_at").isoformat(),
        "operator_reported_physical_custody": True,
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "hash_version": M18_HASH_VERSION,
    }
    if not payload["event_nonce"]:
        raise DeploymentAssuranceError("CWS-MEDIA-006", "Custody event nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_media_custody_event(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {})
    payload = dict(raw.get("payload") or {})
    if raw.get("format") != M18_EVENT_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519" or payload.get("format") != M18_EVENT_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise DeploymentAssuranceError("CWS-MEDIA-007", "M18 custody event envelope/payload ongeldig")
    session = validate_persisted_media_custody_session(project, str(payload.get("session_id") or ""), require_current=True)
    policy = validate_persisted_media_custody_policy(project, session["policy_id"], require_current=True)
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("signer_id") or "") or signer_id not in dict(policy.get("custodian_signer_snapshots") or {}):
        raise DeploymentAssuranceError("CWS-MEDIA-007", "M18 custody signer mismatch/not allowed")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    if str(payload.get("signer_hash") or "") != signer["signer_hash"] or str(payload.get("session_hash") or "") != session["session_hash"] or str(payload.get("physical_identity_hash") or "") != session["physical_identity_hash"]:
        raise DeploymentAssuranceError("CWS-MEDIA-007", "M18 custody event snapshot stale")
    if not bool(payload.get("operator_reported_physical_custody")) or bool(payload.get("machine_observed_by_cws")) or bool(payload.get("deployment_transport_authorized")) or bool(payload.get("direct_machine_transfer")):
        raise DeploymentAssuranceError("CWS-MEDIA-007", "M18 custody event veiligheidsflags ongeldig")
    events = _events_for_session(project, session["session_id"])
    previous = events[-1] if events else None
    expected_index = len(events)
    sequence_value = payload.get("sequence_index")
    if sequence_value is None or int(sequence_value) != expected_index:
        raise DeploymentAssuranceError("CWS-MEDIA-007", "M18 custody event sequence is stale")
    if previous:
        if str(payload.get("previous_event_id") or "") != previous["custody_event_id"] or str(payload.get("previous_event_hash") or "") != previous["custody_event_hash"]:
            raise DeploymentAssuranceError("CWS-MEDIA-007", "M18 custody chain previous-event mismatch")
    elif str(payload.get("previous_event_id") or "") or str(payload.get("previous_event_hash") or ""):
        raise DeploymentAssuranceError("CWS-MEDIA-007", "Eerste M18 custody event mag geen previous event hebben")
    status = custody_session_status(project, session["session_id"])
    event_type = str(payload.get("event_type") or "")
    if event_type not in _ALLOWED_EVENT_TYPES:
        raise DeploymentAssuranceError("CWS-MEDIA-007", "M18 custody event type ongeldig")
    if event_type == "checkout_attestation" and signer_id in status["checkout_custodians"]:
        raise DeploymentAssuranceError("CWS-MEDIA-007", "Duplicate checkout custodian")
    if event_type in {"handoff", "seal_broken", "checkin_attestation", "seal_verified_on_checkin"} and not status["checkout_complete"]:
        raise DeploymentAssuranceError("CWS-MEDIA-007", f"{event_type} vereist completed checkout")
    if event_type == "checkin_attestation" and signer_id in status["checkin_custodians"]:
        raise DeploymentAssuranceError("CWS-MEDIA-007", "Duplicate checkin custodian")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    event_id = "custody-event-" + stable_sha256({"payload": payload["payload_hash"], "signature": raw.get("signature_base64")})[:28]
    existing = project.manufacturing_media_custody_events.get(event_id)
    if isinstance(existing, Mapping):
        return validate_persisted_media_custody_event(project, event_id, require_current=True)
    record = {
        "format": M18_EVENT_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "custody_event_id": event_id,
        "signer_id": signer_id,
        "signer_hash": signer["signer_hash"],
        "algorithm": "ed25519",
        "payload": payload,
        "signature_base64": str(raw.get("signature_base64") or ""),
        "signature_verified": True,
        "received_at": utc_now_iso(),
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "hash_version": M18_HASH_VERSION,
    }
    record["custody_event_hash"] = _hash_record(record, "custody_event_hash")
    result = _store_immutable(project.manufacturing_media_custody_events, event_id, record, "custody_event_hash")
    project.audit("manufacturing.media_custody_event", user=user, entity_id=event_id, after_hash=result["custody_event_hash"], details={"session_id": session["session_id"], "event_type": event_type})
    return result


def validate_persisted_media_custody_event(project: ProjectModel, event_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_media_custody_events.get(event_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M18_EVENT_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION:
        raise ProjectValidationError(f"M18 custody event {event_id} ontbreekt/ongeldig")
    if str(raw.get("custody_event_id") or "") != event_id or str(raw.get("custody_event_hash") or "") != _hash_record(raw, "custody_event_hash"):
        raise ProjectValidationError("M18 custody event identity/hash ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M18 custody event payload hash ongeldig")
    session = validate_persisted_media_custody_session(project, str(payload.get("session_id") or ""), require_current=require_current)
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), require_current=require_current)
    if str(payload.get("session_hash") or "") != session["session_hash"] or str(payload.get("signer_hash") or "") != signer["signer_hash"] or str(raw.get("signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M18 custody event snapshot stale")
    try:
        _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    except DeploymentAssuranceError as exc:
        raise ProjectValidationError("M18 custody event signature ongeldig") from exc
    if not bool(raw.get("signature_verified")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M18 custody event veiligheidsflags ongeldig")
    return dict(raw)


def _station_source_snapshot(project: ProjectModel, station_id: str) -> dict[str, Any]:
    exports = []
    for export_id, raw in sorted(project.manufacturing_deployment_airgap_exports.items()):
        if isinstance(raw, Mapping) and str(raw.get("station_id") or "") == station_id:
            row = validate_persisted_airgap_export(project, str(export_id), require_current=False)
            exports.append({"airgap_export_id": export_id, "hash": row["airgap_export_record_hash"]})
    imports = []
    for rid in sorted(project.manufacturing_deployment_import_receipts):
        row = validate_persisted_import_receipt(project, str(rid), require_current=False)
        p = dict(row["payload"])
        if str(p.get("station_id") or "") == station_id:
            imports.append({"import_receipt_id": rid, "airgap_export_id": p.get("airgap_export_id"), "hash": row["import_receipt_hash"]})
    deployments = []
    for rid in sorted(project.manufacturing_deployment_receipts):
        row = validate_persisted_deployment_receipt(project, str(rid), require_current=False)
        p = dict(row["payload"])
        if str(p.get("station_id") or "") == station_id:
            deployments.append({"deployment_receipt_id": rid, "airgap_export_id": p.get("airgap_export_id"), "hash": row["deployment_receipt_hash"]})
    acks = []
    for aid in sorted(project.manufacturing_deployment_acknowledgements):
        row = validate_persisted_deployment_acknowledgement(project, str(aid), require_current=False)
        p = dict(row["payload"])
        receipt_id = str(p.get("deployment_receipt_id") or "")
        receipt = project.manufacturing_deployment_receipts.get(receipt_id)
        rp = dict(receipt.get("payload") or {}) if isinstance(receipt, Mapping) else {}
        if str(rp.get("station_id") or "") == station_id:
            acks.append({"acknowledgement_id": aid, "deployment_receipt_id": receipt_id, "hash": row["acknowledgement_hash"]})
    sessions = []
    for sid in sorted(project.manufacturing_media_custody_sessions):
        row = validate_persisted_media_custody_session(project, str(sid), require_current=False)
        if str(row.get("station_id") or "") == station_id:
            status = custody_session_status(project, str(sid))
            sessions.append({"session_id": sid, "airgap_export_id": row["airgap_export_id"], "session_hash": row["session_hash"], "status": status})
    return {"station_id": station_id, "exports": exports, "imports": imports, "deployments": deployments, "acknowledgements": acks, "custody_sessions": sessions}


def _reconciliation_issues(snapshot: Mapping[str, Any]) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    imports_by_export = {str(x.get("airgap_export_id") or ""): x for x in list(snapshot.get("imports") or [])}
    deps_by_export = {str(x.get("airgap_export_id") or ""): x for x in list(snapshot.get("deployments") or [])}
    ack_receipts = {str(x.get("deployment_receipt_id") or "") for x in list(snapshot.get("acknowledgements") or [])}
    sessions_by_export = {str(x.get("airgap_export_id") or ""): x for x in list(snapshot.get("custody_sessions") or [])}
    for export in list(snapshot.get("exports") or []):
        eid = str(export.get("airgap_export_id") or "")
        imp = imports_by_export.get(eid)
        dep = deps_by_export.get(eid)
        session = sessions_by_export.get(eid)
        if imp is None:
            issues.append({"code": "CWS-MEDIA-REC-001", "airgap_export_id": eid, "blocking": True, "message": "import receipt ontbreekt"})
        if dep is None:
            issues.append({"code": "CWS-MEDIA-REC-002", "airgap_export_id": eid, "blocking": True, "message": "deployment receipt ontbreekt"})
        elif str(dep.get("deployment_receipt_id") or "") not in ack_receipts:
            issues.append({"code": "CWS-MEDIA-REC-003", "airgap_export_id": eid, "blocking": True, "message": "deployment acknowledgement ontbreekt"})
        if session is None:
            issues.append({"code": "CWS-MEDIA-REC-004", "airgap_export_id": eid, "blocking": True, "message": "media custody session ontbreekt"})
        elif not bool(dict(session.get("status") or {}).get("checkin_complete")):
            issues.append({"code": "CWS-MEDIA-REC-005", "airgap_export_id": eid, "blocking": True, "message": "dual-custody media check-in ontbreekt"})
    return issues


def reconcile_offline_station(project: ProjectModel, *, station_id: str, user: str = "system", persist: bool = True) -> dict[str, Any]:
    station = validate_persisted_airgap_station(project, station_id, require_current=False)
    snapshot = _station_source_snapshot(project, station_id)
    issues = _reconciliation_issues(snapshot)
    source_hash = stable_sha256(snapshot)
    record = {
        "format": M18_RECONCILIATION_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "station_id": station_id,
        "station_hash": station["station_hash"],
        "source_snapshot_hash": source_hash,
        "source_snapshot": snapshot,
        "issues": issues,
        "blocking_issue_count": sum(1 for x in issues if x.get("blocking")),
        "reconciliation_passed": not any(x.get("blocking") for x in issues),
        "reconciled_at": utc_now_iso(),
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "hash_version": M18_HASH_VERSION,
    }
    reconciliation_id = "recon-" + stable_sha256({"station": station["station_hash"], "snapshot": source_hash})[:28]
    record["reconciliation_id"] = reconciliation_id
    record["reconciliation_hash"] = _hash_record(record, "reconciliation_hash")
    if persist:
        result = _store_immutable(project.manufacturing_station_reconciliations, reconciliation_id, record, "reconciliation_hash")
        project.audit("manufacturing.station_reconciliation", user=user, entity_id=reconciliation_id, after_hash=result["reconciliation_hash"], details={"station_id": station_id, "blocking_issue_count": result["blocking_issue_count"]})
        return result
    return record


def validate_persisted_station_reconciliation(project: ProjectModel, reconciliation_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_station_reconciliations.get(reconciliation_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M18_RECONCILIATION_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION:
        raise ProjectValidationError(f"M18 reconciliation {reconciliation_id} ontbreekt/ongeldig")
    if str(raw.get("reconciliation_id") or "") != reconciliation_id or str(raw.get("reconciliation_hash") or "") != _hash_record(raw, "reconciliation_hash"):
        raise ProjectValidationError("M18 reconciliation identity/hash ongeldig")
    station = validate_persisted_airgap_station(project, str(raw.get("station_id") or ""), require_current=False)
    stored_snapshot = dict(raw.get("source_snapshot") or {})
    if str(raw.get("station_hash") or "") != station["station_hash"] or str(raw.get("source_snapshot_hash") or "") != stable_sha256(stored_snapshot):
        raise ProjectValidationError("M18 reconciliation snapshot/hash ongeldig")
    expected_issues = _reconciliation_issues(stored_snapshot)
    if list(raw.get("issues") or []) != expected_issues:
        raise ProjectValidationError("M18 reconciliation issues zijn niet onafhankelijk reproduceerbaar")
    expected_blocking = sum(1 for x in expected_issues if x.get("blocking"))
    if int(raw.get("blocking_issue_count") or 0) != expected_blocking or bool(raw.get("reconciliation_passed")) != (expected_blocking == 0):
        raise ProjectValidationError("M18 reconciliation pass/blocking status mismatch")
    if require_current and str(raw.get("source_snapshot_hash") or "") != stable_sha256(_station_source_snapshot(project, station["station_id"])):
        raise ProjectValidationError("M18 reconciliation is stale")
    if bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M18 reconciliation veiligheidsflags ongeldig")
    return dict(raw)


def rollback_drill_signing_payload(
    project: ProjectModel,
    *,
    rollback_id: str,
    policy_id: str,
    station_id: str,
    signer_id: str,
    drill_nonce: str,
    result: str,
    steps: Iterable[str],
    performed_at: str | None = None,
) -> dict[str, Any]:
    rollback = validate_persisted_rollback_reference(project, rollback_id)
    policy = validate_persisted_media_custody_policy(project, policy_id, require_current=True)
    station = validate_persisted_airgap_station(project, station_id, require_current=True)
    if station["station_id"] != policy["station_id"] or signer_id not in dict(policy.get("custodian_signer_snapshots") or {}):
        raise DeploymentAssuranceError("CWS-MEDIA-008", "Rollback drill station/signer niet toegestaan")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    result = str(result or "").strip().lower()
    if result not in {"passed", "failed"}:
        raise DeploymentAssuranceError("CWS-MEDIA-008", "Rollback drill result moet passed/failed zijn")
    rows = [str(x).strip() for x in steps if str(x).strip()]
    if not rows:
        raise DeploymentAssuranceError("CWS-MEDIA-008", "Rollback drill vereist beschreven stappen")
    payload = {
        "format": M18_DRILL_PAYLOAD_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "rollback_id": rollback_id,
        "rollback_hash": rollback["rollback_hash"],
        "binding_id": rollback["binding_id"],
        "policy_id": policy_id,
        "policy_hash": policy["policy_hash"],
        "station_id": station_id,
        "station_hash": station["station_hash"],
        "signer_id": signer_id,
        "signer_hash": signer["signer_hash"],
        "drill_nonce": str(drill_nonce or "").strip(),
        "result": result,
        "steps": rows,
        "performed_at": _parse_iso(performed_at or utc_now_iso(), label="performed_at").isoformat(),
        "operator_reported_rollback_drill": True,
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "hash_version": M18_HASH_VERSION,
    }
    if not payload["drill_nonce"]:
        raise DeploymentAssuranceError("CWS-MEDIA-008", "Rollback drill nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_rollback_drill(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {})
    payload = dict(raw.get("payload") or {})
    if raw.get("format") != M18_DRILL_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519" or payload.get("format") != M18_DRILL_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise DeploymentAssuranceError("CWS-MEDIA-009", "M18 rollback drill envelope/payload ongeldig")
    rollback = validate_persisted_rollback_reference(project, str(payload.get("rollback_id") or ""))
    policy = validate_persisted_media_custody_policy(project, str(payload.get("policy_id") or ""), require_current=True)
    station = validate_persisted_airgap_station(project, str(payload.get("station_id") or ""), require_current=True)
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("signer_id") or "") or signer_id not in dict(policy.get("custodian_signer_snapshots") or {}):
        raise DeploymentAssuranceError("CWS-MEDIA-009", "Rollback drill signer mismatch/not allowed")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    if str(payload.get("rollback_hash") or "") != rollback["rollback_hash"] or str(payload.get("policy_hash") or "") != policy["policy_hash"] or str(payload.get("station_hash") or "") != station["station_hash"] or str(payload.get("signer_hash") or "") != signer["signer_hash"]:
        raise DeploymentAssuranceError("CWS-MEDIA-009", "Rollback drill snapshot stale")
    if not bool(payload.get("operator_reported_rollback_drill")) or bool(payload.get("machine_observed_by_cws")) or bool(payload.get("deployment_transport_authorized")) or bool(payload.get("direct_machine_transfer")):
        raise DeploymentAssuranceError("CWS-MEDIA-009", "Rollback drill veiligheidsflags ongeldig")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    drill_id = "rollback-drill-" + stable_sha256({"payload": payload["payload_hash"], "signature": raw.get("signature_base64")})[:28]
    existing = project.manufacturing_rollback_drills.get(drill_id)
    if isinstance(existing, Mapping):
        return validate_persisted_rollback_drill(project, drill_id, require_current=True)
    record = {
        "format": M18_DRILL_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "rollback_drill_id": drill_id,
        "signer_id": signer_id,
        "signer_hash": signer["signer_hash"],
        "algorithm": "ed25519",
        "payload": payload,
        "signature_base64": str(raw.get("signature_base64") or ""),
        "signature_verified": True,
        "received_at": utc_now_iso(),
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "hash_version": M18_HASH_VERSION,
    }
    record["rollback_drill_hash"] = _hash_record(record, "rollback_drill_hash")
    result = _store_immutable(project.manufacturing_rollback_drills, drill_id, record, "rollback_drill_hash")
    project.audit("manufacturing.rollback_drill", user=user, entity_id=drill_id, after_hash=result["rollback_drill_hash"], details={"binding_id": rollback["binding_id"], "result": payload["result"]})
    return result


def validate_persisted_rollback_drill(project: ProjectModel, drill_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_rollback_drills.get(drill_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M18_DRILL_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION:
        raise ProjectValidationError(f"M18 rollback drill {drill_id} ontbreekt/ongeldig")
    if str(raw.get("rollback_drill_id") or "") != drill_id or str(raw.get("rollback_drill_hash") or "") != _hash_record(raw, "rollback_drill_hash"):
        raise ProjectValidationError("M18 rollback drill identity/hash ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M18 rollback drill payload hash ongeldig")
    rollback = validate_persisted_rollback_reference(project, str(payload.get("rollback_id") or ""))
    policy = validate_persisted_media_custody_policy(project, str(payload.get("policy_id") or ""), require_current=require_current)
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), require_current=require_current)
    if str(payload.get("rollback_hash") or "") != rollback["rollback_hash"] or str(payload.get("policy_hash") or "") != policy["policy_hash"] or str(payload.get("signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M18 rollback drill snapshot stale")
    try:
        _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    except DeploymentAssuranceError as exc:
        raise ProjectValidationError("M18 rollback drill signature ongeldig") from exc
    if not bool(raw.get("signature_verified")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M18 rollback drill veiligheidsflags ongeldig")
    return dict(raw)


def _latest_passed_drill(project: ProjectModel, *, binding_id: str, policy: Mapping[str, Any], at: datetime) -> dict[str, Any] | None:
    rows = []
    for drill_id in project.manufacturing_rollback_drills:
        row = validate_persisted_rollback_drill(project, str(drill_id), require_current=False)
        p = dict(row["payload"])
        if str(p.get("binding_id") or "") == binding_id and str(p.get("policy_id") or "") == str(policy.get("policy_id") or "") and str(p.get("result") or "") == "passed":
            rows.append(row)
    if not rows:
        return None
    rows.sort(key=lambda r: _parse_iso(dict(r["payload"])["performed_at"], label="rollback drill performed_at"), reverse=True)
    row = rows[0]
    performed = _parse_iso(dict(row["payload"])["performed_at"], label="rollback drill performed_at")
    if performed > at:
        return None
    age = at - performed
    if age > timedelta(hours=int(policy.get("maximum_rollback_drill_age_hours") or 720)):
        return None
    return row


def close_deployment_assurance(
    project: ProjectModel,
    *,
    deployment_receipt_id: str,
    custody_session_id: str,
    reconciliation_id: str,
    user: str = "system",
) -> dict[str, Any]:
    receipt = validate_persisted_deployment_receipt(project, deployment_receipt_id, require_current=False)
    rp = dict(receipt["payload"])
    session = validate_persisted_media_custody_session(project, custody_session_id, require_current=False)
    policy = validate_persisted_media_custody_policy(project, session["policy_id"], require_current=True)
    recon = validate_persisted_station_reconciliation(project, reconciliation_id, require_current=True)
    if str(rp.get("airgap_export_id") or "") != session["airgap_export_id"] or str(rp.get("station_id") or "") != session["station_id"] or recon["station_id"] != session["station_id"]:
        raise DeploymentAssuranceError("CWS-MEDIA-010", "M18 closure receipt/session/reconciliation binding mismatch")
    status = custody_session_status(project, custody_session_id)
    if not status["checkout_complete"] or not status["checkin_complete"]:
        raise DeploymentAssuranceError("CWS-MEDIA-010", "M18 closure vereist dual-custody checkout en check-in")
    if bool(policy.get("require_seal")) and (not status["seal_applied"] or not status["seal_verified_on_checkin"]):
        raise DeploymentAssuranceError("CWS-MEDIA-010", "M18 closure vereist seal applied + verified-on-checkin evidence")
    if bool(policy.get("require_station_reconciliation")) and (not bool(recon.get("reconciliation_passed")) or int(recon.get("blocking_issue_count") or 0)):
        raise DeploymentAssuranceError("CWS-MEDIA-010", "M18 closure vereist clean current station reconciliation")
    acks = []
    for ack_id in project.manufacturing_deployment_acknowledgements:
        ack = validate_persisted_deployment_acknowledgement(project, str(ack_id), require_current=False)
        if str(dict(ack["payload"]).get("deployment_receipt_id") or "") == deployment_receipt_id:
            acks.append(ack)
    if not acks:
        raise DeploymentAssuranceError("CWS-MEDIA-010", "M18 closure vereist M17 deployment acknowledgement")
    request = validate_persisted_release_request(project, str(rp.get("release_request_id") or ""))
    rollback = validate_persisted_rollback_reference(project, str(request.get("rollback_id") or ""))
    drill = None
    if bool(policy.get("require_rollback_drill_for_closure")):
        drill = _latest_passed_drill(project, binding_id=str(rp.get("binding_id") or ""), policy=policy, at=datetime.now(timezone.utc))
        if drill is None:
            raise DeploymentAssuranceError("CWS-MEDIA-010", "M18 closure vereist current passed rollback drill")
    evidence = {
        "deployment_receipt_hash": receipt["deployment_receipt_hash"],
        "acknowledgement_hashes": sorted(str(x["acknowledgement_hash"]) for x in acks),
        "custody_session_hash": session["session_hash"],
        "custody_status_hash": stable_sha256(status),
        "reconciliation_hash": recon["reconciliation_hash"],
        "rollback_hash": rollback["rollback_hash"],
        "rollback_drill_hash": str(drill.get("rollback_drill_hash") or "") if drill else "",
    }
    record = {
        "format": M18_CLOSURE_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "deployment_receipt_id": deployment_receipt_id,
        "binding_id": rp["binding_id"],
        "airgap_export_id": rp["airgap_export_id"],
        "station_id": rp["station_id"],
        "media_id": session["media_id"],
        "custody_session_id": custody_session_id,
        "policy_id": policy["policy_id"],
        "evidence": evidence,
        "closure_status": "closed_with_operator_evidence",
        "immutable_closure": True,
        "operator_reported_evidence_only": True,
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
        "closed_at": utc_now_iso(),
        "hash_version": M18_HASH_VERSION,
    }
    closure_id = "closure-" + stable_sha256({"receipt": receipt["deployment_receipt_hash"], "session": session["session_hash"], "recon": recon["reconciliation_hash"]})[:28]
    record["closure_id"] = closure_id
    record["closure_hash"] = _hash_record(record, "closure_hash")
    result = _store_immutable(project.manufacturing_deployment_closures, closure_id, record, "closure_hash")
    project.audit("manufacturing.deployment_assurance_closed", user=user, entity_id=closure_id, after_hash=result["closure_hash"], details={"binding_id": rp["binding_id"], "machine_observed_by_cws": False})
    return result


def validate_persisted_deployment_closure(project: ProjectModel, closure_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_deployment_closures.get(closure_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M18_CLOSURE_FORMAT or str(raw.get("schema_version") or "") != M18_CONTRACT_VERSION:
        raise ProjectValidationError(f"M18 deployment closure {closure_id} ontbreekt/ongeldig")
    if str(raw.get("closure_id") or "") != closure_id or str(raw.get("closure_hash") or "") != _hash_record(raw, "closure_hash"):
        raise ProjectValidationError("M18 closure identity/hash ongeldig")
    receipt = validate_persisted_deployment_receipt(project, str(raw.get("deployment_receipt_id") or ""), require_current=False)
    rp = dict(receipt.get("payload") or {})
    session = validate_persisted_media_custody_session(project, str(raw.get("custody_session_id") or ""), require_current=require_current)
    policy = validate_persisted_media_custody_policy(project, str(raw.get("policy_id") or ""), require_current=require_current)
    if session["policy_id"] != policy["policy_id"]:
        raise ProjectValidationError("M18 closure policy/session mismatch")
    if str(raw.get("binding_id") or "") != str(rp.get("binding_id") or "") or str(raw.get("airgap_export_id") or "") != str(rp.get("airgap_export_id") or "") or str(raw.get("station_id") or "") != str(rp.get("station_id") or ""):
        raise ProjectValidationError("M18 closure receipt binding mismatch")
    if str(raw.get("airgap_export_id") or "") != session["airgap_export_id"] or str(raw.get("station_id") or "") != session["station_id"] or str(raw.get("media_id") or "") != session["media_id"]:
        raise ProjectValidationError("M18 closure custody binding mismatch")
    evidence = dict(raw.get("evidence") or {})
    if str(evidence.get("deployment_receipt_hash") or "") != receipt["deployment_receipt_hash"] or str(evidence.get("custody_session_hash") or "") != session["session_hash"]:
        raise ProjectValidationError("M18 closure receipt/custody evidence snapshot stale")
    status = custody_session_status(project, session["session_id"])
    if str(evidence.get("custody_status_hash") or "") != stable_sha256(status):
        raise ProjectValidationError("M18 closure custody status hash mismatch")
    if not status["checkout_complete"] or not status["checkin_complete"]:
        raise ProjectValidationError("M18 closure custody loop is niet compleet")
    if bool(policy.get("require_seal")) and (not status["seal_applied"] or not status["seal_verified_on_checkin"]):
        raise ProjectValidationError("M18 closure seal evidence is niet compleet")
    ack_rows: list[dict[str, Any]] = []
    for ack_id in project.manufacturing_deployment_acknowledgements:
        ack = validate_persisted_deployment_acknowledgement(project, str(ack_id), require_current=require_current)
        if str(dict(ack.get("payload") or {}).get("deployment_receipt_id") or "") == receipt["deployment_receipt_id"]:
            ack_rows.append(ack)
    expected_ack_hashes = sorted(str(x["acknowledgement_hash"]) for x in ack_rows)
    if not expected_ack_hashes or sorted(str(x) for x in list(evidence.get("acknowledgement_hashes") or [])) != expected_ack_hashes:
        raise ProjectValidationError("M18 closure acknowledgement evidence mismatch")
    recon_hash = str(evidence.get("reconciliation_hash") or "")
    matches = [validate_persisted_station_reconciliation(project, rid, require_current=require_current) for rid in project.manufacturing_station_reconciliations if str(project.manufacturing_station_reconciliations[rid].get("reconciliation_hash") or "") == recon_hash]
    if len(matches) != 1:
        raise ProjectValidationError("M18 closure reconciliation evidence ontbreekt/ambigu")
    recon = matches[0]
    if recon["station_id"] != session["station_id"]:
        raise ProjectValidationError("M18 closure reconciliation station mismatch")
    if bool(policy.get("require_station_reconciliation")) and (not bool(recon.get("reconciliation_passed")) or int(recon.get("blocking_issue_count") or 0)):
        raise ProjectValidationError("M18 closure reconciliation is niet clean")
    request = validate_persisted_release_request(project, str(rp.get("release_request_id") or ""))
    rollback = validate_persisted_rollback_reference(project, str(request.get("rollback_id") or ""))
    if str(evidence.get("rollback_hash") or "") != rollback["rollback_hash"]:
        raise ProjectValidationError("M18 closure rollback evidence mismatch")
    drill_hash = str(evidence.get("rollback_drill_hash") or "")
    if bool(policy.get("require_rollback_drill_for_closure")):
        if not drill_hash:
            raise ProjectValidationError("M18 closure rollback drill evidence ontbreekt")
        drills = [validate_persisted_rollback_drill(project, did, require_current=require_current) for did in project.manufacturing_rollback_drills if str(project.manufacturing_rollback_drills[did].get("rollback_drill_hash") or "") == drill_hash]
        if len(drills) != 1:
            raise ProjectValidationError("M18 closure rollback drill evidence ontbreekt/ambigu")
        drill = drills[0]
        dp = dict(drill.get("payload") or {})
        if str(dp.get("rollback_hash") or "") != rollback["rollback_hash"] or str(dp.get("policy_hash") or "") != policy["policy_hash"] or str(dp.get("binding_id") or "") != str(rp.get("binding_id") or "") or str(dp.get("result") or "") != "passed":
            raise ProjectValidationError("M18 closure rollback drill semantic mismatch")
        performed = _parse_iso(dp.get("performed_at"), label="rollback drill performed_at")
        now = datetime.now(timezone.utc)
        if performed > now or now - performed > timedelta(hours=int(policy.get("maximum_rollback_drill_age_hours") or 720)):
            raise ProjectValidationError("M18 closure rollback drill is niet current")
    elif drill_hash:
        # Optional evidence must still be genuine when it is present.
        drills = [validate_persisted_rollback_drill(project, did, require_current=require_current) for did in project.manufacturing_rollback_drills if str(project.manufacturing_rollback_drills[did].get("rollback_drill_hash") or "") == drill_hash]
        if len(drills) != 1:
            raise ProjectValidationError("M18 closure optional rollback drill evidence ongeldig")
    if str(raw.get("closure_status") or "") != "closed_with_operator_evidence" or not bool(raw.get("immutable_closure")) or not bool(raw.get("operator_reported_evidence_only")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M18 closure veiligheidsflags/status ongeldig")
    return dict(raw)


def build_deployment_assurance_dashboard(project: ProjectModel) -> dict[str, Any]:
    media = [validate_persisted_removable_media(project, k, require_active=False) for k in sorted(project.manufacturing_media_devices)]
    policies = [validate_persisted_media_custody_policy(project, k, require_current=False) for k in sorted(project.manufacturing_media_custody_policies)]
    sessions = []
    for sid in sorted(project.manufacturing_media_custody_sessions):
        row = validate_persisted_media_custody_session(project, sid, require_current=False)
        row["status"] = custody_session_status(project, sid)
        sessions.append(row)
    reconciliations = [validate_persisted_station_reconciliation(project, k, require_current=False) for k in sorted(project.manufacturing_station_reconciliations)]
    drills = [validate_persisted_rollback_drill(project, k, require_current=False) for k in sorted(project.manufacturing_rollback_drills)]
    closures = [validate_persisted_deployment_closure(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_closures)]
    open_sessions = [x for x in sessions if not bool(dict(x.get("status") or {}).get("checkin_complete"))]
    missing_evidence = sum(int(x.get("blocking_issue_count") or 0) for x in reconciliations)
    return {
        "format": M18_DASHBOARD_FORMAT,
        "schema_version": M18_CONTRACT_VERSION,
        "phase": "M18",
        "media_count": len(media),
        "policy_count": len(policies),
        "custody_session_count": len(sessions),
        "open_custody_session_count": len(open_sessions),
        "custody_event_count": len(project.manufacturing_media_custody_events),
        "reconciliation_count": len(reconciliations),
        "missing_evidence_count": missing_evidence,
        "rollback_drill_count": len(drills),
        "deployment_closure_count": len(closures),
        "media": media,
        "policies": policies,
        "custody_sessions": sessions,
        "reconciliations": reconciliations,
        "rollback_drills": drills,
        "deployment_closures": closures,
        "machine_observed_by_cws": False,
        "deployment_transport_authorized": False,
        "direct_machine_transfer": False,
    }


__all__ = [
    name for name in globals()
    if name.startswith("M18_") or name.startswith("register_") or name.startswith("create_")
    or name.startswith("validate_") or name.startswith("ingest_") or name.startswith("build_")
    or name in {"DeploymentAssuranceError", "custody_session_status", "validate_media_custody_chain", "media_custody_event_signing_payload", "rollback_drill_signing_payload", "reconcile_offline_station", "close_deployment_assurance"}
]
