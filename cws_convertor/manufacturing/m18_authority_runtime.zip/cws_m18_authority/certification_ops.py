"""M14 certification operations: golden batches, lifecycle and renewal.

M14 operationalises M13 certificates without weakening their evidence gate.
Batch runs are diagnostic/pre-certification only. Renewal creates a new M13
certificate plus an immutable supersession record; certificates are never
edited in place. Direct machine transfer is always false.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import json
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from .adapter_certification import (
    AdapterCertificationError,
    AdapterCertificationPolicy,
    M13_CASE_TYPES,
    build_expected_actual_diff,
    issue_adapter_certificate,
    validate_persisted_adapter_certificate,
    validate_persisted_adapter_evidence,
    validate_persisted_adapter_revocation,
)
from .adapter_rehearsal import ManufacturingAdapterDescriptor, ManufacturingAdapterRegistry
from .adapter_sdk import AdapterSDKManifest, validate_adapter_sdk_manifest

M14_CERTOPS_CONTRACT_VERSION = "1.0"
M14_GOLDEN_BATCH_FORMAT = "CWS_M14_GOLDEN_BATCH_V1"
M14_GOLDEN_BATCH_SCHEMA_VERSION = "1.0"
M14_SUPERSESSION_FORMAT = "CWS_M14_CERTIFICATE_SUPERSESSION_V1"
M14_SUPERSESSION_SCHEMA_VERSION = "1.0"
M14_DASHBOARD_FORMAT = "CWS_M14_CERTIFICATION_DASHBOARD_V1"
M14_HASH_VERSION = "cws-m14-certification-ops-v1"


class CertificationOpsError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def _load_json(value: Mapping[str, Any] | str | Path) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    return json.loads(Path(value).read_text(encoding="utf-8"))


def _safe_case_type(value: Any) -> str:
    case_type = str(value or "other").strip().lower()
    if case_type not in M13_CASE_TYPES:
        raise CertificationOpsError("CWS-CERTOPS-001", f"Onbekend candidate case_type {case_type!r}")
    return case_type


def _semantic_diff(left: Any, right: Any, *, limit: int = 100) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    def walk(a: Any, b: Any, path: str) -> None:
        if len(result) >= limit: return
        if type(a) is not type(b):
            result.append({"path": path or "$", "reason": "type_mismatch", "expected": a, "actual": b}); return
        if isinstance(a, dict):
            for key in sorted(set(a) | set(b)):
                p = f"{path}.{key}" if path else str(key)
                if key not in a: result.append({"path": p, "reason": "unexpected_key", "actual": b[key]})
                elif key not in b: result.append({"path": p, "reason": "missing_key", "expected": a[key]})
                else: walk(a[key], b[key], p)
                if len(result) >= limit: return
            return
        if isinstance(a, list):
            if len(a) != len(b): result.append({"path": path or "$", "reason": "length_mismatch", "expected_length": len(a), "actual_length": len(b)})
            for i, (av, bv) in enumerate(zip(a, b)):
                walk(av, bv, f"{path}[{i}]" if path else f"[{i}]")
                if len(result) >= limit: return
            return
        if a != b: result.append({"path": path or "$", "reason": "value_mismatch", "expected": a, "actual": b})
    walk(left, right, "")
    return result


def _sdk_diagnostics_for_case(
    adapter: Any,
    sdk_manifest: AdapterSDKManifest,
    expected_root: str | Path,
    actual_root: str | Path,
    diff_report: Mapping[str, Any],
) -> dict[str, Any]:
    if "diagnostics" not in sdk_manifest.features:
        return {"available": False, "reason": "SDK diagnostics not declared", "semantic_equal": None, "files": []}
    diagnose = getattr(adapter, "diagnose_output", None)
    if not callable(diagnose):
        raise CertificationOpsError("CWS-CERTOPS-003", "SDK diagnostics gedeclareerd maar diagnose_output ontbreekt")
    accepted = set(sdk_manifest.diagnostic_extensions)
    rows = []
    semantic_equal = True
    for artifact in list(diff_report.get("artifacts") or []):
        rel = str(artifact.get("relative_path") or "")
        if PurePosixPath(rel).suffix.lower() not in accepted:
            continue
        ep = Path(expected_root).joinpath(*PurePosixPath(rel).parts)
        ap = Path(actual_root).joinpath(*PurePosixPath(rel).parts)
        if not ep.is_file() or not ap.is_file():
            continue
        try:
            expected_diag = json.loads(json.dumps(diagnose(rel, ep.read_bytes()), sort_keys=True, ensure_ascii=False))
            actual_diag = json.loads(json.dumps(diagnose(rel, ap.read_bytes()), sort_keys=True, ensure_ascii=False))
        except Exception as exc:
            raise CertificationOpsError("CWS-CERTOPS-003", f"SDK diagnostic parser faalde voor {rel}") from exc
        differences = _semantic_diff(expected_diag, actual_diag)
        equal = not differences
        semantic_equal = semantic_equal and equal
        rows.append({
            "relative_path": rel,
            "semantic_equal": equal,
            "expected_diagnostic_hash": stable_sha256(expected_diag),
            "actual_diagnostic_hash": stable_sha256(actual_diag),
            "differences": differences,
        })
    return {"available": True, "semantic_equal": semantic_equal, "files": rows}


def run_golden_batch(
    project: ProjectModel,
    adapter_id: str,
    cases: Iterable[Mapping[str, Any]],
    *,
    user: str = "system",
    persist: bool = True,
    registry: ManufacturingAdapterRegistry | None = None,
    sdk_manifest: Mapping[str, Any] | AdapterSDKManifest | None = None,
) -> dict[str, Any]:
    """Run a deterministic review matrix over M12 rehearsal/golden pairs.

    ``case_type`` in the input is a *candidate review label*, never owner
    evidence. The batch can therefore not issue or renew a certificate.
    """
    adapter = registry.get(adapter_id) if registry is not None else None
    sdk_obj = None
    if sdk_manifest is not None:
        if adapter is None or registry is None:
            raise CertificationOpsError("CWS-CERTOPS-002", "SDK diagnostics vereisen een runtime registry")
        sdk_obj = validate_adapter_sdk_manifest(sdk_manifest, descriptor=adapter.descriptor, runtime_binding=registry.certification_binding(adapter_id, verify_physical=True))
    rows: list[dict[str, Any]] = []
    for index, spec in enumerate(list(cases)):
        rehearsal = _load_json(spec.get("rehearsal") or {})
        golden = _load_json(spec.get("golden") or {})
        expected_root = spec.get("expected_root") or None
        actual_root = spec.get("actual_root") or None
        report = build_expected_actual_diff(rehearsal, golden, expected_root=expected_root, actual_root=actual_root)
        if str(dict(rehearsal.get("adapter") or {}).get("adapter_id") or "") != adapter_id:
            raise CertificationOpsError("CWS-CERTOPS-001", f"Golden batch case {index} hoort bij andere adapter")
        diagnostics = {"available": False, "semantic_equal": None, "files": []}
        if sdk_obj is not None and expected_root and actual_root:
            diagnostics = _sdk_diagnostics_for_case(adapter, sdk_obj, expected_root, actual_root, report)
        rows.append({
            "index": index,
            "case_id": str(golden.get("case_id") or f"case-{index+1}"),
            "candidate_case_type": _safe_case_type(spec.get("case_type") or "other"),
            "owner_attested": False,
            "rehearsal_id": str(rehearsal.get("rehearsal_id") or ""),
            "rehearsal_manifest_hash": str(rehearsal.get("manifest_hash") or ""),
            "golden_hash": str(golden.get("golden_hash") or ""),
            "exact_match": bool(report.get("exact_match")),
            "diff_report_hash": str(report.get("report_hash") or ""),
            "artifact_count": len(report.get("artifacts") or []),
            "mismatch_count": sum(1 for x in report.get("artifacts") or [] if x.get("status") != "exact"),
            "sdk_diagnostics": diagnostics,
        })
    if not rows:
        raise CertificationOpsError("CWS-CERTOPS-001", "M14 golden batch vereist minimaal één case")
    exact_count = sum(1 for row in rows if row["exact_match"])
    batch_seed = {"adapter_id": adapter_id, "cases": [{k: row[k] for k in ("case_id", "rehearsal_manifest_hash", "golden_hash", "diff_report_hash")} for row in rows]}
    batch_id = "cbatch-" + stable_sha256(batch_seed)[:28]
    batch = {
        "format": M14_GOLDEN_BATCH_FORMAT,
        "schema_version": M14_GOLDEN_BATCH_SCHEMA_VERSION,
        "phase": "M14",
        "batch_id": batch_id,
        "adapter_id": adapter_id,
        "case_count": len(rows),
        "exact_count": exact_count,
        "all_exact": exact_count == len(rows),
        "owner_attested": False,
        "certification_eligible": False,
        "cases": rows,
        "sdk_manifest_hash": sdk_obj.manifest_hash if sdk_obj is not None else "",
        "machine_output_released": False,
        "direct_machine_transfer": False,
        "hash_version": M14_HASH_VERSION,
    }
    batch["batch_hash"] = stable_sha256({k: v for k, v in batch.items() if k != "batch_hash"})
    if persist:
        existing = project.manufacturing_adapter_certification_batches.get(batch_id)
        if isinstance(existing, dict) and existing.get("batch_hash") != batch["batch_hash"]:
            raise ProjectValidationError(f"M14 certification batch-ID collision voor {batch_id}")
        project.manufacturing_adapter_certification_batches[batch_id] = batch
        project.audit("manufacturing.certification_batch", user=user, entity_id=batch_id, after_hash=batch["batch_hash"], details={"adapter_id": adapter_id, "all_exact": batch["all_exact"], "owner_attested": False})
    return batch


def validate_persisted_certification_batch(project: ProjectModel, batch_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_certification_batches.get(batch_id)
    if not isinstance(raw, dict): raise ProjectValidationError(f"Onbekende M14 certification batch {batch_id}")
    if raw.get("format") != M14_GOLDEN_BATCH_FORMAT or str(raw.get("schema_version") or "") != M14_GOLDEN_BATCH_SCHEMA_VERSION:
        raise ProjectValidationError("M14 certification batch schema ongeldig")
    if str(raw.get("batch_id") or "") != batch_id:
        raise ProjectValidationError("M14 certification batch ID mismatch")
    if str(raw.get("batch_hash") or "") != stable_sha256({k: v for k, v in raw.items() if k != "batch_hash"}):
        raise ProjectValidationError("M14 certification batch hash ongeldig")
    if bool(raw.get("owner_attested")) or bool(raw.get("certification_eligible")) or bool(raw.get("machine_output_released")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M14 golden batch mag owner/certification/output/transfer niet vrijgeven")
    return raw


def _supersession_for(project: ProjectModel, certificate_id: str) -> dict[str, Any] | None:
    raw = project.manufacturing_adapter_certificate_supersessions.get(certificate_id)
    if raw is None: return None
    if not isinstance(raw, dict): raise ProjectValidationError("M14 certificate supersession-opslag ongeldig")
    if raw.get("format") != M14_SUPERSESSION_FORMAT or str(raw.get("schema_version") or "") != M14_SUPERSESSION_SCHEMA_VERSION:
        raise ProjectValidationError("M14 certificate supersession schema ongeldig")
    if str(raw.get("previous_certificate_id") or "") != certificate_id:
        raise ProjectValidationError("M14 certificate supersession previous ID mismatch")
    if str(raw.get("supersession_hash") or "") != stable_sha256({k: v for k, v in raw.items() if k != "supersession_hash"}):
        raise ProjectValidationError("M14 certificate supersession hash ongeldig")
    new_id = str(raw.get("new_certificate_id") or "")
    if new_id not in project.manufacturing_adapter_certificates:
        raise ProjectValidationError("M14 certificate supersession verwijst naar ontbrekend nieuw certificaat")
    return raw


def validate_persisted_certificate_supersession(project: ProjectModel, previous_certificate_id: str) -> dict[str, Any] | None:
    return _supersession_for(project, previous_certificate_id)


def record_certificate_supersession(project: ProjectModel, previous_certificate_id: str, new_certificate_id: str, *, reason: str, user: str) -> dict[str, Any]:
    if previous_certificate_id == new_certificate_id:
        raise CertificationOpsError("CWS-CERTOPS-004", "Certificaat kan zichzelf niet superseden")
    old = validate_persisted_adapter_certificate(project, previous_certificate_id, require_current=False)
    new = validate_persisted_adapter_certificate(project, new_certificate_id, require_current=False)
    if old.get("adapter_id") != new.get("adapter_id") or old.get("adapter_descriptor_hash") != new.get("adapter_descriptor_hash"):
        raise CertificationOpsError("CWS-CERTOPS-004", "Supersession vereist exact dezelfde adapterdescriptor")
    if str(new.get("supersedes_certificate_id") or "") != previous_certificate_id:
        raise CertificationOpsError("CWS-CERTOPS-004", "Nieuw certificaat is niet cryptografisch aan het vorige certificaat als renewal gekoppeld")
    if validate_persisted_adapter_revocation(project, previous_certificate_id) is not None:
        raise CertificationOpsError("CWS-CERTOPS-004", "Ingetrokken certificaat kan niet worden renewed/superseded")
    if _supersession_for(project, previous_certificate_id) is not None:
        raise CertificationOpsError("CWS-CERTOPS-004", "Certificaat is al superseded")
    if not str(reason or "").strip() or not str(user or "").strip():
        raise CertificationOpsError("CWS-CERTOPS-004", "Supersession vereist reason en user")
    record = {
        "format": M14_SUPERSESSION_FORMAT,
        "schema_version": M14_SUPERSESSION_SCHEMA_VERSION,
        "phase": "M14",
        "previous_certificate_id": previous_certificate_id,
        "previous_certificate_hash": old.get("certificate_hash", ""),
        "new_certificate_id": new_certificate_id,
        "new_certificate_hash": new.get("certificate_hash", ""),
        "reason": str(reason),
        "superseded_by": str(user),
        "superseded_at": utc_now_iso(),
        "direct_machine_transfer": False,
        "hash_version": M14_HASH_VERSION,
    }
    record["supersession_hash"] = stable_sha256({k: v for k, v in record.items() if k != "supersession_hash"})
    project.manufacturing_adapter_certificate_supersessions[previous_certificate_id] = record
    project.audit("manufacturing.adapter_certificate_superseded", user=user, entity_id=previous_certificate_id, before_hash=str(old.get("certificate_hash") or ""), after_hash=record["supersession_hash"], details={"new_certificate_id": new_certificate_id, "direct_machine_transfer": False})
    return record


def renew_adapter_certificate(
    project: ProjectModel,
    previous_certificate_id: str,
    descriptor: ManufacturingAdapterDescriptor,
    *,
    issued_by: str,
    evidence_ids: Iterable[str] | None = None,
    validity_days: int = 180,
    reason: str = "scheduled renewal",
    policy: AdapterCertificationPolicy | None = None,
) -> dict[str, Any]:
    old = validate_persisted_adapter_certificate(project, previous_certificate_id, require_current=False)
    if not str(issued_by or "").strip() or not str(reason or "").strip():
        raise CertificationOpsError("CWS-CERTOPS-005", "Renewal vereist issued_by en een niet-lege reason")
    if validate_persisted_adapter_revocation(project, previous_certificate_id) is not None:
        raise CertificationOpsError("CWS-CERTOPS-005", "Ingetrokken certificaat kan niet worden renewed")
    if _supersession_for(project, previous_certificate_id) is not None:
        raise CertificationOpsError("CWS-CERTOPS-005", "Certificaat is al superseded")
    if descriptor.descriptor_hash != str(old.get("adapter_descriptor_hash") or ""):
        raise CertificationOpsError("CWS-CERTOPS-005", "Renewal is alleen toegestaan voor exact dezelfde adapterdescriptor; nieuwe adapterversie vereist nieuwe certificering")
    ids = tuple(evidence_ids or old.get("evidence_case_ids") or ())
    # Revalidate every evidence record now; stale/tampered evidence cannot be reused.
    for evidence_id in ids: validate_persisted_adapter_evidence(project, str(evidence_id))
    certificate_ids_before = set(project.manufacturing_adapter_certificates)
    supersessions_before = dict(project.manufacturing_adapter_certificate_supersessions)
    audit_len_before = len(project.audit_log)
    try:
        new = issue_adapter_certificate(
            project,
            descriptor,
            ids,
            capability_id=str(old.get("capability_id") or ""),
            certification_scope_operations=old.get("certification_scope_operations") or (),
            adapter_source_commit=str(old.get("adapter_source_commit") or ""),
            adapter_artifact_name=str(old.get("adapter_artifact_name") or ""),
            adapter_artifact_sha256=str(old.get("adapter_artifact_sha256") or ""),
            issued_by=issued_by,
            validity_days=validity_days,
            policy=policy or AdapterCertificationPolicy(**{k: v for k, v in dict(old.get("policy") or {}).items() if k in {"required_case_types","minimum_case_count","maximum_validity_days","require_operation_coverage","policy_hash","schema_version"}}),
            supersedes_certificate_id=previous_certificate_id,
        )
        supersession = record_certificate_supersession(project, previous_certificate_id, str(new["certificate_id"]), reason=reason, user=issued_by)
    except Exception:
        # Renewal is one logical transaction. If supersession cannot be recorded,
        # do not leave an orphan renewal certificate or its audit entry behind.
        for certificate_id in set(project.manufacturing_adapter_certificates) - certificate_ids_before:
            project.manufacturing_adapter_certificates.pop(certificate_id, None)
        project.manufacturing_adapter_certificate_supersessions.clear()
        project.manufacturing_adapter_certificate_supersessions.update(supersessions_before)
        del project.audit_log[audit_len_before:]
        raise
    return {"certificate": new, "supersession": supersession}


def certificate_lifecycle_status(project: ProjectModel, certificate_id: str, *, expiring_within_days: int = 30, now: datetime | None = None) -> dict[str, Any]:
    cert = validate_persisted_adapter_certificate(project, certificate_id, require_current=False)
    revoked = validate_persisted_adapter_revocation(project, certificate_id)
    supersession = _supersession_for(project, certificate_id)
    now = now or datetime.now(timezone.utc)
    expires = datetime.fromisoformat(str(cert.get("expires_at") or "").replace("Z", "+00:00"))
    days_remaining = (expires - now).total_seconds() / 86400.0
    status = "current"
    reason = "certificate is current"
    if revoked is not None:
        status, reason = "revoked", str(revoked.get("reason") or "revoked")
    elif supersession is not None:
        status, reason = "superseded", f"superseded by {supersession.get('new_certificate_id')}"
    else:
        try:
            validate_persisted_adapter_certificate(project, certificate_id, require_current=True)
        except Exception as exc:
            status, reason = ("expired" if days_remaining < 0 else "stale"), str(exc)
        else:
            if days_remaining <= max(0, int(expiring_within_days)):
                status, reason = "expiring", f"expires in {max(0.0, days_remaining):.1f} days"
    return {
        "certificate_id": certificate_id,
        "adapter_id": cert.get("adapter_id", ""),
        "adapter_version": cert.get("adapter_version", ""),
        "status": status,
        "reason": reason,
        "days_remaining": round(days_remaining, 3),
        "expires_at": cert.get("expires_at", ""),
        "renewal_due": status in {"expiring", "expired", "stale"},
        "current_for_output": status in {"current", "expiring"},
        "new_certificate_id": supersession.get("new_certificate_id", "") if supersession else "",
        "machine_output_released": False,
        "direct_machine_transfer": False,
    }


def build_certification_dashboard(project: ProjectModel, *, adapter_id: str = "", expiring_within_days: int = 30) -> dict[str, Any]:
    manifests = [dict(x) for x in project.manufacturing_adapter_sdk_manifests.values() if isinstance(x, dict) and (not adapter_id or x.get("adapter_id") == adapter_id)]
    batches = [dict(x) for x in project.manufacturing_adapter_certification_batches.values() if isinstance(x, dict) and (not adapter_id or x.get("adapter_id") == adapter_id)]
    evidence = [dict(x) for x in project.manufacturing_adapter_evidence_cases.values() if isinstance(x, dict) and (not adapter_id or x.get("adapter_id") == adapter_id)]
    certificates = []
    for cid, raw in sorted(project.manufacturing_adapter_certificates.items()):
        if adapter_id and str(raw.get("adapter_id") or "") != adapter_id: continue
        certificates.append(certificate_lifecycle_status(project, cid, expiring_within_days=expiring_within_days))
    status_counts: dict[str, int] = {}
    for row in certificates: status_counts[row["status"]] = status_counts.get(row["status"], 0) + 1
    report = {
        "format": M14_DASHBOARD_FORMAT,
        "schema_version": M14_CERTOPS_CONTRACT_VERSION,
        "adapter_filter": adapter_id,
        "sdk_manifests": manifests,
        "golden_batches": batches,
        "owner_evidence_count": len(evidence),
        "certificate_lifecycle": certificates,
        "certificate_status_counts": status_counts,
        "renewal_due_count": sum(1 for x in certificates if x.get("renewal_due")),
        "offline_controller_output_released": False,
        "direct_machine_transfer": False,
    }
    report["dashboard_hash"] = stable_sha256({k: v for k, v in report.items() if k != "dashboard_hash"})
    return report


__all__ = [name for name in globals() if not name.startswith("_")]
