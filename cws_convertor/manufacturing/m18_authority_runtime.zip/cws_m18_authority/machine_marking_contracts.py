"""Canonical machine-marking capability contracts for Scribing M5.

M5 evaluates whether an already validated, format-neutral :class:`ManufacturingMark`
can physically be executed by a configured machine marking head/tool while the part
is still in its canonical production orientation.  Nesting placement, clamps on a
specific stock bar and common-cut sequencing are *not* inferred here; M6 must bind
this proof to the selected nesting orientation and bar coordinates.

The contracts are deliberately controller-neutral.  A capability record never
contains DSTV SI lines, G-code or proprietary machine syntax.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import math
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectValidationError, stable_sha256

MARKING_TOOL_SCHEMA_VERSION = "1.0"
MACHINE_MARKING_CAPABILITY_SCHEMA_VERSION = "1.0"
MARK_CAPABILITY_PROOF_SCHEMA_VERSION = "1.0"
MARK_CAPABILITY_REPORT_SCHEMA_VERSION = "1.0"
MARKING_TOOL_HASH_VERSION = "cws-marking-tool-v1"
MACHINE_MARKING_CAPABILITY_HASH_VERSION = "cws-machine-marking-capability-v1"
MARK_CAPABILITY_REPORT_HASH_VERSION = "cws-mark-capability-report-v1"


class MarkingCapabilityValidationStatus(str, Enum):
    DRAFT = "draft"
    VALIDATED = "validated"
    RETIRED = "retired"


class MarkingOperation(str, Enum):
    SCRIBE_LINE = "scribe_line"
    CONTOUR_SCRIBE = "contour_scribe"
    POP_MARK = "pop_mark"
    CENTER_PUNCH = "center_punch"
    TEXT_MARK = "text_mark"
    HARD_STAMP = "hard_stamp"
    INKJET_MARK = "inkjet_mark"
    PAINT_MARK = "paint_mark"
    PLASMA_MARK = "plasma_mark"
    LASER_MARK = "laser_mark"
    DOT_PEEN = "dot_peen"
    NONE = "none"


class InternalFacePolicy(str, Enum):
    BLOCKED = "blocked"
    REVIEW = "review"
    SUPPORTED = "supported"


class ReorientationPolicy(str, Enum):
    BLOCKED = "blocked"
    MANUAL = "manual"
    AUTOMATIC = "automatic"


def _finite(value: Any, label: str, *, non_negative: bool = False) -> float:
    try:
        number = float(value)
    except Exception as exc:  # pragma: no cover - defensive conversion
        raise ProjectValidationError(f"{label} is geen geldig getal") from exc
    if not math.isfinite(number):
        raise ProjectValidationError(f"{label} moet eindig zijn")
    if non_negative and number < 0.0:
        raise ProjectValidationError(f"{label} kan niet negatief zijn")
    return number


def _vec3(value: Iterable[Any], label: str) -> tuple[float, float, float]:
    raw = tuple(value)
    if len(raw) != 3:
        raise ProjectValidationError(f"{label} moet drie componenten bevatten")
    vector = tuple(_finite(item, label) for item in raw)
    length = math.sqrt(sum(v * v for v in vector))
    if length <= 1e-12:
        raise ProjectValidationError(f"{label} mag geen nulvector zijn")
    return tuple(v / length for v in vector)  # type: ignore[return-value]


@dataclass(frozen=True)
class MarkingToolDefinition:
    """Physical marking head/tool independent from a controller postprocessor."""

    tool_id: str
    tool_type: str
    supported_operations: tuple[str, ...]
    allowed_machine_ids: tuple[str, ...] = ()
    allowed_station_ids: tuple[str, ...] = ()
    head_diameter_mm: float = 0.0
    physical_clearance_radius_mm: float = 0.0
    minimum_edge_distance_mm: float = 0.0
    maximum_projection_depth_mm: float = 0.0
    maximum_reach_mm: float = 0.0
    nominal_mark_depth_mm: float = 0.0
    maximum_mark_depth_mm: float = 0.0
    approach_vectors: tuple[tuple[float, float, float], ...] = ()
    status: str = "active"
    maintenance_status: str = "ok"
    validation_status: str = MarkingCapabilityValidationStatus.DRAFT.value
    revision: str = "1"
    provenance: Mapping[str, Any] = field(default_factory=dict)
    tool_hash: str = ""
    schema_version: str = MARKING_TOOL_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if str(self.schema_version) != MARKING_TOOL_SCHEMA_VERSION:
            raise ProjectValidationError(f"Onbekende toekomstige MarkingTool schema-versie {self.schema_version!r}")
        if not self.tool_id.strip() or not self.tool_type.strip():
            raise ProjectValidationError("MarkingTool mist tool_id of tool_type")
        operations = tuple(sorted(set(str(x).strip() for x in self.supported_operations if str(x).strip())))
        if not operations:
            raise ProjectValidationError(f"MarkingTool {self.tool_id} ondersteunt geen operations")
        known = {item.value for item in MarkingOperation}
        unknown = sorted(set(operations) - known)
        if unknown:
            raise ProjectValidationError(f"MarkingTool {self.tool_id} bevat onbekende operations {unknown}")
        object.__setattr__(self, "supported_operations", operations)
        if self.validation_status not in {item.value for item in MarkingCapabilityValidationStatus}:
            raise ProjectValidationError(f"MarkingTool {self.tool_id} heeft ongeldige validation_status")
        for name in (
            "head_diameter_mm", "physical_clearance_radius_mm", "minimum_edge_distance_mm",
            "maximum_projection_depth_mm", "maximum_reach_mm", "nominal_mark_depth_mm",
            "maximum_mark_depth_mm",
        ):
            object.__setattr__(self, name, _finite(getattr(self, name), f"MarkingTool {name}", non_negative=True))
        vectors = tuple(_vec3(v, f"MarkingTool {self.tool_id} approach vector") for v in self.approach_vectors)
        object.__setattr__(self, "approach_vectors", vectors)
        if self.maximum_mark_depth_mm and self.nominal_mark_depth_mm > self.maximum_mark_depth_mm + 1e-9:
            raise ProjectValidationError(f"MarkingTool {self.tool_id} nominale diepte overschrijdt maximum")
        expected = stable_sha256(self.hash_payload())
        if self.tool_hash and self.tool_hash != expected:
            raise ProjectValidationError(f"MarkingTool {self.tool_id} heeft ongeldige tool_hash")
        object.__setattr__(self, "tool_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": MARKING_TOOL_HASH_VERSION,
            "schema_version": self.schema_version,
            "tool_id": self.tool_id,
            "tool_type": self.tool_type,
            "supported_operations": list(self.supported_operations),
            "allowed_machine_ids": sorted(set(self.allowed_machine_ids)),
            "allowed_station_ids": sorted(set(self.allowed_station_ids)),
            "head_diameter_mm": self.head_diameter_mm,
            "physical_clearance_radius_mm": self.physical_clearance_radius_mm,
            "minimum_edge_distance_mm": self.minimum_edge_distance_mm,
            "maximum_projection_depth_mm": self.maximum_projection_depth_mm,
            "maximum_reach_mm": self.maximum_reach_mm,
            "nominal_mark_depth_mm": self.nominal_mark_depth_mm,
            "maximum_mark_depth_mm": self.maximum_mark_depth_mm,
            "approach_vectors": [list(v) for v in self.approach_vectors],
            "status": self.status,
            "maintenance_status": self.maintenance_status,
            "validation_status": self.validation_status,
            "revision": self.revision,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "provenance": dict(self.provenance), "tool_hash": self.tool_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "MarkingToolDefinition":
        return cls(
            tool_id=str(value.get("tool_id") or ""),
            tool_type=str(value.get("tool_type") or ""),
            supported_operations=tuple(str(x) for x in value.get("supported_operations") or []),
            allowed_machine_ids=tuple(str(x) for x in value.get("allowed_machine_ids") or []),
            allowed_station_ids=tuple(str(x) for x in value.get("allowed_station_ids") or []),
            head_diameter_mm=float(value.get("head_diameter_mm") or 0.0),
            physical_clearance_radius_mm=float(value.get("physical_clearance_radius_mm") or 0.0),
            minimum_edge_distance_mm=float(value.get("minimum_edge_distance_mm") or 0.0),
            maximum_projection_depth_mm=float(value.get("maximum_projection_depth_mm") or 0.0),
            maximum_reach_mm=float(value.get("maximum_reach_mm") or 0.0),
            nominal_mark_depth_mm=float(value.get("nominal_mark_depth_mm") or 0.0),
            maximum_mark_depth_mm=float(value.get("maximum_mark_depth_mm") or 0.0),
            approach_vectors=tuple(tuple(float(v) for v in row) for row in value.get("approach_vectors") or []),
            status=str(value.get("status") or "active"),
            maintenance_status=str(value.get("maintenance_status") or "ok"),
            validation_status=str(value.get("validation_status") or MarkingCapabilityValidationStatus.DRAFT.value),
            revision=str(value.get("revision") or "1"),
            provenance=dict(value.get("provenance") or {}),
            tool_hash=str(value.get("tool_hash") or ""),
            schema_version=str(value.get("schema_version") or MARKING_TOOL_SCHEMA_VERSION),
        )


@dataclass(frozen=True)
class ManufacturingMachineCapability:
    capability_id: str
    machine_id: str
    machine_profile_id: str = ""
    station_id: str = ""
    revision: str = "1"
    validation_status: str = MarkingCapabilityValidationStatus.DRAFT.value
    enabled: bool = True
    supported_mark_operations: tuple[str, ...] = ()
    supported_mark_types: tuple[str, ...] = ()
    supported_face_roles: tuple[str, ...] = ()
    supported_surface_types: tuple[str, ...] = ("plane",)
    supported_dstv_side_aliases: tuple[str, ...] = ()
    canonical_approach_vectors_by_face_role: Mapping[str, tuple[tuple[float, float, float], ...]] = field(default_factory=dict)
    rotational_marking_supported: bool = False
    rotational_axis: str = ""
    min_reachable_u_mm: float | None = None
    max_reachable_u_mm: float | None = None
    min_reachable_v_mm: float | None = None
    max_reachable_v_mm: float | None = None
    face_role_clearance_mm: Mapping[str, float] = field(default_factory=dict)
    forbidden_face_roles: tuple[str, ...] = ()
    internal_face_policy: str = InternalFacePolicy.BLOCKED.value
    reorientation_policy: str = ReorientationPolicy.BLOCKED.value
    reclamp_supported: bool = False
    marking_tool_ids: tuple[str, ...] = ()
    operation_tool_ids: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    forbidden_face_zones: Mapping[str, tuple[Mapping[str, Any], ...]] = field(default_factory=dict)
    sequence_constraints: Mapping[str, Any] = field(default_factory=dict)
    provenance: Mapping[str, Any] = field(default_factory=dict)
    base_capability_hash: str = ""
    capability_hash: str = ""
    schema_version: str = MACHINE_MARKING_CAPABILITY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if str(self.schema_version) != MACHINE_MARKING_CAPABILITY_SCHEMA_VERSION:
            raise ProjectValidationError(f"Onbekende toekomstige machine marking capability schema-versie {self.schema_version!r}")
        if not self.capability_id.strip() or not self.machine_id.strip():
            raise ProjectValidationError("ManufacturingMachineCapability mist capability_id of machine_id")
        if self.validation_status not in {item.value for item in MarkingCapabilityValidationStatus}:
            raise ProjectValidationError(f"Machine capability {self.capability_id} heeft ongeldige validation_status")
        if self.internal_face_policy not in {item.value for item in InternalFacePolicy}:
            raise ProjectValidationError(f"Machine capability {self.capability_id} heeft ongeldige internal_face_policy")
        if self.reorientation_policy not in {item.value for item in ReorientationPolicy}:
            raise ProjectValidationError(f"Machine capability {self.capability_id} heeft ongeldige reorientation_policy")
        known_ops = {item.value for item in MarkingOperation}
        unknown_ops = sorted(set(self.supported_mark_operations) - known_ops)
        if unknown_ops:
            raise ProjectValidationError(f"Machine capability {self.capability_id} bevat onbekende operations {unknown_ops}")
        for low_name, high_name in (("min_reachable_u_mm", "max_reachable_u_mm"), ("min_reachable_v_mm", "max_reachable_v_mm")):
            low, high = getattr(self, low_name), getattr(self, high_name)
            if low is not None:
                object.__setattr__(self, low_name, _finite(low, low_name))
            if high is not None:
                object.__setattr__(self, high_name, _finite(high, high_name))
            if low is not None and high is not None and float(low) > float(high):
                raise ProjectValidationError(f"Machine capability {self.capability_id}: {low_name} > {high_name}")
        clearances: dict[str, float] = {}
        for role, value in self.face_role_clearance_mm.items():
            clearances[str(role)] = _finite(value, f"clearance {role}", non_negative=True)
        object.__setattr__(self, "face_role_clearance_mm", clearances)
        vectors: dict[str, tuple[tuple[float, float, float], ...]] = {}
        for role, rows in self.canonical_approach_vectors_by_face_role.items():
            vectors[str(role)] = tuple(_vec3(v, f"approach vector {role}") for v in rows)
        object.__setattr__(self, "canonical_approach_vectors_by_face_role", vectors)
        for operation, tool_ids in self.operation_tool_ids.items():
            if operation not in known_ops:
                raise ProjectValidationError(f"Machine capability {self.capability_id} operation_tool_ids bevat onbekende operation {operation!r}")
            if any(not str(tool_id).strip() for tool_id in tool_ids):
                raise ProjectValidationError(f"Machine capability {self.capability_id} bevat lege tool-ID")
        for role, zones in self.forbidden_face_zones.items():
            for zone in zones:
                if str(zone.get("kind") or "") not in {"circle", "rect"}:
                    raise ProjectValidationError(f"Machine capability {self.capability_id} heeft ongeldige forbidden zone op {role}")
        # The base hash proves the capability record itself even when external
        # tool/profile dependencies later change. The effective capability hash
        # additionally binds those external dependency revisions.
        expected_base = stable_sha256(self.base_hash_payload())
        if self.base_capability_hash and self.base_capability_hash != expected_base:
            raise ProjectValidationError(f"Machine capability {self.capability_id} heeft ongeldige base_capability_hash")
        object.__setattr__(self, "base_capability_hash", expected_base)
        if self.capability_hash and len(self.capability_hash) != 64:
            raise ProjectValidationError(f"Machine capability {self.capability_id} heeft ongeldige capability_hash")

    def base_hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": MACHINE_MARKING_CAPABILITY_HASH_VERSION,
            "schema_version": self.schema_version,
            "capability_id": self.capability_id,
            "machine_id": self.machine_id,
            "machine_profile_id": self.machine_profile_id,
            "station_id": self.station_id,
            "revision": self.revision,
            "validation_status": self.validation_status,
            "enabled": self.enabled,
            "supported_mark_operations": sorted(set(self.supported_mark_operations)),
            "supported_mark_types": sorted(set(self.supported_mark_types)),
            "supported_face_roles": sorted(set(self.supported_face_roles)),
            "supported_surface_types": sorted(set(self.supported_surface_types)),
            "supported_dstv_side_aliases": sorted(set(self.supported_dstv_side_aliases)),
            "canonical_approach_vectors_by_face_role": {
                role: [list(v) for v in vectors] for role, vectors in sorted(self.canonical_approach_vectors_by_face_role.items())
            },
            "rotational_marking_supported": self.rotational_marking_supported,
            "rotational_axis": self.rotational_axis,
            "min_reachable_u_mm": self.min_reachable_u_mm,
            "max_reachable_u_mm": self.max_reachable_u_mm,
            "min_reachable_v_mm": self.min_reachable_v_mm,
            "max_reachable_v_mm": self.max_reachable_v_mm,
            "face_role_clearance_mm": dict(sorted(self.face_role_clearance_mm.items())),
            "forbidden_face_roles": sorted(set(self.forbidden_face_roles)),
            "internal_face_policy": self.internal_face_policy,
            "reorientation_policy": self.reorientation_policy,
            "reclamp_supported": self.reclamp_supported,
            "marking_tool_ids": sorted(set(self.marking_tool_ids)),
            "operation_tool_ids": {op: sorted(set(ids)) for op, ids in sorted(self.operation_tool_ids.items())},
            "forbidden_face_zones": {
                role: [dict(zone) for zone in zones] for role, zones in sorted(self.forbidden_face_zones.items())
            },
            "sequence_constraints": dict(self.sequence_constraints),
        }

    def effective_hash(self, *, tool_hashes: Mapping[str, str] | None = None, machine_profile_hash: str = "") -> str:
        payload = self.base_hash_payload()
        payload["effective_tool_hashes"] = {tool_id: str((tool_hashes or {}).get(tool_id) or "") for tool_id in sorted(set(self.marking_tool_ids))}
        payload["linked_machine_profile_hash"] = str(machine_profile_hash or "")
        return stable_sha256(payload)

    def with_effective_hash(self, *, tool_hashes: Mapping[str, str] | None = None, machine_profile_hash: str = "") -> "ManufacturingMachineCapability":
        from dataclasses import replace
        return replace(
            self,
            base_capability_hash=stable_sha256(self.base_hash_payload()),
            capability_hash=self.effective_hash(tool_hashes=tool_hashes, machine_profile_hash=machine_profile_hash),
        )

    def to_dict(self) -> dict[str, Any]:
        return {**self.base_hash_payload(), "provenance": dict(self.provenance), "base_capability_hash": self.base_capability_hash, "capability_hash": self.capability_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ManufacturingMachineCapability":
        return cls(
            capability_id=str(value.get("capability_id") or ""), machine_id=str(value.get("machine_id") or ""),
            machine_profile_id=str(value.get("machine_profile_id") or ""), station_id=str(value.get("station_id") or ""),
            revision=str(value.get("revision") or "1"), validation_status=str(value.get("validation_status") or MarkingCapabilityValidationStatus.DRAFT.value),
            enabled=bool(value.get("enabled", True)), supported_mark_operations=tuple(str(x) for x in value.get("supported_mark_operations") or []),
            supported_mark_types=tuple(str(x) for x in value.get("supported_mark_types") or []), supported_face_roles=tuple(str(x) for x in value.get("supported_face_roles") or []),
            supported_surface_types=tuple(str(x) for x in value.get("supported_surface_types") or ["plane"]),
            supported_dstv_side_aliases=tuple(str(x) for x in value.get("supported_dstv_side_aliases") or []),
            canonical_approach_vectors_by_face_role={str(k): tuple(tuple(float(v) for v in row) for row in rows) for k, rows in dict(value.get("canonical_approach_vectors_by_face_role") or {}).items()},
            rotational_marking_supported=bool(value.get("rotational_marking_supported", False)), rotational_axis=str(value.get("rotational_axis") or ""),
            min_reachable_u_mm=float(value["min_reachable_u_mm"]) if value.get("min_reachable_u_mm") is not None else None,
            max_reachable_u_mm=float(value["max_reachable_u_mm"]) if value.get("max_reachable_u_mm") is not None else None,
            min_reachable_v_mm=float(value["min_reachable_v_mm"]) if value.get("min_reachable_v_mm") is not None else None,
            max_reachable_v_mm=float(value["max_reachable_v_mm"]) if value.get("max_reachable_v_mm") is not None else None,
            face_role_clearance_mm={str(k): float(v) for k, v in dict(value.get("face_role_clearance_mm") or {}).items()},
            forbidden_face_roles=tuple(str(x) for x in value.get("forbidden_face_roles") or []), internal_face_policy=str(value.get("internal_face_policy") or InternalFacePolicy.BLOCKED.value),
            reorientation_policy=str(value.get("reorientation_policy") or ReorientationPolicy.BLOCKED.value), reclamp_supported=bool(value.get("reclamp_supported", False)),
            marking_tool_ids=tuple(str(x) for x in value.get("marking_tool_ids") or []),
            operation_tool_ids={str(k): tuple(str(x) for x in rows) for k, rows in dict(value.get("operation_tool_ids") or {}).items()},
            forbidden_face_zones={str(k): tuple(dict(row) for row in rows) for k, rows in dict(value.get("forbidden_face_zones") or {}).items()},
            sequence_constraints=dict(value.get("sequence_constraints") or {}), provenance=dict(value.get("provenance") or {}),
            base_capability_hash=str(value.get("base_capability_hash") or ""), capability_hash=str(value.get("capability_hash") or ""), schema_version=str(value.get("schema_version") or MACHINE_MARKING_CAPABILITY_SCHEMA_VERSION),
        )


@dataclass(frozen=True)
class MarkCapabilityIssue:
    code: str
    message: str
    blocking: bool = True
    severity: str = "error"
    mark_id: str = ""
    part_id: str = ""
    face_id: str = ""
    tool_id: str = ""
    suggested_remediation: str = ""
    provenance: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code, "message": self.message, "blocking": self.blocking,
            "severity": self.severity, "mark_id": self.mark_id, "part_id": self.part_id,
            "face_id": self.face_id, "tool_id": self.tool_id,
            "suggested_remediation": self.suggested_remediation, "provenance": dict(self.provenance),
        }


@dataclass(frozen=True)
class MarkCapabilityProof:
    mark_id: str
    machine_id: str
    capability_id: str
    operation: str
    target_part_id: str
    target_face_id: str
    target_face_role: str
    target_surface_type: str
    feasible: bool
    review_required: bool
    selected_tool_id: str = ""
    selected_tool_hash: str = ""
    face_reachable: bool = False
    operation_supported: bool = False
    head_clearance_ok: bool = False
    transverse_reach_ok: bool = False
    approach_ok: bool = False
    rotational_requirement_satisfied: bool = True
    requires_m6_rebind: bool = True
    issues: tuple[MarkCapabilityIssue, ...] = ()
    evidence: Mapping[str, Any] = field(default_factory=dict)
    proof_hash: str = ""
    schema_version: str = MARK_CAPABILITY_PROOF_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if str(self.schema_version) != MARK_CAPABILITY_PROOF_SCHEMA_VERSION:
            raise ProjectValidationError(f"Onbekende toekomstige MarkCapabilityProof schema-versie {self.schema_version!r}")
        expected = stable_sha256(self.hash_payload())
        if self.proof_hash and self.proof_hash != expected:
            raise ProjectValidationError(f"MarkCapabilityProof {self.mark_id} heeft ongeldige proof_hash")
        object.__setattr__(self, "proof_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version, "mark_id": self.mark_id, "machine_id": self.machine_id,
            "capability_id": self.capability_id, "operation": self.operation, "target_part_id": self.target_part_id,
            "target_face_id": self.target_face_id, "target_face_role": self.target_face_role,
            "target_surface_type": self.target_surface_type, "feasible": self.feasible,
            "review_required": self.review_required, "selected_tool_id": self.selected_tool_id,
            "selected_tool_hash": self.selected_tool_hash, "face_reachable": self.face_reachable,
            "operation_supported": self.operation_supported, "head_clearance_ok": self.head_clearance_ok,
            "transverse_reach_ok": self.transverse_reach_ok, "approach_ok": self.approach_ok,
            "rotational_requirement_satisfied": self.rotational_requirement_satisfied,
            "requires_m6_rebind": self.requires_m6_rebind, "issues": [item.to_dict() for item in self.issues],
            "evidence": dict(self.evidence),
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "proof_hash": self.proof_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "MarkCapabilityProof":
        return cls(
            mark_id=str(value.get("mark_id") or ""), machine_id=str(value.get("machine_id") or ""), capability_id=str(value.get("capability_id") or ""),
            operation=str(value.get("operation") or ""), target_part_id=str(value.get("target_part_id") or ""), target_face_id=str(value.get("target_face_id") or ""),
            target_face_role=str(value.get("target_face_role") or ""), target_surface_type=str(value.get("target_surface_type") or ""), feasible=bool(value.get("feasible", False)),
            review_required=bool(value.get("review_required", False)), selected_tool_id=str(value.get("selected_tool_id") or ""), selected_tool_hash=str(value.get("selected_tool_hash") or ""),
            face_reachable=bool(value.get("face_reachable", False)), operation_supported=bool(value.get("operation_supported", False)), head_clearance_ok=bool(value.get("head_clearance_ok", False)),
            transverse_reach_ok=bool(value.get("transverse_reach_ok", False)), approach_ok=bool(value.get("approach_ok", False)),
            rotational_requirement_satisfied=bool(value.get("rotational_requirement_satisfied", True)), requires_m6_rebind=bool(value.get("requires_m6_rebind", True)),
            issues=tuple(MarkCapabilityIssue(**dict(row)) for row in value.get("issues") or []), evidence=dict(value.get("evidence") or {}),
            proof_hash=str(value.get("proof_hash") or ""), schema_version=str(value.get("schema_version") or MARK_CAPABILITY_PROOF_SCHEMA_VERSION),
        )


def machine_marking_report_hash(payload: Mapping[str, Any]) -> str:
    return stable_sha256({"hash_version": MARK_CAPABILITY_REPORT_HASH_VERSION, **dict(payload)})


__all__ = [name for name in globals() if not name.startswith("_")]
