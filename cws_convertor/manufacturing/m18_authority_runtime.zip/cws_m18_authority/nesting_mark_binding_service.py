"""Persistence, stale handling and hard validation gate for Scribing M6."""
from __future__ import annotations

from typing import Any

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from .nesting_mark_binding import NestingAwareMarkBindingEngine, m6_source_snapshot, m6_source_snapshot_hash
from .nesting_mark_binding_contracts import (
    NESTING_MARK_BINDING_STATE_SCHEMA_VERSION,
    NestingMarkBindingProof,
    nesting_mark_binding_report_hash,
)
from .nesting_mark_binding_validator import IndependentNestingMarkBindingValidator

M6_PHASE = "M6"


def binding_set_id(run_id: str, assembly_id: str, capability_id: str) -> str:
    return "nmbs-" + stable_sha256({"run_id": run_id, "assembly_id": assembly_id, "capability_id": capability_id})[:24]


def _state_hash(state: dict[str, Any]) -> str:
    return stable_sha256({k: v for k, v in state.items() if k != "state_hash"})


def bind_assembly_to_nesting(
    project: ProjectModel,
    run_id: str,
    assembly_id: str,
    capability_id: str,
    *,
    user: str = "system",
    persist: bool = True,
):
    """Bind current M3/M4 marks and M5 proofs to one validated nesting plan.

    Independent validation is a hard consistency gate.  The resulting binding set
    may be infeasible (e.g. a clamp blocks a mark) and still be valid evidence.
    """
    report = NestingAwareMarkBindingEngine().bind(project, run_id, assembly_id, capability_id)
    independent = IndependentNestingMarkBindingValidator().validate(
        project, run_id, assembly_id, capability_id, report.bindings
    )
    if independent.status != "passed":
        raise ProjectValidationError("CWS-MARK-039 onafhankelijke M6 transform/sequence-validatie mismatch")

    if persist:
        sid = binding_set_id(run_id, assembly_id, capability_id)
        previous = dict(project.manufacturing_nesting_mark_bindings.get(sid) or {})
        raw_report = report.to_dict()
        raw_validation = independent.to_dict()
        state = {
            "schema_version": NESTING_MARK_BINDING_STATE_SCHEMA_VERSION,
            "phase": M6_PHASE,
            "binding_set_id": sid,
            "run_id": run_id,
            "assembly_id": assembly_id,
            "capability_id": capability_id,
            "machine_id": report.machine_id,
            "status": "current",
            "feasible": bool(report.feasible),
            "review_required": bool(report.review_required),
            "source_snapshot": m6_source_snapshot(project, run_id, assembly_id, capability_id),
            "source_snapshot_hash": report.source_snapshot_hash,
            "plan_hash": report.plan_hash,
            "assembly_marking_variant_hash": report.assembly_marking_variant_hash,
            "report": raw_report,
            "independent_validation": raw_validation,
            "binding_ids": [b.binding_id for b in report.bindings],
            "binding_hashes": [b.binding_hash for b in report.bindings],
            "production_artifact_identities": dict(report.production_artifact_identities),
            "evaluated_at": utc_now_iso(),
            "evaluated_by": user,
            "requires_m7_sequence": True,
            "dstv_si_released": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
        }
        state["state_hash"] = _state_hash(state)
        project.manufacturing_nesting_mark_bindings[sid] = state
        # Any prior M7 sequence derived from the replaced M6 evidence becomes stale.
        try:
            from .manufacturing_sequence_service import invalidate_manufacturing_sequences
            invalidate_manufacturing_sequences(project, reason="m6_binding_recomputed", user=user, run_id=run_id, assembly_id=assembly_id, capability_id=capability_id)
        except ImportError:
            pass
        project.audit(
            "manufacturing.nesting_mark_binding_evaluated",
            user=user,
            entity_id=sid,
            before_hash=str(previous.get("state_hash") or ""),
            after_hash=state["state_hash"],
            details={
                "run_id": run_id,
                "assembly_id": assembly_id,
                "capability_id": capability_id,
                "binding_count": len(report.bindings),
                "feasible": report.feasible,
                "review_required": report.review_required,
                "requires_m7_sequence": True,
            },
        )
    return report, independent


def invalidate_nesting_mark_bindings(
    project: ProjectModel,
    *,
    reason: str,
    user: str = "system",
    run_id: str | None = None,
    assembly_id: str | None = None,
    capability_id: str | None = None,
) -> None:
    now = utc_now_iso()
    for sid, state in project.manufacturing_nesting_mark_bindings.items():
        if not isinstance(state, dict):
            continue
        if run_id and str(state.get("run_id") or "") != run_id:
            continue
        if assembly_id and str(state.get("assembly_id") or "") != assembly_id:
            continue
        if capability_id and str(state.get("capability_id") or "") != capability_id:
            continue
        if state.get("status") in {"stale", "blocked"}:
            continue
        state["status"] = "stale"
        state["stale_reason"] = reason
        state["stale_at"] = now
        state["state_hash"] = _state_hash(state)
        project.audit(
            "manufacturing.nesting_mark_binding_invalidated",
            user=user,
            entity_id=sid,
            after_hash=state["state_hash"],
            details={"reason": reason},
        )
        try:
            from .manufacturing_sequence_service import invalidate_manufacturing_sequences
            invalidate_manufacturing_sequences(project, reason=f"m6_invalidated:{reason}", user=user, run_id=str(state.get("run_id") or ""), assembly_id=str(state.get("assembly_id") or ""), capability_id=str(state.get("capability_id") or ""))
        except ImportError:
            pass


def validate_persisted_nesting_mark_binding(
    project: ProjectModel,
    sid: str,
    *,
    require_current: bool = False,
) -> dict[str, Any]:
    state = project.manufacturing_nesting_mark_bindings.get(sid)
    if not isinstance(state, dict):
        raise ProjectValidationError(f"Onbekende M6 nesting mark binding {sid}")
    if str(state.get("schema_version") or "") != NESTING_MARK_BINDING_STATE_SCHEMA_VERSION:
        raise ProjectValidationError(f"Onbekend toekomstig M6 binding state schema {state.get('schema_version')!r}")
    if str(state.get("phase") or "") != M6_PHASE:
        raise ProjectValidationError(f"M6 binding {sid} heeft ongeldige phase")
    if bool(state.get("dstv_si_released")) or bool(state.get("machine_output_released")) or bool(state.get("direct_machine_transfer")):
        raise ProjectValidationError("M6 mag geen DSTV SI/machine-output/directe transfer vrijgeven")
    if str(state.get("state_hash") or "") != _state_hash(state):
        raise ProjectValidationError(f"M6 binding {sid} state_hash ongeldig")
    run_id = str(state.get("run_id") or "")
    assembly_id = str(state.get("assembly_id") or "")
    capability_id = str(state.get("capability_id") or "")
    if binding_set_id(run_id, assembly_id, capability_id) != sid or str(state.get("binding_set_id") or "") != sid:
        raise ProjectValidationError(f"M6 binding {sid} identity mismatch")

    report = dict(state.get("report") or {})
    if not report:
        raise ProjectValidationError(f"M6 binding {sid} mist report")
    report_hash = str(report.get("report_hash") or "")
    report_payload = {k: v for k, v in report.items() if k != "report_hash"}
    if report_hash != nesting_mark_binding_report_hash(report_payload):
        raise ProjectValidationError(f"M6 binding {sid} report_hash ongeldig")
    proofs = [NestingMarkBindingProof.from_dict(row) for row in report.get("bindings") or []]
    if list(state.get("binding_ids") or []) != [p.binding_id for p in proofs]:
        raise ProjectValidationError(f"M6 binding {sid} binding_ids mismatch")
    if list(state.get("binding_hashes") or []) != [p.binding_hash for p in proofs]:
        raise ProjectValidationError(f"M6 binding {sid} binding_hashes mismatch")

    stored_validation = dict(state.get("independent_validation") or {})
    if not stored_validation:
        raise ProjectValidationError(f"M6 binding {sid} mist independent_validation")
    stored_hash = str(stored_validation.get("report_hash") or "")
    payload = {k: v for k, v in stored_validation.items() if k != "report_hash"}
    if stored_hash != stable_sha256(payload):
        raise ProjectValidationError(f"M6 binding {sid} independent_validation hash ongeldig")

    if require_current:
        current_source = m6_source_snapshot_hash(project, run_id, assembly_id, capability_id)
        if str(state.get("source_snapshot_hash") or "") != current_source:
            raise ProjectValidationError(f"CWS-MARK-041 M6 binding {sid} is stale")
        if state.get("status") != "current":
            raise ProjectValidationError(f"M6 binding {sid} heeft status {state.get('status')}")
        current = IndependentNestingMarkBindingValidator().validate(
            project, run_id, assembly_id, capability_id, proofs
        )
        if current.status != "passed":
            raise ProjectValidationError(f"CWS-MARK-039 M6 binding {sid} faalt onafhankelijke validatie")
    return state


__all__ = [name for name in globals() if not name.startswith("_")]
