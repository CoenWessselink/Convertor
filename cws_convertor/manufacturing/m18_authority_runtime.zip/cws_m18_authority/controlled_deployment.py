"""M17 controlled deployment operations and air-gap change control.

M17 sits above M16 fleet governance.  It does not certify adapters, does not
communicate with controllers and never authorizes network/PLC/machine transfer.
It provides a cryptographically verifiable, dual-control handoff process for
moving an already-released M16 offline deployment bundle across an air gap,
recording independent import verification, operator-reported deployment,
acknowledgement evidence, rollout-wave progress and rollback references.
"""
from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tempfile
from typing import Any, Iterable, Mapping
import zipfile

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from cws_convertor.product import APP_VERSION, PROJECT_SCHEMA_VERSION
from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from cws_convertor.production_export.utils import canonical_json_bytes, sha256_file
from .fleet_governance import (
    validate_controlled_deployment_bundle,
    validate_persisted_fleet_deployment,
    validate_persisted_fleet_machine_binding,
    validate_persisted_fleet_policy,
    validate_persisted_fleet_site,
    validate_persisted_trusted_signer,
)

M17_CONTRACT_VERSION = "1.0"
M17_HASH_VERSION = "cws-m17-controlled-deployment-v1"
M17_STATION_FORMAT = "CWS_M17_AIRGAP_STATION_V1"
M17_POLICY_FORMAT = "CWS_M17_DEPLOYMENT_CONTROL_POLICY_V1"
M17_ROLLOUT_FORMAT = "CWS_M17_ROLLOUT_PLAN_V1"
M17_ROLLBACK_FORMAT = "CWS_M17_ROLLBACK_REFERENCE_V1"
M17_RELEASE_REQUEST_FORMAT = "CWS_M17_RELEASE_REQUEST_V1"
M17_OPERATOR_PAYLOAD_FORMAT = "CWS_M17_OPERATOR_RELEASE_PAYLOAD_V1"
M17_OPERATOR_APPROVAL_FORMAT = "CWS_M17_SIGNED_OPERATOR_APPROVAL_V1"
M17_HANDOFF_PAYLOAD_FORMAT = "CWS_M17_AIRGAP_HANDOFF_PAYLOAD_V1"
M17_HANDOFF_ENVELOPE_FORMAT = "CWS_M17_SIGNED_AIRGAP_HANDOFF_V1"
M17_AIRGAP_PACKAGE_FORMAT = "CWS_M17_SIGNED_AIRGAP_EXPORT_V1"
M17_AIRGAP_EXPORT_RECORD_FORMAT = "CWS_M17_AIRGAP_EXPORT_RECORD_V1"
M17_IMPORT_RECEIPT_PAYLOAD_FORMAT = "CWS_M17_IMPORT_RECEIPT_PAYLOAD_V1"
M17_IMPORT_RECEIPT_FORMAT = "CWS_M17_SIGNED_IMPORT_RECEIPT_V1"
M17_DEPLOYMENT_RECEIPT_PAYLOAD_FORMAT = "CWS_M17_DEPLOYMENT_RECEIPT_PAYLOAD_V1"
M17_DEPLOYMENT_RECEIPT_FORMAT = "CWS_M17_SIGNED_DEPLOYMENT_RECEIPT_V1"
M17_ACK_PAYLOAD_FORMAT = "CWS_M17_ACKNOWLEDGEMENT_PAYLOAD_V1"
M17_ACK_FORMAT = "CWS_M17_SIGNED_ACKNOWLEDGEMENT_V1"
M17_WITHDRAWAL_PAYLOAD_FORMAT = "CWS_M17_WITHDRAWAL_PAYLOAD_V1"
M17_WITHDRAWAL_FORMAT = "CWS_M17_SIGNED_STAGE_WITHDRAWAL_V1"
M17_DASHBOARD_FORMAT = "CWS_M17_CONTROLLED_DEPLOYMENT_DASHBOARD_V1"

_ZIP_DATE = (1980, 1, 1, 0, 0, 0)
_SHA256_RE = re.compile(r"[0-9a-f]{64}")


class ControlledDeploymentError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def _hash_record(value: Mapping[str, Any], field: str) -> str:
    return stable_sha256({k: v for k, v in value.items() if k != field})


def _parse_iso(value: Any, *, label: str) -> datetime:
    text = str(value or "").strip()
    if not text:
        raise ControlledDeploymentError("CWS-DEPLOY-001", f"{label} ontbreekt")
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ControlledDeploymentError("CWS-DEPLOY-001", f"{label} is geen geldige ISO-8601 datum/tijd") from exc
    if dt.tzinfo is None:
        raise ControlledDeploymentError("CWS-DEPLOY-001", f"{label} moet timezone-aware zijn")
    return dt.astimezone(timezone.utc)


def _safe_rel(value: Any) -> str:
    raw = str(value or "").replace("\\", "/").strip()
    p = PurePosixPath(raw)
    if not raw or p.is_absolute() or ".." in p.parts or any(x in {"", "."} for x in p.parts) or len(raw) > 512:
        raise ControlledDeploymentError("CWS-DEPLOY-002", f"Onveilig relatief pad: {raw!r}")
    return p.as_posix()


def _store_immutable(store: dict[str, dict[str, Any]], key: str, record: dict[str, Any], hash_field: str) -> dict[str, Any]:
    old = store.get(key)
    if isinstance(old, Mapping):
        if str(old.get(hash_field) or "") != str(record.get(hash_field) or ""):
            raise ProjectValidationError(f"M17 immutable record-ID collision voor {key}")
        return dict(old)
    store[key] = record
    return record


def _public_key_fingerprint(pem: str) -> str:
    try:
        key = serialization.load_pem_public_key(str(pem).encode("ascii"))
    except Exception as exc:
        raise ControlledDeploymentError("CWS-DEPLOY-003", "Public key kan niet worden geladen") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise ControlledDeploymentError("CWS-DEPLOY-003", "M17 accepteert alleen Ed25519 public keys")
    raw = key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return hashlib.sha256(raw).hexdigest()


def _verify_signature(public_key_pem: str, payload: Mapping[str, Any], signature_base64: str) -> None:
    try:
        key = serialization.load_pem_public_key(str(public_key_pem).encode("ascii"))
        if not isinstance(key, Ed25519PublicKey):
            raise TypeError("not ed25519")
        signature = base64.b64decode(str(signature_base64 or ""), validate=True)
        key.verify(signature, canonical_json_bytes(payload))
    except (InvalidSignature, ValueError, TypeError) as exc:
        raise ControlledDeploymentError("CWS-DEPLOY-004", "Ed25519 signature verification failed") from exc


def _signer_snapshot(project: ProjectModel, signer_ids: Iterable[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for signer_id in sorted({str(x).strip() for x in signer_ids if str(x).strip()}):
        signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
        out[signer_id] = str(signer["signer_hash"])
    return out


def register_airgap_station(
    project: ProjectModel,
    *,
    station_id: str,
    site_id: str,
    name: str,
    station_signer_id: str,
    media_policy: str = "removable_media_only",
    user: str = "system",
) -> dict[str, Any]:
    site = validate_persisted_fleet_site(project, str(site_id))
    signer = validate_persisted_trusted_signer(project, str(station_signer_id), require_current=True)
    station_id = str(station_id or "").strip()
    if not station_id or not str(name or "").strip():
        raise ControlledDeploymentError("CWS-DEPLOY-005", "Deployment station vereist station_id en naam")
    record = {
        "format": M17_STATION_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "station_id": station_id, "site_id": site["site_id"], "site_hash": site["site_hash"],
        "name": str(name).strip(), "station_signer_id": signer["signer_id"], "station_signer_hash": signer["signer_hash"],
        "media_policy": str(media_policy or "removable_media_only"), "status": "active",
        "network_controller_transport": False, "direct_machine_transfer": False,
        "created_for_cws_version": APP_VERSION, "created_for_project_schema": PROJECT_SCHEMA_VERSION,
        "hash_version": M17_HASH_VERSION,
    }
    record["station_hash"] = _hash_record(record, "station_hash")
    result = _store_immutable(project.manufacturing_deployment_stations, station_id, record, "station_hash")
    project.audit("manufacturing.deployment_station_registered", user=user, entity_id=station_id, after_hash=result["station_hash"], details={"direct_machine_transfer": False})
    return result


def validate_persisted_airgap_station(project: ProjectModel, station_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_deployment_stations.get(station_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_STATION_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 air-gap station {station_id} ontbreekt/ongeldig")
    if str(raw.get("station_id") or "") != station_id or str(raw.get("station_hash") or "") != _hash_record(raw, "station_hash"):
        raise ProjectValidationError("M17 station identity/hash ongeldig")
    site = validate_persisted_fleet_site(project, str(raw.get("site_id") or ""))
    signer = validate_persisted_trusted_signer(project, str(raw.get("station_signer_id") or ""), require_current=require_current)
    if str(raw.get("site_hash") or "") != site["site_hash"] or str(raw.get("station_signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M17 station site/signer snapshot is stale")
    if bool(raw.get("network_controller_transport")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 station mag machine/network transport niet vrijgeven")
    return dict(raw)


def create_deployment_control_policy(
    project: ProjectModel,
    *,
    policy_name: str,
    fleet_policy_id: str,
    site_ids: Iterable[str],
    operator_signer_ids: Iterable[str],
    handoff_signer_ids: Iterable[str],
    station_signer_ids: Iterable[str],
    acknowledgement_signer_ids: Iterable[str] | None = None,
    minimum_operator_approvals: int = 2,
    minimum_acknowledgements: int = 1,
    maximum_stage_age_hours: int = 24,
    require_distinct_deploy_and_ack_signers: bool = True,
    require_rollback_reference: bool = True,
    allow_initial_without_rollback: bool = True,
    user: str = "system",
) -> dict[str, Any]:
    fleet_policy = validate_persisted_fleet_policy(project, fleet_policy_id)
    sites = sorted({str(x).strip() for x in site_ids if str(x).strip()})
    if not sites or not str(policy_name or "").strip():
        raise ControlledDeploymentError("CWS-DEPLOY-006", "M17 policy vereist naam en sites")
    for site_id in sites:
        validate_persisted_fleet_site(project, site_id)
        if site_id not in list(fleet_policy.get("site_ids") or []):
            raise ControlledDeploymentError("CWS-DEPLOY-006", f"Site {site_id} valt buiten M16 fleet policy")
    operators = _signer_snapshot(project, operator_signer_ids)
    handoff = _signer_snapshot(project, handoff_signer_ids)
    stations = _signer_snapshot(project, station_signer_ids)
    ack = _signer_snapshot(project, acknowledgement_signer_ids or station_signer_ids)
    minimum_operator_approvals = int(minimum_operator_approvals)
    minimum_acknowledgements = int(minimum_acknowledgements)
    if minimum_operator_approvals < 2 or len(operators) < minimum_operator_approvals:
        raise ControlledDeploymentError("CWS-DEPLOY-006", "M17 vereist minimaal twee verschillende operator signers")
    if minimum_acknowledgements < 1 or len(ack) < minimum_acknowledgements or not handoff or not stations:
        raise ControlledDeploymentError("CWS-DEPLOY-006", "M17 handoff/station/ack signer policy is onvolledig")
    if not 1 <= int(maximum_stage_age_hours) <= 168:
        raise ControlledDeploymentError("CWS-DEPLOY-006", "maximum_stage_age_hours moet 1..168 zijn")
    record = {
        "format": M17_POLICY_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "policy_name": str(policy_name).strip(), "fleet_policy_id": fleet_policy_id, "fleet_policy_hash": fleet_policy["policy_hash"],
        "site_ids": sites, "operator_signer_snapshots": operators, "handoff_signer_snapshots": handoff,
        "station_signer_snapshots": stations, "acknowledgement_signer_snapshots": ack,
        "minimum_operator_approvals": minimum_operator_approvals, "minimum_acknowledgements": minimum_acknowledgements,
        "maximum_stage_age_hours": int(maximum_stage_age_hours),
        "require_distinct_operator_signers": True,
        "require_distinct_deploy_and_ack_signers": bool(require_distinct_deploy_and_ack_signers),
        "require_rollback_reference": bool(require_rollback_reference), "allow_initial_without_rollback": bool(allow_initial_without_rollback),
        "airgap_only": True, "operator_release_required": True, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "created_for_cws_version": APP_VERSION, "created_for_project_schema": PROJECT_SCHEMA_VERSION, "hash_version": M17_HASH_VERSION,
    }
    policy_id = "dpol-" + stable_sha256({k: record[k] for k in ("policy_name", "fleet_policy_id", "site_ids", "operator_signer_snapshots", "handoff_signer_snapshots", "station_signer_snapshots")})[:28]
    record["policy_id"] = policy_id
    record["policy_hash"] = _hash_record(record, "policy_hash")
    result = _store_immutable(project.manufacturing_deployment_control_policies, policy_id, record, "policy_hash")
    project.audit("manufacturing.deployment_control_policy", user=user, entity_id=policy_id, after_hash=result["policy_hash"], details={"minimum_operator_approvals": minimum_operator_approvals, "direct_machine_transfer": False})
    return result


def validate_persisted_deployment_control_policy(project: ProjectModel, policy_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_deployment_control_policies.get(policy_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_POLICY_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 deployment policy {policy_id} ontbreekt/ongeldig")
    if str(raw.get("policy_id") or "") != policy_id or str(raw.get("policy_hash") or "") != _hash_record(raw, "policy_hash"):
        raise ProjectValidationError("M17 deployment policy identity/hash ongeldig")
    fleet = validate_persisted_fleet_policy(project, str(raw.get("fleet_policy_id") or ""))
    if str(raw.get("fleet_policy_hash") or "") != fleet["policy_hash"]:
        raise ProjectValidationError("M17 deployment policy M16 snapshot is stale")
    for field in ("operator_signer_snapshots", "handoff_signer_snapshots", "station_signer_snapshots", "acknowledgement_signer_snapshots"):
        for signer_id, signer_hash in dict(raw.get(field) or {}).items():
            signer = validate_persisted_trusted_signer(project, str(signer_id), require_current=require_current)
            if str(signer_hash) != signer["signer_hash"]:
                raise ProjectValidationError(f"M17 deployment policy signer snapshot stale: {signer_id}")
    if int(raw.get("minimum_operator_approvals") or 0) < 2 or not bool(raw.get("airgap_only")) or not bool(raw.get("operator_release_required")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 deployment policy veiligheidscontract ongeldig")
    return dict(raw)


def create_rollout_plan(project: ProjectModel, *, policy_id: str, plan_name: str, waves: Iterable[Mapping[str, Any]], user: str = "system") -> dict[str, Any]:
    policy = validate_persisted_deployment_control_policy(project, policy_id, require_current=True)
    rows: list[dict[str, Any]] = []
    seen_bindings: set[str] = set()
    for index, source in enumerate(list(waves)):
        wave_id = str(source.get("wave_id") or f"wave-{index+1}").strip()
        site_id = str(source.get("site_id") or "").strip()
        binding_ids = sorted({str(x).strip() for x in source.get("binding_ids") or [] if str(x).strip()})
        start = _parse_iso(source.get("window_start"), label=f"{wave_id} window_start")
        end = _parse_iso(source.get("window_end"), label=f"{wave_id} window_end")
        if end <= start or not binding_ids or site_id not in list(policy.get("site_ids") or []):
            raise ControlledDeploymentError("CWS-DEPLOY-007", f"Rollout wave {wave_id} is ongeldig")
        for binding_id in binding_ids:
            if binding_id in seen_bindings:
                raise ControlledDeploymentError("CWS-DEPLOY-007", f"Binding {binding_id} staat in meerdere rollout waves")
            binding = validate_persisted_fleet_machine_binding(project, binding_id, require_current=False)
            if str(binding.get("site_id") or "") != site_id:
                raise ControlledDeploymentError("CWS-DEPLOY-007", f"Binding {binding_id} hoort niet bij rollout site {site_id}")
            seen_bindings.add(binding_id)
        row = {
            "wave_id": wave_id, "sequence_index": index, "site_id": site_id, "binding_ids": binding_ids,
            "window_start": start.isoformat(), "window_end": end.isoformat(),
            "requires_previous_wave_ack": bool(source.get("requires_previous_wave_ack", index > 0)),
        }
        row["wave_hash"] = stable_sha256(row)
        rows.append(row)
    if not rows or not str(plan_name or "").strip():
        raise ControlledDeploymentError("CWS-DEPLOY-007", "Rollout plan vereist naam en waves")
    record = {
        "format": M17_ROLLOUT_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "plan_name": str(plan_name).strip(), "policy_id": policy_id, "policy_hash": policy["policy_hash"], "waves": rows,
        "airgap_only": True, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    plan_id = "rollout-" + stable_sha256({"policy_hash": policy["policy_hash"], "plan_name": record["plan_name"], "waves": rows})[:28]
    record["plan_id"] = plan_id
    record["plan_hash"] = _hash_record(record, "plan_hash")
    result = _store_immutable(project.manufacturing_deployment_rollout_plans, plan_id, record, "plan_hash")
    project.audit("manufacturing.deployment_rollout_plan", user=user, entity_id=plan_id, after_hash=result["plan_hash"], details={"wave_count": len(rows), "direct_machine_transfer": False})
    return result


def validate_persisted_rollout_plan(project: ProjectModel, plan_id: str) -> dict[str, Any]:
    raw = project.manufacturing_deployment_rollout_plans.get(plan_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_ROLLOUT_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 rollout plan {plan_id} ontbreekt/ongeldig")
    if str(raw.get("plan_id") or "") != plan_id or str(raw.get("plan_hash") or "") != _hash_record(raw, "plan_hash"):
        raise ProjectValidationError("M17 rollout identity/hash ongeldig")
    policy = validate_persisted_deployment_control_policy(project, str(raw.get("policy_id") or ""))
    if str(raw.get("policy_hash") or "") != policy["policy_hash"]:
        raise ProjectValidationError("M17 rollout policy snapshot is stale")
    waves = list(raw.get("waves") or [])
    for i, wave in enumerate(waves):
        if not isinstance(wave, Mapping) or int(wave.get("sequence_index") or 0) != i:
            raise ProjectValidationError("M17 rollout sequence ongeldig")
        if str(wave.get("wave_hash") or "") != stable_sha256({k: v for k, v in wave.items() if k != "wave_hash"}):
            raise ProjectValidationError("M17 rollout wave_hash ongeldig")
        for binding_id in wave.get("binding_ids") or []:
            binding = validate_persisted_fleet_machine_binding(project, str(binding_id), require_current=False)
            if str(binding.get("site_id") or "") != str(wave.get("site_id") or ""):
                raise ProjectValidationError("M17 rollout binding/site mismatch")
    if bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 rollout mag transfer niet vrijgeven")
    return dict(raw)


def create_rollback_reference(
    project: ProjectModel,
    *,
    binding_id: str,
    previous_deployment_id: str = "",
    initial_deployment: bool = False,
    user: str = "system",
) -> dict[str, Any]:
    binding = validate_persisted_fleet_machine_binding(project, binding_id, require_current=False)
    previous = None
    if previous_deployment_id:
        previous = validate_persisted_fleet_deployment(project, previous_deployment_id)
        if str(previous.get("binding_id") or "") != binding_id:
            raise ControlledDeploymentError("CWS-DEPLOY-008", "Rollback deployment hoort niet bij dezelfde binding")
    if bool(initial_deployment) == bool(previous_deployment_id):
        raise ControlledDeploymentError("CWS-DEPLOY-008", "Rollback reference vereist exact initial_deployment of previous_deployment_id")
    record = {
        "format": M17_ROLLBACK_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "binding_id": binding_id, "binding_hash": binding["binding_hash"], "initial_deployment": bool(initial_deployment),
        "previous_deployment_id": str(previous_deployment_id or ""),
        "previous_deployment_record_hash": str(previous.get("deployment_record_hash") or "") if previous else "",
        "previous_bundle_sha256": str(previous.get("bundle_sha256") or "") if previous else "",
        "immutable_rollback_reference": True, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    rollback_id = "rollback-" + stable_sha256(record)[:28]
    record["rollback_id"] = rollback_id
    record["rollback_hash"] = _hash_record(record, "rollback_hash")
    result = _store_immutable(project.manufacturing_deployment_rollback_references, rollback_id, record, "rollback_hash")
    project.audit("manufacturing.deployment_rollback_reference", user=user, entity_id=rollback_id, after_hash=result["rollback_hash"], details={"initial": bool(initial_deployment), "direct_machine_transfer": False})
    return result


def validate_persisted_rollback_reference(project: ProjectModel, rollback_id: str) -> dict[str, Any]:
    raw = project.manufacturing_deployment_rollback_references.get(rollback_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_ROLLBACK_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 rollback reference {rollback_id} ontbreekt/ongeldig")
    if str(raw.get("rollback_id") or "") != rollback_id or str(raw.get("rollback_hash") or "") != _hash_record(raw, "rollback_hash"):
        raise ProjectValidationError("M17 rollback identity/hash ongeldig")
    binding = validate_persisted_fleet_machine_binding(project, str(raw.get("binding_id") or ""), require_current=False)
    if str(raw.get("binding_hash") or "") != binding["binding_hash"]:
        raise ProjectValidationError("M17 rollback binding snapshot stale")
    if raw.get("previous_deployment_id"):
        dep = validate_persisted_fleet_deployment(project, str(raw["previous_deployment_id"]))
        if str(raw.get("previous_deployment_record_hash") or "") != dep["deployment_record_hash"] or str(raw.get("previous_bundle_sha256") or "") != dep["bundle_sha256"]:
            raise ProjectValidationError("M17 rollback deployment snapshot stale")
    if bool(raw.get("initial_deployment")) == bool(raw.get("previous_deployment_id")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 rollback veiligheidscontract ongeldig")
    return dict(raw)


def _wave_for_binding(plan: Mapping[str, Any], wave_id: str, binding_id: str) -> dict[str, Any]:
    for wave in plan.get("waves") or []:
        if str(wave.get("wave_id") or "") == wave_id:
            if binding_id not in list(wave.get("binding_ids") or []):
                raise ControlledDeploymentError("CWS-DEPLOY-009", "Binding staat niet in geselecteerde rollout wave")
            return dict(wave)
    raise ControlledDeploymentError("CWS-DEPLOY-009", f"Rollout wave {wave_id} ontbreekt")


def create_release_request(
    project: ProjectModel,
    *,
    deployment_id: str,
    control_policy_id: str,
    rollout_plan_id: str,
    wave_id: str,
    rollback_id: str,
    user: str = "system",
) -> dict[str, Any]:
    deployment = validate_persisted_fleet_deployment(project, deployment_id)
    policy = validate_persisted_deployment_control_policy(project, control_policy_id, require_current=True)
    plan = validate_persisted_rollout_plan(project, rollout_plan_id)
    if plan["policy_id"] != control_policy_id:
        raise ControlledDeploymentError("CWS-DEPLOY-009", "Rollout plan hoort niet bij control policy")
    binding_id = str(deployment.get("binding_id") or "")
    binding = validate_persisted_fleet_machine_binding(project, binding_id, require_current=True)
    wave = _wave_for_binding(plan, wave_id, binding_id)
    rollback = validate_persisted_rollback_reference(project, rollback_id)
    if rollback["binding_id"] != binding_id:
        raise ControlledDeploymentError("CWS-DEPLOY-009", "Rollback reference hoort niet bij deployment binding")
    if bool(policy.get("require_rollback_reference")) and rollback["initial_deployment"] and not bool(policy.get("allow_initial_without_rollback")):
        raise ControlledDeploymentError("CWS-DEPLOY-009", "Policy staat initial deployment zonder rollback niet toe")
    record = {
        "format": M17_RELEASE_REQUEST_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "deployment_id": deployment_id, "deployment_record_hash": deployment["deployment_record_hash"], "deployment_bundle_sha256": deployment["bundle_sha256"],
        "binding_id": binding_id, "binding_hash": binding["binding_hash"], "control_policy_id": control_policy_id, "control_policy_hash": policy["policy_hash"],
        "rollout_plan_id": rollout_plan_id, "rollout_plan_hash": plan["plan_hash"], "wave_id": wave_id, "wave_hash": wave["wave_hash"],
        "rollback_id": rollback_id, "rollback_hash": rollback["rollback_hash"],
        "minimum_operator_approvals": policy["minimum_operator_approvals"], "operator_release_required": True,
        "airgap_only": True, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "hash_version": M17_HASH_VERSION,
    }
    request_id = "release-" + stable_sha256(record)[:28]
    record["release_request_id"] = request_id
    record["release_request_hash"] = _hash_record(record, "release_request_hash")
    result = _store_immutable(project.manufacturing_deployment_release_requests, request_id, record, "release_request_hash")
    project.audit("manufacturing.deployment_release_request", user=user, entity_id=request_id, after_hash=result["release_request_hash"], details={"wave_id": wave_id, "direct_machine_transfer": False})
    return result


def validate_persisted_release_request(project: ProjectModel, request_id: str) -> dict[str, Any]:
    raw = project.manufacturing_deployment_release_requests.get(request_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_RELEASE_REQUEST_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 release request {request_id} ontbreekt/ongeldig")
    if str(raw.get("release_request_id") or "") != request_id or str(raw.get("release_request_hash") or "") != _hash_record(raw, "release_request_hash"):
        raise ProjectValidationError("M17 release request identity/hash ongeldig")
    dep = validate_persisted_fleet_deployment(project, str(raw.get("deployment_id") or ""))
    policy = validate_persisted_deployment_control_policy(project, str(raw.get("control_policy_id") or ""))
    plan = validate_persisted_rollout_plan(project, str(raw.get("rollout_plan_id") or ""))
    rollback = validate_persisted_rollback_reference(project, str(raw.get("rollback_id") or ""))
    binding = validate_persisted_fleet_machine_binding(project, str(raw.get("binding_id") or ""), require_current=False)
    if any((
        str(raw.get("deployment_record_hash") or "") != dep["deployment_record_hash"],
        str(raw.get("control_policy_hash") or "") != policy["policy_hash"],
        str(raw.get("rollout_plan_hash") or "") != plan["plan_hash"],
        str(raw.get("rollback_hash") or "") != rollback["rollback_hash"],
        str(raw.get("binding_hash") or "") != binding["binding_hash"],
    )):
        raise ProjectValidationError("M17 release request snapshot is stale")
    wave = _wave_for_binding(plan, str(raw.get("wave_id") or ""), str(raw.get("binding_id") or ""))
    if str(raw.get("wave_hash") or "") != wave["wave_hash"]:
        raise ProjectValidationError("M17 release wave snapshot is stale")
    if not bool(raw.get("operator_release_required")) or not bool(raw.get("airgap_only")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 release request veiligheidscontract ongeldig")
    return dict(raw)


def operator_release_approval_payload(
    project: ProjectModel,
    *,
    release_request_id: str,
    signer_id: str,
    approval_nonce: str,
    expires_at: str,
) -> dict[str, Any]:
    request = validate_persisted_release_request(project, release_request_id)
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    snapshots = dict(policy.get("operator_signer_snapshots") or {})
    if signer_id not in snapshots:
        raise ControlledDeploymentError("CWS-DEPLOY-010", "Signer is geen toegestane M17 operator")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    if signer["signer_hash"] != snapshots[signer_id]:
        raise ControlledDeploymentError("CWS-DEPLOY-010", "Operator signer snapshot is stale")
    exp = _parse_iso(expires_at, label="operator approval expires_at")
    if exp <= datetime.now(timezone.utc):
        raise ControlledDeploymentError("CWS-DEPLOY-010", "Operator approval mag niet reeds verlopen zijn")
    payload = {
        "format": M17_OPERATOR_PAYLOAD_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "release_request_id": release_request_id, "release_request_hash": request["release_request_hash"],
        "control_policy_id": policy["policy_id"], "control_policy_hash": policy["policy_hash"],
        "signer_id": signer_id, "signer_hash": signer["signer_hash"], "decision": "approve_airgap_release",
        "approval_nonce": str(approval_nonce or "").strip(), "issued_at": utc_now_iso(), "expires_at": exp.isoformat(),
        "operator_release_only": True, "deployment_transport_authorized": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    if not payload["approval_nonce"]:
        raise ControlledDeploymentError("CWS-DEPLOY-010", "Operator approval nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_operator_release_approval(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {})
    if raw.get("format") != M17_OPERATOR_APPROVAL_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519":
        raise ControlledDeploymentError("CWS-DEPLOY-011", "Operator approval envelope format/schema/algorithm ongeldig")
    payload = dict(raw.get("payload") or {})
    if payload.get("format") != M17_OPERATOR_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ControlledDeploymentError("CWS-DEPLOY-011", "Operator approval payload/hash ongeldig")
    request = validate_persisted_release_request(project, str(payload.get("release_request_id") or ""))
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("signer_id") or "") or signer_id not in dict(policy.get("operator_signer_snapshots") or {}):
        raise ControlledDeploymentError("CWS-DEPLOY-011", "Operator signer mismatch/not allowed")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    if str(payload.get("signer_hash") or "") != signer["signer_hash"] or str(payload.get("release_request_hash") or "") != request["release_request_hash"] or str(payload.get("control_policy_hash") or "") != policy["policy_hash"]:
        raise ControlledDeploymentError("CWS-DEPLOY-011", "Operator approval snapshot is stale")
    issued = _parse_iso(payload.get("issued_at"), label="operator approval issued_at")
    expires = _parse_iso(payload.get("expires_at"), label="operator approval expires_at")
    now = datetime.now(timezone.utc)
    if not (issued <= now < expires) or payload.get("decision") != "approve_airgap_release":
        raise ControlledDeploymentError("CWS-DEPLOY-011", "Operator approval is verlopen/nog niet geldig/beslissing ongeldig")
    if not bool(payload.get("operator_release_only")) or bool(payload.get("deployment_transport_authorized")) or bool(payload.get("direct_machine_transfer")):
        raise ControlledDeploymentError("CWS-DEPLOY-011", "Operator approval probeert deployment boundary te verzwakken")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    approval_id = "opapproval-" + stable_sha256({"request": request["release_request_hash"], "signer": signer["signer_hash"], "signature": raw.get("signature_base64")})[:28]
    existing = project.manufacturing_deployment_operator_approvals.get(approval_id)
    if isinstance(existing, Mapping):
        return validate_persisted_operator_approval(project, approval_id, require_current=True)
    record = {
        "format": M17_OPERATOR_APPROVAL_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "operator_approval_id": approval_id, "signer_id": signer_id, "signer_hash": signer["signer_hash"], "algorithm": "ed25519",
        "payload": payload, "signature_base64": str(raw.get("signature_base64") or ""), "signature_verified": True,
        "received_at": utc_now_iso(), "deployment_transport_authorized": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    record["operator_approval_hash"] = _hash_record(record, "operator_approval_hash")
    result = _store_immutable(project.manufacturing_deployment_operator_approvals, approval_id, record, "operator_approval_hash")
    project.audit("manufacturing.deployment_operator_approval", user=user, entity_id=approval_id, after_hash=result["operator_approval_hash"], details={"signer_id": signer_id, "direct_machine_transfer": False})
    return result


def validate_persisted_operator_approval(project: ProjectModel, approval_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_deployment_operator_approvals.get(approval_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_OPERATOR_APPROVAL_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 operator approval {approval_id} ontbreekt/ongeldig")
    if str(raw.get("operator_approval_id") or "") != approval_id or str(raw.get("operator_approval_hash") or "") != _hash_record(raw, "operator_approval_hash"):
        raise ProjectValidationError("M17 operator approval identity/hash ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M17 operator approval payload_hash ongeldig")
    request = validate_persisted_release_request(project, str(payload.get("release_request_id") or ""))
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=require_current)
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), require_current=require_current)
    if str(raw.get("signer_hash") or "") != signer["signer_hash"] or str(payload.get("signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M17 operator approval signer snapshot stale")
    if str(payload.get("release_request_hash") or "") != request["release_request_hash"] or str(payload.get("control_policy_hash") or "") != policy["policy_hash"]:
        raise ProjectValidationError("M17 operator approval request/policy snapshot stale")
    try:
        _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    except ControlledDeploymentError as exc:
        raise ProjectValidationError("M17 operator approval signature ongeldig") from exc
    if require_current and not (_parse_iso(payload["issued_at"], label="operator issued_at") <= datetime.now(timezone.utc) < _parse_iso(payload["expires_at"], label="operator expires_at")):
        raise ProjectValidationError("M17 operator approval is verlopen/nog niet geldig")
    if not bool(raw.get("signature_verified")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 operator approval veiligheidsflags ongeldig")
    return dict(raw)


def release_request_status(project: ProjectModel, release_request_id: str, *, at: datetime | None = None) -> dict[str, Any]:
    request = validate_persisted_release_request(project, release_request_id)
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=False)
    now = at or datetime.now(timezone.utc)
    approvals: list[dict[str, Any]] = []
    distinct: set[str] = set()
    for approval_id in sorted(project.manufacturing_deployment_operator_approvals):
        try:
            row = validate_persisted_operator_approval(project, approval_id, require_current=False)
        except Exception:
            continue
        payload = dict(row.get("payload") or {})
        if payload.get("release_request_id") != release_request_id:
            continue
        if _parse_iso(payload["issued_at"], label="operator issued_at") <= now < _parse_iso(payload["expires_at"], label="operator expires_at"):
            approvals.append(row); distinct.add(str(row.get("signer_id") or ""))
    required = int(policy.get("minimum_operator_approvals") or 2)
    matching_exports = [
        str(export_id) for export_id, row in project.manufacturing_deployment_airgap_exports.items()
        if isinstance(row, Mapping) and str(row.get("release_request_id") or "") == release_request_id
    ]
    withdrawn_exports = {str(v.get("airgap_export_id") or "") for v in project.manufacturing_deployment_withdrawals.values() if isinstance(v, Mapping)}
    withdrawn = bool(matching_exports) and all(export_id in withdrawn_exports for export_id in matching_exports)
    complete = len(distinct) >= required
    return {
        "release_request_id": release_request_id, "required_operator_approvals": required, "valid_approval_count": len(approvals),
        "distinct_operator_count": len(distinct), "operator_release_complete": complete, "approval_ids": [x["operator_approval_id"] for x in approvals],
        "withdrawn": withdrawn, "airgap_export_authorized": complete and not withdrawn,
        "deployment_transport_authorized": False, "direct_machine_transfer": False,
    }


def _acknowledged_deployment_receipts(
    project: ProjectModel,
    binding_id: str,
    *,
    rollout_plan_id: str = "",
    wave_id: str = "",
) -> list[dict[str, Any]]:
    """Return acknowledged receipts for the exact rollout context.

    The rollout filters are intentionally part of the security boundary: an
    acknowledgement from an older/unrelated campaign must never satisfy a new
    wave prerequisite merely because it targets the same physical binding.
    """
    out = []
    for receipt_id in sorted(project.manufacturing_deployment_receipts):
        try: receipt = validate_persisted_deployment_receipt(project, receipt_id, require_current=False)
        except Exception: continue
        payload = dict(receipt.get("payload") or {})
        if str(payload.get("binding_id") or "") != binding_id: continue
        if rollout_plan_id and str(payload.get("rollout_plan_id") or "") != rollout_plan_id: continue
        if wave_id and str(payload.get("wave_id") or "") != wave_id: continue
        acks = []
        for ack_id in sorted(project.manufacturing_deployment_acknowledgements):
            try: ack = validate_persisted_deployment_acknowledgement(project, ack_id, require_current=False)
            except Exception: continue
            if str(dict(ack.get("payload") or {}).get("deployment_receipt_id") or "") == receipt_id: acks.append(ack)
        if acks: out.append(receipt)
    return out


def _previous_waves_complete(project: ProjectModel, plan: Mapping[str, Any], wave: Mapping[str, Any]) -> bool:
    index = int(wave.get("sequence_index") or 0)
    for earlier in plan.get("waves") or []:
        if int(earlier.get("sequence_index") or 0) >= index: continue
        if not bool(wave.get("requires_previous_wave_ack")): continue
        for binding_id in earlier.get("binding_ids") or []:
            if not _acknowledged_deployment_receipts(
                project, str(binding_id), rollout_plan_id=str(plan.get("plan_id") or ""), wave_id=str(earlier.get("wave_id") or "")
            ):
                return False
    return True


def airgap_handoff_signing_payload(
    project: ProjectModel,
    *,
    release_request_id: str,
    deployment_bundle_path: str | Path,
    station_id: str,
    handoff_signer_id: str,
    export_nonce: str,
    expires_at: str,
) -> dict[str, Any]:
    status = release_request_status(project, release_request_id)
    if not status["operator_release_complete"]:
        raise ControlledDeploymentError("CWS-DEPLOY-012", "Vier-ogen operator release is nog niet compleet")
    request = validate_persisted_release_request(project, release_request_id)
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    plan = validate_persisted_rollout_plan(project, request["rollout_plan_id"])
    wave = _wave_for_binding(plan, request["wave_id"], request["binding_id"])
    if not _previous_waves_complete(project, plan, wave):
        raise ControlledDeploymentError("CWS-DEPLOY-012", "Vorige rollout wave mist deployment acknowledgement")
    station = validate_persisted_airgap_station(project, station_id, require_current=True)
    binding = validate_persisted_fleet_machine_binding(project, request["binding_id"], require_current=True)
    if station["site_id"] != binding["site_id"]:
        raise ControlledDeploymentError("CWS-DEPLOY-012", "Air-gap station hoort niet bij deployment site")
    handoff_snapshots = dict(policy.get("handoff_signer_snapshots") or {})
    if handoff_signer_id not in handoff_snapshots:
        raise ControlledDeploymentError("CWS-DEPLOY-012", "Handoff signer niet toegestaan door M17 policy")
    signer = validate_persisted_trusted_signer(project, handoff_signer_id, require_current=True)
    bundle = Path(deployment_bundle_path)
    verify = validate_controlled_deployment_bundle(bundle)
    deployment = validate_persisted_fleet_deployment(project, request["deployment_id"])
    if str(verify.get("package_id") or "") != request["deployment_id"] or sha256_file(bundle) != deployment["bundle_sha256"]:
        raise ControlledDeploymentError("CWS-DEPLOY-012", "M16 deployment bundle wijkt af van release request")
    now = datetime.now(timezone.utc)
    requested_exp = _parse_iso(expires_at, label="airgap handoff expires_at")
    stage_limit = now + timedelta(hours=int(policy.get("maximum_stage_age_hours") or 24))
    wave_end = _parse_iso(wave["window_end"], label="rollout wave_end")
    final_exp = min(requested_exp, stage_limit, wave_end)
    if final_exp <= now:
        raise ControlledDeploymentError("CWS-DEPLOY-012", "Air-gap handoff vervalt reeds")
    payload = {
        "format": M17_HANDOFF_PAYLOAD_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "project_id": project.project_id, "release_request_id": release_request_id, "release_request_hash": request["release_request_hash"],
        "deployment_id": request["deployment_id"], "deployment_record_hash": deployment["deployment_record_hash"], "deployment_bundle_sha256": deployment["bundle_sha256"],
        "station_id": station_id, "station_hash": station["station_hash"], "site_id": station["site_id"],
        "rollout_plan_id": plan["plan_id"], "rollout_plan_hash": plan["plan_hash"], "wave_id": wave["wave_id"], "wave_hash": wave["wave_hash"],
        "deployment_window_start": wave["window_start"], "deployment_window_end": wave["window_end"],
        "handoff_signer_id": handoff_signer_id, "handoff_signer_hash": signer["signer_hash"],
        "handoff_signer_public_key_fingerprint_sha256": signer["public_key_fingerprint_sha256"],
        "export_nonce": str(export_nonce or "").strip(), "issued_at": utc_now_iso(), "expires_at": final_exp.isoformat(),
        "operator_release_complete": True, "independent_station_verification_required": True, "airgap_media_only": True,
        "controller_files_applied": False, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "hash_version": M17_HASH_VERSION,
    }
    if not payload["export_nonce"]:
        raise ControlledDeploymentError("CWS-DEPLOY-012", "Air-gap export nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def _validate_handoff_envelope(project: ProjectModel, envelope: Mapping[str, Any], *, require_current: bool = True) -> tuple[dict[str, Any], dict[str, Any]]:
    raw = dict(envelope or {})
    if raw.get("format") != M17_HANDOFF_ENVELOPE_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519":
        raise ControlledDeploymentError("CWS-DEPLOY-013", "M17 handoff envelope format/schema/algorithm ongeldig")
    payload = dict(raw.get("payload") or {})
    if payload.get("format") != M17_HANDOFF_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ControlledDeploymentError("CWS-DEPLOY-013", "M17 handoff payload/hash ongeldig")
    request = validate_persisted_release_request(project, str(payload.get("release_request_id") or ""))
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=require_current)
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("handoff_signer_id") or "") or signer_id not in dict(policy.get("handoff_signer_snapshots") or {}):
        raise ControlledDeploymentError("CWS-DEPLOY-013", "M17 handoff signer mismatch/not allowed")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=require_current)
    if str(payload.get("handoff_signer_hash") or "") != signer["signer_hash"] or str(payload.get("release_request_hash") or "") != request["release_request_hash"]:
        raise ControlledDeploymentError("CWS-DEPLOY-013", "M17 handoff snapshot is stale")
    if bool(payload.get("controller_files_applied")) or bool(payload.get("deployment_transport_authorized")) or bool(payload.get("direct_machine_transfer")) or not bool(payload.get("operator_release_complete")):
        raise ControlledDeploymentError("CWS-DEPLOY-013", "M17 handoff veiligheidsflags ongeldig")
    if require_current and not (_parse_iso(payload["issued_at"], label="handoff issued_at") <= datetime.now(timezone.utc) < _parse_iso(payload["expires_at"], label="handoff expires_at")):
        raise ControlledDeploymentError("CWS-DEPLOY-013", "M17 handoff is verlopen/nog niet geldig")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    return raw, payload


def build_signed_airgap_export_bundle(
    project: ProjectModel,
    *,
    handoff_envelope: Mapping[str, Any],
    deployment_bundle_path: str | Path,
    output_path: str | Path,
    rollback_bundle_path: str | Path | None = None,
    created_by: str = "system",
    persist: bool = True,
) -> dict[str, Any]:
    envelope, payload = _validate_handoff_envelope(project, handoff_envelope, require_current=True)
    request = validate_persisted_release_request(project, payload["release_request_id"])
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    plan = validate_persisted_rollout_plan(project, request["rollout_plan_id"])
    station = validate_persisted_airgap_station(project, payload["station_id"], require_current=True)
    rollback = validate_persisted_rollback_reference(project, request["rollback_id"])
    deployment = validate_persisted_fleet_deployment(project, request["deployment_id"])
    source = Path(deployment_bundle_path)
    if sha256_file(source) != deployment["bundle_sha256"]:
        raise ControlledDeploymentError("CWS-DEPLOY-014", "M16 deployment bundle SHA wijkt af")
    validate_controlled_deployment_bundle(source)
    if payload["deployment_bundle_sha256"] != deployment["bundle_sha256"]:
        raise ControlledDeploymentError("CWS-DEPLOY-014", "Handoff payload deployment SHA wijkt af")
    rollback_bytes: bytes | None = None
    if not rollback["initial_deployment"]:
        if rollback_bundle_path is None:
            raise ControlledDeploymentError("CWS-DEPLOY-014", "Rollback bundle is verplicht voor niet-initiële deployment")
        rb = Path(rollback_bundle_path)
        validate_controlled_deployment_bundle(rb)
        if sha256_file(rb) != rollback["previous_bundle_sha256"]:
            raise ControlledDeploymentError("CWS-DEPLOY-014", "Rollback bundle SHA wijkt af van immutable rollback reference")
        rollback_bytes = rb.read_bytes()
    status = release_request_status(project, request["release_request_id"])
    if not status["operator_release_complete"]:
        raise ControlledDeploymentError("CWS-DEPLOY-014", "Operator approvals zijn niet meer current/compleet")
    approvals = [validate_persisted_operator_approval(project, x, require_current=True) for x in status["approval_ids"]]
    files: dict[str, bytes] = {
        "payload/deployment_bundle.zip": source.read_bytes(),
        "evidence/release_request.json": canonical_json_bytes(request),
        "evidence/control_policy.json": canonical_json_bytes(policy),
        "evidence/rollout_plan.json": canonical_json_bytes(plan),
        "evidence/rollback_reference.json": canonical_json_bytes(rollback),
        "evidence/airgap_station.json": canonical_json_bytes(station),
        "handoff/envelope.json": canonical_json_bytes(envelope),
    }
    for i, approval in enumerate(sorted(approvals, key=lambda x: str(x["signer_id"]))):
        files[f"evidence/operator_approval_{i+1:02d}.json"] = canonical_json_bytes(approval)
    if rollback_bytes is not None:
        files["rollback/previous_deployment_bundle.zip"] = rollback_bytes
    artifact_rows = [{"relative_path": rel, "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)} for rel, data in sorted(files.items())]
    export_id = "airgap-" + stable_sha256({"payload_hash": payload["payload_hash"], "release_request_hash": request["release_request_hash"], "deployment_bundle_sha256": deployment["bundle_sha256"], "rollback_hash": rollback["rollback_hash"]})[:28]
    manifest = {
        "format": M17_AIRGAP_PACKAGE_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "airgap_export_id": export_id, "project_id": project.project_id, "release_request_id": request["release_request_id"], "release_request_hash": request["release_request_hash"],
        "deployment_id": deployment["deployment_id"], "deployment_bundle_sha256": deployment["bundle_sha256"], "station_id": station["station_id"], "station_hash": station["station_hash"],
        "control_policy_id": policy["policy_id"], "control_policy_hash": policy["policy_hash"], "rollout_plan_id": plan["plan_id"], "rollout_plan_hash": plan["plan_hash"],
        "wave_id": payload["wave_id"], "rollback_id": rollback["rollback_id"], "rollback_hash": rollback["rollback_hash"],
        "handoff_payload_hash": payload["payload_hash"], "handoff_signer_id": payload["handoff_signer_id"], "handoff_signer_public_key_fingerprint_sha256": payload["handoff_signer_public_key_fingerprint_sha256"],
        "not_before": payload["deployment_window_start"], "expires_at": payload["expires_at"],
        "operator_release_complete": True, "independent_station_verification_required": True, "airgap_media_only": True,
        "controller_files_applied": False, "machine_observed_by_cws": False, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "artifacts": artifact_rows, "hash_version": M17_HASH_VERSION,
    }
    manifest["manifest_hash"] = _hash_record(manifest, "manifest_hash")
    files["manifest.json"] = canonical_json_bytes(manifest)
    checksums = "\n".join(f"{hashlib.sha256(data).hexdigest()}  {name}" for name, data in sorted(files.items())) + "\n"
    files["SHA256SUMS.txt"] = checksums.encode("utf-8")
    output = Path(output_path); output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=_ZIP_DATE); info.compress_type = zipfile.ZIP_DEFLATED; info.external_attr = 0o644 << 16
            zf.writestr(info, data)
    handoff_signer = validate_persisted_trusted_signer(project, payload["handoff_signer_id"], require_current=True)
    verify = verify_airgap_export_bundle(output, trusted_handoff_public_key_pem=handoff_signer["public_key_pem"], at=datetime.now(timezone.utc), require_current=True)
    record = {
        "format": M17_AIRGAP_EXPORT_RECORD_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "airgap_export_id": export_id, "bundle_filename": f"{export_id}.zip", "bundle_sha256": sha256_file(output), "bundle_size_bytes": output.stat().st_size,
        "manifest_hash": manifest["manifest_hash"], "release_request_id": request["release_request_id"], "release_request_hash": request["release_request_hash"],
        "deployment_id": deployment["deployment_id"], "station_id": station["station_id"], "control_policy_id": policy["policy_id"], "rollout_plan_id": plan["plan_id"], "wave_id": payload["wave_id"],
        "not_before": manifest["not_before"], "expires_at": manifest["expires_at"], "operator_release_complete": True, "independent_station_verification_required": True,
        "verified": bool(verify.get("valid")), "withdrawn": False, "controller_files_applied": False, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "hash_version": M17_HASH_VERSION,
    }
    record["airgap_export_record_hash"] = _hash_record(record, "airgap_export_record_hash")
    if persist:
        _store_immutable(project.manufacturing_deployment_airgap_exports, export_id, record, "airgap_export_record_hash")
        project.audit("manufacturing.deployment_airgap_export", user=created_by, entity_id=export_id, after_hash=record["airgap_export_record_hash"], details={"station_id": station["station_id"], "direct_machine_transfer": False})
    return {"output": str(output), "manifest": manifest, "record": record, "verify": verify}


def verify_airgap_export_bundle(
    path: str | Path,
    *,
    trusted_handoff_public_key_pem: str,
    at: datetime | None = None,
    require_current: bool = True,
) -> dict[str, Any]:
    p = Path(path)
    if not p.is_file():
        raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 air-gap export bundle ontbreekt")
    now = at or datetime.now(timezone.utc)
    with zipfile.ZipFile(p, "r") as zf:
        names = zf.namelist()
        if len(names) != len(set(names)) or "manifest.json" not in names or "SHA256SUMS.txt" not in names or "handoff/envelope.json" not in names or "payload/deployment_bundle.zip" not in names:
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 air-gap bundle structuur ongeldig")
        for name in names: _safe_rel(name)
        checks: dict[str, str] = {}
        for line in zf.read("SHA256SUMS.txt").decode("utf-8").splitlines():
            if not line.strip(): continue
            try: sha, rel = line.split("  ", 1)
            except ValueError as exc: raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 SHA256SUMS regel ongeldig") from exc
            rel = _safe_rel(rel)
            if not _SHA256_RE.fullmatch(sha): raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 SHA256SUMS bevat ongeldige hash")
            checks[rel] = sha
        expected = set(names) - {"SHA256SUMS.txt"}
        if set(checks) != expected:
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 SHA256SUMS dekt niet exact alle bundlebestanden")
        for rel, sha in checks.items():
            if hashlib.sha256(zf.read(rel)).hexdigest() != sha:
                raise ControlledDeploymentError("CWS-DEPLOY-015", f"M17 bundle SHA mismatch: {rel}")
        manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
        if manifest.get("format") != M17_AIRGAP_PACKAGE_FORMAT or str(manifest.get("schema_version") or "") != M17_CONTRACT_VERSION or str(manifest.get("manifest_hash") or "") != _hash_record(manifest, "manifest_hash"):
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 air-gap manifest format/schema/hash ongeldig")
        if not bool(manifest.get("operator_release_complete")) or not bool(manifest.get("independent_station_verification_required")) or not bool(manifest.get("airgap_media_only")) or bool(manifest.get("controller_files_applied")) or bool(manifest.get("machine_observed_by_cws")) or bool(manifest.get("deployment_transport_authorized")) or bool(manifest.get("direct_machine_transfer")):
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 air-gap manifest veiligheidsflags ongeldig")
        artifact_names = {str(x.get("relative_path") or "") for x in manifest.get("artifacts") or [] if isinstance(x, Mapping)}
        if artifact_names != (expected - {"manifest.json"}):
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 air-gap manifest artifactset mismatch")
        for item in manifest.get("artifacts") or []:
            rel = _safe_rel(item.get("relative_path")); data = zf.read(rel)
            if str(item.get("sha256") or "") != hashlib.sha256(data).hexdigest() or int(item.get("size_bytes") or -1) != len(data):
                raise ControlledDeploymentError("CWS-DEPLOY-015", f"M17 artifact metadata mismatch: {rel}")
        envelope = json.loads(zf.read("handoff/envelope.json").decode("utf-8")); payload = dict(envelope.get("payload") or {})
        if envelope.get("format") != M17_HANDOFF_ENVELOPE_FORMAT or payload.get("format") != M17_HANDOFF_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 handoff envelope/payload ongeldig")
        fp = _public_key_fingerprint(trusted_handoff_public_key_pem)
        if fp != str(payload.get("handoff_signer_public_key_fingerprint_sha256") or "") or str(payload.get("payload_hash") or "") != str(manifest.get("handoff_payload_hash") or ""):
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 handoff trust-root/manifest binding mismatch")
        _verify_signature(trusted_handoff_public_key_pem, payload, str(envelope.get("signature_base64") or ""))
        if require_current and not (_parse_iso(payload["issued_at"], label="handoff issued_at") <= now < _parse_iso(payload["expires_at"], label="handoff expires_at")):
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 air-gap handoff is verlopen/nog niet geldig")
        nested = zf.read("payload/deployment_bundle.zip")
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            tmp.write(nested); tmp_path = Path(tmp.name)
        try:
            nested_verify = validate_controlled_deployment_bundle(tmp_path)
        finally:
            tmp_path.unlink(missing_ok=True)
        if hashlib.sha256(nested).hexdigest() != str(manifest.get("deployment_bundle_sha256") or ""):
            raise ControlledDeploymentError("CWS-DEPLOY-015", "M17 nested M16 deployment SHA mismatch")
        if "rollback/previous_deployment_bundle.zip" in names:
            rb = zf.read("rollback/previous_deployment_bundle.zip")
            with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                tmp.write(rb); rb_path = Path(tmp.name)
            try: validate_controlled_deployment_bundle(rb_path)
            finally: rb_path.unlink(missing_ok=True)
        return {
            "valid": True, "airgap_export_id": manifest.get("airgap_export_id"), "manifest_hash": manifest.get("manifest_hash"),
            "bundle_sha256": sha256_file(p), "release_request_id": manifest.get("release_request_id"), "station_id": manifest.get("station_id"),
            "deployment_id": manifest.get("deployment_id"), "not_before": manifest.get("not_before"), "expires_at": manifest.get("expires_at"),
            "nested_m16_package_valid": bool(nested_verify.get("valid")), "independent_station_verification_passed": True,
            "controller_files_applied": False, "machine_observed_by_cws": False, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        }


def validate_persisted_airgap_export(project: ProjectModel, export_id: str, *, require_current: bool = False, at: datetime | None = None) -> dict[str, Any]:
    raw = project.manufacturing_deployment_airgap_exports.get(export_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_AIRGAP_EXPORT_RECORD_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 air-gap export {export_id} ontbreekt/ongeldig")
    if str(raw.get("airgap_export_id") or "") != export_id or str(raw.get("airgap_export_record_hash") or "") != _hash_record(raw, "airgap_export_record_hash"):
        raise ProjectValidationError("M17 air-gap export identity/hash ongeldig")
    req = validate_persisted_release_request(project, str(raw.get("release_request_id") or ""))
    station = validate_persisted_airgap_station(project, str(raw.get("station_id") or ""), require_current=require_current)
    if str(raw.get("release_request_hash") or "") != req["release_request_hash"]:
        raise ProjectValidationError("M17 air-gap export request snapshot stale")
    if not bool(raw.get("verified")) or not bool(raw.get("operator_release_complete")) or not bool(raw.get("independent_station_verification_required")) or bool(raw.get("controller_files_applied")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 air-gap export veiligheidsflags ongeldig")
    withdrawn = any(str(v.get("airgap_export_id") or "") == export_id for v in project.manufacturing_deployment_withdrawals.values())
    if require_current:
        now = at or datetime.now(timezone.utc)
        if withdrawn or now >= _parse_iso(raw.get("expires_at"), label="airgap expires_at"):
            raise ProjectValidationError("M17 air-gap export is withdrawn/verlopen")
    result = dict(raw); result["withdrawn"] = withdrawn; result["station_hash_current"] = station["station_hash"]
    return result


def create_airgap_import_receipt_payload(
    bundle_path: str | Path,
    *,
    trusted_handoff_public_key_pem: str,
    station_id: str,
    signer_id: str,
    receipt_nonce: str,
    imported_at: str | None = None,
) -> dict[str, Any]:
    verified = verify_airgap_export_bundle(bundle_path, trusted_handoff_public_key_pem=trusted_handoff_public_key_pem, require_current=True)
    imported = _parse_iso(imported_at or utc_now_iso(), label="imported_at")
    payload = {
        "format": M17_IMPORT_RECEIPT_PAYLOAD_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "airgap_export_id": verified["airgap_export_id"], "airgap_bundle_sha256": verified["bundle_sha256"], "airgap_manifest_hash": verified["manifest_hash"],
        "release_request_id": verified["release_request_id"], "deployment_id": verified["deployment_id"], "station_id": str(station_id), "signer_id": str(signer_id),
        "receipt_nonce": str(receipt_nonce or "").strip(), "imported_at": imported.isoformat(),
        "independent_verification_passed": True, "nested_m16_package_valid": True, "controller_files_applied": False,
        "machine_observed_by_cws": False, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "hash_version": M17_HASH_VERSION,
    }
    if not payload["receipt_nonce"]:
        raise ControlledDeploymentError("CWS-DEPLOY-016", "Import receipt nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_airgap_import_receipt(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {}); payload = dict(raw.get("payload") or {})
    if raw.get("format") != M17_IMPORT_RECEIPT_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519" or payload.get("format") != M17_IMPORT_RECEIPT_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ControlledDeploymentError("CWS-DEPLOY-017", "M17 import receipt envelope/payload ongeldig")
    export = validate_persisted_airgap_export(project, str(payload.get("airgap_export_id") or ""), require_current=True)
    station = validate_persisted_airgap_station(project, str(payload.get("station_id") or ""), require_current=True)
    if station["station_id"] != export["station_id"] or str(raw.get("signer_id") or "") != station["station_signer_id"] or str(payload.get("signer_id") or "") != station["station_signer_id"]:
        raise ControlledDeploymentError("CWS-DEPLOY-017", "M17 import receipt station/signer mismatch")
    signer = validate_persisted_trusted_signer(project, station["station_signer_id"], require_current=True)
    if str(payload.get("airgap_bundle_sha256") or "") != export["bundle_sha256"] or str(payload.get("airgap_manifest_hash") or "") != export["manifest_hash"] or str(payload.get("release_request_id") or "") != export["release_request_id"]:
        raise ControlledDeploymentError("CWS-DEPLOY-017", "M17 import receipt air-gap binding mismatch")
    if not bool(payload.get("independent_verification_passed")) or not bool(payload.get("nested_m16_package_valid")) or bool(payload.get("controller_files_applied")) or bool(payload.get("machine_observed_by_cws")) or bool(payload.get("deployment_transport_authorized")) or bool(payload.get("direct_machine_transfer")):
        raise ControlledDeploymentError("CWS-DEPLOY-017", "M17 import receipt veiligheidsflags ongeldig")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    receipt_id = "import-" + stable_sha256({"export": export["airgap_export_record_hash"], "signer": signer["signer_hash"], "signature": raw.get("signature_base64")})[:28]
    existing = project.manufacturing_deployment_import_receipts.get(receipt_id)
    if isinstance(existing, Mapping): return validate_persisted_import_receipt(project, receipt_id, require_current=True)
    record = {
        "format": M17_IMPORT_RECEIPT_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17", "import_receipt_id": receipt_id,
        "signer_id": signer["signer_id"], "signer_hash": signer["signer_hash"], "algorithm": "ed25519", "payload": payload,
        "signature_base64": str(raw.get("signature_base64") or ""), "signature_verified": True, "received_at": utc_now_iso(),
        "controller_files_applied": False, "machine_observed_by_cws": False, "deployment_transport_authorized": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    record["import_receipt_hash"] = _hash_record(record, "import_receipt_hash")
    result = _store_immutable(project.manufacturing_deployment_import_receipts, receipt_id, record, "import_receipt_hash")
    project.audit("manufacturing.deployment_import_receipt", user=user, entity_id=receipt_id, after_hash=result["import_receipt_hash"], details={"station_id": station["station_id"], "direct_machine_transfer": False})
    return result


def validate_persisted_import_receipt(project: ProjectModel, receipt_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_deployment_import_receipts.get(receipt_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_IMPORT_RECEIPT_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 import receipt {receipt_id} ontbreekt/ongeldig")
    if str(raw.get("import_receipt_id") or "") != receipt_id or str(raw.get("import_receipt_hash") or "") != _hash_record(raw, "import_receipt_hash"):
        raise ProjectValidationError("M17 import receipt identity/hash ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M17 import receipt payload_hash ongeldig")
    export = validate_persisted_airgap_export(project, str(payload.get("airgap_export_id") or ""), require_current=require_current)
    station = validate_persisted_airgap_station(project, str(payload.get("station_id") or ""), require_current=require_current)
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), require_current=require_current)
    if signer["signer_hash"] != str(raw.get("signer_hash") or "") or station["station_signer_id"] != signer["signer_id"] or export["bundle_sha256"] != str(payload.get("airgap_bundle_sha256") or ""):
        raise ProjectValidationError("M17 import receipt snapshot stale")
    try: _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    except ControlledDeploymentError as exc: raise ProjectValidationError("M17 import receipt signature ongeldig") from exc
    if not bool(raw.get("signature_verified")) or bool(raw.get("controller_files_applied")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 import receipt veiligheidsflags ongeldig")
    return dict(raw)


def deployment_receipt_payload(
    project: ProjectModel,
    *,
    import_receipt_id: str,
    signer_id: str,
    receipt_nonce: str,
    deployed_at: str,
    rollback_ready: bool,
) -> dict[str, Any]:
    receipt = validate_persisted_import_receipt(project, import_receipt_id, require_current=True)
    import_payload = dict(receipt["payload"])
    export = validate_persisted_airgap_export(project, import_payload["airgap_export_id"], require_current=True)
    request = validate_persisted_release_request(project, export["release_request_id"])
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    station = validate_persisted_airgap_station(project, import_payload["station_id"], require_current=True)
    if signer_id not in dict(policy.get("station_signer_snapshots") or {}) or signer_id != station["station_signer_id"]:
        raise ControlledDeploymentError("CWS-DEPLOY-018", "Deployment receipt signer is niet de toegestane station signer")
    deployed = _parse_iso(deployed_at, label="deployed_at")
    plan = validate_persisted_rollout_plan(project, request["rollout_plan_id"])
    wave = _wave_for_binding(plan, request["wave_id"], request["binding_id"])
    if not (_parse_iso(wave["window_start"], label="wave start") <= deployed <= _parse_iso(wave["window_end"], label="wave end")):
        raise ControlledDeploymentError("CWS-DEPLOY-018", "Operator-reported deployment valt buiten rollout deployment window")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    payload = {
        "format": M17_DEPLOYMENT_RECEIPT_PAYLOAD_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "import_receipt_id": import_receipt_id, "import_receipt_hash": receipt["import_receipt_hash"], "airgap_export_id": export["airgap_export_id"],
        "release_request_id": request["release_request_id"], "binding_id": request["binding_id"], "deployment_id": request["deployment_id"],
        "rollout_plan_id": plan["plan_id"], "wave_id": wave["wave_id"], "station_id": station["station_id"],
        "signer_id": signer_id, "signer_hash": signer["signer_hash"], "receipt_nonce": str(receipt_nonce or "").strip(), "deployed_at": deployed.isoformat(),
        "operator_reported_deployment_completed": True, "rollback_ready": bool(rollback_ready),
        "machine_observed_by_cws": False, "controller_transport_performed_by_cws": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    if not payload["receipt_nonce"]:
        raise ControlledDeploymentError("CWS-DEPLOY-018", "Deployment receipt nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_deployment_receipt(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {}); payload = dict(raw.get("payload") or {})
    if raw.get("format") != M17_DEPLOYMENT_RECEIPT_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519" or payload.get("format") != M17_DEPLOYMENT_RECEIPT_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ControlledDeploymentError("CWS-DEPLOY-019", "M17 deployment receipt envelope/payload ongeldig")
    import_receipt = validate_persisted_import_receipt(project, str(payload.get("import_receipt_id") or ""), require_current=False)
    if str(payload.get("import_receipt_hash") or "") != import_receipt["import_receipt_hash"]:
        raise ControlledDeploymentError("CWS-DEPLOY-019", "Deployment receipt import snapshot stale")
    request = validate_persisted_release_request(project, str(payload.get("release_request_id") or ""))
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("signer_id") or "") or signer_id not in dict(policy.get("station_signer_snapshots") or {}):
        raise ControlledDeploymentError("CWS-DEPLOY-019", "Deployment receipt signer mismatch/not allowed")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    if str(payload.get("signer_hash") or "") != signer["signer_hash"] or bool(payload.get("machine_observed_by_cws")) or bool(payload.get("controller_transport_performed_by_cws")) or bool(payload.get("direct_machine_transfer")) or not bool(payload.get("operator_reported_deployment_completed")):
        raise ControlledDeploymentError("CWS-DEPLOY-019", "Deployment receipt veiligheidscontract ongeldig")
    plan = validate_persisted_rollout_plan(project, request["rollout_plan_id"]); wave = _wave_for_binding(plan, request["wave_id"], request["binding_id"])
    deployed = _parse_iso(payload["deployed_at"], label="deployed_at")
    if not (_parse_iso(wave["window_start"], label="wave start") <= deployed <= _parse_iso(wave["window_end"], label="wave end")):
        raise ControlledDeploymentError("CWS-DEPLOY-019", "Deployment receipt valt buiten rollout window")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    receipt_id = "depreceipt-" + stable_sha256({"import": import_receipt["import_receipt_hash"], "signer": signer["signer_hash"], "signature": raw.get("signature_base64")})[:28]
    existing = project.manufacturing_deployment_receipts.get(receipt_id)
    if isinstance(existing, Mapping): return validate_persisted_deployment_receipt(project, receipt_id, require_current=True)
    record = {
        "format": M17_DEPLOYMENT_RECEIPT_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17", "deployment_receipt_id": receipt_id,
        "signer_id": signer_id, "signer_hash": signer["signer_hash"], "algorithm": "ed25519", "payload": payload,
        "signature_base64": str(raw.get("signature_base64") or ""), "signature_verified": True, "received_at": utc_now_iso(),
        "machine_observed_by_cws": False, "controller_transport_performed_by_cws": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    record["deployment_receipt_hash"] = _hash_record(record, "deployment_receipt_hash")
    result = _store_immutable(project.manufacturing_deployment_receipts, receipt_id, record, "deployment_receipt_hash")
    project.audit("manufacturing.deployment_receipt", user=user, entity_id=receipt_id, after_hash=result["deployment_receipt_hash"], details={"binding_id": request["binding_id"], "machine_observed_by_cws": False})
    return result


def validate_persisted_deployment_receipt(project: ProjectModel, receipt_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_deployment_receipts.get(receipt_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_DEPLOYMENT_RECEIPT_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 deployment receipt {receipt_id} ontbreekt/ongeldig")
    if str(raw.get("deployment_receipt_id") or "") != receipt_id or str(raw.get("deployment_receipt_hash") or "") != _hash_record(raw, "deployment_receipt_hash"):
        raise ProjectValidationError("M17 deployment receipt identity/hash ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M17 deployment receipt payload_hash ongeldig")
    imp = validate_persisted_import_receipt(project, str(payload.get("import_receipt_id") or ""), require_current=False)
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), require_current=require_current)
    if str(payload.get("import_receipt_hash") or "") != imp["import_receipt_hash"] or str(raw.get("signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M17 deployment receipt snapshot stale")
    try: _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    except ControlledDeploymentError as exc: raise ProjectValidationError("M17 deployment receipt signature ongeldig") from exc
    if not bool(raw.get("signature_verified")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("controller_transport_performed_by_cws")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 deployment receipt veiligheidsflags ongeldig")
    return dict(raw)


def deployment_acknowledgement_payload(
    project: ProjectModel,
    *,
    deployment_receipt_id: str,
    signer_id: str,
    acknowledgement_nonce: str,
    acknowledgement_type: str = "deployment_received_and_accepted",
) -> dict[str, Any]:
    receipt = validate_persisted_deployment_receipt(project, deployment_receipt_id, require_current=True)
    rpayload = dict(receipt["payload"])
    request = validate_persisted_release_request(project, rpayload["release_request_id"])
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    if signer_id not in dict(policy.get("acknowledgement_signer_snapshots") or {}):
        raise ControlledDeploymentError("CWS-DEPLOY-020", "Acknowledgement signer niet toegestaan")
    if bool(policy.get("require_distinct_deploy_and_ack_signers")) and signer_id == receipt["signer_id"]:
        raise ControlledDeploymentError("CWS-DEPLOY-020", "Acknowledgement signer moet verschillen van deployment receipt signer")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    payload = {
        "format": M17_ACK_PAYLOAD_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "deployment_receipt_id": deployment_receipt_id, "deployment_receipt_hash": receipt["deployment_receipt_hash"],
        "release_request_id": request["release_request_id"], "binding_id": request["binding_id"], "rollout_plan_id": request["rollout_plan_id"], "wave_id": request["wave_id"],
        "signer_id": signer_id, "signer_hash": signer["signer_hash"], "acknowledgement_type": str(acknowledgement_type),
        "acknowledgement_nonce": str(acknowledgement_nonce or "").strip(), "acknowledged_at": utc_now_iso(),
        "immutable_acknowledgement": True, "machine_observed_by_cws": False, "deployment_transport_authorized": False, "direct_machine_transfer": False,
        "hash_version": M17_HASH_VERSION,
    }
    if not payload["acknowledgement_nonce"]:
        raise ControlledDeploymentError("CWS-DEPLOY-020", "Acknowledgement nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_deployment_acknowledgement(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {}); payload = dict(raw.get("payload") or {})
    if raw.get("format") != M17_ACK_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519" or payload.get("format") != M17_ACK_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ControlledDeploymentError("CWS-DEPLOY-021", "M17 acknowledgement envelope/payload ongeldig")
    receipt = validate_persisted_deployment_receipt(project, str(payload.get("deployment_receipt_id") or ""), require_current=True)
    rpayload = dict(receipt["payload"]); request = validate_persisted_release_request(project, rpayload["release_request_id"])
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("signer_id") or "") or signer_id not in dict(policy.get("acknowledgement_signer_snapshots") or {}):
        raise ControlledDeploymentError("CWS-DEPLOY-021", "Acknowledgement signer mismatch/not allowed")
    if bool(policy.get("require_distinct_deploy_and_ack_signers")) and signer_id == receipt["signer_id"]:
        raise ControlledDeploymentError("CWS-DEPLOY-021", "Acknowledgement signer moet verschillen van deployer")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    if str(payload.get("signer_hash") or "") != signer["signer_hash"] or str(payload.get("deployment_receipt_hash") or "") != receipt["deployment_receipt_hash"]:
        raise ControlledDeploymentError("CWS-DEPLOY-021", "Acknowledgement snapshot stale")
    if not bool(payload.get("immutable_acknowledgement")) or bool(payload.get("machine_observed_by_cws")) or bool(payload.get("deployment_transport_authorized")) or bool(payload.get("direct_machine_transfer")):
        raise ControlledDeploymentError("CWS-DEPLOY-021", "Acknowledgement veiligheidsflags ongeldig")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    ack_id = "ack-" + stable_sha256({"receipt": receipt["deployment_receipt_hash"], "signer": signer["signer_hash"], "signature": raw.get("signature_base64")})[:28]
    existing = project.manufacturing_deployment_acknowledgements.get(ack_id)
    if isinstance(existing, Mapping): return validate_persisted_deployment_acknowledgement(project, ack_id, require_current=True)
    record = {
        "format": M17_ACK_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17", "acknowledgement_id": ack_id,
        "signer_id": signer_id, "signer_hash": signer["signer_hash"], "algorithm": "ed25519", "payload": payload,
        "signature_base64": str(raw.get("signature_base64") or ""), "signature_verified": True, "received_at": utc_now_iso(),
        "machine_observed_by_cws": False, "deployment_transport_authorized": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    record["acknowledgement_hash"] = _hash_record(record, "acknowledgement_hash")
    result = _store_immutable(project.manufacturing_deployment_acknowledgements, ack_id, record, "acknowledgement_hash")
    project.audit("manufacturing.deployment_acknowledgement", user=user, entity_id=ack_id, after_hash=result["acknowledgement_hash"], details={"binding_id": request["binding_id"], "direct_machine_transfer": False})
    return result


def validate_persisted_deployment_acknowledgement(project: ProjectModel, ack_id: str, *, require_current: bool = False) -> dict[str, Any]:
    raw = project.manufacturing_deployment_acknowledgements.get(ack_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_ACK_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 acknowledgement {ack_id} ontbreekt/ongeldig")
    if str(raw.get("acknowledgement_id") or "") != ack_id or str(raw.get("acknowledgement_hash") or "") != _hash_record(raw, "acknowledgement_hash"):
        raise ProjectValidationError("M17 acknowledgement identity/hash ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M17 acknowledgement payload_hash ongeldig")
    receipt = validate_persisted_deployment_receipt(project, str(payload.get("deployment_receipt_id") or ""), require_current=require_current)
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), require_current=require_current)
    if str(payload.get("deployment_receipt_hash") or "") != receipt["deployment_receipt_hash"] or str(raw.get("signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M17 acknowledgement snapshot stale")
    try: _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    except ControlledDeploymentError as exc: raise ProjectValidationError("M17 acknowledgement signature ongeldig") from exc
    if not bool(raw.get("signature_verified")) or bool(raw.get("machine_observed_by_cws")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 acknowledgement veiligheidsflags ongeldig")
    return dict(raw)


def stage_withdrawal_payload(project: ProjectModel, *, airgap_export_id: str, signer_id: str, reason: str, nonce: str) -> dict[str, Any]:
    export = validate_persisted_airgap_export(project, airgap_export_id, require_current=False)
    request = validate_persisted_release_request(project, export["release_request_id"])
    policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    if signer_id not in dict(policy.get("operator_signer_snapshots") or {}):
        raise ControlledDeploymentError("CWS-DEPLOY-022", "Withdrawal signer is geen toegestane operator")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    payload = {
        "format": M17_WITHDRAWAL_PAYLOAD_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17",
        "airgap_export_id": airgap_export_id, "airgap_export_record_hash": export["airgap_export_record_hash"], "release_request_id": request["release_request_id"],
        "signer_id": signer_id, "signer_hash": signer["signer_hash"], "reason": str(reason or "").strip(), "withdrawal_nonce": str(nonce or "").strip(), "withdrawn_at": utc_now_iso(),
        "stage_use_prohibited": True, "requires_physical_withdrawal_notice_delivery": True, "deployment_transport_authorized": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    if not payload["reason"] or not payload["withdrawal_nonce"]:
        raise ControlledDeploymentError("CWS-DEPLOY-022", "Withdrawal reason/nonce ontbreekt")
    payload["payload_hash"] = _hash_record(payload, "payload_hash")
    return payload


def ingest_signed_stage_withdrawal(project: ProjectModel, envelope: Mapping[str, Any], *, user: str = "system") -> dict[str, Any]:
    raw = dict(envelope or {}); payload = dict(raw.get("payload") or {})
    if raw.get("format") != M17_WITHDRAWAL_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION or str(raw.get("algorithm") or "").lower() != "ed25519" or payload.get("format") != M17_WITHDRAWAL_PAYLOAD_FORMAT or str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ControlledDeploymentError("CWS-DEPLOY-023", "M17 withdrawal envelope/payload ongeldig")
    export = validate_persisted_airgap_export(project, str(payload.get("airgap_export_id") or ""), require_current=False)
    request = validate_persisted_release_request(project, export["release_request_id"]); policy = validate_persisted_deployment_control_policy(project, request["control_policy_id"], require_current=True)
    signer_id = str(raw.get("signer_id") or "")
    if signer_id != str(payload.get("signer_id") or "") or signer_id not in dict(policy.get("operator_signer_snapshots") or {}):
        raise ControlledDeploymentError("CWS-DEPLOY-023", "Withdrawal signer mismatch/not allowed")
    signer = validate_persisted_trusted_signer(project, signer_id, require_current=True)
    if str(payload.get("signer_hash") or "") != signer["signer_hash"] or str(payload.get("airgap_export_record_hash") or "") != export["airgap_export_record_hash"]:
        raise ControlledDeploymentError("CWS-DEPLOY-023", "Withdrawal snapshot stale")
    if not bool(payload.get("stage_use_prohibited")) or not bool(payload.get("requires_physical_withdrawal_notice_delivery")) or bool(payload.get("deployment_transport_authorized")) or bool(payload.get("direct_machine_transfer")):
        raise ControlledDeploymentError("CWS-DEPLOY-023", "Withdrawal veiligheidsflags ongeldig")
    _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    withdrawal_id = "withdraw-" + stable_sha256({"export": export["airgap_export_record_hash"], "signer": signer["signer_hash"], "signature": raw.get("signature_base64")})[:28]
    existing = project.manufacturing_deployment_withdrawals.get(withdrawal_id)
    if isinstance(existing, Mapping): return validate_persisted_stage_withdrawal(project, withdrawal_id)
    record = {
        "format": M17_WITHDRAWAL_FORMAT, "schema_version": M17_CONTRACT_VERSION, "phase": "M17", "withdrawal_id": withdrawal_id,
        "airgap_export_id": export["airgap_export_id"], "signer_id": signer_id, "signer_hash": signer["signer_hash"], "algorithm": "ed25519", "payload": payload,
        "signature_base64": str(raw.get("signature_base64") or ""), "signature_verified": True, "received_at": utc_now_iso(),
        "stage_use_prohibited": True, "deployment_transport_authorized": False, "direct_machine_transfer": False, "hash_version": M17_HASH_VERSION,
    }
    record["withdrawal_hash"] = _hash_record(record, "withdrawal_hash")
    result = _store_immutable(project.manufacturing_deployment_withdrawals, withdrawal_id, record, "withdrawal_hash")
    project.audit("manufacturing.deployment_stage_withdrawal", user=user, entity_id=withdrawal_id, after_hash=result["withdrawal_hash"], details={"airgap_export_id": export["airgap_export_id"], "direct_machine_transfer": False})
    return result


def validate_persisted_stage_withdrawal(project: ProjectModel, withdrawal_id: str) -> dict[str, Any]:
    raw = project.manufacturing_deployment_withdrawals.get(withdrawal_id)
    if not isinstance(raw, Mapping) or raw.get("format") != M17_WITHDRAWAL_FORMAT or str(raw.get("schema_version") or "") != M17_CONTRACT_VERSION:
        raise ProjectValidationError(f"M17 withdrawal {withdrawal_id} ontbreekt/ongeldig")
    if str(raw.get("withdrawal_id") or "") != withdrawal_id or str(raw.get("withdrawal_hash") or "") != _hash_record(raw, "withdrawal_hash"):
        raise ProjectValidationError("M17 withdrawal identity/hash ongeldig")
    payload = dict(raw.get("payload") or {})
    if str(payload.get("payload_hash") or "") != _hash_record(payload, "payload_hash"):
        raise ProjectValidationError("M17 withdrawal payload_hash ongeldig")
    export = validate_persisted_airgap_export(project, str(raw.get("airgap_export_id") or ""), require_current=False)
    signer = validate_persisted_trusted_signer(project, str(raw.get("signer_id") or ""), require_current=False)
    if str(payload.get("airgap_export_record_hash") or "") != export["airgap_export_record_hash"] or str(raw.get("signer_hash") or "") != signer["signer_hash"]:
        raise ProjectValidationError("M17 withdrawal snapshot stale")
    try: _verify_signature(signer["public_key_pem"], payload, str(raw.get("signature_base64") or ""))
    except ControlledDeploymentError as exc: raise ProjectValidationError("M17 withdrawal signature ongeldig") from exc
    if not bool(raw.get("signature_verified")) or not bool(raw.get("stage_use_prohibited")) or bool(raw.get("deployment_transport_authorized")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M17 withdrawal veiligheidsflags ongeldig")
    return dict(raw)


def build_controlled_deployment_dashboard(project: ProjectModel) -> dict[str, Any]:
    stations = [validate_persisted_airgap_station(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_stations)]
    policies = [validate_persisted_deployment_control_policy(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_control_policies)]
    plans = [validate_persisted_rollout_plan(project, k) for k in sorted(project.manufacturing_deployment_rollout_plans)]
    requests = [validate_persisted_release_request(project, k) for k in sorted(project.manufacturing_deployment_release_requests)]
    approvals = [validate_persisted_operator_approval(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_operator_approvals)]
    exports = [validate_persisted_airgap_export(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_airgap_exports)]
    imports = [validate_persisted_import_receipt(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_import_receipts)]
    receipts = [validate_persisted_deployment_receipt(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_receipts)]
    acks = [validate_persisted_deployment_acknowledgement(project, k, require_current=False) for k in sorted(project.manufacturing_deployment_acknowledgements)]
    withdrawals = [validate_persisted_stage_withdrawal(project, k) for k in sorted(project.manufacturing_deployment_withdrawals)]
    rollbacks = [validate_persisted_rollback_reference(project, k) for k in sorted(project.manufacturing_deployment_rollback_references)]
    release_statuses = [release_request_status(project, r["release_request_id"]) for r in requests]
    completed_bindings = sorted({str(dict(r.get("payload") or {}).get("binding_id") or "") for r in receipts if _acknowledged_deployment_receipts(project, str(dict(r.get("payload") or {}).get("binding_id") or ""))})
    return {
        "format": M17_DASHBOARD_FORMAT, "phase": "M17",
        "station_count": len(stations), "policy_count": len(policies), "rollout_plan_count": len(plans), "rollback_reference_count": len(rollbacks),
        "release_request_count": len(requests), "operator_approval_count": len(approvals), "airgap_export_count": len(exports),
        "import_receipt_count": len(imports), "deployment_receipt_count": len(receipts), "acknowledgement_count": len(acks), "withdrawal_count": len(withdrawals),
        "operator_release_complete_count": sum(1 for s in release_statuses if s["operator_release_complete"]),
        "completed_binding_count": len([x for x in completed_bindings if x]),
        "stations": stations, "policies": policies, "rollout_plans": plans, "rollback_references": rollbacks,
        "release_requests": requests, "release_statuses": release_statuses, "operator_approvals": approvals, "airgap_exports": exports,
        "import_receipts": imports, "deployment_receipts": receipts, "acknowledgements": acks, "withdrawals": withdrawals,
        "airgap_change_control_only": True, "machine_observed_by_cws": False, "deployment_transport_authorized": False, "direct_machine_transfer": False,
    }


__all__ = [name for name in globals() if not name.startswith("_")]
