"""M14 controller-adapter SDK contracts and runtime self-test.

The SDK is deliberately *not* a dynamic/untrusted plugin loader. Adapters are
trusted, explicitly registered Python objects (the M12 boundary) and M14 adds a
versioned manifest + deterministic interface self-test around that boundary.
No function in this module enables direct machine transfer.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
from typing import Any, Iterable, Mapping

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256
from cws_convertor.production_export.utils import sha256_file
from .adapter_rehearsal import ManufacturingAdapterDescriptor, ManufacturingAdapterRegistry, validate_neutral_sequence_job

M14_ADAPTER_SDK_API_VERSION = "1.0"
M14_ADAPTER_SDK_MANIFEST_FORMAT = "CWS_M14_ADAPTER_SDK_MANIFEST_V1"
M14_ADAPTER_SDK_MANIFEST_SCHEMA_VERSION = "1.0"
M14_ADAPTER_SDK_SELFTEST_FORMAT = "CWS_M14_ADAPTER_SDK_SELFTEST_V1"
M14_ADAPTER_SDK_HASH_VERSION = "cws-m14-adapter-sdk-v1"
M14_SDK_FEATURES = frozenset({"render", "diagnostics"})
_FULL_SHA_RE = re.compile(r"[0-9a-f]{40}")
_SHA256_RE = re.compile(r"[0-9a-f]{64}")
_ENTRYPOINT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_.]*:[A-Za-z_][A-Za-z0-9_]*")


class AdapterSDKError(RuntimeError):
    def __init__(self, code: str, message: str, *, details: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def _json_native(value: Any) -> Any:
    try:
        return json.loads(json.dumps(value, sort_keys=True, ensure_ascii=False))
    except Exception as exc:
        raise AdapterSDKError("CWS-SDK-006", "Adapterdiagnostics moeten JSON-serialiseerbaar zijn") from exc


def _safe_relative_path(value: Any) -> str:
    raw = str(value or "").replace("\\", "/").strip()
    path = PurePosixPath(raw)
    if not raw or path.is_absolute() or ".." in path.parts or any(part in {"", "."} for part in path.parts):
        raise AdapterSDKError("CWS-SDK-005", f"Onveilig adapter-outputpad: {raw!r}")
    return path.as_posix()


def _validated_render(files: Mapping[str, bytes], descriptor: ManufacturingAdapterDescriptor) -> list[tuple[str, bytes]]:
    if not isinstance(files, Mapping) or not files:
        raise AdapterSDKError("CWS-SDK-005", "Adapter self-test leverde geen uitvoer")
    accepted = set(descriptor.output_extensions)
    result: list[tuple[str, bytes]] = []
    seen: set[str] = set()
    total = 0
    for raw_name, raw_data in sorted(files.items()):
        rel = _safe_relative_path(raw_name)
        if rel in seen:
            raise AdapterSDKError("CWS-SDK-005", f"Dubbel adapter-outputpad: {rel}")
        seen.add(rel)
        data = bytes(raw_data)
        total += len(data)
        if len(data) > 64 * 1024 * 1024 or total > 256 * 1024 * 1024:
            raise AdapterSDKError("CWS-SDK-005", "Adapter self-test output overschrijdt size-limiet")
        if PurePosixPath(rel).suffix.lower() not in accepted:
            raise AdapterSDKError("CWS-SDK-005", f"Outputextensie valt buiten descriptor: {rel}")
        result.append((rel, data))
    return result


@dataclass(frozen=True)
class AdapterSDKManifest:
    adapter_id: str
    adapter_descriptor_hash: str
    machine_id: str
    controller_id: str
    adapter_version: str
    adapter_source_commit: str
    adapter_artifact_name: str
    adapter_artifact_sha256: str
    entrypoint: str
    features: tuple[str, ...] = ("render",)
    diagnostic_extensions: tuple[str, ...] = ()
    sdk_api_version: str = M14_ADAPTER_SDK_API_VERSION
    schema_version: str = M14_ADAPTER_SDK_MANIFEST_SCHEMA_VERSION
    hash_version: str = M14_ADAPTER_SDK_HASH_VERSION
    manifest_hash: str = ""

    def __post_init__(self) -> None:
        if self.sdk_api_version != M14_ADAPTER_SDK_API_VERSION or self.schema_version != M14_ADAPTER_SDK_MANIFEST_SCHEMA_VERSION:
            raise ProjectValidationError("Onbekend toekomstig M14 adapter-SDK contract")
        if not all((self.adapter_id, self.adapter_descriptor_hash, self.machine_id, self.controller_id, self.adapter_version)):
            raise ProjectValidationError("M14 SDK-manifest mist adapteridentiteit")
        if not _SHA256_RE.fullmatch(str(self.adapter_descriptor_hash or "")):
            raise ProjectValidationError("M14 SDK adapter_descriptor_hash ongeldig")
        if not _FULL_SHA_RE.fullmatch(str(self.adapter_source_commit or "").lower()):
            raise ProjectValidationError("M14 SDK adapter_source_commit moet volledige Git SHA zijn")
        if not _SHA256_RE.fullmatch(str(self.adapter_artifact_sha256 or "").lower()):
            raise ProjectValidationError("M14 SDK adapter_artifact_sha256 ongeldig")
        if not self.adapter_artifact_name or "/" in self.adapter_artifact_name or "\\" in self.adapter_artifact_name:
            raise ProjectValidationError("M14 SDK adapter_artifact_name moet eenvoudige bestandsnaam zijn")
        if not _ENTRYPOINT_RE.fullmatch(str(self.entrypoint or "")):
            raise ProjectValidationError("M14 SDK entrypoint moet 'module.path:ClassName' zijn")
        features = tuple(sorted(set(str(x).strip().lower() for x in self.features if str(x).strip())))
        if not features or "render" not in features or not set(features).issubset(M14_SDK_FEATURES):
            raise ProjectValidationError("M14 SDK features ongeldig of render ontbreekt")
        diagnostics = tuple(sorted(set(str(x).strip().lower() for x in self.diagnostic_extensions if str(x).strip())))
        for ext in diagnostics:
            if not re.fullmatch(r"\.[a-z0-9][a-z0-9._-]{0,15}", ext):
                raise ProjectValidationError(f"M14 SDK diagnostic extension ongeldig: {ext}")
        if diagnostics and "diagnostics" not in features:
            raise ProjectValidationError("M14 diagnostic_extensions vereisen feature diagnostics")
        object.__setattr__(self, "features", features)
        object.__setattr__(self, "diagnostic_extensions", diagnostics)
        object.__setattr__(self, "adapter_source_commit", self.adapter_source_commit.lower())
        object.__setattr__(self, "adapter_artifact_sha256", self.adapter_artifact_sha256.lower())
        expected = stable_sha256(self.hash_payload())
        if self.manifest_hash and self.manifest_hash != expected:
            raise ProjectValidationError("M14 SDK manifest_hash ongeldig")
        object.__setattr__(self, "manifest_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "format": M14_ADAPTER_SDK_MANIFEST_FORMAT,
            "schema_version": self.schema_version,
            "sdk_api_version": self.sdk_api_version,
            "adapter_id": self.adapter_id,
            "adapter_descriptor_hash": self.adapter_descriptor_hash,
            "machine_id": self.machine_id,
            "controller_id": self.controller_id,
            "adapter_version": self.adapter_version,
            "adapter_source_commit": self.adapter_source_commit,
            "adapter_artifact_name": self.adapter_artifact_name,
            "adapter_artifact_sha256": self.adapter_artifact_sha256,
            "entrypoint": self.entrypoint,
            "features": list(self.features),
            "diagnostic_extensions": list(self.diagnostic_extensions),
            "hash_version": self.hash_version,
            "direct_machine_transfer": False,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "manifest_hash": self.manifest_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "AdapterSDKManifest":
        raw = dict(value or {})
        if raw.get("format") != M14_ADAPTER_SDK_MANIFEST_FORMAT:
            raise ProjectValidationError("M14 SDK manifest format ongeldig")
        return cls(
            adapter_id=str(raw.get("adapter_id") or ""),
            adapter_descriptor_hash=str(raw.get("adapter_descriptor_hash") or ""),
            machine_id=str(raw.get("machine_id") or ""),
            controller_id=str(raw.get("controller_id") or ""),
            adapter_version=str(raw.get("adapter_version") or ""),
            adapter_source_commit=str(raw.get("adapter_source_commit") or ""),
            adapter_artifact_name=str(raw.get("adapter_artifact_name") or ""),
            adapter_artifact_sha256=str(raw.get("adapter_artifact_sha256") or ""),
            entrypoint=str(raw.get("entrypoint") or ""),
            features=tuple(raw.get("features") or ()),
            diagnostic_extensions=tuple(raw.get("diagnostic_extensions") or ()),
            sdk_api_version=str(raw.get("sdk_api_version") or ""),
            schema_version=str(raw.get("schema_version") or ""),
            hash_version=str(raw.get("hash_version") or ""),
            manifest_hash=str(raw.get("manifest_hash") or ""),
        )


def create_adapter_sdk_manifest(
    descriptor: ManufacturingAdapterDescriptor,
    *,
    source_commit: str,
    artifact_path: str | Path,
    entrypoint: str,
    features: Iterable[str] = ("render",),
    diagnostic_extensions: Iterable[str] = (),
) -> AdapterSDKManifest:
    artifact = Path(artifact_path).expanduser().resolve()
    if not artifact.is_file():
        raise AdapterSDKError("CWS-SDK-001", f"Adapterartefact ontbreekt: {artifact}")
    return AdapterSDKManifest(
        adapter_id=descriptor.adapter_id,
        adapter_descriptor_hash=descriptor.descriptor_hash,
        machine_id=descriptor.machine_id,
        controller_id=descriptor.controller_id,
        adapter_version=descriptor.adapter_version,
        adapter_source_commit=str(source_commit).lower(),
        adapter_artifact_name=artifact.name,
        adapter_artifact_sha256=sha256_file(artifact),
        entrypoint=entrypoint,
        features=tuple(features),
        diagnostic_extensions=tuple(diagnostic_extensions),
    )


def validate_adapter_sdk_manifest(
    manifest: Mapping[str, Any] | AdapterSDKManifest,
    *,
    descriptor: ManufacturingAdapterDescriptor | None = None,
    runtime_binding: Mapping[str, str] | None = None,
) -> AdapterSDKManifest:
    obj = manifest if isinstance(manifest, AdapterSDKManifest) else AdapterSDKManifest.from_dict(manifest)
    if descriptor is not None:
        checks = {
            "adapter_id": descriptor.adapter_id,
            "adapter_descriptor_hash": descriptor.descriptor_hash,
            "machine_id": descriptor.machine_id,
            "controller_id": descriptor.controller_id,
            "adapter_version": descriptor.adapter_version,
        }
        for key, expected in checks.items():
            if str(getattr(obj, key)) != str(expected):
                raise AdapterSDKError("CWS-SDK-002", f"SDK-manifest descriptor binding mismatch op {key}")
        if not set(obj.diagnostic_extensions).issubset(set(descriptor.output_extensions)):
            raise AdapterSDKError("CWS-SDK-002", "SDK diagnostic extensions vallen buiten descriptor output_extensions")
    if runtime_binding is not None:
        for key, expected in (
            ("adapter_id", obj.adapter_id),
            ("descriptor_hash", obj.adapter_descriptor_hash),
            ("source_commit", obj.adapter_source_commit),
            ("artifact_sha256", obj.adapter_artifact_sha256),
        ):
            if str(runtime_binding.get(key) or "") != str(expected):
                raise AdapterSDKError("CWS-SDK-003", f"SDK runtime binding mismatch op {key}")
    return obj


def persist_adapter_sdk_manifest(project: ProjectModel, manifest: Mapping[str, Any] | AdapterSDKManifest, *, user: str = "system") -> dict[str, Any]:
    obj = validate_adapter_sdk_manifest(manifest)
    record = obj.to_dict()
    manifest_id = "sdk-" + stable_sha256({"adapter_id": obj.adapter_id, "manifest_hash": obj.manifest_hash})[:28]
    record.update({"manifest_id": manifest_id, "phase": "M14", "status": "registered", "machine_output_released": False})
    record["state_hash"] = stable_sha256({k: v for k, v in record.items() if k != "state_hash"})
    existing = project.manufacturing_adapter_sdk_manifests.get(manifest_id)
    if isinstance(existing, dict) and existing.get("state_hash") != record["state_hash"]:
        raise ProjectValidationError(f"M14 SDK manifest-ID collision voor {manifest_id}")
    project.manufacturing_adapter_sdk_manifests[manifest_id] = record
    project.audit("manufacturing.adapter_sdk_registered", user=user, entity_id=manifest_id, after_hash=record["state_hash"], details={"adapter_id": obj.adapter_id, "direct_machine_transfer": False})
    return record


def validate_persisted_adapter_sdk_manifest(project: ProjectModel, manifest_id: str) -> dict[str, Any]:
    raw = project.manufacturing_adapter_sdk_manifests.get(manifest_id)
    if not isinstance(raw, dict):
        raise ProjectValidationError(f"Onbekend M14 SDK manifest {manifest_id}")
    if str(raw.get("manifest_id") or "") != manifest_id or str(raw.get("phase") or "") != "M14":
        raise ProjectValidationError("M14 SDK persisted identity ongeldig")
    obj = validate_adapter_sdk_manifest(raw)
    if str(raw.get("state_hash") or "") != stable_sha256({k: v for k, v in raw.items() if k != "state_hash"}):
        raise ProjectValidationError("M14 SDK state_hash ongeldig")
    if bool(raw.get("machine_output_released")) or bool(raw.get("direct_machine_transfer")):
        raise ProjectValidationError("M14 SDK manifest mag output/transfer niet vrijgeven")
    if raw.get("manifest_hash") != obj.manifest_hash:
        raise ProjectValidationError("M14 SDK manifest hash binding mismatch")
    return raw


def run_adapter_sdk_self_test(
    registry: ManufacturingAdapterRegistry,
    adapter_id: str,
    neutral_jobs: Iterable[Mapping[str, Any] | str | Path],
    *,
    manifest: Mapping[str, Any] | AdapterSDKManifest | None = None,
) -> dict[str, Any]:
    adapter = registry.get(adapter_id)
    binding = registry.certification_binding(adapter_id, verify_physical=True)
    if manifest is not None:
        validate_adapter_sdk_manifest(manifest, descriptor=adapter.descriptor, runtime_binding=binding)
    rows: list[dict[str, Any]] = []
    jobs = list(neutral_jobs)
    if not jobs:
        raise AdapterSDKError("CWS-SDK-004", "M14 SDK self-test vereist minimaal één neutral job")
    for index, value in enumerate(jobs):
        job = validate_neutral_sequence_job(value)
        op_types = sorted({str(x.get("operation_type") or "") for x in job.get("operations") or [] if isinstance(x, Mapping)})
        if not set(op_types).issubset(set(adapter.descriptor.supported_operation_types)):
            raise AdapterSDKError("CWS-SDK-004", f"Self-test job {index} bevat unsupported operations")
        first = _validated_render(adapter.render(dict(job)), adapter.descriptor)
        second = _validated_render(adapter.render(dict(job)), adapter.descriptor)
        first_index = [(n, hashlib.sha256(b).hexdigest(), len(b)) for n, b in first]
        second_index = [(n, hashlib.sha256(b).hexdigest(), len(b)) for n, b in second]
        if first_index != second_index:
            raise AdapterSDKError("CWS-SDK-005", f"Adapter self-test job {index} is niet byte-deterministisch")
        diagnostic_hashes: dict[str, str] = {}
        if manifest is not None:
            mobj = validate_adapter_sdk_manifest(manifest, descriptor=adapter.descriptor, runtime_binding=binding)
            if "diagnostics" in mobj.features:
                diagnose = getattr(adapter, "diagnose_output", None)
                if not callable(diagnose):
                    raise AdapterSDKError("CWS-SDK-006", "SDK-manifest declareert diagnostics maar adapter implementeert diagnose_output niet")
                for rel, data in first:
                    if PurePosixPath(rel).suffix.lower() not in set(mobj.diagnostic_extensions):
                        continue
                    d1 = _json_native(diagnose(rel, data))
                    d2 = _json_native(diagnose(rel, data))
                    if stable_sha256(d1) != stable_sha256(d2):
                        raise AdapterSDKError("CWS-SDK-006", f"Adapterdiagnostics zijn niet deterministisch voor {rel}")
                    diagnostic_hashes[rel] = stable_sha256(d1)
        rows.append({
            "job_index": index,
            "sequence_id": job.get("sequence_id", ""),
            "sequence_hash": job.get("sequence_hash", ""),
            "operation_types": op_types,
            "artifacts": [{"relative_path": n, "sha256": h, "size_bytes": s} for n, h, s in first_index],
            "diagnostic_hashes": diagnostic_hashes,
        })
    report = {
        "format": M14_ADAPTER_SDK_SELFTEST_FORMAT,
        "schema_version": M14_ADAPTER_SDK_MANIFEST_SCHEMA_VERSION,
        "adapter": adapter.descriptor.to_dict(),
        "runtime_binding": {k: v for k, v in dict(binding or {}).items() if k != "artifact_path"},
        "job_count": len(rows),
        "jobs": rows,
        "passed": True,
        "production_eligible": False,
        "machine_output_released": False,
        "direct_machine_transfer": False,
    }
    report["report_hash"] = stable_sha256({k: v for k, v in report.items() if k != "report_hash"})
    return report


__all__ = [name for name in globals() if not name.startswith("_")]
