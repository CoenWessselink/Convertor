"""Project-bound orchestration and persistence for Scribing M3 marks."""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from .marking_contracts import (
    MANUFACTURING_MARK_STATE_SCHEMA_VERSION,
    ManufacturingMark,
    ManufacturingRuleSet,
    RuleValidationStatus,
    default_scribing_ruleset,
    validate_mark_set,
)
from .marking_engine import (
    SCRIBING_ENGINE_SCHEMA_VERSION,
    SCRIBING_ENGINE_VERSION,
    ScribingGenerationReport,
    ScribingMarkEngine,
    marking_source_snapshot,
    marking_source_snapshot_hash,
)
from .marking_validator import MARK_VALIDATOR_VERSION, IndependentManufacturingMarkValidator


def register_ruleset(project: ProjectModel, ruleset: ManufacturingRuleSet, *, user: str = "system", replace: bool = False) -> ManufacturingRuleSet:
    existing = project.manufacturing_rulesets.get(ruleset.ruleset_id)
    if existing and not replace:
        restored = ManufacturingRuleSet.from_dict(existing)
        if restored.ruleset_hash != ruleset.ruleset_hash:
            raise ProjectValidationError(f"Ruleset {ruleset.ruleset_id} bestaat al met andere inhoud")
        return restored
    before = str(existing.get("ruleset_hash") or "") if isinstance(existing, dict) else ""
    project.manufacturing_rulesets[ruleset.ruleset_id] = ruleset.to_dict()
    project.audit(
        "manufacturing_ruleset.registered",
        user=user or "system",
        entity_id=ruleset.ruleset_id,
        before_hash=before,
        after_hash=ruleset.ruleset_hash,
        details={"validation_status": ruleset.validation_status, "version": ruleset.version},
    )
    # Rule replacement makes every mark state that references the same rule stale.
    if existing and before != ruleset.ruleset_hash:
        for assembly_id, state in project.manufacturing_mark_states.items():
            if isinstance(state, dict) and str(state.get("ruleset_id") or "") == ruleset.ruleset_id and str(state.get("status") or "") in {"current", "review"}:
                state["status"] = "stale"
                state["stale_reason"] = "ruleset_changed"
                state["stale_at"] = utc_now_iso()
    return ruleset


def ensure_default_ruleset(project: ProjectModel, *, user: str = "system") -> ManufacturingRuleSet:
    ruleset = default_scribing_ruleset()
    return register_ruleset(project, ruleset, user=user, replace=False)


def load_ruleset(project: ProjectModel, ruleset_id: str) -> ManufacturingRuleSet:
    raw = project.manufacturing_rulesets.get(ruleset_id)
    if not isinstance(raw, dict):
        raise ProjectValidationError(f"Onbekende ManufacturingRuleSet {ruleset_id}")
    return ManufacturingRuleSet.from_dict(raw)


def load_assembly_marks(project: ProjectModel, assembly_id: str) -> list[ManufacturingMark]:
    state = dict(project.manufacturing_mark_states.get(assembly_id) or {})
    ids = [str(x) for x in state.get("mark_ids") or []]
    return [ManufacturingMark.from_dict(project.manufacturing_marks[mid]) for mid in ids if mid in project.manufacturing_marks]


def validate_persisted_mark_state(project: ProjectModel, assembly_id: str, *, require_current: bool = False) -> dict[str, Any]:
    state = dict(project.manufacturing_mark_states.get(assembly_id) or {})
    if not state:
        return {"status": "not_generated", "mark_count": 0, "current": False}
    if str(state.get("schema_version") or "") != MANUFACTURING_MARK_STATE_SCHEMA_VERSION:
        raise ProjectValidationError(f"Assembly {assembly_id} heeft onbekend ManufacturingMark state-schema")
    if str(state.get("engine_schema_version") or "") != SCRIBING_ENGINE_SCHEMA_VERSION:
        raise ProjectValidationError(f"Assembly {assembly_id} heeft onbekend scribing-engine-schema")
    if str(state.get("phase") or "") == "M4":
        from .reference_identification import M4_ENGINE_SCHEMA_VERSION
        if str(state.get("phase4_engine_schema_version") or "") != M4_ENGINE_SCHEMA_VERSION:
            raise ProjectValidationError(f"Assembly {assembly_id} heeft onbekend M4 reference/identification-schema")
    if str(state.get("assembly_id") or "") != assembly_id:
        raise ProjectValidationError("ManufacturingMark state verwijst naar verkeerde assembly")
    status = str(state.get("status") or "")
    if status not in {"current", "review", "blocked", "stale"}:
        raise ProjectValidationError(f"Onbekende ManufacturingMark state-status {status!r}")
    ruleset_id = str(state.get("ruleset_id") or "")
    ruleset = load_ruleset(project, ruleset_id)
    state_ruleset_hash = str(state.get("ruleset_hash") or "")
    ruleset_changed = state_ruleset_hash != ruleset.ruleset_hash
    if ruleset_changed and status in {"current", "review"}:
        raise ProjectValidationError(f"ManufacturingMark state van {assembly_id} gebruikt gewijzigde ruleset")
    ids = [str(x) for x in state.get("mark_ids") or []]
    missing = [mid for mid in ids if mid not in project.manufacturing_marks]
    if missing:
        raise ProjectValidationError(f"ManufacturingMark state van {assembly_id} verwijst naar ontbrekende marks: {missing}")
    marks = [ManufacturingMark.from_dict(project.manufacturing_marks[mid]) for mid in ids]
    # A stale set remains audit-valid against the ruleset hash it was created
    # with, even after that ruleset ID has deliberately been replaced.
    actual_set_hash = validate_mark_set(assembly_id, state_ruleset_hash, marks)
    if actual_set_hash != str(state.get("mark_set_hash") or ""):
        raise ProjectValidationError(f"ManufacturingMark set hash ongeldig voor assembly {assembly_id}")
    try:
        if ruleset_changed:
            current_source_hash = ""
        elif str(state.get("phase") or "") == "M4":
            from .reference_identification import m4_source_snapshot_hash
            current_source_hash = m4_source_snapshot_hash(project, assembly_id, ruleset)
        else:
            current_source_hash = marking_source_snapshot_hash(project, assembly_id, ruleset)
    except ProjectValidationError:
        current_source_hash = ""
    current = status in {"current", "review"} and not ruleset_changed and bool(current_source_hash) and current_source_hash == str(state.get("source_snapshot_hash") or "")
    if status in {"current", "review"} and not current:
        raise ProjectValidationError(f"ManufacturingMark state van {assembly_id} is actueel gemarkeerd maar broninputs zijn gewijzigd")
    if require_current and not current:
        raise ProjectValidationError(f"ManufacturingMark state van {assembly_id} is niet actueel")
    validation = dict(state.get("validation") or {})
    if validation:
        report_hash = str(validation.get("report_hash") or "")
        payload = dict(validation); payload.pop("report_hash", None)
        if report_hash and stable_sha256(payload) != report_hash:
            raise ProjectValidationError(f"ManufacturingMark validation report hash ongeldig voor assembly {assembly_id}")
    return {
        "status": status,
        "mark_count": len(marks),
        "mark_set_hash": actual_set_hash,
        "source_snapshot_hash": current_source_hash,
        "ruleset_id": ruleset_id,
        "ruleset_hash": state_ruleset_hash,
        "current_ruleset_hash": ruleset.ruleset_hash,
        "current": current,
        "proof_status": str(state.get("proof_status") or ""),
        "phase": str(state.get("phase") or "M3"),
        "scribe_mark_count": len(state.get("scribe_mark_ids") or []),
        "hole_reference_mark_count": len(state.get("hole_reference_mark_ids") or []),
        "identification_mark_count": len(state.get("identification_mark_ids") or []),
        "issues": list(state.get("issues") or []),
        "suppressions": list(state.get("suppressions") or []),
        "validation": validation,
    }


def invalidate_marks_for_assembly(project: ProjectModel, assembly_id: str, *, reason: str = "source_changed") -> bool:
    state = project.manufacturing_mark_states.get(assembly_id)
    if not isinstance(state, dict) or str(state.get("status") or "") not in {"current", "review"}:
        return False
    state["status"] = "stale"
    state["stale_reason"] = reason
    state["stale_at"] = utc_now_iso()
    return True


def invalidate_marks_for_part(project: ProjectModel, part_id: str, *, reason: str = "part_changed") -> list[str]:
    out=[]
    for assembly_id, assembly in project.assemblies.items():
        if part_id in assembly.part_ids and invalidate_marks_for_assembly(project, assembly_id, reason=reason):
            out.append(assembly_id)
    return out


def refresh_mark_staleness(project: ProjectModel, *, reason: str = "mark_source_snapshot_changed") -> list[str]:
    stale=[]
    for assembly_id, state in project.manufacturing_mark_states.items():
        if not isinstance(state,dict) or str(state.get("status") or "") not in {"current","review"}:
            continue
        try:
            ruleset=load_ruleset(project,str(state.get("ruleset_id") or ""))
            if str(state.get("phase") or "") == "M4":
                from .reference_identification import m4_source_snapshot_hash
                actual=m4_source_snapshot_hash(project,assembly_id,ruleset)
            else:
                actual=marking_source_snapshot_hash(project,assembly_id,ruleset)
        except Exception:
            actual=""
        if actual and actual==str(state.get("source_snapshot_hash") or ""):
            continue
        state["status"]="stale";state["stale_reason"]=reason;state["stale_at"]=utc_now_iso();stale.append(assembly_id)
    return stale


def remove_assembly_marks(project: ProjectModel, assembly_id: str) -> None:
    state=dict(project.manufacturing_mark_states.get(assembly_id) or {})
    for mark_id in list(state.get("mark_ids") or []):project.manufacturing_marks.pop(str(mark_id),None)
    project.manufacturing_mark_states.pop(assembly_id,None)


class ScribingMarkService:
    def __init__(self, engine: ScribingMarkEngine | None = None, validator: IndependentManufacturingMarkValidator | None = None) -> None:
        self.engine=engine or ScribingMarkEngine();self.validator=validator or IndependentManufacturingMarkValidator()

    def generate_assembly(self, project: ProjectModel, assembly_id: str, *, ruleset_id: str | None = None, user: str = "system", persist: bool = True) -> ScribingGenerationReport:
        ruleset = load_ruleset(project, ruleset_id) if ruleset_id else ensure_default_ruleset(project, user=user)
        if ruleset.validation_status != RuleValidationStatus.VALIDATED.value:
            raise ProjectValidationError("CWS-MARK-013 ruleset not validated")
        report=self.engine.generate(project,assembly_id,ruleset)
        validation=self.validator.validate(project,assembly_id,ruleset,report.marks)
        if report.marks and validation.status!="passed":
            raise ProjectValidationError(
                f"Onafhankelijke ManufacturingMark-validatie faalde voor assembly {assembly_id}: "
                + "; ".join(item.message for item in validation.issues if item.blocking)
            )
        if persist:
            previous=deepcopy(project.manufacturing_mark_states.get(assembly_id) or {})
            remove_assembly_marks(project,assembly_id)
            for mark in report.marks:project.manufacturing_marks[mark.mark_id]=mark.to_dict()
            blockers=[issue for issue in report.issues if issue.blocking]
            status="current" if report.marks and not blockers else ("review" if report.marks else "blocked")
            state={
                "schema_version":MANUFACTURING_MARK_STATE_SCHEMA_VERSION,
                "engine_schema_version":SCRIBING_ENGINE_SCHEMA_VERSION,
                "engine_version":SCRIBING_ENGINE_VERSION,
                "validator_version":MARK_VALIDATOR_VERSION,
                "assembly_id":assembly_id,
                "status":status,
                "proof_status":report.proof_status,
                "ruleset_id":ruleset.ruleset_id,
                "ruleset_hash":ruleset.ruleset_hash,
                "mark_ids":[m.mark_id for m in report.marks],
                "mark_set_hash":report.mark_set_hash,
                "source_snapshot_hash":report.source_snapshot_hash,
                "source_snapshot":marking_source_snapshot(project,assembly_id,ruleset),
                "raw_candidate_count":report.raw_candidate_count,
                "normalized_count":report.normalized_count,
                "accepted_count":len(report.marks),
                "issues":[issue.to_dict() for issue in report.issues],
                "suppressions":[item.to_dict() for item in report.suppressions],
                "validation":validation.to_dict(),
                "generated_at":utc_now_iso(),
                "generated_by":user or "system",
                "machine_output_released":False,
                "dstv_si_released":False,
            }
            project.manufacturing_mark_states[assembly_id]=state
            validate_persisted_mark_state(project,assembly_id)
            # M5 capability proofs are bound to the exact mark-set hash.  Keep
            # historical evidence, but explicitly stale it whenever M3 writes a
            # replacement canonical mark set.
            try:
                from .machine_marking_service import invalidate_machine_marking_evaluations
                invalidate_machine_marking_evaluations(project, assembly_id=assembly_id, reason="canonical_mark_set_changed", user=user or "system")
            except ImportError:  # pragma: no cover - older project schema compatibility
                pass
            project.audit(
                "manufacturing_marks.generated",user=user or "system",entity_id=assembly_id,
                before_hash=str(previous.get("mark_set_hash") or ""),after_hash=report.mark_set_hash,
                details={"ruleset_id":ruleset.ruleset_id,"ruleset_hash":ruleset.ruleset_hash,"mark_count":len(report.marks),"suppression_count":len(report.suppressions),"proof_status":report.proof_status,"validation_status":validation.status,"machine_output_released":False,"dstv_si_released":False},
            )
        return report

    def current_marks(self,project:ProjectModel,assembly_id:str,*,require_current=True)->list[ManufacturingMark]:
        validate_persisted_mark_state(project,assembly_id,require_current=require_current)
        return load_assembly_marks(project,assembly_id)


class MarkValidationService:
    """Read-only service facade for independent ManufacturingMark validation.

    M3 deliberately keeps generation and validation as separate named service
    surfaces so GUI/CLI/future jobs can never treat generated geometry as proof.
    """

    def __init__(self, validator: IndependentManufacturingMarkValidator | None = None) -> None:
        self.validator = validator or IndependentManufacturingMarkValidator()

    def validate_assembly(
        self,
        project: ProjectModel,
        assembly_id: str,
        *,
        ruleset_id: str | None = None,
        require_current: bool = True,
    ):
        state = validate_persisted_mark_state(project, assembly_id, require_current=require_current)
        effective_ruleset_id = ruleset_id or str(state.get("ruleset_id") or "")
        ruleset = load_ruleset(project, effective_ruleset_id)
        marks = load_assembly_marks(project, assembly_id)
        if str(state.get("phase") or "") == "M4":
            from .reference_identification import SCRIBE_TYPES, HOLE_TYPES, TEXT_TYPES
            from .reference_identification_validator import IndependentM4MarkValidator
            scribe = [mark for mark in marks if mark.mark_type in SCRIBE_TYPES]
            m4 = [mark for mark in marks if mark.mark_type in HOLE_TYPES or mark.mark_type in TEXT_TYPES]
            m3_report = self.validator.validate(project, assembly_id, ruleset, scribe)
            m4_report = IndependentM4MarkValidator().validate(project, assembly_id, ruleset, m4, existing_scribe_marks=scribe)
            persisted_generation_issues = [dict(item) for item in state.get("issues") or [] if isinstance(item, dict)]
            persisted_blockers = [item for item in persisted_generation_issues if bool(item.get("blocking", True))]
            class CombinedReport:
                status = "passed" if m3_report.status == "passed" and m4_report.status == "passed" and not persisted_blockers else "failed"
                def to_dict(self):
                    payload = {
                        "schema_version":"cws-combined-mark-validation-v1",
                        "status":self.status,
                        "m3":m3_report.to_dict(),
                        "m4":m4_report.to_dict(),
                        "generation_issues":persisted_generation_issues,
                        "issues":[*m3_report.to_dict().get("issues",[]),*m4_report.to_dict().get("issues",[]),*persisted_generation_issues],
                    }
                    payload["report_hash"] = stable_sha256(payload)
                    return payload
            return CombinedReport()
        return self.validator.validate(project, assembly_id, ruleset, marks)


# Explicit architectural name requested by the Manufacturing Faces / Scribing
# superprompt.  This aliases the same deterministic implementation rather than
# introducing a second generation path.
MarkGenerationService = ScribingMarkService


__all__=[
    "ScribingMarkService","MarkGenerationService","MarkValidationService","register_ruleset","ensure_default_ruleset","load_ruleset","load_assembly_marks",
    "validate_persisted_mark_state","invalidate_marks_for_assembly","invalidate_marks_for_part","refresh_mark_staleness","remove_assembly_marks",
]
