"""M11 production-marking release gate.

M1-M10 prove deterministic software behaviour.  M11 deliberately adds the
external evidence boundary required before CWS may claim that public DSTV
marking output is production-released for one exact machine/capability/source
commit.  The gate never enables proprietary controller output or direct machine
transfer; those remain separate validated-adapter concerns.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path, PurePosixPath
import json
import re
from typing import Any, Iterable, Mapping

from cws_convertor.product import APP_VERSION
from cws_convertor.project.model import ProjectModel, ProjectValidationError, stable_sha256, utc_now_iso
from cws_convertor.production_export.utils import sha256_file
from .dstv_marking_adapter import DstvMarkingAdapter, validate_persisted_dstv_roundtrip
from .machine_marking_service import load_machine_marking_capability

M11_RELEASE_GATE_SCHEMA_VERSION = "1.0"
M11_RELEASE_RECORD_SCHEMA_VERSION = "1.0"
M11_WINDOWS_EVIDENCE_SCHEMA_VERSION = "1.0"
M11_OWNER_MACHINE_EVIDENCE_SCHEMA_VERSION = "1.0"
M11_RELEASE_RECORD_HASH_VERSION = "cws-scribing-production-release-v1"

REQUIRED_OWNER_CASE_TYPES = {
    "straight_attached_part",
    "miter_marking",
    "plate_hole_reference",
    "mirrored_identification",
    "flange_web_marking",
    "dstv_downstream_interpretation",
}
PUBLIC_DSTV_MARKING_BLOCKS = {"SI", "KO", "PU", "BO"}
_SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
_GIT_COMMIT_RE = re.compile(r"^(?:[0-9a-fA-F]{40}|[0-9a-fA-F]{64})$")


@dataclass(frozen=True)
class ScribingReleaseCheck:
    check_id: str
    status: str  # passed | blocked | warning
    message: str
    details: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"check_id": self.check_id, "status": self.status, "message": self.message, "details": dict(self.details)}


@dataclass
class ScribingReleaseGate:
    product_version: str
    expected_source_commit: str
    project_id: str
    machine_id: str
    capability_id: str
    capability_hash: str
    selected_part_ids: tuple[str, ...]
    required_dstv_blocks: tuple[str, ...]
    checks: list[ScribingReleaseCheck]
    production_marking_released: bool
    machine_output_released: bool = False
    direct_machine_transfer: bool = False
    generated_at: str = field(default_factory=utc_now_iso)
    schema_version: str = M11_RELEASE_GATE_SCHEMA_VERSION
    report_hash: str = ""

    def refresh_hash(self) -> str:
        payload = self.to_dict(include_hash=False)
        payload.pop("generated_at", None)
        self.report_hash = stable_sha256(payload)
        return self.report_hash

    def to_dict(self, *, include_hash: bool = True) -> dict[str, Any]:
        payload = {
            "schema_version": self.schema_version,
            "product_version": self.product_version,
            "expected_source_commit": self.expected_source_commit,
            "project_id": self.project_id,
            "machine_id": self.machine_id,
            "capability_id": self.capability_id,
            "capability_hash": self.capability_hash,
            "selected_part_ids": list(self.selected_part_ids),
            "required_dstv_blocks": list(self.required_dstv_blocks),
            "checks": [x.to_dict() for x in self.checks],
            "production_marking_released": bool(self.production_marking_released),
            "machine_output_released": bool(self.machine_output_released),
            "direct_machine_transfer": bool(self.direct_machine_transfer),
            "generated_at": self.generated_at,
        }
        if include_hash:
            payload["report_hash"] = self.report_hash
        return payload


@dataclass(frozen=True)
class ScribingProductionReleaseRecord:
    release_id: str
    project_id: str
    product_version: str
    source_commit: str
    machine_id: str
    capability_id: str
    capability_hash: str
    part_manufacturing_hashes: Mapping[str, str]
    roundtrip_state_hashes: Mapping[str, str]
    required_dstv_blocks: tuple[str, ...]
    windows_evidence_sha256: str
    owner_evidence_sha256: str
    owner_approval_sha256: str
    gate_report_hash: str
    released_by: str
    released_at: str
    production_marking_released: bool
    machine_output_released: bool = False
    direct_machine_transfer: bool = False
    record_hash: str = ""
    schema_version: str = M11_RELEASE_RECORD_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != M11_RELEASE_RECORD_SCHEMA_VERSION:
            raise ProjectValidationError(f"Onbekende toekomstige M11 release-record schema-versie {self.schema_version!r}")
        if not self.release_id or not self.project_id or not self.machine_id or not self.capability_id:
            raise ProjectValidationError("M11 release-record mist identiteit")
        if not self.release_id.startswith("mrel-"):
            raise ProjectValidationError("M11 release-record heeft ongeldige release_id")
        if not self.product_version or not _valid_commit(self.source_commit):
            raise ProjectValidationError("M11 release-record mist productversie of volledige source_commit")
        if not self.released_by or not self.released_at:
            raise ProjectValidationError("M11 release-record mist released_by/released_at")
        if not _SHA256_RE.fullmatch(self.capability_hash or ""):
            raise ProjectValidationError("M11 release-record mist geldige capability_hash")
        for label, value in (
            ("windows_evidence_sha256", self.windows_evidence_sha256),
            ("owner_evidence_sha256", self.owner_evidence_sha256),
            ("owner_approval_sha256", self.owner_approval_sha256),
            ("gate_report_hash", self.gate_report_hash),
        ):
            if not _SHA256_RE.fullmatch(str(value or "")):
                raise ProjectValidationError(f"M11 release-record mist geldige {label}")
        if self.machine_output_released or self.direct_machine_transfer:
            raise ProjectValidationError("M11 standaard-DSTV release-record mag geen proprietary machineoutput/direct transfer vrijgeven")
        if not self.production_marking_released:
            raise ProjectValidationError("M11 release-record mag alleen voor daadwerkelijk gepasseerde production marking worden opgeslagen")
        if not self.part_manufacturing_hashes or not self.roundtrip_state_hashes:
            raise ProjectValidationError("M11 release-record mist project/roundtrip binding")
        if any(not _SHA256_RE.fullmatch(str(v or "")) for v in self.part_manufacturing_hashes.values()):
            raise ProjectValidationError("M11 release-record bevat ongeldige part manufacturing hash")
        if any(not _SHA256_RE.fullmatch(str(v or "")) for v in self.roundtrip_state_hashes.values()):
            raise ProjectValidationError("M11 release-record bevat ongeldige roundtrip state hash")
        blocks = tuple(sorted(set(str(x).upper() for x in self.required_dstv_blocks if str(x).strip())))
        if not blocks or not set(blocks).issubset(PUBLIC_DSTV_MARKING_BLOCKS):
            raise ProjectValidationError("M11 release-record bevat ongeldige DSTV marking scope")
        object.__setattr__(self, "required_dstv_blocks", blocks)
        expected = stable_sha256(self.hash_payload())
        if self.record_hash and self.record_hash != expected:
            raise ProjectValidationError("M11 release-record hash klopt niet")
        object.__setattr__(self, "record_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": M11_RELEASE_RECORD_HASH_VERSION,
            "schema_version": self.schema_version,
            "release_id": self.release_id,
            "project_id": self.project_id,
            "product_version": self.product_version,
            "source_commit": self.source_commit,
            "machine_id": self.machine_id,
            "capability_id": self.capability_id,
            "capability_hash": self.capability_hash,
            "part_manufacturing_hashes": dict(sorted(self.part_manufacturing_hashes.items())),
            "roundtrip_state_hashes": dict(sorted(self.roundtrip_state_hashes.items())),
            "required_dstv_blocks": list(self.required_dstv_blocks),
            "windows_evidence_sha256": self.windows_evidence_sha256,
            "owner_evidence_sha256": self.owner_evidence_sha256,
            "owner_approval_sha256": self.owner_approval_sha256,
            "gate_report_hash": self.gate_report_hash,
            "released_by": self.released_by,
            "released_at": self.released_at,
            "production_marking_released": bool(self.production_marking_released),
            "machine_output_released": False,
            "direct_machine_transfer": False,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "record_hash": self.record_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ScribingProductionReleaseRecord":
        return cls(
            release_id=str(value.get("release_id") or ""),
            project_id=str(value.get("project_id") or ""),
            product_version=str(value.get("product_version") or ""),
            source_commit=str(value.get("source_commit") or ""),
            machine_id=str(value.get("machine_id") or ""),
            capability_id=str(value.get("capability_id") or ""),
            capability_hash=str(value.get("capability_hash") or ""),
            part_manufacturing_hashes={str(k): str(v) for k, v in dict(value.get("part_manufacturing_hashes") or {}).items()},
            roundtrip_state_hashes={str(k): str(v) for k, v in dict(value.get("roundtrip_state_hashes") or {}).items()},
            required_dstv_blocks=tuple(str(x) for x in value.get("required_dstv_blocks") or []),
            windows_evidence_sha256=str(value.get("windows_evidence_sha256") or ""),
            owner_evidence_sha256=str(value.get("owner_evidence_sha256") or ""),
            owner_approval_sha256=str(value.get("owner_approval_sha256") or ""),
            gate_report_hash=str(value.get("gate_report_hash") or ""),
            released_by=str(value.get("released_by") or ""),
            released_at=str(value.get("released_at") or ""),
            production_marking_released=bool(value.get("production_marking_released")),
            machine_output_released=bool(value.get("machine_output_released")),
            direct_machine_transfer=bool(value.get("direct_machine_transfer")),
            record_hash=str(value.get("record_hash") or ""),
            schema_version=str(value.get("schema_version") or M11_RELEASE_RECORD_SCHEMA_VERSION),
        )


def _load_context(value: Mapping[str, Any] | str | Path | None) -> tuple[dict[str, Any] | None, Path | None, str]:
    if value is None:
        return None, None, ""
    if isinstance(value, Mapping):
        payload = dict(value)
        root = payload.pop("evidence_root", None)
        digest = stable_sha256(payload)
        return payload, Path(root).expanduser().resolve() if root else None, digest
    path = Path(value).expanduser().resolve()
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload, path.parent, sha256_file(path).lower()


def _resolve_evidence_path(root: Path | None, relative_path: str) -> Path | None:
    if root is None or not relative_path:
        return None
    pure = PurePosixPath(str(relative_path).replace("\\", "/"))
    if pure.is_absolute() or ".." in pure.parts:
        return None
    candidate = root.joinpath(*pure.parts).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError:
        return None
    return candidate


def _verify_artifact(ref: Any, root: Path | None, label: str) -> tuple[bool, str, dict[str, Any]]:
    item = dict(ref or {}) if isinstance(ref, Mapping) else {}
    rel = str(item.get("path") or "")
    expected = str(item.get("sha256") or "").lower()
    if not rel:
        return False, f"{label}: artefactpad ontbreekt", {}
    if not _SHA256_RE.fullmatch(expected):
        return False, f"{label}: geldige SHA-256 ontbreekt", {"path": rel}
    path = _resolve_evidence_path(root, rel)
    if path is None:
        return False, f"{label}: bewijsroot/pad is ongeldig of ontbreekt", {"path": rel}
    if not path.is_file():
        return False, f"{label}: bewijsbestand bestaat niet: {rel}", {"path": rel}
    actual = sha256_file(path).lower()
    if actual != expected:
        return False, f"{label}: SHA-256 mismatch voor {rel}", {"path": rel, "expected": expected, "actual": actual}
    return True, "", {"path": rel, "sha256": actual, "size_bytes": path.stat().st_size}


def _valid_commit(value: str) -> bool:
    # M11 evidence is release evidence, so abbreviated Git SHAs are not
    # accepted. Support both current SHA-1 repositories and SHA-256 repos.
    text = str(value or "").strip()
    return bool(_GIT_COMMIT_RE.fullmatch(text))


def validate_m11_windows_evidence(
    value: Mapping[str, Any] | str | Path | None,
    *,
    expected_source_commit: str = "",
) -> ScribingReleaseCheck:
    payload, root, digest = _load_context(value)
    if not payload:
        return ScribingReleaseCheck("windows_x64", "blocked", "M11 clean-Windows-x64 scribing evidence ontbreekt")
    errors: list[str] = []
    verified: dict[str, Any] = {}
    if str(payload.get("schema_version") or "") != M11_WINDOWS_EVIDENCE_SCHEMA_VERSION:
        errors.append("onbekende M11 Windows-evidence schema-versie")
    if str(payload.get("product_version") or "") != APP_VERSION:
        errors.append("M11 Windows-evidence hoort niet bij de actuele applicatieversie")
    commit = str(payload.get("source_commit") or "")
    if not _valid_commit(commit):
        errors.append("M11 Windows-evidence mist concrete source_commit")
    if expected_source_commit and commit != expected_source_commit:
        errors.append("M11 Windows-evidence source_commit wijkt af van verwachte commit")
    if str(payload.get("platform") or "").lower() not in {"windows-x64", "windows_amd64", "windows-amd64"}:
        errors.append("M11 Windows-evidence is niet expliciet Windows x64")
    if str(payload.get("status") or "") != "passed":
        errors.append("M11 Windows-evidence status is niet passed")
    if payload.get("python_required") is not False:
        errors.append("M11 packaged runtime is niet bewezen Python-onafhankelijk")
    matrix = dict(payload.get("matrix") or {})
    for key in ("source", "dist", "portable", "installed", "installer", "uninstall"):
        if str(matrix.get(key) or "") != "passed":
            errors.append(f"M11 Windows matrix {key} is niet passed")
    scribing_matrix = dict(payload.get("scribing_matrix") or {})
    for key in ("source", "dist", "portable", "installed"):
        if str(scribing_matrix.get(key) or "") != "passed":
            errors.append(f"M11 scribing packaged matrix {key} is niet passed")
    artifacts = dict(payload.get("artifacts") or {})
    required = {
        "installer", "portable", "gui_exe", "cli_exe",
        "source_scribing_smoke", "dist_scribing_smoke", "portable_scribing_smoke", "installed_scribing_smoke", "uninstall_log",
    }
    for key in sorted(required):
        ok, message, details = _verify_artifact(artifacts.get(key), root, f"M11 Windows {key}")
        if ok:
            verified[key] = details
        else:
            errors.append(message)
    for key in ("source_scribing_smoke", "dist_scribing_smoke", "portable_scribing_smoke", "installed_scribing_smoke"):
        ref = artifacts.get(key)
        path = _resolve_evidence_path(root, str(dict(ref or {}).get("path") or "")) if isinstance(ref, Mapping) else None
        if path and path.is_file():
            try:
                smoke = json.loads(path.read_text(encoding="utf-8"))
                if str(smoke.get("status") or "") != "passed" or str(smoke.get("product_version") or "") != APP_VERSION:
                    errors.append(f"{key} is geen passed scribing smoke voor actuele productversie")
                if not bool(smoke.get("marking_validation_passed")):
                    errors.append(f"{key} mist passed canonical marking validation")
                if not bool(smoke.get("export_preflight_passed")):
                    errors.append(f"{key} mist passed M8 export preflight")
                if not bool(smoke.get("dstv_roundtrip_verified")):
                    errors.append(f"{key} mist verified DSTV marking roundtrip")
                if not bool(smoke.get("dstv_geometry_preserved")):
                    errors.append(f"{key} mist bewezen behoud van basisgeometrie")
                if bool(smoke.get("production_marking_released")) or bool(smoke.get("machine_output_released")) or bool(smoke.get("direct_machine_transfer")):
                    errors.append(f"{key} claimt ten onrechte production/machine release")
            except Exception:
                errors.append(f"{key} is geen geldig JSON-evidencebestand")
    return ScribingReleaseCheck(
        "windows_x64",
        "passed" if not errors else "blocked",
        "M11 clean-Windows-x64 scribing poort geslaagd" if not errors else "; ".join(errors),
        {"source_commit": commit, "evidence_sha256": digest, "verified_artifacts": verified},
    )


def validate_m11_owner_machine_evidence(
    value: Mapping[str, Any] | str | Path | None,
    *,
    expected_source_commit: str = "",
    machine_id: str = "",
    capability_id: str = "",
    capability_hash: str = "",
    required_dstv_blocks: Iterable[str] = (),
) -> ScribingReleaseCheck:
    payload, root, digest = _load_context(value)
    if not payload:
        return ScribingReleaseCheck("owner_machine", "blocked", "M11 owner/machine praktijkvalidatie ontbreekt")
    errors: list[str] = []
    verified_cases: list[dict[str, Any]] = []
    if str(payload.get("schema_version") or "") != M11_OWNER_MACHINE_EVIDENCE_SCHEMA_VERSION:
        errors.append("onbekende M11 owner/machine schema-versie")
    if str(payload.get("product_version") or "") != APP_VERSION:
        errors.append("M11 owner-evidence hoort niet bij actuele applicatieversie")
    commit = str(payload.get("source_commit") or "")
    if not _valid_commit(commit):
        errors.append("M11 owner-evidence mist concrete source_commit")
    if expected_source_commit and commit != expected_source_commit:
        errors.append("M11 owner-evidence source_commit wijkt af van verwachte commit")
    if str(payload.get("status") or "") != "passed":
        errors.append("M11 owner-evidence status is niet passed")
    machine = dict(payload.get("machine") or {})
    for key in ("machine_id", "machine_model", "controller", "controller_version", "downstream_software", "downstream_version", "capability_id", "capability_hash"):
        if not str(machine.get(key) or "").strip():
            errors.append(f"M11 machine-identiteit mist {key}")
    if machine_id and str(machine.get("machine_id") or "") != machine_id:
        errors.append("M11 owner-evidence hoort bij andere machine_id")
    if capability_id and str(machine.get("capability_id") or "") != capability_id:
        errors.append("M11 owner-evidence hoort bij andere capability_id")
    if capability_hash and str(machine.get("capability_hash") or "") != capability_hash:
        errors.append("M11 owner-evidence capability_hash wijkt af")
    blocks = {str(x).upper() for x in machine.get("validated_dstv_blocks") or []}
    if not blocks or not blocks.issubset(PUBLIC_DSTV_MARKING_BLOCKS):
        errors.append("M11 owner-evidence validated_dstv_blocks is leeg/ongeldig")
    required_blocks = {str(x).upper() for x in required_dstv_blocks if str(x).strip()}
    if not required_blocks.issubset(blocks):
        errors.append(f"M11 owner-evidence dekt niet alle vereiste DSTV blocks: {sorted(required_blocks - blocks)}")
    approval_ok, approval_message, approval_details = _verify_artifact(payload.get("approval_artifact"), root, "M11 owner approval")
    if not approval_ok:
        errors.append(approval_message)
    cases = [dict(x) for x in payload.get("cases") or [] if isinstance(x, Mapping)]
    approved_types = {
        str(c.get("case_type") or "")
        for c in cases
        if str(c.get("status") or "") == "passed" and bool(c.get("owner_approved"))
    }
    missing = sorted(REQUIRED_OWNER_CASE_TYPES - approved_types)
    if missing:
        errors.append(f"M11 verplichte owner cases ontbreken: {', '.join(missing)}")
    case_ids = [str(c.get("case_id") or "") for c in cases if str(c.get("case_type") or "") in REQUIRED_OWNER_CASE_TYPES]
    case_types = [str(c.get("case_type") or "") for c in cases if str(c.get("case_type") or "") in REQUIRED_OWNER_CASE_TYPES]
    if len(case_ids) != len(set(case_ids)):
        errors.append("M11 owner-evidence bevat dubbele case_id")
    if len(case_types) != len(set(case_types)):
        errors.append("M11 owner-evidence bevat dubbele verplichte case_type")
    for case in cases:
        case_id = str(case.get("case_id") or "")
        ctype = str(case.get("case_type") or "")
        if ctype not in REQUIRED_OWNER_CASE_TYPES:
            continue
        if not case_id:
            errors.append(f"M11 case {ctype} mist case_id")
            continue
        if str(case.get("status") or "") != "passed" or not bool(case.get("owner_approved")):
            errors.append(f"M11 case {case_id} is niet passed + owner_approved")
        if not str(case.get("approved_by") or "") or not str(case.get("approved_at") or ""):
            errors.append(f"M11 case {case_id} mist approved_by/approved_at")
        if str(case.get("machine_id") or "") != str(machine.get("machine_id") or ""):
            errors.append(f"M11 case {case_id} machine_id mismatch")
        artifacts = dict(case.get("artifacts") or {})
        verified_artifacts: dict[str, Any] = {}
        for key in ("input_model", "input_nc1", "expected_output", "actual_output", "comparison"):
            ok, message, details = _verify_artifact(artifacts.get(key), root, f"M11 case {case_id} {key}")
            if ok:
                verified_artifacts[key] = details
            else:
                errors.append(message)
        comparison_ref = artifacts.get("comparison")
        comparison_path = _resolve_evidence_path(root, str(dict(comparison_ref or {}).get("path") or "")) if isinstance(comparison_ref, Mapping) else None
        if comparison_path and comparison_path.is_file():
            try:
                comparison = json.loads(comparison_path.read_text(encoding="utf-8"))
                if str(comparison.get("status") or "") != "passed":
                    errors.append(f"M11 case {case_id} comparison status is niet passed")
                if str(comparison.get("case_id") or "") != case_id:
                    errors.append(f"M11 case {case_id} comparison verwijst naar andere case")
                if comparison.get("semantic_compare") is not True:
                    errors.append(f"M11 case {case_id} comparison mist semantic_compare=true")
            except Exception:
                errors.append(f"M11 case {case_id} comparison is geen geldig JSON")
        verified_cases.append({"case_id": case_id, "case_type": ctype, "artifacts": verified_artifacts})
    return ScribingReleaseCheck(
        "owner_machine",
        "passed" if not errors else "blocked",
        "M11 owner/machine praktijkpoort geslaagd" if not errors else "; ".join(errors),
        {
            "source_commit": commit,
            "evidence_sha256": digest,
            "machine_id": machine.get("machine_id", ""),
            "capability_id": machine.get("capability_id", ""),
            "capability_hash": machine.get("capability_hash", ""),
            "validated_dstv_blocks": sorted(blocks),
            "approval": approval_details,
            "verified_cases": verified_cases,
        },
    )


def _selected_marked_parts(project: ProjectModel, part_ids: Iterable[str] | None = None) -> tuple[str, ...]:
    requested = {str(x) for x in (part_ids or []) if str(x)}
    marked = {
        str(raw.get("target_part_id") or raw.get("part_id") or "")
        for raw in project.manufacturing_marks.values()
        if isinstance(raw, Mapping) and str(raw.get("review_status") or "") not in {"suppressed", "blocked"}
    }
    marked.discard("")
    selected = (requested & marked) if requested else marked
    return tuple(sorted(x for x in selected if x in project.parts))


def validate_m11_project_readiness(
    project: ProjectModel,
    capability_id: str,
    *,
    part_ids: Iterable[str] | None = None,
    require_roundtrip_files: bool = True,
) -> ScribingReleaseCheck:
    errors: list[str] = []
    details: dict[str, Any] = {"part_ids": [], "roundtrip_ids": [], "required_dstv_blocks": []}
    try:
        capability = load_machine_marking_capability(project, capability_id, require_current=True)
    except Exception as exc:
        return ScribingReleaseCheck("project_readiness", "blocked", f"M11 machine capability niet current/valide: {exc}")
    if not capability.enabled or capability.validation_status != "validated":
        errors.append("M11 capability is niet enabled + validated")
    selected = _selected_marked_parts(project, part_ids)
    if not selected:
        errors.append("M11 project bevat geen geselecteerde accepted/current marking parts")
    roundtrip_ids: list[str] = []
    blocks: set[str] = set()
    adapter = DstvMarkingAdapter()
    for pid in selected:
        part = project.parts[pid]
        try:
            records = adapter.records_for_part(project, pid)
            blocks.update(x.block for x in records)
        except Exception as exc:
            errors.append(f"part {pid}: DSTV mapping/records niet current: {exc}")
            continue
        candidates: list[tuple[str, dict[str, Any]]] = []
        for artifact_id, raw in project.manufacturing_dstv_roundtrips.items():
            if isinstance(raw, Mapping) and str(raw.get("part_id") or "") == pid:
                candidates.append((str(artifact_id), dict(raw)))
        valid = False
        for artifact_id, _ in sorted(candidates, reverse=True):
            try:
                validate_persisted_dstv_roundtrip(project, artifact_id, require_current=True, require_file=require_roundtrip_files)
                roundtrip_ids.append(artifact_id)
                valid = True
                break
            except Exception:
                continue
        if not valid:
            errors.append(f"part {pid}: geen current verified M9 roundtrip met fysiek artefact")
        if not _SHA256_RE.fullmatch(str(part.manufacturing_hash or "")):
            errors.append(f"part {pid}: manufacturing_hash ontbreekt/ongeldig")
    if not blocks:
        errors.append("M11 project heeft geen representabele DSTV marking blocks")
    if not blocks.issubset(PUBLIC_DSTV_MARKING_BLOCKS):
        errors.append(f"M11 project vraagt niet-vrijgegeven DSTV marking blocks: {sorted(blocks-PUBLIC_DSTV_MARKING_BLOCKS)}")
    details.update({
        "part_ids": list(selected),
        "roundtrip_ids": roundtrip_ids,
        "required_dstv_blocks": sorted(blocks),
        "machine_id": capability.machine_id,
        "capability_id": capability.capability_id,
        "capability_hash": capability.capability_hash,
    })
    return ScribingReleaseCheck(
        "project_readiness",
        "passed" if not errors else "blocked",
        "M11 project/M9/capability readiness geslaagd" if not errors else "; ".join(errors),
        details,
    )


def evaluate_scribing_release_gate(
    project: ProjectModel,
    capability_id: str,
    *,
    windows_evidence: Mapping[str, Any] | str | Path | None = None,
    owner_evidence: Mapping[str, Any] | str | Path | None = None,
    expected_source_commit: str = "",
    part_ids: Iterable[str] | None = None,
    require_roundtrip_files: bool = True,
) -> ScribingReleaseGate:
    readiness = validate_m11_project_readiness(project, capability_id, part_ids=part_ids, require_roundtrip_files=require_roundtrip_files)
    machine_id = str(readiness.details.get("machine_id") or "")
    capability_hash = str(readiness.details.get("capability_hash") or "")
    required_blocks = tuple(str(x) for x in readiness.details.get("required_dstv_blocks") or [])
    selected = tuple(str(x) for x in readiness.details.get("part_ids") or [])
    windows = validate_m11_windows_evidence(windows_evidence, expected_source_commit=expected_source_commit)
    owner = validate_m11_owner_machine_evidence(
        owner_evidence,
        expected_source_commit=expected_source_commit,
        machine_id=machine_id,
        capability_id=capability_id,
        capability_hash=capability_hash,
        required_dstv_blocks=required_blocks,
    )
    commit_check = ScribingReleaseCheck("source_commit", "blocked", "M11 source_commit ontbreekt")
    if _valid_commit(expected_source_commit):
        wcommit = str(windows.details.get("source_commit") or "")
        ocommit = str(owner.details.get("source_commit") or "")
        if wcommit == expected_source_commit and ocommit == expected_source_commit:
            commit_check = ScribingReleaseCheck("source_commit", "passed", "Windows/owner evidence is aan exact dezelfde source_commit gebonden", {"source_commit": expected_source_commit})
        else:
            commit_check = ScribingReleaseCheck("source_commit", "blocked", "Windows/owner evidence is niet aan exact dezelfde source_commit gebonden", {"expected": expected_source_commit, "windows": wcommit, "owner": ocommit})
    checks = [readiness, windows, owner, commit_check]
    released = all(x.status == "passed" for x in checks)
    gate = ScribingReleaseGate(
        product_version=APP_VERSION,
        expected_source_commit=expected_source_commit,
        project_id=project.project_id,
        machine_id=machine_id,
        capability_id=capability_id,
        capability_hash=capability_hash,
        selected_part_ids=selected,
        required_dstv_blocks=tuple(sorted(set(required_blocks))),
        checks=checks,
        production_marking_released=released,
        machine_output_released=False,
        direct_machine_transfer=False,
    )
    gate.refresh_hash()
    return gate


def _evidence_digest(value: Mapping[str, Any] | str | Path | None) -> str:
    _, _, digest = _load_context(value)
    return digest


def persist_scribing_release_gate(
    project: ProjectModel,
    gate: ScribingReleaseGate,
    *,
    windows_evidence: Mapping[str, Any] | str | Path,
    owner_evidence: Mapping[str, Any] | str | Path,
    user: str,
) -> ScribingProductionReleaseRecord:
    if not gate.production_marking_released or any(x.status != "passed" for x in gate.checks):
        raise ProjectValidationError("CWS-MARK-020 M11 production marking release blijft geblokkeerd")
    # Re-evaluate the exact evidence at write time. This closes a TOCTOU gap
    # where a caller could evaluate one evidence set and persist a changed one.
    live_gate = evaluate_scribing_release_gate(
        project, gate.capability_id, windows_evidence=windows_evidence, owner_evidence=owner_evidence,
        expected_source_commit=gate.expected_source_commit, part_ids=gate.selected_part_ids,
        require_roundtrip_files=True,
    )
    if not live_gate.production_marking_released or any(x.status != "passed" for x in live_gate.checks):
        raise ProjectValidationError("CWS-MARK-020 M11 evidence is gewijzigd/ongeldig bij persistence")
    if live_gate.report_hash != gate.report_hash:
        raise ProjectValidationError("CWS-MARK-020 M11 gate/evidence snapshot is gewijzigd vóór persistence")
    gate = live_gate
    readiness = next((x for x in gate.checks if x.check_id == "project_readiness"), None)
    owner = next((x for x in gate.checks if x.check_id == "owner_machine"), None)
    if readiness is None or owner is None:
        raise ProjectValidationError("M11 gate mist readiness/owner bewijs")
    part_hashes = {pid: project.parts[pid].manufacturing_hash for pid in gate.selected_part_ids}
    rt_hashes: dict[str, str] = {}
    for artifact_id in readiness.details.get("roundtrip_ids") or []:
        raw = project.manufacturing_dstv_roundtrips.get(str(artifact_id))
        if isinstance(raw, Mapping):
            rt_hashes[str(artifact_id)] = str(raw.get("state_hash") or "")
    approval_sha = str(dict(owner.details.get("approval") or {}).get("sha256") or "")
    release_seed = {
        "project_id": project.project_id,
        "machine_id": gate.machine_id,
        "capability_hash": gate.capability_hash,
        "source_commit": gate.expected_source_commit,
        "part_hashes": part_hashes,
        "roundtrip_state_hashes": rt_hashes,
        "gate_report_hash": gate.report_hash,
    }
    release_id = "mrel-" + stable_sha256(release_seed)[:24]
    record = ScribingProductionReleaseRecord(
        release_id=release_id,
        project_id=project.project_id,
        product_version=APP_VERSION,
        source_commit=gate.expected_source_commit,
        machine_id=gate.machine_id,
        capability_id=gate.capability_id,
        capability_hash=gate.capability_hash,
        part_manufacturing_hashes=part_hashes,
        roundtrip_state_hashes=rt_hashes,
        required_dstv_blocks=gate.required_dstv_blocks,
        windows_evidence_sha256=_evidence_digest(windows_evidence),
        owner_evidence_sha256=_evidence_digest(owner_evidence),
        owner_approval_sha256=approval_sha,
        gate_report_hash=gate.report_hash,
        released_by=str(user or "m11"),
        released_at=utc_now_iso(),
        production_marking_released=True,
        machine_output_released=False,
        direct_machine_transfer=False,
    )
    project.manufacturing_release_records[record.release_id] = record.to_dict()
    project.audit(
        "manufacturing.scribing.production_marking_released",
        user=user or "m11",
        entity_id=record.release_id,
        after_hash=record.record_hash,
        details={"machine_id": record.machine_id, "capability_id": record.capability_id, "source_commit": record.source_commit},
    )
    return record


def validate_persisted_scribing_release_record(
    project: ProjectModel,
    release_id: str,
    *,
    require_current: bool = True,
    part_ids: Iterable[str] | None = None,
    capability_id: str = "",
) -> dict[str, Any]:
    raw = project.manufacturing_release_records.get(release_id)
    if not isinstance(raw, Mapping):
        raise ProjectValidationError(f"Onbekend M11 scribing release-record {release_id}")
    record = ScribingProductionReleaseRecord.from_dict(raw)
    if record.release_id != release_id:
        raise ProjectValidationError(f"M11 release-opslagsleutel {release_id} wijkt af van record-ID {record.release_id}")
    if dict(raw) != record.to_dict():
        raise ProjectValidationError(f"M11 release {release_id} bevat niet-canonical/tampered velden")
    if record.project_id != project.project_id:
        raise ProjectValidationError(f"M11 release {release_id} hoort bij ander project")
    if require_current:
        if record.product_version != APP_VERSION:
            raise ProjectValidationError(f"M11 release {release_id} hoort bij andere softwareversie")
        if capability_id and record.capability_id != capability_id:
            raise ProjectValidationError(f"M11 release {release_id} hoort bij andere capability")
        capability = load_machine_marking_capability(project, record.capability_id, require_current=True)
        if capability.capability_hash != record.capability_hash or capability.machine_id != record.machine_id:
            raise ProjectValidationError(f"M11 release {release_id} capability/machine is stale")
        requested = {str(x) for x in (part_ids or []) if str(x)}
        if requested and not requested.issubset(set(record.part_manufacturing_hashes)):
            raise ProjectValidationError(f"M11 release {release_id} dekt niet alle gevraagde parts")
        for pid, expected in record.part_manufacturing_hashes.items():
            part = project.parts.get(pid)
            if part is None or str(part.manufacturing_hash or "") != expected:
                raise ProjectValidationError(f"M11 release {release_id} is stale door part {pid}")
        for artifact_id, expected_state_hash in record.roundtrip_state_hashes.items():
            state = validate_persisted_dstv_roundtrip(project, artifact_id, require_current=True, require_file=False)
            if str(state.get("state_hash") or "") != expected_state_hash:
                raise ProjectValidationError(f"M11 release {release_id} roundtrip {artifact_id} is gewijzigd")
    return record.to_dict()


def current_scribing_release(
    project: ProjectModel,
    *,
    part_ids: Iterable[str] | None = None,
    capability_id: str = "",
) -> dict[str, Any] | None:
    candidates = sorted(
        (dict(raw) for raw in project.manufacturing_release_records.values() if isinstance(raw, Mapping)),
        key=lambda x: (str(x.get("released_at") or ""), str(x.get("release_id") or "")),
        reverse=True,
    )
    for raw in candidates:
        rid = str(raw.get("release_id") or "")
        try:
            return validate_persisted_scribing_release_record(project, rid, require_current=True, part_ids=part_ids, capability_id=capability_id)
        except Exception:
            continue
    return None


def scribing_release_manifest_state(
    project: ProjectModel,
    *,
    part_ids: Iterable[str] | None = None,
    capability_id: str = "",
) -> dict[str, Any]:
    record = current_scribing_release(project, part_ids=part_ids, capability_id=capability_id)
    if not record:
        return {
            "m11_release_id": "",
            "production_marking_released": False,
            "machine_output_released": False,
            "direct_machine_transfer": False,
        }
    return {
        "m11_release_id": str(record.get("release_id") or ""),
        "m11_release_record_hash": str(record.get("record_hash") or ""),
        "m11_machine_id": str(record.get("machine_id") or ""),
        "m11_capability_id": str(record.get("capability_id") or ""),
        "m11_source_commit": str(record.get("source_commit") or ""),
        "production_marking_released": True,
        "machine_output_released": False,
        "direct_machine_transfer": False,
    }


__all__ = [name for name in globals() if not name.startswith("_")]
