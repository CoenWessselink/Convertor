"""Controller-neutral Manufacturing Sequence contracts for Scribing M7.

M7 converts validated M6 nesting-aware mark bindings and the immutable profile
nesting plan into an explicit operation DAG.  It remains machine/controller
neutral: no DSTV SI, proprietary syntax or direct machine transfer is permitted.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from cws_convertor.project.model import ProjectValidationError, stable_sha256

MANUFACTURING_SEQUENCE_SCHEMA_VERSION = "1.0"
MANUFACTURING_SEQUENCE_STATE_SCHEMA_VERSION = "1.0"
MANUFACTURING_SEQUENCE_VALIDATION_SCHEMA_VERSION = "1.0"
MANUFACTURING_SEQUENCE_NEUTRAL_JOB_SCHEMA_VERSION = "2.0"
SEQUENCE_HASH_VERSION = "cws-manufacturing-sequence-v1"
SEQUENCE_OPERATION_HASH_VERSION = "cws-manufacturing-sequence-operation-v1"
SEQUENCE_DEPENDENCY_HASH_VERSION = "cws-manufacturing-sequence-dependency-v1"


class SequenceOperationType(str, Enum):
    LOAD_BAR = "load_bar"
    CLAMP = "clamp"
    REORIENT = "reorient"
    RECLAMP = "reclamp"
    SCRIBE = "scribe"
    IDENTIFY = "identify"
    HOLE_REFERENCE = "hole_reference"
    POP_MARK = "pop_mark"
    CENTER_PUNCH = "center_punch"
    DRILL = "drill"
    SAW_START = "saw_start"
    SAW_END = "saw_end"
    COMMON_CUT = "common_cut"
    SEVER_PIECE = "sever_piece"
    UNLOAD_PIECE = "unload_piece"
    UNLOAD_BAR = "unload_bar"


@dataclass(frozen=True)
class ManufacturingSequenceIssue:
    code: str
    message: str
    blocking: bool = True
    severity: str = "error"
    operation_id: str = ""
    bar_id: str = ""
    piece_instance_id: str = ""
    mark_id: str = ""
    suggested_remediation: str = ""
    provenance: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code, "message": self.message, "blocking": bool(self.blocking),
            "severity": self.severity, "operation_id": self.operation_id, "bar_id": self.bar_id,
            "piece_instance_id": self.piece_instance_id, "mark_id": self.mark_id,
            "suggested_remediation": self.suggested_remediation, "provenance": dict(self.provenance),
        }


@dataclass(frozen=True)
class SequenceOperation:
    operation_id: str
    operation_type: str
    machine_id: str
    bar_id: str
    piece_instance_id: str = ""
    part_id: str = ""
    part_position: str = ""
    binding_id: str = ""
    mark_id: str = ""
    feature_id: str = ""
    transition_id: str = ""
    face_id: str = ""
    tool_id: str = ""
    position_mm: float | None = None
    sequence_group: str = ""
    estimated_seconds: float = 0.0
    feasible: bool = True
    parameters: Mapping[str, Any] = field(default_factory=dict)
    provenance: Mapping[str, Any] = field(default_factory=dict)
    operation_hash: str = ""

    def __post_init__(self) -> None:
        if not self.operation_id or not self.operation_type or not self.machine_id or not self.bar_id:
            raise ProjectValidationError("M7 operation mist verplichte identiteit")
        if self.operation_type not in {x.value for x in SequenceOperationType}:
            raise ProjectValidationError(f"Onbekend M7 operation_type {self.operation_type!r}")
        if float(self.estimated_seconds) < 0:
            raise ProjectValidationError("M7 estimated_seconds kan niet negatief zijn")
        expected = stable_sha256(self.hash_payload())
        if self.operation_hash and self.operation_hash != expected:
            raise ProjectValidationError(f"M7 operation {self.operation_id} heeft ongeldige hash")
        object.__setattr__(self, "operation_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": SEQUENCE_OPERATION_HASH_VERSION,
            "operation_id": self.operation_id, "operation_type": self.operation_type,
            "machine_id": self.machine_id, "bar_id": self.bar_id,
            "piece_instance_id": self.piece_instance_id, "part_id": self.part_id,
            "part_position": self.part_position, "binding_id": self.binding_id,
            "mark_id": self.mark_id, "feature_id": self.feature_id,
            "transition_id": self.transition_id, "face_id": self.face_id, "tool_id": self.tool_id,
            "position_mm": self.position_mm, "sequence_group": self.sequence_group,
            "estimated_seconds": float(self.estimated_seconds), "feasible": bool(self.feasible),
            "parameters": dict(self.parameters), "provenance": dict(self.provenance),
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "operation_hash": self.operation_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SequenceOperation":
        return cls(
            operation_id=str(value.get("operation_id") or ""), operation_type=str(value.get("operation_type") or ""),
            machine_id=str(value.get("machine_id") or ""), bar_id=str(value.get("bar_id") or ""),
            piece_instance_id=str(value.get("piece_instance_id") or ""), part_id=str(value.get("part_id") or ""),
            part_position=str(value.get("part_position") or ""), binding_id=str(value.get("binding_id") or ""),
            mark_id=str(value.get("mark_id") or ""), feature_id=str(value.get("feature_id") or ""),
            transition_id=str(value.get("transition_id") or ""), face_id=str(value.get("face_id") or ""),
            tool_id=str(value.get("tool_id") or ""), position_mm=(None if value.get("position_mm") is None else float(value.get("position_mm"))),
            sequence_group=str(value.get("sequence_group") or ""), estimated_seconds=float(value.get("estimated_seconds") or 0.0),
            feasible=bool(value.get("feasible", True)), parameters=dict(value.get("parameters") or {}),
            provenance=dict(value.get("provenance") or {}), operation_hash=str(value.get("operation_hash") or ""),
        )


@dataclass(frozen=True)
class SequenceDependency:
    predecessor_id: str
    successor_id: str
    reason: str
    source_ref: str = ""
    dependency_hash: str = ""

    def __post_init__(self) -> None:
        if not self.predecessor_id or not self.successor_id or self.predecessor_id == self.successor_id:
            raise ProjectValidationError("Ongeldige M7 dependency")
        expected = stable_sha256(self.hash_payload())
        if self.dependency_hash and self.dependency_hash != expected:
            raise ProjectValidationError("M7 dependency hash ongeldig")
        object.__setattr__(self, "dependency_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {"hash_version": SEQUENCE_DEPENDENCY_HASH_VERSION, "predecessor_id": self.predecessor_id,
                "successor_id": self.successor_id, "reason": self.reason, "source_ref": self.source_ref}

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "dependency_hash": self.dependency_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SequenceDependency":
        return cls(str(value.get("predecessor_id") or ""), str(value.get("successor_id") or ""),
                   str(value.get("reason") or ""), str(value.get("source_ref") or ""), str(value.get("dependency_hash") or ""))


@dataclass(frozen=True)
class ManufacturingSequencePlan:
    sequence_id: str
    run_id: str
    assembly_id: str
    capability_id: str
    binding_set_id: str
    machine_id: str
    operations: tuple[SequenceOperation, ...]
    dependencies: tuple[SequenceDependency, ...]
    linearized_operation_ids: tuple[str, ...]
    feasible: bool
    review_required: bool
    issues: tuple[ManufacturingSequenceIssue, ...]
    source_snapshot_hash: str
    plan_hash: str
    m6_state_hash: str
    estimated_total_seconds: float = 0.0
    requires_m8_scope: bool = True
    dstv_si_released: bool = False
    machine_output_released: bool = False
    direct_machine_transfer: bool = False
    sequence_hash: str = ""
    schema_version: str = MANUFACTURING_SEQUENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != MANUFACTURING_SEQUENCE_SCHEMA_VERSION:
            raise ProjectValidationError(f"Onbekend toekomstig M7 sequence schema {self.schema_version!r}")
        if self.dstv_si_released or self.machine_output_released or self.direct_machine_transfer:
            raise ProjectValidationError("M7 mag geen DSTV SI/machine-output/directe transfer vrijgeven")
        op_ids = [x.operation_id for x in self.operations]
        if len(op_ids) != len(set(op_ids)):
            raise ProjectValidationError("M7 sequence bevat dubbele operation IDs")
        if set(self.linearized_operation_ids) != set(op_ids) or len(self.linearized_operation_ids) != len(op_ids):
            raise ProjectValidationError("M7 linearization bevat niet exact alle operations")
        expected = stable_sha256(self.hash_payload())
        if self.sequence_hash and self.sequence_hash != expected:
            raise ProjectValidationError("M7 sequence_hash ongeldig")
        object.__setattr__(self, "sequence_hash", expected)

    def hash_payload(self) -> dict[str, Any]:
        return {
            "hash_version": SEQUENCE_HASH_VERSION, "schema_version": self.schema_version,
            "sequence_id": self.sequence_id, "run_id": self.run_id, "assembly_id": self.assembly_id,
            "capability_id": self.capability_id, "binding_set_id": self.binding_set_id,
            "machine_id": self.machine_id, "operations": [x.to_dict() for x in self.operations],
            "dependencies": [x.to_dict() for x in self.dependencies],
            "linearized_operation_ids": list(self.linearized_operation_ids), "feasible": bool(self.feasible),
            "review_required": bool(self.review_required), "issues": [x.to_dict() for x in self.issues],
            "source_snapshot_hash": self.source_snapshot_hash, "plan_hash": self.plan_hash,
            "m6_state_hash": self.m6_state_hash, "estimated_total_seconds": float(self.estimated_total_seconds),
            "requires_m8_scope": bool(self.requires_m8_scope), "dstv_si_released": False,
            "machine_output_released": False, "direct_machine_transfer": False,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.hash_payload(), "sequence_hash": self.sequence_hash}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ManufacturingSequencePlan":
        return cls(
            sequence_id=str(value.get("sequence_id") or ""), run_id=str(value.get("run_id") or ""),
            assembly_id=str(value.get("assembly_id") or ""), capability_id=str(value.get("capability_id") or ""),
            binding_set_id=str(value.get("binding_set_id") or ""), machine_id=str(value.get("machine_id") or ""),
            operations=tuple(SequenceOperation.from_dict(x) for x in value.get("operations") or []),
            dependencies=tuple(SequenceDependency.from_dict(x) for x in value.get("dependencies") or []),
            linearized_operation_ids=tuple(str(x) for x in value.get("linearized_operation_ids") or []),
            feasible=bool(value.get("feasible", False)), review_required=bool(value.get("review_required", False)),
            issues=tuple(ManufacturingSequenceIssue(**dict(x)) for x in value.get("issues") or []),
            source_snapshot_hash=str(value.get("source_snapshot_hash") or ""), plan_hash=str(value.get("plan_hash") or ""),
            m6_state_hash=str(value.get("m6_state_hash") or ""), estimated_total_seconds=float(value.get("estimated_total_seconds") or 0.0),
            requires_m8_scope=bool(value.get("requires_m8_scope", True)), dstv_si_released=bool(value.get("dstv_si_released", False)),
            machine_output_released=bool(value.get("machine_output_released", False)), direct_machine_transfer=bool(value.get("direct_machine_transfer", False)),
            sequence_hash=str(value.get("sequence_hash") or ""), schema_version=str(value.get("schema_version") or MANUFACTURING_SEQUENCE_SCHEMA_VERSION),
        )


@dataclass
class ManufacturingSequenceValidationReport:
    status: str
    sequence_id: str
    source_snapshot_hash: str
    expected_operation_ids: list[str]
    issues: list[ManufacturingSequenceIssue] = field(default_factory=list)
    report_hash: str = ""
    schema_version: str = MANUFACTURING_SEQUENCE_VALIDATION_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        payload = {"schema_version": self.schema_version, "status": self.status, "sequence_id": self.sequence_id,
                   "source_snapshot_hash": self.source_snapshot_hash, "expected_operation_ids": list(self.expected_operation_ids),
                   "issues": [x.to_dict() for x in self.issues]}
        payload["report_hash"] = self.report_hash or stable_sha256(payload)
        return payload


__all__ = [name for name in globals() if not name.startswith("_")]
